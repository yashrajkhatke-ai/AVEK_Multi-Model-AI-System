# Avek — a fully customisable AI chat app (Android · Jetpack Compose)

Avek is the Android client of **AVEK**, your own agent harness running on a laptop. It talks to the
harness over the `avek-ui/2` protocol (`docs`: UI-WIRE spec) on your Wi-Fi: an encrypted WebSocket
(AVEK-SEC/1: ECDH P-256, HKDF-SHA256, AES-256-GCM) to `ws://<laptop>:7810/ui`. Chats and models live
on the PC; the phone keeps only the chats you download. A built-in **Demo mode** (Settings → Connection)
simulates a PC so the app can be shown without one.

| Chat | Live thinking | Depth bar | Themes |
|---|---|---|---|
| ![](docs/screenshots/01_chat_light.png) | ![](docs/screenshots/03_thinking_live.png) | ![](docs/screenshots/10_depth_levels.png) | ![](docs/screenshots/12_customize_themes.png) |

| Connection | Pairing | Asks | Tools |
|---|---|---|---|
| ![](docs/screenshots/52_connection_connected.png) | ![](docs/screenshots/55_pairing.png) | ![](docs/screenshots/45_ask_approval.png) | ![](docs/screenshots/43_tool_cards.png) |

More in [`docs/screenshots`](docs/screenshots).

## Pair with your PC

1. Phone and laptop on the same Wi-Fi (a phone hotspot works).
2. On the laptop: `bun run Avek_Harness/pair.ts`. It prints a 12-character code and the laptop's address.
3. In the app: Settings → **Connection** → **Pair a new PC**. Pick the PC found on Wi-Fi, or type
   the address (`192.168.x.x:7810`), type the code (dashes are added for you), keep or change the
   device name, tap **Pair**.
4. The app connects at once. Routes (last address, Wi-Fi discovery, typed addresses) are tried in
   parallel; edit their order on the Connection screen.
5. Optional: turn on **Work in background** to get questions (Allow / Deny) and answers as notifications
   while the app is closed.

Revoking on the laptop (`bun run Avek_Harness/pair.ts --revoke <deviceId>`) takes effect at once.

## Open & run

1. Unzip, then in Android Studio choose **File → Open** and select the `AvekChat` folder.
2. Let Gradle sync (it downloads Gradle 8.11.1 and the dependencies on first run).
3. Run the `app` configuration on a device or emulator (Android 8.0 / API 26+).

> Google Fonts are downloaded on demand through Google Play Services. On an emulator, use a
> system image **with Google Play**. Without Play Services the app still works and falls back
> to the built-in fonts.

Unit tests: `./gradlew testDebugUnitTest` (crypto vectors, handshake against a fake harness, paging, TTL, routes, view models).

## What's inside

**Chat**
- Claude-style transcript: user bubbles, full-width serif answers, Markdown (headings, lists,
  tables, quotes, citations, inline code), syntax-highlighted code blocks with copy and line numbers.
- Streaming replies with a live **thinking panel** (current step, elapsed timer, fading live preview),
  collapsible to "Thought for 12s". Research replies stream in **sources** as they are found.
- Stop, regenerate, edit & resend, copy, share, thumbs up/down. Auto-follow while streaming,
  jump-to-latest button when you scroll away.

**Models, tasks and thinking depth**
- 7 simulated models (Atlas, Nova, Flash, Forge, Sage, Muse, Lumen) with speed, intelligence,
  context and maximum reasoning depth.
- 8 task modes (General, Deep research, Coding, Writing, Analysis, Math, Brainstorm, Learn) plus
  **Auto**, which classifies every message — the composer shows the detected mode live as you type.
- **Thinking depth bar**: drag across 6 levels (Instant → Maximum). Each level has its own animated
  emblem, the track carries energy that speeds up with depth, Extended/Maximum throw sparks,
  levels a model can't reach are fenced off, and every notch ticks with haptics.

**History sidebar** (split 40 / 60)
- Upper 40%: custom menu glyph, compact search bar, New chat / Starred / Archived / Customize, profile.
- Lower 60%: one continuous, minimal list of chats (newest first) marked with small circles —
  filled for starred chats. Search covers titles *and* message content.
- Long-press to star, rename, archive or delete (with undo). Seeded with realistic sample chats.

**Soft-fading header**
- The conversation scrolls under a transparent top bar and dissolves into the background
  using an alpha-gradient mask (`BlendMode.DstIn` on an offscreen layer — the Compose
  equivalent of CSS `mask-image`), instead of being clipped by a hard line.

**Customisation studio** (live preview at the top reflects every change instantly)
- **Themes**: 36 hand-tuned themes + 1,728 generated combinations (24 accents × 6 neutral families ×
  4 bubble tones × 3 contrast levels), each with light and dark variants — **3,528 colour schemes**.
  All are unit-tested for readable contrast. System / Light / Dark, and "Surprise me".
- **Colors**: override any of 22 roles (chat background, top bar, user bubble, answer text,
  thinking panel, code, sidebar, composer, accent, thinking animation, …) with an HSV picker,
  hex input, colour harmonies and swatches. Light and dark keep separate overrides.
- **Fonts**: pick from the **1,892-family Google Fonts catalogue** independently for the interface,
  headings, your messages, the final answer, thinking and code. Size, weight, line height, letter
  spacing and italic per role, plus 11 one-tap font pairings.
- **Shapes**: global corner roundness (0–150%, from perfectly square to pillowy, with presets)
  and corner style — Rounded, Smooth (continuous, squircle-like) or Cut — applied to every
  surface: composer, cards, chips, menus, sheets, dialogs.
- **Chat**: 5 bubble styles, answer style (plain / card / bubble), corner radius, bubble width,
  alignment, density, avatars, model badge, timestamps, code line numbers.
- **Motion**: 10 thinking animations (Spark, Orbit, Pulse, Wave, Shimmer, Morph, Galaxy, Helix,
  Equalizer, Constellation), animation and streaming speed, message entrance animations,
  streaming cursor styles, reduce motion, haptics.

## Architecture

Single `:app` module organised by layer and feature, with clear boundaries so it can be split
into Gradle modules (`:core:*`, `:feature:*`) without moving code around.

```
com.avek.chat
├── core
│   ├── common          dispatchers, clock, ids, formatting
│   ├── model           pure Kotlin domain + settings models (kotlinx.serialization)
│   ├── domain          repository & engine contracts, use cases (send, stream reply, regenerate,
│   │                   edit, task classifier, title generator, history grouping)
│   ├── data            Room (conversations, messages), DataStore (settings JSON),
│   │                   font catalogue, simulated inference engine + demo seeder
│   ├── designsystem    theme engine (tokens, palettes, generator, typography, font resolver),
│   │                   motion (thinking indicators, depth glyphs, cursor, entrance), components
│   └── markdown        streaming-tolerant parser, renderer, syntax highlighter
├── feature
│   ├── chat            screen, ViewModel, composer, messages, pickers, welcome
│   ├── history         sidebar + ViewModel
│   ├── customize       studio, tabs, live preview, font pairings
│   └── settings
├── navigation          type-safe Navigation Compose graph
├── platform/android    Google Fonts provider, asset catalogue
└── di                  Hilt modules
```

- **UI**: Jetpack Compose + Material 3, unidirectional data flow, stateless screens fed by
  `StateFlow` UI state; every colour/type token comes from `AvekTheme`, never hard-coded.
- **State**: MVVM with Hilt-injected ViewModels; `combine`/`flatMapLatest` pipelines.
- **Persistence**: Room for history (with recovery of replies interrupted by process death),
  DataStore with a schema-tolerant JSON serializer for settings.
- **Tests**: JVM unit tests for the task router, title generator, history grouping, Markdown parser,
  font catalogue, the theme catalogue's contrast guarantees and the full send → think → stream →
  persist → stop pipeline (with an in-memory fake repository and virtual time).

### Plugging in a real model

Implement `core/domain/engine/InferenceEngine` (emit `ThinkingStep`, `ThinkingDelta`,
`SourceFound`, `AnswerDelta`, `Finished`) and change one line in `di/BindingsModule.kt`.
Everything else — streaming UI, persistence, stop/regenerate — already works against the contract.

## Tech

Kotlin 2.0.21 · AGP 8.7.3 · Gradle 8.11.1 · Compose BOM 2024.12.01 · Material 3 · Hilt 2.53.1 ·
Room 2.6.1 · DataStore 1.1.1 · Navigation 2.8.5 · kotlinx.serialization · Coroutines/Flow ·
compileSdk 35 · minSdk 26
