package com.avek.chat.core.data.remote

import com.avek.chat.core.domain.repository.ChatListQuery
import com.avek.chat.core.domain.repository.ChatRepository
import com.avek.chat.core.domain.repository.ChatTurns
import com.avek.chat.core.domain.repository.Page
import com.avek.chat.core.domain.repository.TurnMessages
import com.avek.chat.core.link.rpc.RpcException
import com.avek.chat.core.model.Conversation
import com.avek.chat.core.model.Feedback
import com.avek.chat.core.model.TaskMode
import com.avek.chat.core.model.ToolView

/**
 * Decides where chat data comes from: the PC when connected, otherwise the downloaded copy
 * (read only). Mutations always go to the PC and fail clearly when it is not reachable.
 */
class ChatSource(
    private val remote: ChatRepository,
    private val local: ChatRepository,
    private val isConnected: () -> Boolean,
    private val isDownloaded: suspend (String) -> Boolean,
) : ChatRepository {

    override suspend fun list(query: ChatListQuery, limit: Int, after: String?): Page<Conversation> =
        if (isConnected()) remote.list(query, limit, after) else local.list(query, limit, after)

    override suspend fun open(chatId: String, limit: Int, after: String?): ChatTurns =
        reading(chatId) { it.open(chatId, limit, after) }

    override suspend fun turn(chatId: String, promptId: String, withThinking: Boolean): TurnMessages =
        reading(chatId) { it.turn(chatId, promptId, withThinking) }

    override suspend fun tool(chatId: String, promptId: String, callId: String): ToolView =
        reading(chatId) { it.tool(chatId, promptId, callId) }

    override suspend fun setChat(chatId: String, title: String?, mode: TaskMode?, starred: Boolean?, archived: Boolean?, modelId: String?): Conversation =
        needsPc { remote.setChat(chatId, title, mode, starred, archived, modelId) }

    override suspend fun delete(chatId: String) = needsPc { remote.delete(chatId) }

    override suspend fun rewind(chatId: String, fromPromptId: String) = needsPc { remote.rewind(chatId, fromPromptId) }

    override suspend fun feedback(chatId: String, promptId: String, value: Feedback) =
        needsPc { remote.feedback(chatId, promptId, value) }

    /** Reads from the PC; falls back to the local copy if the PC just became unreachable. */
    private suspend fun <T> reading(chatId: String, block: suspend (ChatRepository) -> T): T {
        if (isConnected()) {
            try {
                return block(remote)
            } catch (e: RpcException) {
                val unreachable = e.code == RpcException.NOT_CONNECTED || e.code == RpcException.CONNECTION_LOST || e.code == RpcException.TIMEOUT
                if (!unreachable || !isDownloaded(chatId)) throw e
            }
        }
        if (isDownloaded(chatId)) return block(local)
        throw RpcException.notConnected()
    }

    private suspend fun <T> needsPc(block: suspend () -> T): T {
        if (!isConnected()) throw RpcException.notConnected()
        return block()
    }
}
