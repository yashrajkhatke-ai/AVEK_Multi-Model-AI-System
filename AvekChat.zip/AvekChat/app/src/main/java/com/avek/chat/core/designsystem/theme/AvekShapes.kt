package com.avek.chat.core.designsystem.theme

import androidx.compose.foundation.shape.CornerBasedShape
import androidx.compose.foundation.shape.CornerSize
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Shapes
import androidx.compose.runtime.Composable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.avek.chat.core.model.settings.CornerStyle
import com.avek.chat.core.model.settings.ShapeSettings

val LocalShapeSettings = staticCompositionLocalOf { ShapeSettings() }

/**
 * Builds a corner shape in the user's chosen style. Radii are given in the
 * component's *designed* size; [scale] applies the user's roundness.
 */
fun cornerShape(
    style: CornerStyle,
    topStart: Dp,
    topEnd: Dp,
    bottomEnd: Dp,
    bottomStart: Dp,
    scale: Float = 1f,
): CornerBasedShape {
    val s = scale.coerceAtLeast(0f)
    return when (style) {
        CornerStyle.ROUNDED -> RoundedCornerShape(topStart * s, topEnd * s, bottomEnd * s, bottomStart * s)
        // Chamfers read larger than arcs of the same size, so pull them in a little.
        CornerStyle.CUT -> CutCornerShape(topStart * s * 0.6f, topEnd * s * 0.6f, bottomEnd * s * 0.6f, bottomStart * s * 0.6f)
        CornerStyle.SMOOTH -> SmoothCornerShape(
            CornerSize(topStart * s),
            CornerSize(topEnd * s),
            CornerSize(bottomEnd * s),
            CornerSize(bottomStart * s),
        )
    }
}

/** A surface shape with the user's corner style and roundness applied. */
@Composable
@ReadOnlyComposable
fun avekShape(radius: Dp): CornerBasedShape = avekShape(radius, radius, radius, radius)

@Composable
@ReadOnlyComposable
fun avekShape(
    topStart: Dp = 0.dp,
    topEnd: Dp = 0.dp,
    bottomEnd: Dp = 0.dp,
    bottomStart: Dp = 0.dp,
    scaled: Boolean = true,
): CornerBasedShape {
    val settings = LocalShapeSettings.current
    return cornerShape(settings.style, topStart, topEnd, bottomEnd, bottomStart, if (scaled) settings.roundness else 1f)
}

/**
 * Shape for chips, pills and pill-buttons: a full capsule at the original
 * roundness, flattening toward a soft rectangle as roundness decreases.
 */
@Composable
@ReadOnlyComposable
fun avekPill(): CornerBasedShape {
    val settings = LocalShapeSettings.current
    return if (settings.roundness >= 1f) {
        cornerShape(settings.style, 999.dp, 999.dp, 999.dp, 999.dp)
    } else {
        val r = 22.dp * settings.roundness
        cornerShape(settings.style, r, r, r, r)
    }
}

fun materialShapes(settings: ShapeSettings): Shapes {
    fun c(r: Dp) = cornerShape(settings.style, r, r, r, r, settings.roundness)
    return Shapes(extraSmall = c(6.dp), small = c(10.dp), medium = c(14.dp), large = c(20.dp), extraLarge = c(28.dp))
}

/**
 * Continuous-curvature ("squircle-like") corners. Each corner's curve starts
 * further along the edge than a circular arc and its control points sit closer
 * to the corner, so the transition from straight edge to curve is gradual.
 */
class SmoothCornerShape(
    topStart: CornerSize,
    topEnd: CornerSize,
    bottomEnd: CornerSize,
    bottomStart: CornerSize,
) : CornerBasedShape(topStart, topEnd, bottomEnd, bottomStart) {

    override fun copy(topStart: CornerSize, topEnd: CornerSize, bottomEnd: CornerSize, bottomStart: CornerSize) =
        SmoothCornerShape(topStart, topEnd, bottomEnd, bottomStart)

    override fun createOutline(
        size: Size,
        topStart: Float,
        topEnd: Float,
        bottomEnd: Float,
        bottomStart: Float,
        layoutDirection: LayoutDirection,
    ): Outline {
        if (topStart + topEnd + bottomEnd + bottomStart == 0f) {
            return Outline.Rectangle(androidx.compose.ui.geometry.Rect(0f, 0f, size.width, size.height))
        }
        val ltr = layoutDirection == LayoutDirection.Ltr
        val tl = if (ltr) topStart else topEnd
        val tr = if (ltr) topEnd else topStart
        val br = if (ltr) bottomEnd else bottomStart
        val bl = if (ltr) bottomStart else bottomEnd
        val maxExtent = minOf(size.width, size.height) / 2f
        fun e(r: Float) = (r * SMOOTHING).coerceAtMost(maxExtent)
        val w = size.width
        val h = size.height
        val (a, b, c, d) = listOf(e(tl), e(tr), e(br), e(bl))
        val path = Path().apply {
            moveTo(a, 0f)
            lineTo(w - b, 0f)
            cubicTo(w - b * K, 0f, w, b * K, w, b)
            lineTo(w, h - c)
            cubicTo(w, h - c * K, w - c * K, h, w - c, h)
            lineTo(d, h)
            cubicTo(d * K, h, 0f, h - d * K, 0f, h - d)
            lineTo(0f, a)
            cubicTo(0f, a * K, a * K, 0f, a, 0f)
            close()
        }
        return Outline.Generic(path)
    }

    override fun equals(other: Any?): Boolean =
        other is SmoothCornerShape && topStart == other.topStart && topEnd == other.topEnd &&
            bottomEnd == other.bottomEnd && bottomStart == other.bottomStart

    override fun hashCode(): Int = listOf(topStart, topEnd, bottomEnd, bottomStart).hashCode()

    private companion object {
        /** How much further along the edge the curve begins, relative to a circular arc. */
        const val SMOOTHING = 1.35f

        /** Control-point position as a fraction of the curve extent (0.448 ≈ circle). */
        const val K = 0.24f
    }
}

