package com.avek.chat.feature.chat.components

import androidx.compose.animation.AnimatedContent
import com.avek.chat.core.designsystem.theme.avekShape
import com.avek.chat.core.designsystem.theme.avekPill
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowForward
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.avek.chat.core.designsystem.component.AvekSpark
import com.avek.chat.core.designsystem.icon.icon
import com.avek.chat.core.designsystem.theme.AvekTheme
import com.avek.chat.core.model.TaskMode
import java.time.LocalTime

private val Suggestions: Map<TaskMode, List<String>> = mapOf(
    TaskMode.CODING to listOf(
        "Write a Kotlin function that debounces search input with coroutines",
        "Review this approach for caching API responses offline",
        "Explain the difference between StateFlow and SharedFlow with examples",
    ),
    TaskMode.WRITING to listOf(
        "Draft a friendly note asking my landlord to fix the heating",
        "Rewrite my product description to sound warmer and more concise",
        "Write an opening paragraph for a short story set in a lighthouse",
    ),
    TaskMode.LEARN to listOf(
        "Explain how vaccines train the immune system",
        "What is the intuition behind Bayes' theorem?",
        "Teach me the basics of music theory in ten minutes",
    ),
    TaskMode.DEEP_RESEARCH to listOf(
        "Research the state of small modular nuclear reactors",
        "Compare evidence on standing desks and long-term health",
        "Investigate trends in urban vertical farming",
    ),
    TaskMode.BRAINSTORM to listOf(
        "Brainstorm names for a minimalist journaling app",
        "Come up with weekend ideas for a rainy day with kids",
        "Suggest creative themes for a team offsite",
    ),
    TaskMode.ANALYSIS to listOf(
        "Should I learn Rust or Go next? Analyze the trade-offs",
        "Analyze the pros and cons of leasing versus buying a car",
        "Evaluate a subscription vs one-time pricing model for my app",
    ),
)

@Composable
fun WelcomePane(
    profileName: String,
    onSuggestion: (String, TaskMode) -> Unit,
    modifier: Modifier = Modifier,
) {
    val colors = AvekTheme.colors
    val hour = remember { LocalTime.now().hour }
    val greeting = when (hour) {
        in 5..11 -> "Good morning"
        in 12..16 -> "Good afternoon"
        in 17..21 -> "Good evening"
        else -> "Hello, night owl"
    }
    var selected by rememberSaveable { mutableStateOf<TaskMode?>(null) }

    Column(
        modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Spacer(Modifier.height(48.dp))
        AvekSpark(colors.thinkingGlow, Modifier.size(46.dp), animated = !AvekTheme.motion.reduceMotion)
        Spacer(Modifier.height(18.dp))
        Text(
            if (profileName.isBlank()) greeting else "$greeting, $profileName",
            style = AvekTheme.type.display,
            color = colors.textPrimary,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(6.dp))
        Text(
            "What's on your mind today?",
            style = AvekTheme.type.body,
            color = colors.textSecondary,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(28.dp))

        Row(
            Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
        ) {
            Suggestions.keys.forEach { task ->
                val isSelected = task == selected
                Row(
                    Modifier
                        .clip(avekPill())
                        .background(if (isSelected) colors.accentContainer else colors.surface)
                        .border(1.dp, if (isSelected) colors.accent else colors.outline, avekPill())
                        .clickable { selected = if (isSelected) null else task }
                        .padding(horizontal = 14.dp, vertical = 9.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(task.icon, null, tint = if (isSelected) colors.accent else colors.textSecondary, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(task.label, style = AvekTheme.type.label, color = colors.textPrimary)
                }
            }
        }

        Spacer(Modifier.height(16.dp))
        AnimatedContent(
            targetState = selected,
            transitionSpec = { (fadeIn() + slideInVertically { it / 8 }) togetherWith fadeOut() },
            label = "suggestions",
        ) { task ->
            if (task != null) {
                Column(
                    Modifier
                        .fillMaxWidth()
                        .clip(avekShape(18.dp))
                        .background(colors.surface)
                        .border(1.dp, colors.outline.copy(alpha = 0.7f), avekShape(18.dp)),
                ) {
                    Suggestions.getValue(task).forEachIndexed { index, prompt ->
                        if (index > 0) HorizontalDivider(color = colors.outline.copy(alpha = 0.5f))
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clickable { onSuggestion(prompt, task) }
                                .padding(horizontal = 16.dp, vertical = 14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(prompt, style = AvekTheme.type.body, color = colors.textPrimary, modifier = Modifier.weight(1f))
                            Spacer(Modifier.width(8.dp))
                            Icon(Icons.AutoMirrored.Outlined.ArrowForward, null, tint = colors.textTertiary, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            } else {
                Spacer(Modifier.height(1.dp))
            }
        }
        Spacer(Modifier.height(32.dp))
    }
}
