package com.avek.chat.core.link.wire

import kotlinx.serialization.Serializable

// ---------------------------------------------------------------------- routes (section 8.9)

@Serializable
data class WifiAddressDto(val `interface`: String = "", val address: String = "")

@Serializable
data class WifiRoutesDto(
    val addresses: List<WifiAddressDto> = emptyList(),
    val port: Int = 7810,
    val knockPort: Int = 7811,
)

@Serializable
data class TailscaleRouteDto(
    val host: String = "",
    val dns: String? = null,
    val port: Int = 7810,
    val knockPort: Int = 7811,
)

@Serializable
data class NgrokRouteDto(
    val url: String = "",
    /** `starting` | `online` | `offline`. */
    val state: String = "",
    val error: String? = null,
)

/** The answer of `routes.get` and the data of `routes.changed`. */
@Serializable
data class RoutesData(
    val wifi: WifiRoutesDto = WifiRoutesDto(),
    val tailscale: TailscaleRouteDto? = null,
    val ngrok: NgrokRouteDto? = null,
    val updatedAt: String? = null,
) {
    /** The ngrok host for `wss://<host>/ui` (the `url` without scheme, path or port). */
    val ngrokHost: String?
        get() = ngrok?.url?.takeIf { it.isNotBlank() }
            ?.substringAfter("://")
            ?.substringBefore('/')
            ?.substringBefore('?')
            ?.takeIf { it.isNotBlank() }
}

// ---------------------------------------------------------------------- key rotation (section 4.1)

@Serializable
data class RekeyResultDto(val dk: String, val rk: String, val graceSec: Int = 600)

// ---------------------------------------------------------------------- waking (section 9)

@Serializable
data class WakingDto(val phase: String = "core", val since: String = "")

// ---------------------------------------------------------------------- load profiles (section 8.10)

@Serializable
data class HardwareGpuDto(val id: String = "", val name: String = "", val totalMb: Long = 0, val freeMb: Long = 0)

@Serializable
data class CpuDto(val threads: Int = 0, val ramTotalMb: Long = 0, val ramFreeMb: Long = 0)

@Serializable
data class HardwareData(val rtx: HardwareGpuDto? = null, val igpu: HardwareGpuDto? = null, val cpu: CpuDto = CpuDto())

@Serializable
data class LayersDto(val rtx: Int = 0, val igpu: Int = 0, val cpu: Int = 0)

@Serializable
data class ProfileLimitsDto(
    val minContext: Int = 4096,
    val maxContext: Int = 524_288,
    val maxSlots: Int = 8,
    val cacheTypes: List<String> = listOf("f16", "q8_0", "q4_0"),
)

@Serializable
data class MeasuredDto(val decodeTps: Double? = null, val at: String? = null)

@Serializable
data class EstimateDto(
    val rtxMb: Long? = null,
    val igpuMb: Long? = null,
    val cpuMb: Long? = null,
    /** `fits` | `tight` | `too-big` | `unknown`. */
    val verdict: String = "unknown",
    val notes: List<String> = emptyList(),
)

@Serializable
data class LoadProfileDto(
    val id: String,
    val modelId: String = "",
    val name: String = "",
    val builtin: Boolean = false,
    val layers: LayersDto = LayersDto(),
    val contextTokens: Int = 0,
    val slots: Int = 1,
    val cacheType: String? = null,
    val threads: Int? = null,
    val ubatch: Int? = null,
    val note: String? = null,
    val active: Boolean = false,
    val measured: MeasuredDto? = null,
    val estimate: EstimateDto? = null,
    val problems: List<String> = emptyList(),
)

@Serializable
data class ProfilesData(
    val modelId: String,
    val layersTotal: Int = 0,
    val activeId: String? = null,
    val hardware: HardwareData? = null,
    val limits: ProfileLimitsDto = ProfileLimitsDto(),
    val profiles: List<LoadProfileDto> = emptyList(),
)

@Serializable
data class ProfileSaveResultDto(val profile: LoadProfileDto)

@Serializable
data class ProfileApplyResultDto(val modelId: String = "", val activeId: String = "", val reloading: Boolean = false)

@Serializable
data class ProfilesChangedDto(val modelId: String, val activeId: String? = null, val change: String = "")

/** What the profile editor sends with `profile.save` ([id] only when editing one of your own). */
data class ProfileDraft(
    val id: String? = null,
    val name: String,
    val layers: LayersDto,
    val contextTokens: Int,
    val slots: Int,
    val cacheType: String,
    val note: String? = null,
)
