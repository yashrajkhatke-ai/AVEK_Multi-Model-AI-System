package com.avek.chat.core.link.discovery

import com.avek.chat.core.link.crypto.AvekProtocol
import com.avek.chat.core.link.crypto.SecureCrypto
import com.avek.chat.core.link.store.IdentityVault
import com.avek.chat.core.link.store.PairedPc
import com.avek.chat.core.link.transport.Datagram
import com.avek.chat.core.link.transport.HostPort
import com.avek.chat.core.link.transport.UdpSocket
import com.avek.chat.core.link.transport.UdpTransport
import com.avek.chat.core.link.wire.WireJson
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.longOrNull
import kotlinx.serialization.json.put
import java.security.SecureRandom

/**
 * When knocks go out (UI-WIRE v3 section 2): to the last address, 255.255.255.255 and the subnet
 * broadcast at once; the /24 sweep (batches, spaced) if nothing answered within 1.5 s; repeats at
 * 0, 1 s and 3 s; then a short wait for late answers.
 */
data class KnockSchedule(
    val repeatsAtMs: List<Long> = listOf(0L, 1_000L, 3_000L),
    val sweepAfterMs: Long = 1_500L,
    val sweepBatch: Int = 32,
    val sweepGapMs: Long = 150L,
    val finalWaitMs: Long = 2_000L,
)

/** Where to send a datagram: every target of one round, in order. */
object KnockTargets {
    const val PORT = 7811
    const val GLOBAL_BROADCAST = "255.255.255.255"

    fun direct(lastHost: String?, subnetBroadcast: String?): List<String> =
        listOfNotNull(lastHost, GLOBAL_BROADCAST, subnetBroadcast).distinct()
}

/** Shared mechanics of "send to these targets on this schedule and collect valid answers". */
internal suspend fun <T : Any> udpRound(
    transport: UdpTransport,
    schedule: KnockSchedule,
    lastHost: String?,
    stopAtFirst: Boolean,
    newDatagram: () -> Pair<ByteArray, ByteArray>, // (datagram bytes, nonce)
    accept: (Datagram, Set<String>) -> T?,
    onAnswer: (T) -> Unit = {},
): List<T> {
    val socket: UdpSocket = transport.open()
    val answers = mutableListOf<T>()
    val nonces = java.util.Collections.synchronizedSet(mutableSetOf<String>())
    try {
        coroutineScope {
            val first = CompletableDeferred<Unit>()
            val local = transport.localAddress()
            val direct = KnockTargets.direct(lastHost, local?.broadcast)

            val receiver = launch {
                while (isActive) {
                    val datagram = socket.receive(RECEIVE_POLL_MS) ?: continue
                    val answer = runCatching { accept(datagram, nonces.toSet()) }.getOrNull() ?: continue
                    synchronized(answers) { answers += answer }
                    onAnswer(answer)
                    first.complete(Unit)
                }
            }

            fun fresh(): ByteArray {
                val (bytes, nonce) = newDatagram()
                nonces += SecureCrypto.b64(nonce)
                return bytes
            }

            // Repeats on their own schedule (0, 1 s, 3 s), each with a fresh nonce.
            val sender = launch {
                var elapsed = 0L
                for (at in schedule.repeatsAtMs) {
                    if (at > elapsed) delay(at - elapsed)
                    elapsed = at
                    if (stopAtFirst && first.isCompleted) break
                    val bytes = fresh()
                    direct.forEach { runCatching { socket.send(it, KnockTargets.PORT, bytes) } }
                }
            }

            // Nothing answered within 1.5 s: every other host of the /24, in spaced batches (some hotspots drop broadcasts).
            val sweeper = launch {
                if (local == null) return@launch
                delay(schedule.sweepAfterMs)
                if (stopAtFirst && first.isCompleted) return@launch
                val bytes = fresh()
                for (batch in local.hostsOf24.filter { it !in direct }.chunked(schedule.sweepBatch)) {
                    if (stopAtFirst && first.isCompleted) break
                    batch.forEach { runCatching { socket.send(it, KnockTargets.PORT, bytes) } }
                    delay(schedule.sweepGapMs)
                }
            }

            if (stopAtFirst) {
                withTimeoutOrNull(schedule.repeatsAtMs.last() + schedule.finalWaitMs + SWEEP_ALLOWANCE_MS) { first.await() }
            } else {
                sender.join()
                sweeper.join()
                delay(schedule.finalWaitMs)
            }
            sender.cancel()
            sweeper.cancel()
            receiver.cancel()
        }
    } finally {
        socket.close()
    }
    return synchronized(answers) { answers.toList() }
}

private const val RECEIVE_POLL_MS = 200L
private const val SWEEP_ALLOWANCE_MS = 1_500L

/** A PC that answered a knock: where to open the WebSocket. */
data class KnockAnswer(val host: String, val port: Int) {
    val target: HostPort get() = HostPort(host, port)
}

/**
 * Knocks for the paired PC (section 2). Only a `here` answer whose `sid` is the paired PC's id,
 * whose `n` is one we sent and whose signature verifies with the pinned key is accepted; anything
 * else is ignored silently.
 */
class KnockClient(
    private val transport: UdpTransport,
    private val identity: IdentityVault,
    private val nowMs: () -> Long = System::currentTimeMillis,
    private val randomBytes: (Int) -> ByteArray = { n -> ByteArray(n).also(SecureRandom()::nextBytes) },
    private val schedule: KnockSchedule = KnockSchedule(),
) {
    suspend fun knock(pc: PairedPc): KnockAnswer? {
        val deviceId = AvekProtocol.deviceIdOf(identity.publicKey())
        val answers = udpRound(
            transport = transport,
            schedule = schedule,
            lastHost = pc.lastHost,
            stopAtFirst = true,
            newDatagram = { build(deviceId) },
            accept = { datagram, nonces -> accept(datagram, nonces, pc, deviceId) },
        )
        return answers.firstOrNull()
    }

    /** A signed knock datagram and its nonce. */
    fun build(deviceId: String): Pair<ByteArray, ByteArray> {
        val nonce = randomBytes(16)
        val ts = nowMs()
        val signature = identity.sign(AvekProtocol.knockMessage(deviceId, ts, nonce))
        val json = buildJsonObject {
            put("avek", AvekProtocol.VERSION)
            put("k", "knock")
            put("id", deviceId)
            put("ts", ts)
            put("n", SecureCrypto.b64(nonce))
            put("sig", SecureCrypto.b64(signature))
        }
        return WireJson.encodeToString(JsonObject.serializer(), json).toByteArray(Charsets.UTF_8) to nonce
    }

    companion object {
        /** Checks a `here` answer; returns where to connect, or null to ignore it. */
        fun accept(datagram: Datagram, nonces: Set<String>, pc: PairedPc, deviceId: String): KnockAnswer? {
            if (datagram.data.size > MAX_DATAGRAM) return null
            val obj = parse(datagram.data) ?: return null
            if (obj.int("avek") != AvekProtocol.VERSION || obj.str("k") != "here") return null
            val sid = obj.str("sid") ?: return null
            val port = obj.int("port") ?: return null
            val n = obj.str("n") ?: return null
            val sig = obj.str("sig") ?: return null
            if (sid != pc.serverId || n !in nonces || port !in 1..65535) return null
            val nonce = runCatching { SecureCrypto.unb64(n) }.getOrNull() ?: return null
            val signature = runCatching { SecureCrypto.unb64(sig) }.getOrNull() ?: return null
            if (!SecureCrypto.verify(pc.serverPub, AvekProtocol.hereMessage(sid, port, deviceId, nonce), signature)) return null
            return KnockAnswer(datagram.host, port)
        }
    }
}

/** A PC with its pairing window open (an `open` answer to `find`). Unsigned: the six digits protect the pairing. */
data class FoundPc(val serverId: String, val name: String, val host: String, val port: Int) {
    val target: HostPort get() = HostPort(host, port)
}

/** Finds PCs whose pairing window is open (section 2, `find`). */
class FindClient(
    private val transport: UdpTransport,
    private val randomBytes: (Int) -> ByteArray = { n -> ByteArray(n).also(SecureRandom()::nextBytes) },
    private val schedule: KnockSchedule = KnockSchedule(),
) {
    /** Every PC that answered during one round (de-duplicated by `sid`). */
    suspend fun find(): List<FoundPc> {
        val answers = udpRound(
            transport = transport,
            schedule = schedule,
            lastHost = null,
            stopAtFirst = false,
            newDatagram = ::build,
            accept = ::accept,
        )
        return answers.distinctBy { it.serverId }
    }

    fun build(): Pair<ByteArray, ByteArray> {
        val nonce = randomBytes(16)
        val json = buildJsonObject {
            put("avek", AvekProtocol.VERSION)
            put("k", "find")
            put("n", SecureCrypto.b64(nonce))
        }
        return WireJson.encodeToString(JsonObject.serializer(), json).toByteArray(Charsets.UTF_8) to nonce
    }

    fun accept(datagram: Datagram, nonces: Set<String>): FoundPc? {
        if (datagram.data.size > MAX_DATAGRAM) return null
        val obj = parse(datagram.data) ?: return null
        if (obj.int("avek") != AvekProtocol.VERSION || obj.str("k") != "open") return null
        val sid = obj.str("sid")?.takeIf { it.isNotBlank() } ?: return null
        val port = obj.int("port")?.takeIf { it in 1..65535 } ?: return null
        val n = obj.str("n") ?: return null
        if (n !in nonces) return null
        return FoundPc(sid, obj.str("name")?.takeIf { it.isNotBlank() } ?: sid, datagram.host, port)
    }
}

private const val MAX_DATAGRAM = 4096

private fun parse(bytes: ByteArray): JsonObject? =
    runCatching { WireJson.parseToJsonElement(bytes.toString(Charsets.UTF_8)).jsonObject }.getOrNull()

private fun JsonObject.str(key: String): String? = (this[key] as? JsonPrimitive)?.takeIf { it.isString }?.contentOrNull
private fun JsonObject.int(key: String): Int? = (this[key] as? JsonPrimitive)?.takeIf { !it.isString }?.intOrNull
@Suppress("unused") private fun JsonObject.long(key: String): Long? = (this[key] as? JsonPrimitive)?.longOrNull
