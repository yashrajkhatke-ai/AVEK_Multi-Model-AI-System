package com.avek.chat.core.data.local

import com.avek.chat.core.model.Conversation
import com.avek.chat.core.model.Feedback
import com.avek.chat.core.model.Message
import com.avek.chat.core.model.MessageStatus
import com.avek.chat.core.model.Role
import com.avek.chat.core.model.SourceRef
import com.avek.chat.core.model.TaskMode
import com.avek.chat.core.model.ThinkingDepth
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.json.Json

private val json = Json { ignoreUnknownKeys = true }
private val sourcesSerializer = ListSerializer(SourceRef.serializer())

private inline fun <reified E : Enum<E>> enumOrDefault(name: String?, default: E): E =
    enumValues<E>().firstOrNull { it.name == name } ?: default

fun ConversationEntity.asDomain() = Conversation(
    id = id,
    title = title,
    createdAt = createdAt,
    updatedAt = updatedAt,
    isStarred = isStarred,
    isArchived = isArchived,
    modelId = modelId,
    taskMode = TaskMode.fromName(taskMode),
    preview = preview,
    messageCount = messageCount,
)

fun Conversation.asEntity() = ConversationEntity(
    id = id,
    title = title,
    createdAt = createdAt,
    updatedAt = updatedAt,
    isStarred = isStarred,
    isArchived = isArchived,
    modelId = modelId,
    taskMode = taskMode.name,
    preview = preview,
    messageCount = messageCount,
)

fun MessageEntity.asDomain() = Message(
    id = id,
    conversationId = conversationId,
    role = enumOrDefault(role, Role.ASSISTANT),
    content = content,
    createdAt = createdAt,
    thinking = thinking,
    thinkingDurationMs = thinkingDurationMs,
    modelId = modelId,
    requestedTask = TaskMode.fromName(requestedTask),
    resolvedTask = resolvedTask?.let { TaskMode.fromName(it) },
    depth = ThinkingDepth.fromLevel(depth),
    status = enumOrDefault(status, MessageStatus.COMPLETE),
    feedback = enumOrDefault(feedback, Feedback.NONE),
    sources = runCatching { json.decodeFromString(sourcesSerializer, sourcesJson) }.getOrDefault(emptyList()),
)

fun Message.asEntity() = MessageEntity(
    id = id,
    conversationId = conversationId,
    role = role.name,
    content = content,
    thinking = thinking,
    thinkingDurationMs = thinkingDurationMs,
    modelId = modelId,
    requestedTask = requestedTask.name,
    resolvedTask = resolvedTask?.name,
    depth = depth.level,
    status = status.name,
    feedback = feedback.name,
    sourcesJson = if (sources.isEmpty()) "[]" else json.encodeToString(sourcesSerializer, sources),
    createdAt = createdAt,
)
