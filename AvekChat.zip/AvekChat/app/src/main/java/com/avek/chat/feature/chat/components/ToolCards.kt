package com.avek.chat.feature.chat.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.outlined.ErrorOutline
import androidx.compose.material.icons.outlined.KeyboardArrowDown
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import com.avek.chat.core.designsystem.theme.AvekTheme
import com.avek.chat.core.designsystem.theme.avekShape
import com.avek.chat.core.model.Message
import com.avek.chat.core.model.ToolCall
import com.avek.chat.feature.chat.ChatViewModel
import com.avek.chat.feature.chat.ToolViewState

/**
 * The tools the PC used during a turn: one small card each (title, state), expandable. The body is
 * fetched with `tool.get` only when the card is opened.
 */
@Composable
fun ToolCards(
    message: Message,
    toolViews: Map<String, ToolViewState>,
    onLoadTool: (Message, ToolCall) -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        message.tools.forEach { call ->
            val state = message.promptId?.let { toolViews[ChatViewModel.toolKey(it, call.callId)] }
            ToolCard(call = call, state = state, onExpand = { onLoadTool(message, call) })
        }
    }
}

@Composable
private fun ToolCard(call: ToolCall, state: ToolViewState?, onExpand: () -> Unit) {
    val colors = AvekTheme.colors
    var expanded by remember { mutableStateOf(false) }
    val chevron by animateFloatAsState(if (expanded) 180f else 0f, label = "tool-chevron")
    val canExpand = !call.isRunning

    Column(
        Modifier
            .fillMaxWidth()
            .clip(avekShape(14.dp))
            .background(colors.thinkingSurface)
            .border(1.dp, colors.outline.copy(alpha = 0.45f), avekShape(14.dp)),
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .clickable(enabled = canExpand) {
                    expanded = !expanded
                    if (expanded) onExpand()
                }
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            when (call.ok) {
                null -> CircularProgressIndicator(Modifier.size(16.dp), color = colors.thinkingGlow, strokeWidth = 2.dp)
                true -> Icon(Icons.Filled.CheckCircle, contentDescription = "Done", tint = colors.accent, modifier = Modifier.size(16.dp))
                false -> Icon(Icons.Outlined.ErrorOutline, contentDescription = "Failed", tint = colors.danger, modifier = Modifier.size(16.dp))
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    call.title.ifBlank { call.name.ifBlank { "Tool" } },
                    style = AvekTheme.type.label,
                    color = colors.textPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                if (!call.detail.isNullOrBlank()) {
                    Text(call.detail, style = AvekTheme.type.caption, color = colors.textTertiary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
            if (canExpand) {
                Icon(
                    Icons.Outlined.KeyboardArrowDown,
                    contentDescription = if (expanded) "Collapse" else "Expand",
                    tint = colors.textSecondary,
                    modifier = Modifier.size(20.dp).rotate(chevron),
                )
            }
        }

        AnimatedVisibility(expanded, enter = expandVertically() + fadeIn(), exit = shrinkVertically() + fadeOut()) {
            Column(Modifier.padding(start = 12.dp, end = 12.dp, bottom = 12.dp)) {
                when (state) {
                    ToolViewState.Loading -> Text("Loading…", style = AvekTheme.type.caption, color = colors.textTertiary)
                    is ToolViewState.Failed -> Text(state.message, style = AvekTheme.type.caption, color = colors.danger)
                    is ToolViewState.Loaded -> ToolBody(state.view.body, state.view.style, state.view.detail)
                    null -> if (call.body != null) ToolBody(call.body, "text", "") else Text("Loading…", style = AvekTheme.type.caption, color = colors.textTertiary)
                }
            }
        }
    }
}

@Composable
private fun ToolBody(body: String, style: String, detail: String) {
    val colors = AvekTheme.colors
    if (detail.isNotBlank()) {
        Text(detail, style = AvekTheme.type.caption, color = colors.textSecondary, modifier = Modifier.padding(bottom = 6.dp))
    }
    val text: AnnotatedString = if (style == "diff") diffText(body, colors.accent, colors.danger, colors.textSecondary) else AnnotatedString(body)
    val mono = style == "command" || style == "diff"
    Text(
        text,
        style = (if (mono) AvekTheme.type.code else AvekTheme.type.bodySmall),
        fontFamily = if (mono) FontFamily.Monospace else null,
        color = colors.textSecondary,
        modifier = Modifier
            .fillMaxWidth()
            .clip(avekShape(10.dp))
            .background(colors.codeSurface)
            .horizontalScroll(rememberScrollState())
            .padding(10.dp),
        softWrap = !mono,
    )
}

private fun diffText(body: String, added: androidx.compose.ui.graphics.Color, removed: androidx.compose.ui.graphics.Color, base: androidx.compose.ui.graphics.Color): AnnotatedString =
    buildAnnotatedString {
        body.lines().forEachIndexed { index, line ->
            val color = when {
                line.startsWith("+") && !line.startsWith("+++") -> added
                line.startsWith("-") && !line.startsWith("---") -> removed
                else -> base
            }
            withStyle(SpanStyle(color = color)) { append(line) }
            if (index < body.lines().lastIndex) append('\n')
        }
    }
