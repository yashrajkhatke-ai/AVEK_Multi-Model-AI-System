package com.avek.chat.platform.android

import android.os.Build
import com.avek.chat.core.common.DeviceInfo
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AndroidDeviceInfo @Inject constructor() : DeviceInfo {
    override val model: String get() = Build.MODEL.orEmpty().ifBlank { "Android" }
}
