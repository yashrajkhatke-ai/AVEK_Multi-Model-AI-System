package com.avek.chat.feature.chat.thinking.panels

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.avek.chat.core.designsystem.theme.AvekTheme
import com.avek.chat.core.domain.trace.PhaseSpan
import com.avek.chat.core.domain.trace.TurnTelemetry
import com.avek.chat.feature.chat.thinking.ThinkingFormat

// ------------------------------------------------------------------ 3. phase timeline

/** One chip per phase that happened, with its measured duration; the open one pulses. */
@Composable
fun PhaseTimelinePanel(t: TurnTelemetry, now: Long, compact: Boolean, modifier: Modifier = Modifier) {
    val palette = rememberThinkingPalette()
    if (t.phases.isEmpty()) return NoData("No phases reported yet", modifier)
    val pcNow = t.pcNow(now) ?: 0L
    val pulse by rememberPulse(t.phases.any { it.open })
    val scroll = rememberScrollState()
    LaunchedEffect(t.phases.size) { scroll.animateScrollTo(scroll.maxValue) }
    Row(
        modifier.fillMaxWidth().horizontalScroll(scroll),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        val phases = if (compact) t.phases.takeLast(4) else t.phases
        phases.forEach { p ->
            val label = p.label.ifEmpty { ThinkingFormat.phaseName(p.phase) }
            val duration = ThinkingFormat.ms(p.durationMs(pcNow))
            Chip(
                if (compact) label else "$label · $duration",
                if (p.open) palette.accent else palette.muted,
                filled = p.open,
                alpha = if (p.open) pulse.coerceAtLeast(0.6f) else 1f,
                modifier = Modifier.semantics { contentDescription = "$label, $duration${if (p.open) ", in progress" else ""}" },
            )
        }
    }
}

// ------------------------------------------------------------------ 4. pipeline diagram

private enum class Node(val label: String) { CONTEXT("Context"), PREFILL("Prefill"), THINKING("Thinking"), TOOL("Tool"), ANSWER("Answer") }

private fun nodeOf(phase: String): Node? = when (phase) {
    "building-context", "counting-tokens", "fitting-context", "growing-window", "compacting", "attachments", "plugins", "opening-session" -> Node.CONTEXT
    "prefill" -> Node.PREFILL
    "thinking" -> Node.THINKING
    "writing-tool-call", "running-tool", "parking", "resuming" -> Node.TOOL
    "answering" -> Node.ANSWER
    else -> null
}

/** Context → Prefill → Thinking → Tool → Answer; the active node glows; a tool round trip loops back. */
@Composable
fun PipelinePanel(t: TurnTelemetry, now: Long, compact: Boolean, modifier: Modifier = Modifier) {
    val palette = rememberThinkingPalette()
    val pcNow = t.pcNow(now) ?: 0L
    val totals = remember(t.phases, pcNow) {
        Node.entries.associateWith { node -> t.phases.filter { nodeOf(it.phase) == node }.sumOf { it.durationMs(pcNow) ?: 0L } }
    }
    val seen = remember(t.phases) { t.phases.mapNotNull { nodeOf(it.phase) }.toSet() }
    val active = t.currentPhase?.let { nodeOf(it.phase) }
    val loops = remember(t.steps) { (t.steps.size - 1).coerceAtLeast(0) }
    val pulse by rememberPulse(active != null)
    Column(modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Node.entries.forEachIndexed { i, node ->
                val on = node == active
                val done = node in seen && !on
                Column(
                    Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (on) palette.accent.copy(alpha = 0.18f + 0.12f * pulse) else palette.track.copy(alpha = if (done) 0.35f else 0.15f))
                        .border(1.dp, if (on) palette.accent else palette.track, RoundedCornerShape(10.dp))
                        .padding(vertical = if (compact) 4.dp else 8.dp)
                        .semantics { contentDescription = "${node.label}${if (on) ", active" else if (done) ", ${totals[node]} milliseconds" else ""}" },
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text(node.label, style = AvekTheme.type.caption.copy(fontWeight = FontWeight.Medium), color = if (on || done) palette.text else palette.faint, maxLines = 1)
                    if (!compact) Text(if (node in seen) ThinkingFormat.ms(totals[node]) else ThinkingFormat.NONE, style = AvekTheme.type.caption, color = palette.muted)
                }
                if (i < Node.entries.lastIndex) {
                    val flowing = active != null && (node == active || Node.entries.getOrNull(i + 1) == active)
                    Canvas(Modifier.width(10.dp).height(2.dp)) {
                        drawLine(
                            if (flowing) palette.accent else palette.track,
                            Offset(0f, size.height / 2), Offset(size.width, size.height / 2), strokeWidth = size.height,
                            pathEffect = if (flowing) PathEffect.dashPathEffect(floatArrayOf(4f, 3f), phase = -pulse * 7f) else null,
                        )
                    }
                }
            }
        }
        if (!compact && loops > 0) {
            Text(
                "↺ Tool → Prefill: $loops round trip${if (loops == 1) "" else "s"} (step ${t.steps.size} now)",
                style = AvekTheme.type.caption, color = palette.toolCall, modifier = Modifier.padding(top = 6.dp),
            )
        }
    }
}

// ------------------------------------------------------------------ 5. context window bar

/** One stacked bar of the window: categories, then free; markers for compactAt and windowMax. */
@Composable
fun ContextBarPanel(t: TurnTelemetry, compact: Boolean, modifier: Modifier = Modifier) {
    val palette = rememberThinkingPalette()
    val c = t.context ?: return NoData("The context is measured when the prompt is built", modifier)
    val scale = maxOf(c.windowMax, c.window, c.promptTokens, 1).toFloat()
    val ordered = remember(c) { c.categories.sortedBy { ThinkingFormat.CATEGORY_ORDER.indexOf(it.key).let { i -> if (i < 0) 99 else i } } }
    val windowFraction by animateFloatAsState(c.window / scale, label = "window")
    val fill = if (c.window > 0) c.promptTokens.toFloat() / c.window else 0f
    val summary = "${ThinkingFormat.tokens(c.promptTokens)} / ${ThinkingFormat.tokens(c.window)} (${(fill * 100).toInt()}%) · ${ThinkingFormat.exact(c.exact)}"
    Column(modifier.fillMaxWidth().semantics { contentDescription = "Context window ${(fill * 100).toInt()} percent full" }) {
        if (!compact) PanelTitle("Context window", trailing = "step ${c.step}")
        Canvas(Modifier.fillMaxWidth().height(if (compact) 8.dp else 14.dp)) {
            val h = size.height
            drawRoundRect(palette.track.copy(alpha = 0.25f), size = Size(size.width, h), cornerRadius = CornerRadius(h / 2))
            drawRoundRect(palette.track.copy(alpha = 0.5f), size = Size(size.width * windowFraction, h), cornerRadius = CornerRadius(h / 2))
            var x = 0f
            ordered.forEach { cat ->
                val w = size.width * cat.tokens / scale
                drawRect(palette.category(cat.key), topLeft = Offset(x, 0f), size = Size(w, h))
                x += w
            }
            if (c.compactAt > 0) {
                val mx = size.width * c.compactAt / scale
                drawLine(palette.warn, Offset(mx, -2f), Offset(mx, h + 2f), strokeWidth = 2f)
            }
            val wx = size.width * c.window / scale
            drawLine(palette.text.copy(alpha = 0.6f), Offset(wx, -2f), Offset(wx, h + 2f), strokeWidth = 2f)
        }
        Spacer(Modifier.height(4.dp))
        Text(summary, style = AvekTheme.type.caption, color = palette.muted)
        if (!compact) {
            Spacer(Modifier.height(6.dp))
            Legend(ordered.map { "${it.label} ${ThinkingFormat.tokens(it.tokens)}" to palette.category(it.key) } + ("Free ${ThinkingFormat.tokens(c.free)}" to palette.track))
            val notes = buildList {
                c.grew?.let { add("Window grew ${ThinkingFormat.tokens(it.from)} → ${ThinkingFormat.tokens(it.to)}") }
                if (c.compacted != null) add("Older turns were summarized")
                if (c.trimmed != null) add("History was trimmed to fit")
                add("Compacts at ${ThinkingFormat.tokens(c.compactAt)} · max ${ThinkingFormat.tokens(c.windowMax)} · ${ThinkingFormat.tokens(c.outputReserve)} kept for the answer")
            }
            notes.forEach { Text(it, style = AvekTheme.type.caption, color = palette.faint, modifier = Modifier.padding(top = 2.dp)) }
        }
    }
}

// ------------------------------------------------------------------ 6. token ledger

@Composable
fun TokenLedgerPanel(t: TurnTelemetry, compact: Boolean, modifier: Modifier = Modifier) {
    val palette = rememberThinkingPalette()
    if (t.steps.isEmpty() && t.context == null) return NoData("No token counts yet", modifier)
    Column(modifier.fillMaxWidth()) {
        if (compact) {
            Text(
                "Prompt ${ThinkingFormat.tokens(t.promptTokens)} · reasoning ${t.reasoningTokens} · answer ${t.answerTokens} · tool ${t.toolCallTokens} · ${ThinkingFormat.exact(t.tokensExact)}",
                style = AvekTheme.type.caption, color = palette.muted, maxLines = 2,
            )
            return@Column
        }
        t.context?.let { c ->
            PanelTitle("Prompt (step ${c.step})", trailing = ThinkingFormat.exact(c.exact))
            c.categories.forEach { cat -> LedgerRow(cat.label, ThinkingFormat.tokens(cat.tokens), palette.category(cat.key)) }
            LedgerRow("Total", ThinkingFormat.tokens(c.promptTokens), null, bold = true)
            Spacer(Modifier.height(8.dp))
        }
        PanelTitle("Generated")
        Row(Modifier.fillMaxWidth()) {
            listOf("Step", "Reasoning", "Answer", "Tool", "Total").forEach {
                Text(it, style = AvekTheme.type.caption, color = palette.faint, modifier = Modifier.weight(1f))
            }
        }
        t.steps.forEach { s ->
            Row(Modifier.fillMaxWidth()) {
                listOf("${s.step}", "${s.tokens.reasoning}", "${s.tokens.answer}", "${s.tokens.toolCall}", "${s.tokens.total}${if (s.tokens.exact) "" else " ≈"}").forEach {
                    Text(it, style = AvekTheme.type.caption, color = palette.text, modifier = Modifier.weight(1f))
                }
            }
        }
        Row(Modifier.fillMaxWidth()) {
            listOf("Turn", "${t.reasoningTokens}", "${t.answerTokens}", "${t.toolCallTokens}", "${t.generatedTokens}").forEach {
                Text(it, style = AvekTheme.type.caption.copy(fontWeight = FontWeight.SemiBold), color = palette.text, modifier = Modifier.weight(1f))
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(
            "Turn totals (server): prompt ${ThinkingFormat.tokens(t.promptTokens)} · completion ${ThinkingFormat.tokens(t.completionTokens)} · ${ThinkingFormat.exact(t.tokensExact)}",
            style = AvekTheme.type.caption, color = palette.muted,
        )
    }
}

@Composable
private fun LedgerRow(label: String, value: String, color: androidx.compose.ui.graphics.Color?, bold: Boolean = false) {
    Row(Modifier.fillMaxWidth().padding(vertical = 1.dp), verticalAlignment = Alignment.CenterVertically) {
        if (color != null) Dot(color, 7) else Spacer(Modifier.width(7.dp))
        Spacer(Modifier.width(6.dp))
        val style = if (bold) AvekTheme.type.caption.copy(fontWeight = FontWeight.SemiBold) else AvekTheme.type.caption
        Text(label, style = style, color = AvekTheme.colors.textSecondary, modifier = Modifier.weight(1f))
        Text(value, style = style, color = AvekTheme.colors.textPrimary)
    }
}

// ------------------------------------------------------------------ 7. throughput gauge

@Composable
fun ThroughputPanel(t: TurnTelemetry, compact: Boolean, modifier: Modifier = Modifier) {
    val palette = rememberThinkingPalette()
    val tps = t.tps
    val peak = remember(t.tpsSamples) { t.tpsSamples.maxOfOrNull { it.tps }?.coerceAtLeast(1.0) ?: 1.0 }
    val gauge by animateFloatAsState(((tps ?: 0.0) / peak).toFloat().coerceIn(0f, 1f), label = "gauge")
    val samples = remember(t.tpsSamples) { t.tpsSamples.map { it.tps.toFloat() } }
    Row(modifier.fillMaxWidth().semantics { contentDescription = "Throughput ${ThinkingFormat.tps(tps)}" }, verticalAlignment = Alignment.CenterVertically) {
        Box(contentAlignment = Alignment.Center) {
            Canvas(Modifier.width(if (compact) 40.dp else 84.dp).height(if (compact) 24.dp else 48.dp)) {
                val stroke = if (compact) 4f else 8f
                val d = minOf(size.width, size.height * 2) - stroke
                val topLeft = Offset((size.width - d) / 2, stroke / 2)
                drawArc(palette.track, 180f, 180f, false, topLeft, Size(d, d), style = androidx.compose.ui.graphics.drawscope.Stroke(stroke))
                drawArc(palette.accent, 180f, 180f * gauge, false, topLeft, Size(d, d), style = androidx.compose.ui.graphics.drawscope.Stroke(stroke))
            }
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(ThinkingFormat.tps(tps), style = AvekTheme.type.label.copy(fontWeight = FontWeight.SemiBold), color = palette.text)
            if (!compact) {
                Text("avg ${ThinkingFormat.tps(t.avgTps)} · first token ${ThinkingFormat.ms(t.ttftMs)}", style = AvekTheme.type.caption, color = palette.muted)
                Spacer(Modifier.height(4.dp))
                Sparkline(samples, palette.accent, Modifier.fillMaxWidth().height(28.dp))
                Text("last 60 s", style = AvekTheme.type.caption, color = palette.faint)
            }
        }
    }
}

@Composable
fun Sparkline(values: List<Float>, color: androidx.compose.ui.graphics.Color, modifier: Modifier = Modifier) {
    if (values.size < 2) return NoData("Collecting samples", modifier)
    val path = remember { androidx.compose.ui.graphics.Path() }
    Canvas(modifier) {
        val max = values.max().coerceAtLeast(1f)
        path.reset()
        values.forEachIndexed { i, v ->
            val x = size.width * i / (values.size - 1)
            val y = size.height - size.height * v / max
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        drawPath(path, color, style = androidx.compose.ui.graphics.drawscope.Stroke(2f))
    }
}

// ------------------------------------------------------------------ 8. tool-call inspector

@Composable
fun ToolCardsPanel(t: TurnTelemetry, compact: Boolean, modifier: Modifier = Modifier) {
    val palette = rememberThinkingPalette()
    val keys = remember(t.tools, t.toolArgs) { (t.tools.keys + t.toolArgs.keys).sortedWith(compareBy({ it.step }, { it.index })) }
    if (keys.isEmpty()) return NoData("No tool calls in this turn", modifier)
    Column(modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        keys.forEach { key ->
            val tool = t.tools[key]
            val args = t.toolArgs[key]
            val name = tool?.name?.ifEmpty { null } ?: args?.name ?: "tool"
            val state = tool?.state ?: "writing"
            val stateText = when (state) {
                "writing" -> "writing arguments"
                "running" -> "running"
                "done" -> "done"
                "error" -> "error"
                else -> state
            }
            val stateColor = when (state) {
                "done" -> palette.success
                "error" -> palette.danger
                else -> palette.accent
            }
            val pulse by rememberPulse(state == "writing" || state == "running")
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(palette.track.copy(alpha = 0.18f)).padding(10.dp),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Chip(tool?.owner ?: "core", palette.muted)
                    Spacer(Modifier.width(6.dp))
                    Text(name, style = AvekTheme.type.label.copy(fontWeight = FontWeight.SemiBold), color = palette.text, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Dot(stateColor, 7, alpha = pulse)
                    Spacer(Modifier.width(4.dp))
                    Text(stateText, style = AvekTheme.type.caption, color = stateColor)
                }
                if (!compact) {
                    val text = args?.text.orEmpty()
                    if (text.isNotEmpty()) {
                        Spacer(Modifier.height(6.dp))
                        Text(
                            JsonTint.color(text, palette),
                            style = AvekTheme.type.code.copy(fontSize = AvekTheme.type.caption.fontSize),
                            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(6.dp)).background(AvekTheme.colors.codeSurface).padding(8.dp),
                        )
                        if (args?.gap == true) Text("Some of the arguments were missed while streaming", style = AvekTheme.type.caption, color = palette.warn)
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(
                        listOfNotNull(
                            tool?.argTokens?.let { "$it argument tokens" },
                            tool?.ms?.let { ThinkingFormat.ms(it) },
                            tool?.resultChars?.let { "result $it chars" },
                            tool?.resultTokens?.let { "≈ $it tokens" },
                            "step ${key.step}",
                        ).joinToString(" · "),
                        style = AvekTheme.type.caption, color = palette.muted,
                    )
                }
            }
        }
    }
}

/** Light JSON coloring for streamed arguments (keys, strings, numbers, punctuation). */
object JsonTint {
    fun color(text: String, palette: ThinkingPalette): androidx.compose.ui.text.AnnotatedString = androidx.compose.ui.text.buildAnnotatedString {
        var i = 0
        var expectKey = true
        while (i < text.length) {
            val ch = text[i]
            when {
                ch == '"' -> {
                    var j = i + 1
                    while (j < text.length && text[j] != '"') { if (text[j] == '\\') j++; j++ }
                    val end = minOf(j + 1, text.length)
                    pushStyle(androidx.compose.ui.text.SpanStyle(color = if (expectKey) palette.accent else palette.answer))
                    append(text, i, end)
                    pop()
                    i = end
                    continue
                }
                ch == ':' -> { expectKey = false; pushStyle(androidx.compose.ui.text.SpanStyle(color = palette.faint)); append(ch); pop() }
                ch == ',' || ch == '{' || ch == '[' -> { expectKey = ch != '['; pushStyle(androidx.compose.ui.text.SpanStyle(color = palette.faint)); append(ch); pop() }
                ch.isDigit() || ch == '-' -> { pushStyle(androidx.compose.ui.text.SpanStyle(color = palette.toolCall)); append(ch); pop() }
                else -> { pushStyle(androidx.compose.ui.text.SpanStyle(color = palette.text)); append(ch); pop() }
            }
            i++
        }
    }
}

// ------------------------------------------------------------------ 9. harness console

private data class ConsoleLine(val t: Long, val level: String, val source: String, val text: String)

@Composable
fun ConsolePanel(t: TurnTelemetry, compact: Boolean, paused: Boolean, modifier: Modifier = Modifier) {
    val palette = rememberThinkingPalette()
    val lines = remember(t.logs, t.phaseHistory) {
        (t.logs.map { ConsoleLine(it.t, it.level, it.source, it.text) } +
            t.phaseHistory.map { ConsoleLine(it.t, "phase", "phase", "${if (it.state == "start") "▶" else "■"} ${it.label.ifEmpty { ThinkingFormat.phaseName(it.phase) }}") })
            .sortedBy { it.t }
    }
    if (lines.isEmpty()) return NoData("The harness has not logged anything for this turn", modifier)
    val frozen = remember(paused) { if (paused) lines else null }
    val shown = (frozen ?: lines).let { if (compact) it.takeLast(2) else it.takeLast(200) }
    val start = lines.first().t
    Column(
        modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(AvekTheme.colors.codeSurface).padding(8.dp),
    ) {
        shown.forEach { line ->
            Row {
                Text("+${ThinkingFormat.ms(line.t - start)}".padEnd(9), style = AvekTheme.type.code.copy(fontSize = AvekTheme.type.caption.fontSize), color = palette.faint)
                Text(
                    "${line.source}: ${line.text}",
                    style = AvekTheme.type.code.copy(fontSize = AvekTheme.type.caption.fontSize),
                    color = if (line.level == "phase") palette.accent else if (line.level == "info") AvekTheme.colors.codeText else palette.level(line.level),
                    maxLines = if (compact) 1 else 4,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
        if (paused) Text("Paused", style = AvekTheme.type.caption, color = palette.warn, modifier = Modifier.alpha(0.9f))
    }
}

/** Helper for open phase lists elsewhere. */
fun PhaseSpan.displayLabel(): String = label.ifEmpty { ThinkingFormat.phaseName(phase) }
