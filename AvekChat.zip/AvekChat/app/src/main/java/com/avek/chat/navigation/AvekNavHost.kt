package com.avek.chat.navigation

import androidx.compose.animation.AnimatedContentTransitionScope.SlideDirection
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.avek.chat.core.designsystem.theme.AvekTheme
import com.avek.chat.feature.chat.ChatRoute
import com.avek.chat.feature.customize.CustomizeRoute
import com.avek.chat.feature.settings.SettingsRoute
import kotlinx.serialization.Serializable

@Serializable data object ChatDestination

@Serializable data object CustomizeDestination

@Serializable data object SettingsDestination

private const val DURATION = 320

@Composable
fun AvekNavHost(navController: NavHostController = rememberNavController()) {
    NavHost(
        navController = navController,
        startDestination = ChatDestination,
        modifier = Modifier
            .fillMaxSize()
            .background(AvekTheme.colors.chatBackground),
        enterTransition = { slideIntoContainer(SlideDirection.Start, tween(DURATION)) + fadeIn(tween(DURATION)) },
        exitTransition = { slideOutOfContainer(SlideDirection.Start, tween(DURATION)) { it / 4 } + fadeOut(tween(DURATION / 2)) },
        popEnterTransition = { slideIntoContainer(SlideDirection.End, tween(DURATION)) { it / 4 } + fadeIn(tween(DURATION)) },
        popExitTransition = { slideOutOfContainer(SlideDirection.End, tween(DURATION)) + fadeOut(tween(DURATION / 2)) },
    ) {
        composable<ChatDestination> {
            ChatRoute(
                onOpenCustomize = { navController.navigate(CustomizeDestination) { launchSingleTop = true } },
                onOpenSettings = { navController.navigate(SettingsDestination) { launchSingleTop = true } },
            )
        }
        composable<CustomizeDestination> {
            CustomizeRoute(onBack = { navController.popBackStack() })
        }
        composable<SettingsDestination> {
            SettingsRoute(
                onBack = { navController.popBackStack() },
                onOpenCustomize = { navController.navigate(CustomizeDestination) { launchSingleTop = true } },
            )
        }
    }
}
