package com.avek.chat.platform.android

import android.app.Activity
import android.app.Application
import android.os.Bundle
import com.avek.chat.core.link.AppVisibility
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import javax.inject.Inject
import javax.inject.Singleton

/** The app is "visible" while at least one of its activities is started. */
@Singleton
class AppVisibilityTracker @Inject constructor(application: Application) : AppVisibility {

    private var started = 0
    private val state = MutableStateFlow(false)
    override val visible: StateFlow<Boolean> = state

    init {
        application.registerActivityLifecycleCallbacks(object : Application.ActivityLifecycleCallbacks {
            override fun onActivityStarted(activity: Activity) {
                started++
                state.value = true
            }

            override fun onActivityStopped(activity: Activity) {
                started = (started - 1).coerceAtLeast(0)
                // A configuration change stops and restarts the activity within the same frame; the
                // lifecycle controller waits 30 s before acting on "not visible", so no flicker matters.
                state.value = started > 0
            }

            override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) = Unit
            override fun onActivityResumed(activity: Activity) = Unit
            override fun onActivityPaused(activity: Activity) = Unit
            override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) = Unit
            override fun onActivityDestroyed(activity: Activity) = Unit
        })
    }
}
