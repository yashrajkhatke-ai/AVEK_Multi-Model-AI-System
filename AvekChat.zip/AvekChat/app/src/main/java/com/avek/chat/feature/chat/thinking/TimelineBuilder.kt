package com.avek.chat.feature.chat.thinking

import com.avek.chat.core.domain.trace.CallKey
import com.avek.chat.core.domain.trace.TokenKind
import com.avek.chat.core.domain.trace.TurnTelemetry
import com.avek.chat.core.model.ToolCall

/**
 * Splits a turn into its thinking stretches and tool calls, in the order they happened. The order
 * comes from the streamed deltas (each one is a token): a run of reasoning tokens is one thinking
 * stretch, a run of tool-call tokens is one call. Without that (an old turn) the whole reasoning is
 * one stretch, followed by the tool calls.
 */
object TimelineBuilder {

    fun build(thinking: String?, tools: List<ToolCall>, t: TurnTelemetry?, thinkingActive: Boolean, streaming: Boolean): List<TimelineItem> {
        val text = thinking.orEmpty()
        val calls = t?.let { tel -> (tel.toolArgs.keys + tel.tools.keys).distinct().sortedWith(compareBy({ it.step }, { it.index })) }.orEmpty()
        val cells = t?.tokens.orEmpty()
        val complete = t != null && cells.isNotEmpty() && t.tokenCount == cells.size && cells.filter { it.kind == TokenKind.REASONING }.sumOf { it.chars } == text.length
        val items = mutableListOf<TimelineItem>()
        if (complete) {
            var pos = 0
            var callIndex = 0
            var i = 0
            while (i < cells.size) {
                val kind = cells[i].kind
                var j = i
                var chars = 0
                while (j < cells.size && cells[j].kind == kind) { chars += cells[j].chars; j++ }
                when (kind) {
                    TokenKind.REASONING -> {
                        val segment = text.substring(pos, minOf(text.length, pos + chars))
                        pos += chars
                        val last = j >= cells.size
                        items += TimelineItem.Thinking("think-$i", segment, active = last && thinkingActive, durationMs = (cells[j - 1].atMs - cells[i].atMs).takeIf { it > 0 })
                    }
                    TokenKind.TOOL_CALL -> calls.getOrNull(callIndex++)?.let { items += toolItem(it, t!!, tools, streaming) }
                    TokenKind.ANSWER -> Unit
                }
                i = j
            }
            calls.drop(callIndex).forEach { items += toolItem(it, t!!, tools, streaming) }
        } else {
            if (text.isNotEmpty() || thinkingActive) items += TimelineItem.Thinking("think-0", text, active = thinkingActive)
            if (t != null && calls.isNotEmpty()) {
                calls.forEach { items += toolItem(it, t, tools, streaming) }
            } else {
                tools.forEach { tc ->
                    items += TimelineItem.Tool("tool-${tc.callId}", tc.name.ifEmpty { "tool" }, tc.title, tc.detail.orEmpty(), active = streaming && tc.ok == null, ok = tc.ok)
                }
            }
        }
        return items
    }

    private fun toolItem(key: CallKey, t: TurnTelemetry, tools: List<ToolCall>, streaming: Boolean): TimelineItem.Tool {
        val trace = t.tools[key]
        val args = t.toolArgs[key]
        val callId = trace?.callId?.ifEmpty { null } ?: args?.callId
        val known = tools.firstOrNull { it.callId == callId }
        val state = trace?.state ?: "writing"
        return TimelineItem.Tool(
            id = "tool-${key.step}-${key.index}",
            name = trace?.name?.ifEmpty { null } ?: args?.name ?: known?.name ?: "tool",
            title = known?.title,
            args = args?.text.orEmpty(),
            active = streaming && (state == "writing" || state == "running"),
            ok = when (state) { "done" -> true; "error" -> false; else -> known?.ok },
            durationMs = trace?.ms,
        )
    }
}
