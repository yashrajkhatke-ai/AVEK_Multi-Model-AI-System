package com.avek.chat.platform.android

import android.content.Context
import android.os.SystemClock
import android.provider.Settings
import com.avek.chat.core.domain.lock.LockClock
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * The lock's clock: `SystemClock.elapsedRealtime()` (monotonic, cannot be changed by the person) and
 * `Settings.Global.BOOT_COUNT`, so a lockout seen after a reboot starts again instead of being shortened.
 */
@Singleton
class AndroidLockClock @Inject constructor(@ApplicationContext private val context: Context) : LockClock {
    override fun elapsedRealtime(): Long = SystemClock.elapsedRealtime()

    override fun bootCount(): Int =
        runCatching { Settings.Global.getInt(context.contentResolver, Settings.Global.BOOT_COUNT) }.getOrDefault(0)
}
