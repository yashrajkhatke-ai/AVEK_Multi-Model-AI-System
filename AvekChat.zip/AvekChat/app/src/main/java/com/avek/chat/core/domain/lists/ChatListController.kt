package com.avek.chat.core.domain.lists

import com.avek.chat.core.domain.repository.Page
import com.avek.chat.core.model.Conversation
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class ChatListState(
    val items: List<Conversation> = emptyList(),
    val total: Int = 0,
    /** More chats exist on the PC than are loaded. */
    val hasMore: Boolean = false,
    /** The person tapped "See all": the list is now a normal infinite scroll. */
    val expanded: Boolean = false,
    val loading: Boolean = false,
    val loadingMore: Boolean = false,
    val error: String? = null,
) {
    /** The `See all (total)` row, in the 21st position. */
    val showSeeAll: Boolean get() = !expanded && hasMore
}

/**
 * The sidebar's paging rules (UI-WIRE section 13, "Chat list"):
 *  1. first request `limit 20`; if more exist, a `See all (total)` row follows the 20 items;
 *  2. when the 13th item becomes visible (once per page) the next 40 are prefetched into memory;
 *  3. "See all" shows the prefetched 40 at once (waiting for an unfinished prefetch);
 *  4. afterwards, whenever one of the last 8 loaded items is visible, the next 40 are prefetched
 *     (once per page) and appended, until `next` is null.
 * Items 21+ are never requested before the person scrolls to item 13 or taps "See all".
 * Pages live in memory only while the list is in use; see [ListMemoryController].
 */
class ChatListController(
    private val scope: CoroutineScope,
    private val fetch: suspend (limit: Int, after: String?) -> Page<Conversation>,
    keepSeconds: () -> Int,
    registry: ListMemoryRegistry? = null,
) {
    private val _state = MutableStateFlow(ChatListState())
    val state: StateFlow<ChatListState> = _state

    private val memory = ListMemoryController(scope, keepSeconds, ::onDrop).also { registry?.register(it) }

    private var next: String? = null
    private var firstJob: Job? = null
    private var prefetch: Deferred<Result<Page<Conversation>>>? = null
    private var prefetchedFor: String? = null
    private var prefetched: Page<Conversation>? = null

    // ------------------------------------------------------------------ view lifecycle

    /** The sidebar opened: cancels the countdown and loads the first page if nothing is in memory. */
    @Synchronized
    fun opened() {
        memory.inUse()
        if (_state.value.items.isEmpty() && firstJob?.isActive != true) loadFirst()
    }

    /** The sidebar closed: starts the countdown. */
    fun closed() = memory.idle()

    fun trim() = memory.trim()

    /** Countdown ended or the system is short of memory: forget everything; a list that is on screen starts over. */
    private fun onDrop() {
        reset()
        if (memory.isActive) loadFirst()
    }

    /** Drops every page and prefetch (the next open starts again with the first 20). */
    @Synchronized
    private fun reset() {
        firstJob?.cancel()
        prefetch?.cancel()
        firstJob = null
        prefetch = null
        prefetched = null
        prefetchedFor = null
        next = null
        _state.value = ChatListState()
    }

    /** Reloads from the first page (a filter changed, or the PC became reachable). */
    @Synchronized
    fun refresh() {
        reset()
        loadFirst()
    }

    // ------------------------------------------------------------------ user actions

    /** [lastVisibleIndex] = index of the last item currently visible (0-based, among loaded items). */
    @Synchronized
    fun onVisibleIndex(lastVisibleIndex: Int) {
        val state = _state.value
        val cursor = next ?: return
        if (state.items.isEmpty()) return
        val trigger = if (!state.expanded) lastVisibleIndex >= PREFETCH_AT_INDEX else lastVisibleIndex >= state.items.size - LOOKAHEAD
        if (trigger && prefetchedFor != cursor) startPrefetch(cursor)
    }

    @Synchronized
    fun seeAll() {
        val cursor = next ?: return
        if (_state.value.expanded) return
        _state.update { it.copy(expanded = true) }
        val ready = prefetched
        if (ready != null && prefetchedFor == cursor) {
            append(ready)
            return
        }
        if (prefetchedFor != cursor) startPrefetch(cursor)
        _state.update { it.copy(loadingMore = true) }
    }

    // ------------------------------------------------------------------ live updates

    /** A chat changed on the PC: move it to the top (or insert it when it matches the list). */
    @Synchronized
    fun upsert(chat: Conversation, insertIfMissing: Boolean) {
        _state.update { state ->
            val exists = state.items.any { it.id == chat.id }
            when {
                exists -> state.copy(items = listOf(chat) + state.items.filterNot { it.id == chat.id })
                insertIfMissing && state.items.isNotEmpty() -> state.copy(items = listOf(chat) + state.items, total = state.total + 1)
                else -> state
            }
        }
    }

    /** A chat changed (renamed, starred…): replaced where it is, without moving it. */
    @Synchronized
    fun update(chat: Conversation) {
        _state.update { state -> state.copy(items = state.items.map { if (it.id == chat.id) chat else it }) }
    }

    @Synchronized
    fun remove(chatId: String) {
        _state.update { state ->
            if (state.items.none { it.id == chatId }) state
            else state.copy(items = state.items.filterNot { it.id == chatId }, total = (state.total - 1).coerceAtLeast(0))
        }
    }

    // ------------------------------------------------------------------ internals

    private fun loadFirst() {
        _state.update { it.copy(loading = true, error = null) }
        firstJob = scope.launch {
            try {
                val page = fetch(FIRST_PAGE, null)
                synchronized(this@ChatListController) {
                    next = page.next
                    _state.value = ChatListState(items = page.items, total = page.total, hasMore = page.next != null)
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _state.update { it.copy(loading = false, error = e.message ?: "Could not load chats") }
            }
        }
    }

    private fun startPrefetch(cursor: String) {
        prefetchedFor = cursor
        // The result is wrapped so a failed fetch can never cancel the owning scope.
        val job = scope.async { attempt { fetch(NEXT_PAGE, cursor) } }
        prefetch = job
        scope.launch {
            val result = job.await()
            synchronized(this@ChatListController) {
                if (prefetchedFor != cursor) return@synchronized // dropped meanwhile
                result.fold(
                    onSuccess = { page -> if (_state.value.expanded) append(page) else prefetched = page },
                    onFailure = { error ->
                        prefetchedFor = null // allow another try
                        _state.update { it.copy(loadingMore = false, error = error.message ?: "Could not load more chats") }
                    },
                )
            }
        }
    }

    private suspend fun <T> attempt(block: suspend () -> T): Result<T> = try {
        Result.success(block())
    } catch (e: CancellationException) {
        throw e
    } catch (e: Throwable) {
        Result.failure(e)
    }

    private fun append(page: Page<Conversation>) {
        next = page.next
        prefetched = null
        prefetch = null
        _state.update {
            it.copy(
                items = it.items + page.items.filter { new -> it.items.none { old -> old.id == new.id } },
                total = page.total,
                hasMore = page.next != null,
                loadingMore = false,
                error = null,
            )
        }
    }

    companion object {
        const val FIRST_PAGE = 20
        const val NEXT_PAGE = 40

        /** The 13th item (0-based index 12) triggers the first prefetch. */
        const val PREFETCH_AT_INDEX = 12

        /** Once expanded: one of the last 8 loaded items being visible triggers the next prefetch. */
        const val LOOKAHEAD = 8
    }
}
