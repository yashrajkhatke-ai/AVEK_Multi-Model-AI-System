package com.avek.chat.core.data.fake

import com.avek.chat.core.common.TimeProvider
import com.avek.chat.core.domain.engine.GenerationEvent
import com.avek.chat.core.domain.engine.GenerationRequest
import com.avek.chat.core.domain.engine.InferenceEngine
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.FlowCollector
import kotlinx.coroutines.flow.flow
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.random.Random

/**
 * Streams a [ReplyScript] token-by-token with realistic pacing:
 * time-to-first-token, thinking that runs faster than answering,
 * sources that "arrive" during research steps, and per-model speed.
 */
@Singleton
class SimulatedInferenceEngine @Inject constructor(
    private val composer: ResponseComposer,
    private val time: TimeProvider,
) : InferenceEngine {

    override fun generate(request: GenerationRequest): Flow<GenerationEvent> = flow {
        val variant = request.variant
        val script = composer.compose(request.prompt, request.task, request.depth, variant)
        val random = Random(request.prompt.hashCode() + variant)
        val speed = request.speed.coerceIn(0.25f, 4f)
        val answerDelay = (1000f / request.tokensPerSecond / speed).toLong().coerceAtLeast(4)
        val thinkingDelay = (answerDelay / 2).coerceAtLeast(3)

        delay((250 + random.nextInt(350)).toLong())

        val sources = ArrayDeque(script.sources)
        if (script.thinking.isNotEmpty()) {
            val started = time.now()
            script.thinking.forEachIndexed { index, step ->
                emit(GenerationEvent.ThinkingStep(step.title))
                delay(120)
                streamTokens(step.text, thinkingDelay, random) { GenerationEvent.ThinkingDelta(it) }
                // Research steps surface a few sources as they "read".
                repeat(if (index == 0) 0 else sourcesPerStep(sources.size, script.thinking.size - index)) {
                    sources.removeFirstOrNull()?.let { source ->
                        emit(GenerationEvent.SourceFound(source))
                        delay(90)
                    }
                }
            }
            emit(GenerationEvent.ThinkingFinished(time.now() - started))
            delay(200)
        }
        while (sources.isNotEmpty()) {
            emit(GenerationEvent.SourceFound(sources.removeFirst()))
            delay(70)
        }

        streamTokens(script.answer, answerDelay, random) { GenerationEvent.AnswerDelta(it) }
        emit(GenerationEvent.Finished)
    }

    private fun sourcesPerStep(remaining: Int, stepsLeft: Int): Int =
        if (stepsLeft <= 0) remaining else (remaining + stepsLeft - 1) / stepsLeft

    private suspend fun FlowCollector<GenerationEvent>.streamTokens(
        text: String,
        perToken: Long,
        random: Random,
        event: (String) -> GenerationEvent,
    ) {
        val tokens = TOKEN.findAll(text).map { it.value }.toList()
        var i = 0
        while (i < tokens.size) {
            // Emit 1–3 tokens at a time, like real streaming chunking.
            val take = 1 + random.nextInt(3)
            val chunk = tokens.subList(i, minOf(tokens.size, i + take)).joinToString("")
            emit(event(chunk))
            i += take
            val jitter = random.nextLong(perToken / 2 + 1)
            delay(perToken * take + jitter)
        }
    }

    private companion object {
        /** A word plus its trailing whitespace, or a run of whitespace / punctuation. */
        val TOKEN = Regex("""\S+\s*|\s+""")
    }
}
