package com.avek.chat.core.link

import com.avek.chat.core.link.rpc.ListPart
import com.avek.chat.core.link.wire.AttachBeginResultDto
import com.avek.chat.core.link.wire.AttachEndResultDto
import com.avek.chat.core.link.wire.ChatGetPartDto
import com.avek.chat.core.link.wire.ChatListPartDto
import com.avek.chat.core.link.wire.ChatResultDto
import com.avek.chat.core.link.wire.DownloadsSetResultDto
import com.avek.chat.core.link.wire.DownloadsStatusResultDto
import com.avek.chat.core.link.wire.ModelDto
import com.avek.chat.core.link.wire.ModelListPartDto
import com.avek.chat.core.link.wire.ModelLoadResultDto
import com.avek.chat.core.link.wire.ModelsStateResultDto
import com.avek.chat.core.link.wire.TraceRuntimeDto
import com.avek.chat.core.link.wire.TimelineDto
import com.avek.chat.core.link.wire.ContextDataDto
import com.avek.chat.core.link.wire.TraceSnapshotDto
import com.avek.chat.core.link.wire.PromptAckDto
import com.avek.chat.core.link.wire.RewindResultDto
import com.avek.chat.core.link.wire.ToolGetDto
import com.avek.chat.core.link.wire.TurnGetDto
import com.avek.chat.core.link.wire.WireJson
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.serialization.KSerializer
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonObjectBuilder
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put

/** `limit` of a list request: an integer 1..100 or the string "all" (UI-WIRE section 7). */
sealed interface Limit {
    data class Count(val n: Int) : Limit {
        init {
            require(n in 1..100) { "limit must be 1..100" }
        }
    }

    data object All : Limit
}

/** Typed operations (UI-WIRE section 8) over a [LinkRepository]. Pure mapping; no caching, no policy. */
class HarnessApi(private val link: LinkRepository) {

    // ------------------------------------------------------------------ models

    /** The default model: `models.list {limit:1}` (null = no model is ready on the PC). */
    suspend fun defaultModel(): ModelDto? =
        link.call("models.list", buildJsonObject { putLimit(Limit.Count(1)) })
            .decode(ModelListPartDto.serializer()).items.firstOrNull()

    /** Every available model, one part (one model) at a time. */
    fun allModels(): Flow<ModelListPartDto> =
        link.callList("models.list", buildJsonObject { putLimit(Limit.All) }).decodeParts(ModelListPartDto.serializer())

    /** `model.load`: asks the PC to load a model while the person types (section 8.2). Answers at once. */
    suspend fun modelLoad(modelId: String): ModelLoadResultDto =
        link.call("model.load", buildJsonObject { put("modelId", modelId) }).decode(ModelLoadResultDto.serializer())

    suspend fun modelsState(): ModelsStateResultDto = link.call("models.state").decode(ModelsStateResultDto.serializer())

    /** What is loaded, the memory pool, GPU / RAM and plug-ins (the `trace.runtime` object). */
    suspend fun runtimeGet(): TraceRuntimeDto = link.call("runtime.get").decode(TraceRuntimeDto.serializer())

    /** Revision 2 or later: the harness sends the timeline and the context circle. */
    val revision: Int get() = link.ready.value?.revision ?: 1

    /** The blocks of a turn (all parts merged); [ids] limits it, [outline] leaves the texts out. */
    suspend fun timelineGet(chatId: String, promptId: String, ids: List<String>? = null, outline: Boolean = false): TimelineDto =
        link.call(
            "timeline.get",
            buildJsonObject {
                put("chatId", chatId)
                put("promptId", promptId)
                if (ids != null) put("ids", JsonArray(ids.map { JsonPrimitive(it) }))
                if (outline) put("outline", true)
            },
        ).decode(TimelineDto.serializer())

    /** The context circle of a chat; [modelId] sizes it for a model the chat has not used yet. */
    suspend fun contextGet(chatId: String, modelId: String? = null): ContextDataDto =
        link.call(
            "context.get",
            buildJsonObject {
                put("chatId", chatId)
                if (modelId != null) put("modelId", modelId)
            },
        ).decode(ContextDataDto.serializer())

    /** The latest telemetry of a turn, running or finished. */
    suspend fun traceGet(chatId: String, promptId: String): TraceSnapshotDto =
        link.call(
            "trace.get",
            buildJsonObject {
                put("chatId", chatId)
                put("promptId", promptId)
            },
        ).decode(TraceSnapshotDto.serializer())

    // ------------------------------------------------------------------ chats

    suspend fun chatsList(
        limit: Int,
        after: String?,
        query: String? = null,
        archived: Boolean = false,
        starred: Boolean = false,
    ): ChatListPartDto = link.call(
        "chats.list",
        buildJsonObject {
            putLimit(Limit.Count(limit))
            putAfter(after)
            if (!query.isNullOrBlank()) put("query", query)
            if (archived) put("archived", true)
            if (starred) put("starred", true)
        },
    ).decode(ChatListPartDto.serializer())

    /** Turns newest first; `after` goes further back in time. */
    suspend fun chatGet(chatId: String, limit: Int, after: String? = null, include: Set<String> = emptySet()): ChatGetPartDto =
        link.call("chat.get", chatGetArgs(chatId, Limit.Count(limit), after, include)).decode(ChatGetPartDto.serializer())

    /** A complete copy (downloads): every turn, streamed in parts. */
    fun chatGetAll(chatId: String, include: Set<String>): Flow<ChatGetPartDto> =
        link.callList("chat.get", chatGetArgs(chatId, Limit.All, null, include)).decodeParts(ChatGetPartDto.serializer())

    suspend fun turnGet(chatId: String, promptId: String, include: Set<String> = emptySet()): TurnGetDto =
        link.call(
            "turn.get",
            buildJsonObject {
                put("chatId", chatId)
                put("promptId", promptId)
                putInclude(include)
            },
        ).decode(TurnGetDto.serializer())

    suspend fun toolGet(chatId: String, promptId: String, callId: String): ToolGetDto =
        link.call(
            "tool.get",
            buildJsonObject {
                put("chatId", chatId)
                put("promptId", promptId)
                put("callId", callId)
            },
        ).decode(ToolGetDto.serializer())

    suspend fun chatSet(
        chatId: String,
        title: String? = null,
        modelId: String? = null,
        mode: String? = null,
        starred: Boolean? = null,
        archived: Boolean? = null,
    ): ChatResultDto = link.call(
        "chat.set",
        buildJsonObject {
            put("chatId", chatId)
            title?.let { put("title", it) }
            modelId?.let { put("modelId", it) }
            mode?.let { put("mode", it) }
            starred?.let { put("starred", it) }
            archived?.let { put("archived", it) }
        },
    ).decode(ChatResultDto.serializer())

    suspend fun chatDelete(chatId: String) {
        link.call("chat.delete", buildJsonObject { put("chatId", chatId) })
    }

    suspend fun chatRewind(chatId: String, fromPromptId: String): RewindResultDto =
        link.call(
            "chat.rewind",
            buildJsonObject {
                put("chatId", chatId)
                put("fromPromptId", fromPromptId)
            },
        ).decode(RewindResultDto.serializer())

    suspend fun turnFeedback(chatId: String, promptId: String, value: String) {
        link.call(
            "turn.feedback",
            buildJsonObject {
                put("chatId", chatId)
                put("promptId", promptId)
                put("value", value)
            },
        )
    }

    // ------------------------------------------------------------------ asking

    /**
     * `prompt`. [chatId] = null creates a new chat (the PC titles it). [modelId] absent keeps the chat's
     * model (or the default one for a new chat). The reply arrives BEFORE any event of the turn.
     */
    suspend fun prompt(
        chatId: String?,
        text: String,
        modelId: String?,
        attachments: List<String>,
        depth: Int,
        mode: String,
    ): PromptAckDto = link.call(
        "prompt",
        buildJsonObject {
            if (chatId == null) put("chatId", JsonNull) else put("chatId", chatId)
            modelId?.let { put("modelId", it) }
            put("text", text)
            if (attachments.isNotEmpty()) put("attachments", JsonArray(attachments.map { JsonPrimitive(it) }))
            put(
                "options",
                buildJsonObject {
                    put("depth", depth)
                    put("mode", mode)
                },
            )
        },
    ).decode(PromptAckDto.serializer())

    suspend fun turnCancel(chatId: String, promptId: String? = null) {
        link.call(
            "turn.cancel",
            buildJsonObject {
                put("chatId", chatId)
                promptId?.let { put("promptId", it) }
            },
        )
    }

    // ------------------------------------------------------------------ doubts

    suspend fun askAnswerDecision(askId: String, decision: String) {
        link.call(
            "ask.answer",
            buildJsonObject {
                put("askId", askId)
                put("decision", decision)
            },
        )
    }

    suspend fun askAnswerText(askId: String, text: String) {
        link.call(
            "ask.answer",
            buildJsonObject {
                put("askId", askId)
                put("text", text)
            },
        )
    }

    // ------------------------------------------------------------------ downloads

    suspend fun downloadsSet(chatIds: List<String>): List<String> =
        link.call("downloads.set", buildJsonObject { put("chatIds", JsonArray(chatIds.map { JsonPrimitive(it) })) })
            .decode(DownloadsSetResultDto.serializer()).chatIds

    suspend fun downloadsStatus(chatIds: List<String>): DownloadsStatusResultDto =
        link.call("downloads.status", buildJsonObject { put("chatIds", JsonArray(chatIds.map { JsonPrimitive(it) })) })
            .decode(DownloadsStatusResultDto.serializer())

    // ------------------------------------------------------------------ attachments

    suspend fun attachBegin(name: String, mime: String, size: Long): AttachBeginResultDto =
        link.call(
            "attach.begin",
            buildJsonObject {
                put("name", name)
                put("mime", mime)
                put("size", size)
            },
        ).decode(AttachBeginResultDto.serializer())

    suspend fun attachChunk(uploadId: String, index: Int, base64: String) {
        link.call(
            "attach.chunk",
            buildJsonObject {
                put("uploadId", uploadId)
                put("index", index)
                put("data", base64)
            },
        )
    }

    suspend fun attachEnd(uploadId: String, sha256Hex: String): AttachEndResultDto =
        link.call(
            "attach.end",
            buildJsonObject {
                put("uploadId", uploadId)
                put("sha256", sha256Hex)
            },
        ).decode(AttachEndResultDto.serializer())

    suspend fun attachAbort(uploadId: String) {
        link.call("attach.abort", buildJsonObject { put("uploadId", uploadId) })
    }

    // ------------------------------------------------------------------ device

    suspend fun deviceRename(name: String) {
        link.call("device.rename", buildJsonObject { put("name", name) })
    }

    suspend fun deviceUnpair() {
        link.call("device.unpair")
    }

    // ------------------------------------------------------------------ helpers

    private fun chatGetArgs(chatId: String, limit: Limit, after: String?, include: Set<String>) = buildJsonObject {
        put("chatId", chatId)
        putLimit(limit)
        putAfter(after)
        putInclude(include)
    }

    private fun JsonObjectBuilder.putLimit(limit: Limit) {
        when (limit) {
            is Limit.Count -> put("limit", limit.n)
            Limit.All -> put("limit", "all")
        }
    }

    private fun JsonObjectBuilder.putAfter(after: String?) {
        if (after != null) put("after", after)
    }

    private fun JsonObjectBuilder.putInclude(requested: Set<String>) {
        // The outline exists from revision 2 on; an older harness is not asked for it.
        val include = if (revision >= 2) requested else requested - "outline"
        if (include.isNotEmpty()) put("include", JsonArray(include.sorted().map { JsonPrimitive(it) }))
    }

    private fun <T> JsonElement.decode(serializer: KSerializer<T>): T = WireJson.decodeFromJsonElement(serializer, this)

    private fun <T> Flow<ListPart>.decodeParts(serializer: KSerializer<T>): Flow<T> =
        map { part -> WireJson.decodeFromJsonElement(serializer, part.raw) }

    companion object {
        val INCLUDE_THINKING_AND_TOOLS = setOf("thinking", "tools")
        val INCLUDE_THINKING = setOf("thinking")
    }
}
