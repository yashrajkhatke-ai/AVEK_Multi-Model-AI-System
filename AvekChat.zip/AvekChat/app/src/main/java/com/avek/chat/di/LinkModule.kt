package com.avek.chat.di

import android.app.Application
import android.content.Context
import com.avek.chat.core.common.TimeProvider
import com.avek.chat.core.data.fake.ResponseComposer
import com.avek.chat.core.data.fake.SimulatedInferenceEngine
import com.avek.chat.core.data.link.DemoLinkRepository
import com.avek.chat.core.data.link.SwitchingLinkRepository
import com.avek.chat.core.domain.usecase.TaskClassifier
import com.avek.chat.core.domain.usecase.TitleGenerator
import com.avek.chat.core.link.AppVisibility
import com.avek.chat.core.link.BackgroundHost
import com.avek.chat.core.link.DefaultLinkRepository
import com.avek.chat.core.link.HarnessApi
import com.avek.chat.core.link.LinkLifecycleController
import com.avek.chat.core.link.LinkRepository
import com.avek.chat.core.link.crypto.Handshake
import com.avek.chat.core.link.discovery.BeaconSource
import com.avek.chat.core.link.discovery.UdpBeaconSource
import com.avek.chat.core.link.pairing.PairingManager
import com.avek.chat.core.link.route.RouteFactory
import com.avek.chat.core.link.store.FilePairedPcStore
import com.avek.chat.core.link.store.PairedPcStore
import com.avek.chat.core.link.store.SecretVault
import com.avek.chat.core.link.transport.ChannelFactory
import com.avek.chat.core.link.transport.MulticastGuard
import com.avek.chat.core.link.transport.OkHttpChannelFactory
import com.avek.chat.core.link.transport.WifiBinding
import com.avek.chat.core.model.settings.UserSettings
import dagger.Binds
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import java.io.File
import javax.inject.Singleton

/** The link to the PC: storage, network, routes, the real repository and the built-in demo. */
@Module
@InstallIn(SingletonComponent::class)
abstract class LinkBindingsModule {
    @Binds @Singleton abstract fun bindVault(impl: com.avek.chat.platform.android.AndroidKeystoreVault): SecretVault
    @Binds @Singleton abstract fun bindWifiBinding(impl: com.avek.chat.platform.android.WifiNetworkBinder): WifiBinding
    @Binds @Singleton abstract fun bindMulticast(impl: com.avek.chat.platform.android.AndroidMulticastGuard): MulticastGuard
    @Binds @Singleton abstract fun bindVisibility(impl: com.avek.chat.platform.android.AppVisibilityTracker): AppVisibility
    @Binds @Singleton abstract fun bindBackgroundHost(impl: com.avek.chat.platform.android.AndroidBackgroundHost): BackgroundHost
    @Binds @Singleton abstract fun bindDeviceInfo(impl: com.avek.chat.platform.android.AndroidDeviceInfo): com.avek.chat.core.common.DeviceInfo
    @Binds @Singleton abstract fun bindAttachmentSources(impl: com.avek.chat.platform.android.AndroidAttachmentSourceFactory): com.avek.chat.core.domain.chat.AttachmentSourceFactory
}

@Module
@InstallIn(SingletonComponent::class)
object LinkModule {

    @Provides
    @Singleton
    fun providePairedPcStore(@ApplicationContext context: Context, vault: SecretVault): PairedPcStore =
        // `link/` is excluded from backups (backup_rules.xml, data_extraction_rules.xml).
        FilePairedPcStore(File(context.filesDir, "link/paired.json"), vault)

    @Provides
    @Singleton
    fun provideChannelFactory(binding: WifiBinding): ChannelFactory = OkHttpChannelFactory(binding = binding)

    @Provides
    @Singleton
    fun provideBeaconSource(binding: WifiBinding, multicast: MulticastGuard): BeaconSource = UdpBeaconSource(binding, multicast)

    @Provides
    @Singleton
    fun provideHandshake(): Handshake = Handshake()

    @Provides
    @Singleton
    fun providePairingManager(
        store: PairedPcStore,
        channels: ChannelFactory,
        beacons: BeaconSource,
        binding: WifiBinding,
        handshake: Handshake,
    ): PairingManager = PairingManager(store, channels, beacons, binding, handshake)

    @Provides
    @Singleton
    fun provideDefaultLink(
        store: PairedPcStore,
        settings: StateFlow<UserSettings>,
        channels: ChannelFactory,
        beacons: BeaconSource,
        binding: WifiBinding,
        handshake: Handshake,
        @ApplicationScope scope: CoroutineScope,
    ): DefaultLinkRepository = DefaultLinkRepository(
        store = store,
        routeSpecs = { settings.value.connection.routes },
        routeFactory = RouteFactory(channels, beacons),
        binding = binding,
        handshake = handshake,
        scope = scope,
    )

    @Provides
    @Singleton
    fun provideDemoLink(
        composer: ResponseComposer,
        classifier: TaskClassifier,
        titles: TitleGenerator,
        time: TimeProvider,
        @ApplicationScope scope: CoroutineScope,
    ): DemoLinkRepository = DemoLinkRepository(SimulatedInferenceEngine(composer, time), composer, classifier, titles, time, scope)

    /** What the rest of the app talks to: the real link, or the demo while "Demo mode" is on. */
    @Provides
    @Singleton
    fun provideLink(
        real: DefaultLinkRepository,
        demo: DemoLinkRepository,
        settings: StateFlow<UserSettings>,
        @ApplicationScope scope: CoroutineScope,
    ): LinkRepository = SwitchingLinkRepository(real, demo, settings.map { it.connection.demoMode }.distinctUntilChanged(), scope)

    @Provides
    @Singleton
    fun provideHarnessApi(link: LinkRepository): HarnessApi = HarnessApi(link)

    @Provides
    @Singleton
    fun provideLifecycleController(
        @ApplicationScope scope: CoroutineScope,
        visibility: AppVisibility,
        settings: StateFlow<UserSettings>,
        store: PairedPcStore,
        link: LinkRepository,
        background: BackgroundHost,
    ): LinkLifecycleController = LinkLifecycleController(
        scope = scope,
        visibility = visibility.visible,
        settings = settings.map { it.connection }.distinctUntilChanged(),
        pairing = store.pc,
        link = link,
        background = background,
    )
}
