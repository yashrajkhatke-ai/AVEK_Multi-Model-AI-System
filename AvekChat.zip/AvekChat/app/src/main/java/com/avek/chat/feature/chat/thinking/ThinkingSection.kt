package com.avek.chat.feature.chat.thinking

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AccountTree
import androidx.compose.material.icons.outlined.Build
import androidx.compose.material.icons.outlined.ErrorOutline
import androidx.compose.material.icons.outlined.KeyboardArrowDown
import androidx.compose.material.icons.outlined.Notes
import androidx.compose.material.icons.outlined.Psychology
import androidx.compose.material.icons.outlined.Subject
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.avek.chat.core.designsystem.theme.AvekTheme
import com.avek.chat.core.designsystem.theme.avekShape
import com.avek.chat.core.domain.timeline.BlockKind
import com.avek.chat.core.domain.timeline.CollapseRules
import com.avek.chat.core.domain.timeline.GroupSummary
import com.avek.chat.core.domain.timeline.LayoutItem
import com.avek.chat.core.domain.timeline.RowState
import com.avek.chat.core.domain.timeline.TimelineBlock
import com.avek.chat.core.domain.timeline.TurnTimeline
import com.avek.chat.core.model.settings.ThinkingSettings
import com.avek.chat.core.model.ToolCall
import com.avek.chat.feature.chat.ToolViewState
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement

/** Where the thinking section gets its data (the chat screen provides it). */
@Stable
interface TimelineEnvironment {
    /** The harness's revision: 2 or more = the timeline exists. */
    val revision: Int
    val demo: Boolean
    val settings: StateFlow<ThinkingSettings>

    /** The timeline of a turn; [live] = the turn runs now (joined late: fetched first). */
    fun timeline(chatId: String, promptId: String, live: Boolean): StateFlow<TurnTimeline>

    /** Fetch the texts of blocks the person opened (saved turns). */
    fun loadTexts(chatId: String, promptId: String, ids: List<String>)
}

val LocalTimelineEnvironment = compositionLocalOf<TimelineEnvironment?> { null }

/** Tool results ("Show result"): the stored body of a call, loaded with `tool.get`. */
class ToolResults(val views: (callId: String) -> ToolViewState?, val load: (ToolCall) -> Unit)

// ------------------------------------------------------------------ one turn

/**
 * The assistant side of a turn drawn from its timeline: groups (plain rows) and answers, in order.
 * [answer] draws an answer block's text (markdown, cursor on the last open answer).
 */
@Composable
fun TimelineTurn(
    timeline: TurnTimeline,
    startedAt: Long,
    results: ToolResults,
    answer: @Composable (text: String, streaming: Boolean) -> Unit,
    modifier: Modifier = Modifier,
) {
    val env = LocalTimelineEnvironment.current
    val settings by (env?.settings ?: remember { MutableStateFlow(ThinkingSettings()) }).collectAsState()
    val layout = remember(timeline) { timeline.layout }
    val lastGroupIndex = layout.indexOfLast { it is LayoutItem.Group }
    val lastAnswer = layout.lastOrNull { it is LayoutItem.Answer } as LayoutItem.Answer?
    Column(modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        layout.forEachIndexed { index, item ->
            key(item.key) {
                when (item) {
                    is LayoutItem.Group -> ThinkingGroup(
                        timeline = timeline,
                        group = item,
                        isLastGroup = index == lastGroupIndex,
                        settings = settings,
                        startedAt = startedAt,
                        results = results,
                    )
                    is LayoutItem.Answer -> answer(item.block.text, item == lastAnswer && item.block.running && timeline.live)
                }
            }
        }
    }
}

@Composable
fun ThinkingGroup(
    timeline: TurnTimeline,
    group: LayoutItem.Group,
    isLastGroup: Boolean,
    settings: ThinkingSettings,
    startedAt: Long,
    results: ToolResults,
) {
    val colors = AvekTheme.colors
    var userChoice by rememberSaveable(timeline.key.chatId, timeline.key.promptId, group.key) { mutableStateOf<Boolean?>(null) }
    val expanded = CollapseRules.groupExpanded(group, timeline.live, isLastGroup, userChoice, settings.keepRunningGroupOpen)
    val running = timeline.live && group.running
    val chevron by animateFloatAsState(if (expanded) 180f else 0f, label = "group-chevron")
    val now by produceState(System.currentTimeMillis(), running) {
        while (running) {
            value = System.currentTimeMillis()
            delay(500)
        }
    }
    val summary = if (running) "Thinking..." else GroupSummary.of(group)
    Column(Modifier.fillMaxWidth().animateContentSize()) {
        Row(
            Modifier
                .fillMaxWidth()
                .clip(avekShape(8.dp))
                .clickable { userChoice = !expanded }
                .semantics { contentDescription = summary; stateDescription = if (expanded) "expanded" else "collapsed" }
                .padding(vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (running) Spinner(colors.thinkingGlow) else Icon(Icons.Outlined.Psychology, null, tint = colors.textTertiary, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text(summary, style = AvekTheme.type.label, color = colors.textSecondary, maxLines = 1)
            if (running && startedAt > 0) {
                Spacer(Modifier.width(6.dp))
                Text("${((now - startedAt) / 1000).coerceAtLeast(0)} s", style = AvekTheme.type.caption, color = colors.textTertiary)
            }
            Spacer(Modifier.width(2.dp))
            Icon(Icons.Outlined.KeyboardArrowDown, null, tint = colors.textTertiary, modifier = Modifier.size(18.dp).rotate(chevron))
        }
        AnimatedVisibility(expanded, enter = expandVertically() + fadeIn(), exit = shrinkVertically() + fadeOut()) {
            Column(Modifier.padding(start = 4.dp)) {
                group.blocks.forEach { block -> key(block.id) { BlockRow(timeline, block, 0, settings, results) } }
            }
        }
    }
}

// ------------------------------------------------------------------ rows

@Composable
private fun BlockRow(timeline: TurnTimeline, block: TimelineBlock, depth: Int, settings: ThinkingSettings, results: ToolResults) {
    val env = LocalTimelineEnvironment.current
    var row by rememberSaveable(timeline.key.chatId, timeline.key.promptId, block.id, stateSaver = RowSaver) { mutableStateOf(RowState()) }
    // A thinking block that ends closes by itself (unless pinned after it ended).
    var wasRunning by remember(block.id) { mutableStateOf(block.running) }
    LaunchedEffect(block.ended) {
        if (wasRunning && block.ended) row = CollapseRules.onEnd(block.kind, row, settings.collapseWhenEnds)
        wasRunning = block.running
    }
    // Opening a row of a saved turn fetches its text.
    LaunchedEffect(row.expanded, block.textMissing) {
        if (row.expanded && block.textMissing) env?.loadTexts(timeline.key.chatId, timeline.key.promptId, listOf(block.id))
    }
    val toggle = { row = CollapseRules.onTap(row, block.ended) }
    val children = remember(timeline, block.id) { timeline.children(block.id) }
    Column(Modifier.fillMaxWidth()) {
        when (block.kind) {
            BlockKind.TOOL -> ToolHeading(block, row.expanded, toggle)
            BlockKind.AGENT -> AgentHeading(block, row.expanded, toggle)
            else -> Heading(
                icon = when (block.kind) {
                    BlockKind.NOTE -> Icons.Outlined.Notes
                    BlockKind.ANSWER -> Icons.Outlined.Subject
                    else -> Icons.Outlined.Psychology
                },
                text = block.title.ifEmpty { if (block.kind == BlockKind.ANSWER) "Output" else "Thinking" },
                sub = null,
                running = block.running && timeline.live,
                tint = AvekTheme.colors.thinkingGlow,
                expanded = row.expanded,
                state = if (block.running) "streaming" else "done",
                onClick = toggle,
            )
        }
        AnimatedVisibility(row.expanded, enter = expandVertically() + fadeIn(), exit = shrinkVertically() + fadeOut()) {
            Column(Modifier.padding(start = 26.dp, bottom = 6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                when (block.kind) {
                    BlockKind.TOOL -> ToolCard(block, timeline.live, results)
                    BlockKind.AGENT -> Unit
                    else -> TextCard(block, monospace = false)
                }
                // The infra tree under a tool (agents, notes) and an agent's own rows.
                if (children.isNotEmpty()) {
                    Tree(depth) { children.forEach { child -> key(child.id) { BlockRow(timeline, child, depth + 1, settings, results) } } }
                }
            }
        }
    }
}

@Composable
private fun Tree(depth: Int, content: @Composable () -> Unit) {
    val colors = AvekTheme.colors
    Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min).padding(start = if (depth < 3) 2.dp else 0.dp)) {
        Box(Modifier.width(1.5.dp).fillMaxHeight().background(colors.outline))
        Spacer(Modifier.width(if (depth < 3) 12.dp else 6.dp))
        Column(Modifier.weight(1f)) { content() }
    }
}

@Composable
private fun ToolHeading(block: TimelineBlock, expanded: Boolean, onClick: () -> Unit) {
    val colors = AvekTheme.colors
    val tint = when {
        block.state == "error" -> colors.danger
        block.state == "writing" -> colors.thinkingGlow
        block.state == "running" -> colors.accent
        else -> colors.textTertiary
    }
    val sub = listOfNotNull(
        block.summary?.title?.takeIf { it.isNotBlank() },
        (block.summary?.detail ?: block.detail)?.takeIf { it.isNotBlank() },
        block.tool?.owner?.takeIf { it.isNotBlank() && it != "core" },
    ).joinToString(" · ").ifEmpty { null }
    Heading(
        icon = if (block.state == "error") Icons.Outlined.ErrorOutline else Icons.Outlined.Build,
        text = block.title.ifEmpty { "Tool calling" },
        sub = sub,
        running = block.running,
        tint = tint,
        expanded = expanded,
        state = block.state,
        onClick = onClick,
    )
}

@Composable
private fun AgentHeading(block: TimelineBlock, expanded: Boolean, onClick: () -> Unit) {
    val colors = AvekTheme.colors
    val agent = block.agent
    val stateText = when (block.state) {
        "waiting" -> "Waiting for memory"
        "working" -> "Working"
        "done" -> "Done"
        "cancelled" -> "Cancelled"
        else -> "Failed"
    }
    Row(
        Modifier
            .fillMaxWidth()
            .clip(avekShape(8.dp))
            .clickable(onClick = onClick)
            .semantics { contentDescription = "${agent?.role ?: "agent"} ${agent?.label ?: block.title}, $stateText" }
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (block.running) Spinner(colors.accent) else Icon(Icons.Outlined.AccountTree, null, tint = colors.textTertiary, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(8.dp))
        Text(
            (agent?.role ?: "agent"),
            style = AvekTheme.type.caption.copy(fontWeight = FontWeight.Medium),
            color = colors.thinkingGlow,
            modifier = Modifier.clip(avekShape(6.dp)).background(colors.accentContainer).padding(horizontal = 6.dp, vertical = 1.dp),
        )
        Spacer(Modifier.width(6.dp))
        Column(Modifier.weight(1f)) {
            Text(agent?.label ?: block.title, style = AvekTheme.type.label, color = colors.textSecondary, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                listOfNotNull(agent?.modelName, stateText).joinToString(" · "),
                style = AvekTheme.type.caption, color = colors.textTertiary, maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
        }
        Chevron(expanded)
    }
}

@Composable
private fun Heading(
    icon: ImageVector,
    text: String,
    sub: String?,
    running: Boolean,
    tint: Color,
    expanded: Boolean,
    state: String,
    onClick: () -> Unit,
) {
    val colors = AvekTheme.colors
    Row(
        Modifier
            .fillMaxWidth()
            .clip(avekShape(8.dp))
            .clickable(onClick = onClick)
            .semantics {
                contentDescription = text
                stateDescription = "$state, ${if (expanded) "tap to hide" else "tap to show"}"
            }
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (running) Spinner(tint) else Icon(icon, null, tint = if (state == "error") colors.danger else colors.textTertiary, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(8.dp))
        Column(Modifier.weight(1f, fill = false)) {
            // The harness renames a thinking block once it has enough text: a short cross-fade.
            Crossfade(text, label = "heading") { title ->
                Text(title, style = AvekTheme.type.label, color = if (running) colors.textPrimary else colors.textSecondary, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            if (sub != null) Text(sub, style = AvekTheme.type.caption, color = colors.textTertiary, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Chevron(expanded)
    }
}

@Composable
private fun Chevron(expanded: Boolean) {
    val rotation by animateFloatAsState(if (expanded) 180f else 0f, label = "chevron")
    Icon(Icons.Outlined.KeyboardArrowDown, null, tint = AvekTheme.colors.textTertiary, modifier = Modifier.size(18.dp).rotate(rotation))
}

@Composable
private fun Spinner(color: Color) {
    CircularProgressIndicator(Modifier.padding(2.dp).size(14.dp), color = color, strokeWidth = 1.6.dp)
}

// ------------------------------------------------------------------ cards

@Composable
private fun Card(scrollWhenLong: Boolean, content: @Composable () -> Unit) {
    val colors = AvekTheme.colors
    val scroll = rememberScrollState()
    Box(
        Modifier
            .fillMaxWidth()
            .clip(avekShape(14.dp))
            .background(colors.thinkingSurface)
            .border(1.dp, colors.outline.copy(alpha = 0.5f), avekShape(14.dp))
            .animateContentSize()
            // While it streams the card grows with the text; a long finished text gets its own scroll.
            .then(if (scrollWhenLong) Modifier.heightIn(max = 320.dp).verticalScroll(scroll) else Modifier)
            .padding(12.dp),
    ) { content() }
}

/** The exact text of a thinking / output / note block. */
@Composable
private fun TextCard(block: TimelineBlock, monospace: Boolean) {
    val colors = AvekTheme.colors
    Card(scrollWhenLong = block.ended) {
        SelectionContainer {
            Text(
                when {
                    block.text.isNotEmpty() -> block.text.trimStart('\n')
                    block.textMissing -> "Loading…"
                    block.running -> "…"
                    else -> "No text."
                },
                style = if (monospace) AvekTheme.type.code else AvekTheme.type.thinking,
                color = colors.thinkingText,
            )
        }
        if (block.truncated) Text("(cut by the PC)", style = AvekTheme.type.caption, color = colors.textTertiary)
    }
}

/** A tool call as the model writes it, then "Running...", then the result. */
@Composable
private fun ToolCard(block: TimelineBlock, turnLive: Boolean, results: ToolResults) {
    val colors = AvekTheme.colors
    val writing = block.state == "writing"
    val shown = remember(block.args, writing) { if (!writing) prettyJson(block.args) ?: block.args else block.args }
    Card(scrollWhenLong = block.ended) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            SelectionContainer {
                Text(
                    buildAnnotatedString {
                        append(if (shown.isEmpty() && !block.textMissing) (if (writing) "" else "No arguments.") else if (block.textMissing && shown.isEmpty()) "Loading…" else shown)
                        if (writing && turnLive) {
                            pushStyle(SpanStyle(color = colors.thinkingGlow))
                            append(if (cursorVisible()) "▍" else " ")
                            pop()
                        }
                    },
                    style = AvekTheme.type.code.copy(fontSize = AvekTheme.type.caption.fontSize),
                    color = colors.codeText,
                )
            }
            if (block.state == "running") Text("Running...", style = AvekTheme.type.caption, color = colors.accent)
            if (block.ended) {
                block.summary?.let { s ->
                    Text(listOfNotNull(s.title, s.detail).joinToString(" · "), style = AvekTheme.type.caption, color = colors.textSecondary)
                }
                val callId = block.tool?.callId
                if (callId != null) {
                    when (val view = results.views(callId)) {
                        is ToolViewState.Loaded -> SelectionContainer {
                            Text(view.view.body, style = AvekTheme.type.code.copy(fontSize = AvekTheme.type.caption.fontSize), color = colors.codeText)
                        }
                        ToolViewState.Loading -> Text("Loading…", style = AvekTheme.type.caption, color = colors.textTertiary)
                        is ToolViewState.Failed -> Text(view.message, style = AvekTheme.type.caption, color = colors.danger)
                        null -> TextButton(onClick = {
                            results.load(ToolCall(callId, block.tool?.name.orEmpty(), block.summary?.title ?: block.title, block.summary?.detail, block.ok))
                        }) { Text("Show result", color = colors.accent) }
                    }
                }
            }
        }
    }
}

@Composable
private fun cursorVisible(): Boolean {
    if (AvekTheme.motion.reduceMotion) return true
    val blink by rememberInfiniteTransition(label = "cursor").animateFloat(0f, 1f, infiniteRepeatable(tween(500), RepeatMode.Reverse), label = "blink")
    return blink > 0.5f
}

private val prettyPrinter = Json { prettyPrint = true }

/** Pretty-printed only when the text is complete, valid JSON. */
fun prettyJson(text: String): String? {
    val trimmed = text.trim()
    if (!(trimmed.startsWith("{") || trimmed.startsWith("["))) return null
    return try {
        prettyPrinter.encodeToString(JsonElement.serializer(), Json.parseToJsonElement(trimmed))
    } catch (_: Exception) {
        null
    }
}

private val RowSaver = androidx.compose.runtime.saveable.Saver<RowState, List<Boolean>>(
    save = { listOf(it.expanded, it.pinned) },
    restore = { RowState(it[0], it[1]) },
)

// ------------------------------------------------------------------ old turns (no timeline)

/**
 * A turn written before revision 2 (or a downloaded copy): one row "Thought for 12 s" that opens the
 * stored reasoning, and one row per stored tool call. Same look, no tree.
 */
@Composable
fun LegacyThinking(
    thinking: String?,
    hasThinking: Boolean,
    thinkingMs: Long,
    streaming: Boolean,
    tools: List<ToolCall>,
    results: ToolResults,
    onLoadThinking: () -> Unit,
) {
    val colors = AvekTheme.colors
    Column(Modifier.fillMaxWidth()) {
        if (hasThinking) {
            var expanded by rememberSaveable { mutableStateOf(false) }
            LaunchedEffect(expanded) { if (expanded && thinking == null && !streaming) onLoadThinking() }
            val seconds = (thinkingMs + 500) / 1000
            Heading(
                icon = Icons.Outlined.Psychology,
                text = if (streaming) "Thinking..." else if (seconds < 1) "Thought for a moment" else "Thought for $seconds s",
                sub = null,
                running = streaming,
                tint = colors.thinkingGlow,
                expanded = expanded,
                state = if (streaming) "streaming" else "done",
                onClick = { expanded = !expanded },
            )
            AnimatedVisibility(expanded, enter = expandVertically() + fadeIn(), exit = shrinkVertically() + fadeOut()) {
                Box(Modifier.padding(start = 26.dp, bottom = 6.dp)) {
                    Card(scrollWhenLong = !streaming) {
                        SelectionContainer {
                            Text(
                                when {
                                    thinking == null -> "Loading…"
                                    thinking.isBlank() -> "No reasoning text was kept for this turn."
                                    else -> thinking
                                },
                                style = AvekTheme.type.thinking, color = colors.thinkingText,
                            )
                        }
                    }
                }
            }
        }
        tools.forEach { call ->
            key(call.callId) {
                var expanded by rememberSaveable { mutableStateOf(false) }
                val name = call.name.ifEmpty { call.title }
                Heading(
                    icon = if (call.ok == false) Icons.Outlined.ErrorOutline else Icons.Outlined.Build,
                    text = when {
                        call.ok == null && streaming -> "Tool calling for $name"
                        call.ok == false -> "Tool call failed for $name"
                        else -> "Tool called for $name"
                    },
                    sub = listOfNotNull(call.title.takeIf { it.isNotBlank() && it != name }, call.detail).joinToString(" · ").ifEmpty { null },
                    running = call.ok == null && streaming,
                    tint = colors.accent,
                    expanded = expanded,
                    state = if (call.ok == null) "running" else "done",
                    onClick = {
                        expanded = !expanded
                        if (expanded && results.views(call.callId) == null) results.load(call)
                    },
                )
                AnimatedVisibility(expanded) {
                    Box(Modifier.padding(start = 26.dp, bottom = 6.dp)) {
                        Card(scrollWhenLong = true) {
                            when (val view = results.views(call.callId)) {
                                is ToolViewState.Loaded -> SelectionContainer {
                                    Text(view.view.body.ifEmpty { view.view.detail }, style = AvekTheme.type.code.copy(fontSize = AvekTheme.type.caption.fontSize), color = colors.codeText)
                                }
                                is ToolViewState.Failed -> Text(view.message, style = AvekTheme.type.caption, color = colors.danger)
                                else -> Text("Loading…", style = AvekTheme.type.caption, color = colors.textTertiary)
                            }
                        }
                    }
                }
            }
        }
    }
}
