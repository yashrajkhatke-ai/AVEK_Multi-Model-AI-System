package com.avek.chat.feature.chat.thinking

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.QueryStats
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.avek.chat.core.designsystem.theme.AvekTheme
import com.avek.chat.core.domain.trace.TurnTelemetry
import com.avek.chat.core.link.wire.TraceRuntimeDto
import com.avek.chat.core.markdown.MarkdownContent
import com.avek.chat.feature.chat.thinking.panels.ConsolePanel
import com.avek.chat.feature.chat.thinking.panels.ContextBarPanel
import com.avek.chat.feature.chat.thinking.panels.DashboardPanel
import com.avek.chat.feature.chat.thinking.panels.HeatStripPanel
import com.avek.chat.feature.chat.thinking.panels.LoopGraphPanel
import com.avek.chat.feature.chat.thinking.panels.PanelGap
import com.avek.chat.feature.chat.thinking.panels.PanelTitle
import com.avek.chat.feature.chat.thinking.panels.PhaseTimelinePanel
import com.avek.chat.feature.chat.thinking.panels.RuntimePanel
import com.avek.chat.feature.chat.thinking.panels.ThroughputPanel
import com.avek.chat.feature.chat.thinking.panels.TokenLedgerPanel
import com.avek.chat.feature.chat.thinking.panels.ToolCardsPanel
import com.avek.chat.feature.chat.thinking.panels.WaterfallPanel
import com.avek.chat.feature.chat.thinking.panels.rememberNow
import kotlinx.coroutines.flow.StateFlow

/** Long-press on the header: every style with a small live preview fed by the same turn. */
@Composable
fun ThinkingStyleSwitcher(
    t: TurnTelemetry,
    thinkingText: String,
    selectedId: String,
    onSelect: (String) -> Unit,
    onOpenInspector: () -> Unit,
    onDismiss: () -> Unit,
) {
    val colors = AvekTheme.colors
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = colors.chatBackground,
        scrimColor = colors.scrim,
    ) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Display style", style = AvekTheme.type.title, color = colors.textPrimary, modifier = Modifier.weight(1f))
            TextButton(onClick = onOpenInspector) {
                Icon(Icons.Outlined.QueryStats, null, tint = colors.accent, modifier = Modifier.padding(end = 6.dp))
                Text("Open inspector", color = colors.accent)
            }
        }
        LazyColumn(
            Modifier.navigationBarsPadding(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            item(key = ThinkingStyleCatalog.AUTO) {
                val resolved = ThinkingStyleCatalog.resolve(ThinkingStyleCatalog.AUTO, t)
                StyleOption(
                    name = ThinkingStyleCatalog.AUTO_NAME,
                    description = "${ThinkingStyleCatalog.AUTO_DESCRIPTION}. Now: ${resolved.name}",
                    selected = selectedId == ThinkingStyleCatalog.AUTO,
                    onClick = { onSelect(ThinkingStyleCatalog.AUTO); onDismiss() },
                ) { resolved.content(t, thinkingText, ThinkingMode.Compact, Modifier) }
            }
            items(ThinkingStyleCatalog.styles, key = { it.id }) { style ->
                StyleOption(
                    name = style.name,
                    description = style.description,
                    selected = selectedId == style.id,
                    onClick = { onSelect(style.id); onDismiss() },
                ) { style.content(t, thinkingText, ThinkingMode.Compact, Modifier) }
            }
        }
    }
}

@Composable
private fun StyleOption(name: String, description: String, selected: Boolean, onClick: () -> Unit, preview: @Composable () -> Unit) {
    val colors = AvekTheme.colors
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(if (selected) colors.accentContainer else colors.thinkingSurface)
            .border(1.dp, if (selected) colors.accent else colors.outline.copy(alpha = 0.5f), RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(12.dp),
    ) {
        Text(name, style = AvekTheme.type.label.copy(fontWeight = FontWeight.SemiBold), color = colors.textPrimary)
        Text(description, style = AvekTheme.type.caption, color = colors.textSecondary)
        Spacer(Modifier.height(8.dp))
        preview()
    }
}

private enum class InspectorTab(val label: String) {
    OVERVIEW("Overview"), CONTEXT("Context"), TOKENS("Tokens"), TOOLS("Tools"),
    TIMELINE("Timeline"), RUNTIME("Runtime"), LOG("Log"), THOUGHTS("Thoughts"),
}

/** The full-screen inspector: the same data and panels as the styles, one tab per area. */
@Composable
fun ThinkingInspector(
    t: TurnTelemetry,
    thinkingText: String?,
    runtime: StateFlow<TraceRuntimeDto?>?,
    onRefreshRuntime: () -> Unit,
    onLoadThinking: () -> Unit,
    onDismiss: () -> Unit,
) {
    val colors = AvekTheme.colors
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val now by rememberNow(t.live)
    val pcRuntime = runtime?.collectAsState()?.value
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(Modifier.fillMaxSize().background(colors.chatBackground).statusBarsPadding().navigationBarsPadding()) {
            Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 4.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Inspector", style = AvekTheme.type.title, color = colors.textPrimary)
                    Text(
                        listOfNotNull(t.modelName.ifEmpty { null }, if (t.live) "live" else if (t.hasTrace) "finished" else null, if (t.demo) "Demo: no telemetry" else null).joinToString(" · ").ifEmpty { ThinkingFormat.NONE },
                        style = AvekTheme.type.caption, color = colors.textSecondary,
                    )
                }
                IconButton(onClick = onDismiss) { Icon(Icons.Outlined.Close, contentDescription = "Close the inspector", tint = colors.textSecondary) }
            }
            ScrollableTabRow(selectedTabIndex = tab, containerColor = colors.chatBackground, contentColor = colors.accent, edgePadding = 12.dp) {
                InspectorTab.entries.forEachIndexed { i, entry ->
                    Tab(selected = tab == i, onClick = { tab = i }, text = { Text(entry.label) })
                }
            }
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
                when (InspectorTab.entries[tab]) {
                    InspectorTab.OVERVIEW -> {
                        DashboardPanel(t, ThinkingFormat.phaseLabel(t, t.live), t.elapsedMs(now), compact = false)
                        PanelGap()
                        PanelTitle("Throughput")
                        ThroughputPanel(t, compact = false)
                        PanelGap()
                        PanelTitle("Model calls")
                        LoopGraphPanel(t, compact = false)
                    }
                    InspectorTab.CONTEXT -> ContextBarPanel(t, compact = false)
                    InspectorTab.TOKENS -> {
                        TokenLedgerPanel(t, compact = false)
                        PanelGap()
                        PanelTitle("Every token")
                        HeatStripPanel(t, compact = false)
                    }
                    InspectorTab.TOOLS -> ToolCardsPanel(t, compact = false)
                    InspectorTab.TIMELINE -> {
                        PanelTitle("Phases")
                        PhaseTimelinePanel(t, now, compact = false)
                        PanelGap()
                        PanelTitle("Waterfall")
                        WaterfallPanel(t, now, compact = false)
                    }
                    InspectorTab.RUNTIME -> {
                        // When no turn runs, ask the PC (`runtime.get`).
                        LaunchedEffect(Unit) { if (!t.live) onRefreshRuntime() }
                        val shown = if (t.live) t.runtime ?: pcRuntime else pcRuntime ?: t.runtime
                        RuntimePanel(shown, compact = false)
                    }
                    InspectorTab.LOG -> {
                        var paused by remember { mutableStateOf(false) }
                        ConsolePanel(t, compact = false, paused = paused, modifier = Modifier.clickable { paused = !paused })
                    }
                    InspectorTab.THOUGHTS -> {
                        LaunchedEffect(Unit) { if (thinkingText == null) onLoadThinking() }
                        when {
                            thinkingText == null -> Text("Loading reasoning…", style = AvekTheme.type.thinking, color = colors.textTertiary)
                            thinkingText.isBlank() -> Text("No reasoning text was kept for this turn.", style = AvekTheme.type.thinking, color = colors.textTertiary)
                            else -> MarkdownContent(markdown = thinkingText, textStyle = AvekTheme.type.thinking, color = colors.thinkingText)
                        }
                    }
                }
            }
        }
    }
}
