package com.avek.chat.core.common

/** Facts about this device that pure code needs (the Android implementation reads `Build`). */
interface DeviceInfo {
    /** e.g. "Pixel Tablet": the default device name when pairing. */
    val model: String
}
