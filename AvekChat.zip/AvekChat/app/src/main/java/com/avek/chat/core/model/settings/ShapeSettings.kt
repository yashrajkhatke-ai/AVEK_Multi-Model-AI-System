package com.avek.chat.core.model.settings

import kotlinx.serialization.Serializable

@Serializable
enum class CornerStyle(val label: String, val description: String) {
    ROUNDED("Rounded", "Classic circular corners"),
    SMOOTH("Smooth", "Continuous, squircle-like corners"),
    CUT("Cut", "Chamfered, angular corners"),
}

/**
 * Global corner treatment for every surface in the app (composer, cards, chips,
 * sheets, menus, buttons). [roundness] scales each component's designed radius:
 * 0 = perfectly square, 1 = original design, 1.5 = extra soft.
 */
@Serializable
data class ShapeSettings(
    val roundness: Float = 0.55f,
    val style: CornerStyle = CornerStyle.SMOOTH,
)
