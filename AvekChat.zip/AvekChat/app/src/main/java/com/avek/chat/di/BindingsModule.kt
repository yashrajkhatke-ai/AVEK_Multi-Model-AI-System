package com.avek.chat.di

import com.avek.chat.core.data.fake.SimulatedInferenceEngine
import com.avek.chat.core.data.fonts.DefaultFontCatalogRepository
import com.avek.chat.core.data.fonts.FontCatalogSource
import com.avek.chat.core.data.repository.OfflineConversationRepository
import com.avek.chat.core.data.repository.StaticModelRepository
import com.avek.chat.core.data.settings.DataStoreSettingsRepository
import com.avek.chat.core.designsystem.theme.FontResolver
import com.avek.chat.core.domain.engine.InferenceEngine
import com.avek.chat.core.domain.repository.ConversationRepository
import com.avek.chat.core.domain.repository.FontCatalogRepository
import com.avek.chat.core.domain.repository.ModelRepository
import com.avek.chat.core.domain.repository.SettingsRepository
import com.avek.chat.platform.android.AssetFontCatalogSource
import com.avek.chat.platform.android.GoogleFontResolver
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/**
 * Interface → implementation bindings. Swapping the simulated engine for a
 * real one is a one-line change to [bindInferenceEngine].
 */
@Module
@InstallIn(SingletonComponent::class)
abstract class BindingsModule {

    @Binds
    @Singleton
    abstract fun bindConversationRepository(impl: OfflineConversationRepository): ConversationRepository

    @Binds
    @Singleton
    abstract fun bindModelRepository(impl: StaticModelRepository): ModelRepository

    @Binds
    @Singleton
    abstract fun bindSettingsRepository(impl: DataStoreSettingsRepository): SettingsRepository

    @Binds
    @Singleton
    abstract fun bindFontCatalogRepository(impl: DefaultFontCatalogRepository): FontCatalogRepository

    @Binds
    abstract fun bindFontCatalogSource(impl: AssetFontCatalogSource): FontCatalogSource

    @Binds
    @Singleton
    abstract fun bindFontResolver(impl: GoogleFontResolver): FontResolver

    @Binds
    @Singleton
    abstract fun bindInferenceEngine(impl: SimulatedInferenceEngine): InferenceEngine
}
