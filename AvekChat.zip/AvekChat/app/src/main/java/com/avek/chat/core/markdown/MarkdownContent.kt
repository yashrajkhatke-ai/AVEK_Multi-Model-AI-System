package com.avek.chat.core.markdown

import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.InlineTextContent
import androidx.compose.foundation.text.appendInlineContent
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.Placeholder
import androidx.compose.ui.text.PlaceholderVerticalAlign
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import com.avek.chat.core.designsystem.theme.AvekTheme
import com.avek.chat.core.designsystem.theme.ColorMath
import kotlinx.coroutines.delay

private const val CURSOR_ID = "streaming-cursor"

/**
 * Renders Markdown with the app's typography. Used for answers (answer font),
 * thinking (thinking font) and anywhere else rich text appears.
 *
 * @param trailing optional inline content (e.g. a streaming cursor) placed
 *   right after the last word of the final text block.
 */
@Composable
fun MarkdownContent(
    markdown: String,
    textStyle: TextStyle,
    color: Color,
    modifier: Modifier = Modifier,
    onCopyCode: (String) -> Unit = {},
    showLineNumbers: Boolean = true,
    trailing: (@Composable () -> Unit)? = null,
) {
    val blocks = remember(markdown) { MarkdownParser.parse(markdown) }
    val colors = AvekTheme.colors
    val codeStyle = AvekTheme.type.code
    val inline = remember(colors, codeStyle) {
        InlineStyles(
            codeFamily = codeStyle.fontFamily,
            codeBackground = colors.codeSurface,
            codeColor = colors.codeText,
            link = colors.accent,
            citation = colors.accent,
        )
    }
    val blockGap = (textStyle.fontSize.value * 0.75f).dp
    val lastTextIndex = blocks.indexOfLast { it is MdBlock.Paragraph || it is MdBlock.Bullets || it is MdBlock.Numbered || it is MdBlock.Heading }
    val cursorInline = trailing?.let { cursor ->
        mapOf(
            CURSOR_ID to InlineTextContent(Placeholder(0.9.em, 1.em, PlaceholderVerticalAlign.TextCenter)) { cursor() },
        )
    } ?: emptyMap()

    Column(modifier, verticalArrangement = Arrangement.spacedBy(blockGap)) {
        blocks.forEachIndexed { index, block ->
            val withCursor = trailing != null && index == lastTextIndex && index == blocks.lastIndex
            fun AnnotatedString.maybeCursor(): AnnotatedString =
                if (withCursor) buildAnnotatedString { append(this@maybeCursor); append(' '); appendInlineContent(CURSOR_ID, "▍") } else this

            when (block) {
                is MdBlock.Heading -> {
                    val scale = when (block.level) {
                        1 -> 1.45f
                        2 -> 1.25f
                        3 -> 1.1f
                        else -> 1f
                    }
                    Text(
                        InlineMarkdown.render(block.text, inline).maybeCursor(),
                        style = textStyle.copy(
                            fontSize = textStyle.fontSize * scale,
                            lineHeight = textStyle.lineHeight * scale,
                            fontWeight = FontWeight.SemiBold,
                        ),
                        color = color,
                        inlineContent = cursorInline,
                        modifier = Modifier.padding(top = if (index == 0) 0.dp else 4.dp),
                    )
                }
                is MdBlock.Paragraph -> Text(
                    InlineMarkdown.render(block.text, inline).maybeCursor(),
                    style = textStyle,
                    color = color,
                    inlineContent = cursorInline,
                )
                is MdBlock.Bullets -> ListBlock(
                    items = block.items.map { it.indent to InlineMarkdown.render(it.text, inline) },
                    marker = { "•" },
                    textStyle = textStyle,
                    color = color,
                    lastSuffix = { it.maybeCursor() },
                    inlineContent = cursorInline,
                )
                is MdBlock.Numbered -> ListBlock(
                    items = block.items.map { it.indent to InlineMarkdown.render(it.text, inline) },
                    marker = { i -> "${block.start + i}." },
                    textStyle = textStyle,
                    color = color,
                    lastSuffix = { it.maybeCursor() },
                    inlineContent = cursorInline,
                )
                is MdBlock.Quote -> Row(Modifier.height(IntrinsicSize.Min)) {
                    Box(
                        Modifier
                            .width(3.dp)
                            .fillMaxHeight()
                            .clip(RoundedCornerShape(2.dp))
                            .background(colors.accent.copy(alpha = 0.6f)),
                    )
                    Spacer(Modifier.width(12.dp))
                    Text(
                        InlineMarkdown.render(block.text, inline),
                        style = textStyle,
                        color = ColorMath.mix(color, colors.textSecondary, 0.5f),
                    )
                }
                is MdBlock.Code -> CodeBlock(block, onCopyCode, showLineNumbers)
                is MdBlock.Table -> TableBlock(block, textStyle, color, inline)
                MdBlock.Rule -> HorizontalDivider(color = colors.outline)
            }
        }
        if (trailing != null && lastTextIndex != blocks.lastIndex) {
            Box(Modifier.size(width = 14.dp, height = 18.dp)) { trailing() }
        }
    }
}

@Composable
private fun ListBlock(
    items: List<Pair<Int, AnnotatedString>>,
    marker: (Int) -> String,
    textStyle: TextStyle,
    color: Color,
    lastSuffix: (AnnotatedString) -> AnnotatedString,
    inlineContent: Map<String, InlineTextContent>,
) {
    Column(verticalArrangement = Arrangement.spacedBy((textStyle.fontSize.value * 0.35f).dp)) {
        items.forEachIndexed { i, (indent, text) ->
            Row(Modifier.padding(start = (indent * 18).dp)) {
                Text(
                    marker(i),
                    style = textStyle.copy(fontWeight = FontWeight.Medium),
                    color = AvekTheme.colors.textSecondary,
                    modifier = Modifier.widthIn(min = (textStyle.fontSize.value * 1.4f).dp),
                )
                Text(
                    if (i == items.lastIndex) lastSuffix(text) else text,
                    style = textStyle,
                    color = color,
                    inlineContent = inlineContent,
                )
            }
        }
    }
}

@Composable
private fun CodeBlock(block: MdBlock.Code, onCopy: (String) -> Unit, showLineNumbers: Boolean) {
    val colors = AvekTheme.colors
    val codeStyle = AvekTheme.type.code
    val syntax = remember(colors) {
        SyntaxColors(
            plain = colors.codeText,
            keyword = colors.accent,
            string = ColorMath.readableOn(colors.codeSurface, ColorMath.hsl(140f, 0.45f, if (colors.isDark) 0.65f else 0.32f), 3.5f),
            comment = colors.textTertiary,
            number = ColorMath.readableOn(colors.codeSurface, ColorMath.hsl(28f, 0.7f, if (colors.isDark) 0.66f else 0.42f), 3.5f),
            type = ColorMath.readableOn(colors.codeSurface, ColorMath.hsl(205f, 0.55f, if (colors.isDark) 0.7f else 0.38f), 3.5f),
            annotation = ColorMath.readableOn(colors.codeSurface, ColorMath.hsl(285f, 0.45f, if (colors.isDark) 0.72f else 0.45f), 3.5f),
        )
    }
    val highlighted = remember(block.code, block.language, syntax) { SyntaxHighlighter.highlight(block.code, block.language, syntax) }
    var copied by remember { mutableStateOf(false) }
    LaunchedEffect(copied) {
        if (copied) {
            delay(1600)
            copied = false
        }
    }

    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(colors.codeSurface)
            .border(1.dp, colors.outline.copy(alpha = 0.5f), RoundedCornerShape(14.dp)),
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .background(colors.textPrimary.copy(alpha = 0.04f))
                .padding(start = 14.dp, end = 6.dp, top = 4.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                block.language.ifBlank { "code" },
                style = AvekTheme.type.caption.copy(fontWeight = FontWeight.Medium),
                color = colors.textSecondary,
                modifier = Modifier.weight(1f),
            )
            Row(
                Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .clickable {
                        onCopy(block.code)
                        copied = true
                    }
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                AnimatedContent(copied, label = "copy") { done ->
                    Icon(
                        if (done) Icons.Outlined.Check else Icons.Outlined.ContentCopy,
                        contentDescription = "Copy code",
                        tint = colors.textSecondary,
                        modifier = Modifier.size(15.dp),
                    )
                }
                Spacer(Modifier.width(6.dp))
                Text(if (copied) "Copied" else "Copy", style = AvekTheme.type.caption, color = colors.textSecondary)
            }
        }
        Row(
            Modifier
                .horizontalScroll(rememberScrollState())
                .padding(vertical = 12.dp),
        ) {
            if (showLineNumbers) {
                val lineCount = block.code.count { it == '\n' } + 1
                Text(
                    (1..lineCount).joinToString("\n"),
                    style = codeStyle,
                    color = colors.textTertiary.copy(alpha = 0.7f),
                    modifier = Modifier.padding(start = 12.dp, end = 12.dp),
                )
            }
            Text(
                highlighted,
                style = codeStyle,
                color = colors.codeText,
                softWrap = false,
                modifier = Modifier.padding(start = if (showLineNumbers) 0.dp else 14.dp, end = 16.dp),
            )
        }
    }
}

@Composable
private fun TableBlock(block: MdBlock.Table, textStyle: TextStyle, color: Color, inline: InlineStyles) {
    val colors = AvekTheme.colors
    val columns = block.header.size
    val widths = (0 until columns).map { c ->
        val longest = (listOf(block.header) + block.rows).maxOf { row -> row.getOrNull(c)?.length ?: 0 }
        (longest * textStyle.fontSize.value * 0.55f + 28f).coerceIn(84f, 240f).dp
    }
    val cellStyle = textStyle.copy(fontSize = textStyle.fontSize * 0.88f, lineHeight = textStyle.lineHeight * 0.88f)
    Box(
        Modifier
            .clip(RoundedCornerShape(12.dp))
            .border(1.dp, colors.outline, RoundedCornerShape(12.dp))
            .horizontalScroll(rememberScrollState()),
    ) {
        Column {
            Row(Modifier.background(colors.textPrimary.copy(alpha = 0.05f))) {
                block.header.forEachIndexed { c, cell ->
                    Text(
                        InlineMarkdown.render(cell, inline),
                        style = cellStyle.copy(fontWeight = FontWeight.SemiBold),
                        color = color,
                        modifier = Modifier.width(widths[c]).padding(horizontal = 12.dp, vertical = 10.dp),
                    )
                }
            }
            block.rows.forEach { row ->
                HorizontalDivider(color = colors.outline.copy(alpha = 0.6f), modifier = Modifier.width(widths.fold(0.dp) { a, b -> a + b }))
                Row {
                    row.forEachIndexed { c, cell ->
                        Text(
                            InlineMarkdown.render(cell, inline),
                            style = cellStyle,
                            color = color,
                            modifier = Modifier.width(widths[c]).padding(horizontal = 12.dp, vertical = 10.dp),
                        )
                    }
                }
            }
        }
    }
}
