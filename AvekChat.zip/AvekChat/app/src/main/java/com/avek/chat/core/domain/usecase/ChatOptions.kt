package com.avek.chat.core.domain.usecase

import com.avek.chat.core.model.Message
import com.avek.chat.core.model.TaskMode
import com.avek.chat.core.model.ThinkingDepth

/** The knobs the user picked in the composer for a single turn. */
data class ChatOptions(
    val modelId: String,
    val task: TaskMode,
    val depth: ThinkingDepth,
    val speed: Float = 1f,
)

enum class ReplyPhase { THINKING, ANSWERING, DONE }

/** A live snapshot of an assistant reply while it streams. */
data class StreamingReply(
    val message: Message,
    val phase: ReplyPhase,
    /** Title of the reasoning step currently in progress, if any. */
    val activity: String?,
)
