package com.avek.chat.core.designsystem.theme

import androidx.compose.material3.ColorScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.Color
import com.avek.chat.core.model.settings.ColorRole

/**
 * The full semantic colour system of the app. Every surface in the UI reads
 * from here, never from hard-coded colours, which is what makes thousands of
 * themes and per-role overrides possible.
 */
@Immutable
data class AvekColors(
    val isDark: Boolean,
    val chatBackground: Color,
    val topBar: Color,
    val surface: Color,
    val outline: Color,
    val userBubble: Color,
    val userText: Color,
    val assistantBubble: Color,
    val assistantText: Color,
    val thinkingSurface: Color,
    val thinkingText: Color,
    val codeSurface: Color,
    val codeText: Color,
    val sidebar: Color,
    val sidebarSelected: Color,
    val sidebarText: Color,
    val composer: Color,
    val composerBorder: Color,
    val accent: Color,
    val onAccent: Color,
    val thinkingGlow: Color,
    val textPrimary: Color,
    val textSecondary: Color,
) {
    val textTertiary: Color get() = ColorMath.mix(textSecondary, chatBackground, 0.35f)
    val danger: Color get() = if (isDark) Color(0xFFFF8A80) else Color(0xFFC62828)
    val success: Color get() = if (isDark) Color(0xFF81C995) else Color(0xFF2E7D32)
    val scrim: Color get() = Color.Black.copy(alpha = if (isDark) 0.6f else 0.32f)
    val hover: Color get() = textPrimary.copy(alpha = 0.06f)
    val accentContainer: Color get() = accent.copy(alpha = if (isDark) 0.22f else 0.14f)

    operator fun get(role: ColorRole): Color = when (role) {
        ColorRole.CHAT_BACKGROUND -> chatBackground
        ColorRole.TOP_BAR -> topBar
        ColorRole.SURFACE -> surface
        ColorRole.OUTLINE -> outline
        ColorRole.USER_BUBBLE -> userBubble
        ColorRole.USER_TEXT -> userText
        ColorRole.ASSISTANT_BUBBLE -> assistantBubble
        ColorRole.ASSISTANT_TEXT -> assistantText
        ColorRole.THINKING_SURFACE -> thinkingSurface
        ColorRole.THINKING_TEXT -> thinkingText
        ColorRole.CODE_SURFACE -> codeSurface
        ColorRole.CODE_TEXT -> codeText
        ColorRole.SIDEBAR -> sidebar
        ColorRole.SIDEBAR_SELECTED -> sidebarSelected
        ColorRole.SIDEBAR_TEXT -> sidebarText
        ColorRole.COMPOSER -> composer
        ColorRole.COMPOSER_BORDER -> composerBorder
        ColorRole.ACCENT -> accent
        ColorRole.ON_ACCENT -> onAccent
        ColorRole.THINKING_GLOW -> thinkingGlow
        ColorRole.TEXT_PRIMARY -> textPrimary
        ColorRole.TEXT_SECONDARY -> textSecondary
    }

    fun with(role: ColorRole, color: Color): AvekColors = when (role) {
        ColorRole.CHAT_BACKGROUND -> copy(chatBackground = color)
        ColorRole.TOP_BAR -> copy(topBar = color)
        ColorRole.SURFACE -> copy(surface = color)
        ColorRole.OUTLINE -> copy(outline = color)
        ColorRole.USER_BUBBLE -> copy(userBubble = color)
        ColorRole.USER_TEXT -> copy(userText = color)
        ColorRole.ASSISTANT_BUBBLE -> copy(assistantBubble = color)
        ColorRole.ASSISTANT_TEXT -> copy(assistantText = color)
        ColorRole.THINKING_SURFACE -> copy(thinkingSurface = color)
        ColorRole.THINKING_TEXT -> copy(thinkingText = color)
        ColorRole.CODE_SURFACE -> copy(codeSurface = color)
        ColorRole.CODE_TEXT -> copy(codeText = color)
        ColorRole.SIDEBAR -> copy(sidebar = color)
        ColorRole.SIDEBAR_SELECTED -> copy(sidebarSelected = color)
        ColorRole.SIDEBAR_TEXT -> copy(sidebarText = color)
        ColorRole.COMPOSER -> copy(composer = color)
        ColorRole.COMPOSER_BORDER -> copy(composerBorder = color)
        ColorRole.ACCENT -> copy(accent = color)
        ColorRole.ON_ACCENT -> copy(onAccent = color)
        ColorRole.THINKING_GLOW -> copy(thinkingGlow = color)
        ColorRole.TEXT_PRIMARY -> copy(textPrimary = color)
        ColorRole.TEXT_SECONDARY -> copy(textSecondary = color)
    }

    fun withOverrides(overrides: Map<ColorRole, Long>): AvekColors =
        overrides.entries.fold(this) { acc, (role, argb) -> acc.with(role, Color(argb.toInt())) }

    fun toMaterial(): ColorScheme {
        val base = if (isDark) darkColorScheme() else lightColorScheme()
        return base.copy(
            primary = accent,
            onPrimary = onAccent,
            primaryContainer = ColorMath.mix(accent, chatBackground, 0.75f),
            onPrimaryContainer = textPrimary,
            secondary = textSecondary,
            onSecondary = chatBackground,
            secondaryContainer = sidebarSelected,
            onSecondaryContainer = textPrimary,
            tertiary = thinkingGlow,
            background = chatBackground,
            onBackground = textPrimary,
            surface = surface,
            onSurface = textPrimary,
            surfaceVariant = sidebarSelected,
            onSurfaceVariant = textSecondary,
            surfaceContainerLowest = chatBackground,
            surfaceContainerLow = sidebar,
            surfaceContainer = surface,
            surfaceContainerHigh = surface,
            surfaceContainerHighest = sidebarSelected,
            outline = outline,
            outlineVariant = ColorMath.mix(outline, chatBackground, 0.4f),
            inverseSurface = textPrimary,
            inverseOnSurface = chatBackground,
            error = danger,
            scrim = Color.Black,
        )
    }
}
