package com.avek.chat.core.domain.lock

import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/** The password's check value: PBKDF2-HMAC-SHA256 (UI-WIRE v4 section 13, "App lock"). Never the password itself. */
class PasswordRecord(val salt: ByteArray, val hash: ByteArray, val iterations: Int) {
    override fun toString(): String = "PasswordRecord(***)"
}

/**
 * The wrong-password counter and the lockout. [lockStartElapsed] is `SystemClock.elapsedRealtime()`
 * when the lockout began and [bootCount] the boot it began in: a reboot resets the elapsed clock, so a
 * lockout seen in another boot starts again in full (a reboot can only make it longer, never shorter).
 */
data class LockCounter(
    val failures: Int = 0,
    /** How many lockouts happened since the last correct password (each one doubles the next). */
    val lockouts: Int = 0,
    val lockStartElapsed: Long? = null,
    val lockDurationMs: Long = 0,
    val bootCount: Int = 0,
)

/** Persistence of the lock (Android: files excluded from backups). Unreadable data throws. */
interface LockStore {
    /** Null when no password was ever set. Throws when the stored record cannot be read. */
    fun readPassword(): PasswordRecord?
    fun writePassword(record: PasswordRecord)

    /** Null when missing. Throws when the stored counter cannot be read. */
    fun readCounter(): LockCounter?
    fun writeCounter(counter: LockCounter)

    /** "Forget this PC and start over": the password and the counter go. */
    fun clear()
}

/** The monotonic clock and the boot count (Android: `SystemClock.elapsedRealtime()`, `Settings.Global.BOOT_COUNT`). */
interface LockClock {
    fun elapsedRealtime(): Long
    fun bootCount(): Int
}

sealed interface LockState {
    /** No app password yet: the password creation screen. */
    data object NoPassword : LockState

    /** Nothing is shown. [biometricPassed]: the phone's fingerprint/PIN step is done, the app password is next. */
    data class Locked(val biometricPassed: Boolean) : LockState

    /** The stored password check value cannot be read: only "Forget this PC and start over" helps. */
    data object Broken : LockState

    data object Unlocked : LockState
}

sealed interface PasswordCheck {
    data object Correct : PasswordCheck
    data class Wrong(val triesLeft: Int) : PasswordCheck
    data class LockedOut(val remainingMs: Long) : PasswordCheck
}

/**
 * The app lock (section 13): on every open the phone's fingerprint or PIN, then the app password;
 * nothing is shown until both pass. 10 wrong passwords in a row lock for 10 minutes, doubling at
 * every further lockout; an unreadable counter counts as a 10-minute lockout, never as a reset.
 * The grace period lets a quick return skip the prompts (default none). The lock covers the UI
 * only: the connection keeps working. Pure logic: the store and the clock are injected.
 */
class AppLockManager(
    private val store: LockStore,
    private val clock: LockClock,
    private val iterations: Int = ITERATIONS,
    private val random: SecureRandom = SecureRandom(),
    private val compute: CoroutineDispatcher = Dispatchers.Default,
    private val log: (String) -> Unit = {},
) {
    private val _state = MutableStateFlow<LockState>(initialState())
    val state: StateFlow<LockState> = _state

    /** Elapsed time when the app left the screen (null while visible or never unlocked). */
    @Volatile
    private var leftAtElapsed: Long? = null

    val isUnlocked: Boolean get() = _state.value == LockState.Unlocked

    private fun initialState(): LockState = try {
        if (store.readPassword() == null) LockState.NoPassword else LockState.Locked(biometricPassed = false)
    } catch (e: Exception) {
        log("app lock: password record unreadable")
        LockState.Broken
    }

    // ------------------------------------------------------------------ creation

    /** Null when [first]/[second] make a valid new password, otherwise the sentence to show. */
    fun validateNew(first: CharArray, second: CharArray): String? = when {
        first.size < MIN_LENGTH -> "The password needs at least $MIN_LENGTH characters."
        !first.contentEquals(second) -> "The two passwords are not the same."
        else -> null
    }

    /** Sets the first password (or a new one after [changePassword] checked the old). Wipes both arrays. */
    suspend fun createPassword(first: CharArray, second: CharArray): String? {
        try {
            validateNew(first, second)?.let { return it }
            val salt = ByteArray(SALT_BYTES).also(random::nextBytes)
            val hash = withContext(compute) { pbkdf2(first, salt, iterations) }
            store.writePassword(PasswordRecord(salt, hash, iterations))
            store.writeCounter(LockCounter(bootCount = clock.bootCount()))
            log("app lock: password set")
            _state.value = LockState.Unlocked
            return null
        } finally {
            first.fill('\u0000')
            second.fill('\u0000')
        }
    }

    // ------------------------------------------------------------------ unlocking

    fun onBiometricPassed() {
        val current = _state.value
        if (current is LockState.Locked) _state.value = current.copy(biometricPassed = true)
    }

    /** The remaining lockout in ms (0 = none). An unreadable or missing counter arms a 10-minute lockout. */
    fun lockoutRemainingMs(): Long {
        val counter = readCounterOrLock()
        val start = counter.lockStartElapsed ?: return 0
        val now = clock.elapsedRealtime()
        val boot = clock.bootCount()
        if (boot != counter.bootCount || now < start) {
            // Another boot: the elapsed clock restarted. Start the lockout again in full.
            store.writeCounter(counter.copy(lockStartElapsed = now, bootCount = boot))
            return counter.lockDurationMs
        }
        val remaining = start + counter.lockDurationMs - now
        if (remaining <= 0) {
            store.writeCounter(counter.copy(failures = 0, lockStartElapsed = null, lockDurationMs = 0))
            return 0
        }
        return remaining
    }

    /** Checks the app password (after the biometric step). Wipes [password]. */
    suspend fun checkPassword(password: CharArray): PasswordCheck {
        try {
            val record = try {
                store.readPassword()
            } catch (e: Exception) {
                _state.value = LockState.Broken
                return PasswordCheck.LockedOut(Long.MAX_VALUE)
            } ?: return PasswordCheck.Wrong(MAX_FAILURES)
            val remaining = lockoutRemainingMs()
            if (remaining > 0) return PasswordCheck.LockedOut(remaining)
            val candidate = withContext(compute) { pbkdf2(password, record.salt, record.iterations) }
            val ok = MessageDigest.isEqual(candidate, record.hash)
            candidate.fill(0)
            val counter = readCounterOrLock()
            if (ok) {
                store.writeCounter(LockCounter(bootCount = clock.bootCount()))
                _state.value = LockState.Unlocked
                leftAtElapsed = null
                log("app lock: unlocked")
                return PasswordCheck.Correct
            }
            val failures = counter.failures + 1
            log("app lock: wrong password")
            if (failures >= MAX_FAILURES) {
                val duration = BASE_LOCK_MS shl counter.lockouts.coerceAtMost(MAX_DOUBLINGS)
                store.writeCounter(
                    LockCounter(
                        failures = failures,
                        lockouts = counter.lockouts + 1,
                        lockStartElapsed = clock.elapsedRealtime(),
                        lockDurationMs = duration,
                        bootCount = clock.bootCount(),
                    ),
                )
                return PasswordCheck.LockedOut(duration)
            }
            store.writeCounter(counter.copy(failures = failures, bootCount = counter.bootCount))
            return PasswordCheck.Wrong(MAX_FAILURES - failures)
        } finally {
            password.fill('\u0000')
        }
    }

    /** Settings → Security → change password: the old one first. Wipes all arrays. */
    suspend fun changePassword(old: CharArray, first: CharArray, second: CharArray): String? {
        val invalid = validateNew(first, second)
        if (invalid != null) {
            old.fill('\u0000')
            first.fill('\u0000')
            second.fill('\u0000')
            return invalid
        }
        return when (val check = checkPassword(old)) {
            PasswordCheck.Correct -> createPassword(first, second)
            is PasswordCheck.Wrong -> {
                first.fill('\u0000')
                second.fill('\u0000')
                "The current password is not right."
            }
            is PasswordCheck.LockedOut -> {
                first.fill('\u0000')
                second.fill('\u0000')
                "Too many wrong passwords. Try again later."
            }
        }
    }

    // ------------------------------------------------------------------ foreground / background

    /** The app left the screen. */
    fun onBackground() {
        if (_state.value == LockState.Unlocked) leftAtElapsed = clock.elapsedRealtime()
    }

    /** The app came back: locks again unless it was away for less than the grace period. */
    fun onForeground(graceMinutes: Int) {
        if (_state.value != LockState.Unlocked) return
        val left = leftAtElapsed ?: return
        leftAtElapsed = null
        val away = clock.elapsedRealtime() - left
        if (graceMinutes <= 0 || away < 0 || away >= graceMinutes * 60_000L) {
            _state.value = LockState.Locked(biometricPassed = false)
        }
    }

    /** "Forget this PC and start over": the password goes (a new one is set after pairing again). */
    fun reset() {
        store.clear()
        leftAtElapsed = null
        log("app lock: reset")
        _state.value = LockState.NoPassword
    }

    private fun readCounterOrLock(): LockCounter {
        val counter = try {
            store.readCounter()
        } catch (e: Exception) {
            null
        }
        if (counter != null) return counter
        // Unreadable or missing next to a password: locked for 10 minutes, never a reset.
        log("app lock: counter unreadable")
        val locked = LockCounter(
            failures = MAX_FAILURES,
            lockouts = 1,
            lockStartElapsed = clock.elapsedRealtime(),
            lockDurationMs = BASE_LOCK_MS,
            bootCount = clock.bootCount(),
        )
        store.writeCounter(locked)
        return locked
    }

    companion object {
        const val ITERATIONS = 600_000
        const val SALT_BYTES = 16
        const val HASH_BYTES = 32
        const val MIN_LENGTH = 8
        const val MAX_FAILURES = 10
        const val BASE_LOCK_MS = 10 * 60_000L
        private const val MAX_DOUBLINGS = 16

        /** PBKDF2WithHmacSHA256, 32-byte result. Clears the key spec's copy of the password. */
        fun pbkdf2(password: CharArray, salt: ByteArray, iterations: Int): ByteArray {
            val spec = PBEKeySpec(password, salt, iterations, HASH_BYTES * 8)
            try {
                return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
            } finally {
                spec.clearPassword()
            }
        }
    }
}
