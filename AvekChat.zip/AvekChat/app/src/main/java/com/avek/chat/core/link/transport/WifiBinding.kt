package com.avek.chat.core.link.transport

import java.net.DatagramSocket
import javax.net.SocketFactory

/**
 * Routes sockets through the Wi-Fi network (UI-WIRE section 13, "Network"): a phone
 * hotspot has no internet, so Android might otherwise send our traffic elsewhere.
 * Reference-counted: [acquire] while the app wants to talk to the PC, [release] after.
 */
interface WifiBinding {
    fun acquire()
    fun release()

    /** A factory bound to the Wi-Fi network (waiting briefly for it), or null to use the default route. */
    suspend fun socketFactory(): SocketFactory?

    /** Binds an (unbound) datagram socket to the Wi-Fi network when there is one. */
    fun bind(socket: DatagramSocket)
}

object NoWifiBinding : WifiBinding {
    override fun acquire() = Unit
    override fun release() = Unit
    override suspend fun socketFactory(): SocketFactory? = null
    override fun bind(socket: DatagramSocket) = Unit
}

/** Holds a `WifiManager.MulticastLock` while the UDP beacon listener runs. */
interface MulticastGuard {
    fun acquire()
    fun release()
}

object NoMulticastGuard : MulticastGuard {
    override fun acquire() = Unit
    override fun release() = Unit
}
