package com.avek.chat.feature.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.ChevronRight
import androidx.compose.material.icons.outlined.DeleteForever
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Layers
import androidx.compose.material.icons.outlined.Memory
import androidx.compose.material.icons.outlined.Palette
import androidx.compose.material.icons.outlined.Restore
import androidx.compose.material.icons.outlined.Title
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.avek.chat.BuildConfig
import com.avek.chat.core.designsystem.component.SectionHeader
import com.avek.chat.core.designsystem.component.SettingRow
import com.avek.chat.core.designsystem.component.SettingsCard
import com.avek.chat.core.designsystem.component.SwitchRow
import com.avek.chat.core.designsystem.component.ThinkingDepthBar
import com.avek.chat.core.designsystem.icon.icon
import com.avek.chat.core.designsystem.theme.AvekTheme
import com.avek.chat.core.model.TaskMode

@Composable
fun SettingsRoute(onBack: () -> Unit, onOpenCustomize: () -> Unit, viewModel: SettingsViewModel = hiltViewModel()) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }
    LaunchedEffect(viewModel) { viewModel.messages.collect { snackbar.showSnackbar(it) } }

    val colors = AvekTheme.colors
    var modelMenu by remember { mutableStateOf(false) }
    var taskMenu by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    // Local echo of the name so typing never waits on a DataStore round-trip.
    var nameDraft by rememberSaveable { mutableStateOf<String?>(null) }
    val settings = state.settings

    Scaffold(
        containerColor = colors.chatBackground,
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                title = { Text("Settings", style = AvekTheme.type.headline, color = colors.textPrimary) },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Outlined.ArrowBack, "Back", tint = colors.textPrimary) }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = colors.chatBackground),
            )
        },
    ) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding), contentPadding = PaddingValues(bottom = 40.dp)) {
            item { SectionHeader("Profile") }
            item {
                SettingsCard {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier
                                .size(52.dp)
                                .clip(CircleShape)
                                .background(colors.textPrimary),
                            contentAlignment = Alignment.Center,
                        ) {
                            Text(
                                settings.profile.displayName.trim().firstOrNull()?.uppercase() ?: "A",
                                style = AvekTheme.type.title,
                                color = colors.chatBackground,
                            )
                        }
                        Spacer(Modifier.width(14.dp))
                        OutlinedTextField(
                            value = nameDraft ?: settings.profile.displayName,
                            onValueChange = {
                                nameDraft = it
                                viewModel.setName(it)
                            },
                            label = { Text("What should Avek call you?") },
                            singleLine = true,
                            textStyle = AvekTheme.type.body.copy(color = colors.textPrimary),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = colors.accent,
                                unfocusedBorderColor = colors.outline,
                                focusedLabelColor = colors.accent,
                                cursorColor = colors.accent,
                            ),
                            modifier = Modifier.weight(1f),
                        )
                    }
                }
            }

            item { SectionHeader("New chat defaults") }
            item {
                SettingsCard {
                    Box {
                        SettingRow(
                            "Model",
                            subtitle = state.defaultModel?.let { "${it.displayName} — ${it.tagline}" },
                            icon = Icons.Outlined.Memory,
                            onClick = { modelMenu = true },
                        ) { Icon(Icons.Outlined.ChevronRight, null, tint = colors.textSecondary) }
                        DropdownMenu(expanded = modelMenu, onDismissRequest = { modelMenu = false }, containerColor = colors.surface) {
                            state.models.forEach { model ->
                                DropdownMenuItem(
                                    text = {
                                        Column {
                                            Text(model.displayName, color = colors.textPrimary, style = AvekTheme.type.body.copy(fontWeight = FontWeight.Medium))
                                            Text(model.tagline, color = colors.textSecondary, style = AvekTheme.type.caption)
                                        }
                                    },
                                    onClick = {
                                        modelMenu = false
                                        viewModel.setDefaultModel(model.id)
                                    },
                                )
                            }
                        }
                    }
                    HorizontalDivider(color = colors.outline.copy(alpha = 0.4f))
                    Box {
                        SettingRow(
                            "Task mode",
                            subtitle = settings.defaults.taskMode.let { "${it.label} — ${it.tagline}" },
                            icon = settings.defaults.taskMode.icon,
                            onClick = { taskMenu = true },
                        ) { Icon(Icons.Outlined.ChevronRight, null, tint = colors.textSecondary) }
                        DropdownMenu(expanded = taskMenu, onDismissRequest = { taskMenu = false }, containerColor = colors.surface) {
                            TaskMode.entries.forEach { task ->
                                DropdownMenuItem(
                                    text = { Text(task.label, color = colors.textPrimary) },
                                    leadingIcon = { Icon(task.icon, null, tint = colors.textSecondary) },
                                    onClick = {
                                        taskMenu = false
                                        viewModel.setDefaultTask(task)
                                    },
                                )
                            }
                        }
                    }
                    HorizontalDivider(color = colors.outline.copy(alpha = 0.4f))
                    ThinkingDepthBar(
                        depth = state.defaultModel?.clampDepth(settings.defaults.depth) ?: settings.defaults.depth,
                        onDepthChange = viewModel::setDefaultDepth,
                        maxDepth = state.defaultModel?.maxDepth ?: com.avek.chat.core.model.ThinkingDepth.MAXIMUM,
                        modelName = state.defaultModel?.name ?: "This model",
                        modifier = Modifier.padding(16.dp),
                    )
                    HorizontalDivider(color = colors.outline.copy(alpha = 0.4f))
                    SwitchRow(
                        "Auto-title conversations",
                        settings.defaults.autoTitle,
                        viewModel::setAutoTitle,
                        subtitle = "Name chats from your first message",
                        icon = Icons.Outlined.Title,
                    )
                }
            }

            item { SectionHeader("Appearance") }
            item {
                SettingsCard {
                    SettingRow(
                        "Customize",
                        subtitle = "Themes, colours, fonts, layout and motion",
                        icon = Icons.Outlined.Palette,
                        onClick = onOpenCustomize,
                    ) { Icon(Icons.Outlined.ChevronRight, null, tint = colors.textSecondary) }
                }
            }

            item { SectionHeader("Data") }
            item {
                SettingsCard {
                    SettingRow(
                        "Add sample conversations",
                        subtitle = "Fill history with realistic demo chats",
                        icon = Icons.Outlined.Restore,
                        onClick = viewModel::restoreDemoConversations,
                    )
                    HorizontalDivider(color = colors.outline.copy(alpha = 0.4f))
                    SettingRow(
                        "Delete all conversations",
                        subtitle = "This can't be undone",
                        icon = Icons.Outlined.DeleteForever,
                        onClick = { confirmDelete = true },
                    )
                }
            }

            item { SectionHeader("About") }
            item {
                SettingsCard {
                    SettingRow("Avek", subtitle = "Version ${BuildConfig.VERSION_NAME}", icon = Icons.Outlined.Info)
                    HorizontalDivider(color = colors.outline.copy(alpha = 0.4f))
                    SettingRow(
                        "Simulated models",
                        subtitle = "Replies are generated on-device by a scripted engine. Plug a real backend into InferenceEngine.",
                        icon = Icons.Outlined.AutoAwesome,
                    )
                    HorizontalDivider(color = colors.outline.copy(alpha = 0.4f))
                    SettingRow(
                        "Architecture",
                        subtitle = "Clean architecture · MVVM + UDF · Hilt · Room · DataStore · Jetpack Compose",
                        icon = Icons.Outlined.Layers,
                    )
                }
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            containerColor = colors.surface,
            title = { Text("Delete all conversations?", color = colors.textPrimary) },
            text = { Text("Every chat and message on this device will be permanently removed.", color = colors.textSecondary) },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.deleteAllConversations()
                    confirmDelete = false
                }) { Text("Delete all", color = colors.danger) }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel", color = colors.textSecondary) } },
        )
    }
}

