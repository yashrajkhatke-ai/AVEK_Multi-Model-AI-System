package com.avek.chat.feature.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.ChevronRight
import androidx.compose.material.icons.outlined.Cable
import androidx.compose.material.icons.outlined.DownloadDone
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Layers
import androidx.compose.material.icons.outlined.Memory
import androidx.compose.material.icons.outlined.Palette
import androidx.compose.material.icons.outlined.Password
import androidx.compose.material.icons.outlined.Timer
import androidx.compose.material.icons.outlined.Screenshot
import androidx.compose.material.icons.outlined.Key
import androidx.compose.material.icons.outlined.LinkOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.avek.chat.BuildConfig
import com.avek.chat.core.designsystem.component.SectionHeader
import com.avek.chat.core.designsystem.component.SettingRow
import com.avek.chat.core.designsystem.component.SettingsCard
import com.avek.chat.core.designsystem.component.SwitchRow
import com.avek.chat.core.designsystem.component.ThinkingDepthBar
import com.avek.chat.core.designsystem.icon.icon
import com.avek.chat.core.designsystem.theme.AvekTheme
import com.avek.chat.core.model.TaskMode

@Composable
fun SettingsRoute(
    onBack: () -> Unit,
    onOpenCustomize: () -> Unit,
    onOpenConnection: () -> Unit,
    onOpenDownloads: () -> Unit,
    viewModel: SettingsViewModel = hiltViewModel(),
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }
    LaunchedEffect(viewModel) { viewModel.messages.collect { snackbar.showSnackbar(it) } }
    var changePassword by remember { mutableStateOf(false) }
    var graceMenu by remember { mutableStateOf(false) }

    val colors = AvekTheme.colors
    var taskMenu by remember { mutableStateOf(false) }
    // Local echo of the name so typing never waits on a DataStore round-trip.
    var nameDraft by rememberSaveable { mutableStateOf<String?>(null) }
    val settings = state.settings

    Scaffold(
        containerColor = colors.chatBackground,
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                title = { Text("Settings", style = AvekTheme.type.headline, color = colors.textPrimary) },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Outlined.ArrowBack, "Back", tint = colors.textPrimary) }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = colors.chatBackground),
            )
        },
    ) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding), contentPadding = PaddingValues(bottom = 40.dp)) {
            item { SectionHeader("Profile") }
            item {
                SettingsCard {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier
                                .size(52.dp)
                                .clip(CircleShape)
                                .background(colors.textPrimary),
                            contentAlignment = Alignment.Center,
                        ) {
                            Text(
                                settings.profile.displayName.trim().firstOrNull()?.uppercase() ?: "A",
                                style = AvekTheme.type.title,
                                color = colors.chatBackground,
                            )
                        }
                        Spacer(Modifier.width(14.dp))
                        OutlinedTextField(
                            value = nameDraft ?: settings.profile.displayName,
                            onValueChange = {
                                nameDraft = it
                                viewModel.setName(it)
                            },
                            label = { Text("What should Avek call you?") },
                            singleLine = true,
                            textStyle = AvekTheme.type.body.copy(color = colors.textPrimary),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = colors.accent,
                                unfocusedBorderColor = colors.outline,
                                focusedLabelColor = colors.accent,
                                cursorColor = colors.accent,
                            ),
                            modifier = Modifier.weight(1f),
                        )
                    }
                }
            }

            item { SectionHeader("PC") }
            item {
                SettingsCard {
                    SettingRow(
                        "Connection",
                        subtitle = state.connectionStatus,
                        icon = Icons.Outlined.Cable,
                        onClick = onOpenConnection,
                    ) { Icon(Icons.Outlined.ChevronRight, null, tint = colors.textSecondary) }
                    HorizontalDivider(color = colors.outline.copy(alpha = 0.4f))
                    SettingRow(
                        "Downloaded chats",
                        subtitle = "Copies kept on this device for reading without the PC",
                        icon = Icons.Outlined.DownloadDone,
                        onClick = onOpenDownloads,
                    ) { Icon(Icons.Outlined.ChevronRight, null, tint = colors.textSecondary) }
                }
            }

            item { SectionHeader("Security") }
            item {
                SettingsCard {
                    SettingRow(
                        "App password",
                        subtitle = "Change the password asked after your fingerprint or PIN",
                        icon = Icons.Outlined.Password,
                        onClick = { changePassword = true },
                    ) { Icon(Icons.Outlined.ChevronRight, null, tint = colors.textSecondary) }
                    HorizontalDivider(color = colors.outline.copy(alpha = 0.4f))
                    Box {
                        SettingRow(
                            "Lock again after",
                            subtitle = graceLabel(settings.security.graceMinutes),
                            icon = Icons.Outlined.Timer,
                            onClick = { graceMenu = true },
                        ) { Icon(Icons.Outlined.ChevronRight, null, tint = colors.textSecondary) }
                        DropdownMenu(expanded = graceMenu, onDismissRequest = { graceMenu = false }, containerColor = colors.surface) {
                            com.avek.chat.core.model.settings.SecuritySettings.GRACE_OPTIONS.forEach { minutes ->
                                DropdownMenuItem(
                                    text = { Text(graceLabel(minutes), color = colors.textPrimary) },
                                    onClick = {
                                        graceMenu = false
                                        viewModel.setGraceMinutes(minutes)
                                    },
                                )
                            }
                        }
                    }
                    HorizontalDivider(color = colors.outline.copy(alpha = 0.4f))
                    SwitchRow(
                        "Allow screenshots",
                        settings.security.allowScreenshots,
                        viewModel::setAllowScreenshots,
                        subtitle = "Off: the app cannot be captured and is hidden in the recent apps list",
                        icon = Icons.Outlined.Screenshot,
                    )
                    HorizontalDivider(color = colors.outline.copy(alpha = 0.4f))
                    SettingRow(
                        "Replace this device's keys",
                        subtitle = "In Connection: new keys without pairing again",
                        icon = Icons.Outlined.Key,
                        onClick = onOpenConnection,
                    ) { Icon(Icons.Outlined.ChevronRight, null, tint = colors.textSecondary) }
                    HorizontalDivider(color = colors.outline.copy(alpha = 0.4f))
                    SettingRow(
                        "Forget this PC",
                        subtitle = "In Connection: delete this device's keys and the stored PC",
                        icon = Icons.Outlined.LinkOff,
                        onClick = onOpenConnection,
                    ) { Icon(Icons.Outlined.ChevronRight, null, tint = colors.textSecondary) }
                }
            }

            item { SectionHeader("New chat defaults") }
            item {
                SettingsCard {
                    SettingRow(
                        "Model",
                        subtitle = "Chosen by your PC: the best model that is ready. Pick another from the top of a chat.",
                        icon = Icons.Outlined.Memory,
                    )
                    HorizontalDivider(color = colors.outline.copy(alpha = 0.4f))
                    Box {
                        SettingRow(
                            "Task mode",
                            subtitle = settings.defaults.taskMode.let { "${it.label} — ${it.tagline}" },
                            icon = settings.defaults.taskMode.icon,
                            onClick = { taskMenu = true },
                        ) { Icon(Icons.Outlined.ChevronRight, null, tint = colors.textSecondary) }
                        DropdownMenu(expanded = taskMenu, onDismissRequest = { taskMenu = false }, containerColor = colors.surface) {
                            TaskMode.entries.forEach { task ->
                                DropdownMenuItem(
                                    text = { Text(task.label, color = colors.textPrimary) },
                                    leadingIcon = { Icon(task.icon, null, tint = colors.textSecondary) },
                                    onClick = {
                                        taskMenu = false
                                        viewModel.setDefaultTask(task)
                                    },
                                )
                            }
                        }
                    }
                    HorizontalDivider(color = colors.outline.copy(alpha = 0.4f))
                    ThinkingDepthBar(
                        depth = settings.defaults.depth,
                        onDepthChange = viewModel::setDefaultDepth,
                        maxDepth = com.avek.chat.core.model.ThinkingDepth.MAXIMUM,
                        modelName = "The model",
                        modifier = Modifier.padding(16.dp),
                    )
                }
            }

            item { SectionHeader("Appearance") }
            item {
                SettingsCard {
                    SettingRow(
                        "Customize",
                        subtitle = "Themes, colours, fonts, layout and motion",
                        icon = Icons.Outlined.Palette,
                        onClick = onOpenCustomize,
                    ) { Icon(Icons.Outlined.ChevronRight, null, tint = colors.textSecondary) }
                }
            }

            item { SectionHeader("About") }
            item {
                SettingsCard {
                    SettingRow("Avek", subtitle = "Version ${BuildConfig.VERSION_NAME}", icon = Icons.Outlined.Info)
                    HorizontalDivider(color = colors.outline.copy(alpha = 0.4f))
                    SettingRow(
                        "Your PC does the thinking",
                        subtitle = "Chats and models live on your PC. This app talks to it over an encrypted link: on your Wi-Fi, through Tailscale or through ngrok.",
                        icon = Icons.Outlined.AutoAwesome,
                    )
                    HorizontalDivider(color = colors.outline.copy(alpha = 0.4f))
                    SettingRow(
                        "Architecture",
                        subtitle = "Clean architecture · MVVM + UDF · Hilt · Room · DataStore · OkHttp · Jetpack Compose",
                        icon = Icons.Outlined.Layers,
                    )
                }
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
    if (changePassword) {
        ChangePasswordDialog(
            onDismiss = { changePassword = false },
            onChange = { old, a, b, done -> viewModel.changePassword(old, a, b, done) },
        )
    }
}

private fun graceLabel(minutes: Int): String = if (minutes <= 0) "Every time (no grace period)" else "$minutes ${if (minutes == 1) "minute" else "minutes"} away from the app"

/** Change the app password: the current one first, then the new one twice. */
@Composable
private fun ChangePasswordDialog(onDismiss: () -> Unit, onChange: (CharArray, CharArray, CharArray, (String?) -> Unit) -> Unit) {
    val colors = AvekTheme.colors
    var old by remember { mutableStateOf("") }
    var first by remember { mutableStateOf("") }
    var second by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    androidx.compose.runtime.DisposableEffect(Unit) {
        onDispose {
            old = ""
            first = ""
            second = ""
        }
    }
    AlertDialog(
        onDismissRequest = { if (!busy) onDismiss() },
        containerColor = colors.surface,
        title = { Text("Change app password", color = colors.textPrimary) },
        text = {
            Column {
                com.avek.chat.feature.lock.PasswordField(old, { old = it; error = null }, "Current password", imeAction = androidx.compose.ui.text.input.ImeAction.Next)
                Spacer(Modifier.height(8.dp))
                com.avek.chat.feature.lock.PasswordField(first, { first = it; error = null }, "New password (at least 8 characters)", imeAction = androidx.compose.ui.text.input.ImeAction.Next)
                Spacer(Modifier.height(8.dp))
                com.avek.chat.feature.lock.PasswordField(second, { second = it; error = null }, "New password again")
                error?.let {
                    Spacer(Modifier.height(8.dp))
                    Text(it, style = AvekTheme.type.bodySmall, color = colors.danger)
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = !busy && old.isNotEmpty() && first.isNotEmpty() && second.isNotEmpty(),
                onClick = {
                    busy = true
                    val a = old.toCharArray()
                    val b = first.toCharArray()
                    val c = second.toCharArray()
                    old = ""
                    first = ""
                    second = ""
                    onChange(a, b, c) { result ->
                        busy = false
                        if (result == null) onDismiss() else error = result
                    }
                },
            ) { Text("Change", color = colors.accent) }
        },
        dismissButton = { TextButton(onClick = onDismiss, enabled = !busy) { Text("Cancel", color = colors.textSecondary) } },
    )
}
