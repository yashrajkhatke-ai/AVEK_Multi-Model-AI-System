package com.avek.chat.core.common

import java.time.ZoneId

/** Source of "now". Injected everywhere time matters so behaviour is testable. */
interface TimeProvider {
    fun now(): Long
    fun zone(): ZoneId = ZoneId.systemDefault()
}

class SystemTimeProvider : TimeProvider {
    override fun now(): Long = System.currentTimeMillis()
}
