package com.avek.chat.platform.android

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.avek.chat.MainActivity
import com.avek.chat.R
import com.avek.chat.core.model.AskKind
import com.avek.chat.core.model.AskRequest
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * The three notification channels of UI-WIRE section 13 and the notifications posted on them:
 * a persistent low-priority "Connected to <PC>", high-priority questions with Allow / Deny, and
 * default-priority answers.
 */
@Singleton
class AvekNotifications @Inject constructor(
    @ApplicationContext private val context: Context,
    private val lock: com.avek.chat.core.domain.lock.AppLockManager,
) {
    /** While the app is locked, notifications show only a generic title (section 13, "App lock"). */
    private val locked: Boolean get() = !lock.isUnlocked

    private val manager = NotificationManagerCompat.from(context)

    init {
        createChannels()
    }

    // ------------------------------------------------------------------ the foreground service

    fun foreground(text: String): Notification =
        NotificationCompat.Builder(context, CHANNEL_CONNECTION)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(context.getString(R.string.app_name))
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setContentIntent(open(null))
            .build()

    fun updateForeground(text: String) = post(FOREGROUND_ID, foreground(text))

    // ------------------------------------------------------------------ questions and answers

    fun showAsk(ask: AskRequest) {
        if (locked) {
            // Nothing sensitive and no Allow / Deny while locked: the question is answered after unlocking.
            val generic = NotificationCompat.Builder(context, CHANNEL_QUESTIONS)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle("AVEK: your PC has a question")
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                .setVisibility(NotificationCompat.VISIBILITY_PRIVATE)
                .setAutoCancel(false)
                .setOnlyAlertOnce(true)
                .setContentIntent(open(ask.chatId))
                .build()
            post(askNotificationId(ask.askId), generic)
            return
        }
        val builder = NotificationCompat.Builder(context, CHANNEL_QUESTIONS)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(ask.summary.ifBlank { "Your PC has a question" })
            .setContentText(ask.detail ?: ask.tool?.let { "Tool: $it" } ?: "Tap to answer")
            .setStyle(NotificationCompat.BigTextStyle().bigText(ask.detail ?: ask.summary))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setVisibility(NotificationCompat.VISIBILITY_PRIVATE)
            .setAutoCancel(false)
            .setOnlyAlertOnce(true)
            .setContentIntent(open(ask.chatId))
        // Buttons only for approvals: a free-text question is answered inside the app.
        if (ask.kind == AskKind.APPROVAL) {
            if ("allow" in ask.choices) builder.addAction(0, context.getString(R.string.action_allow), answer(ask.askId, "allow"))
            if ("deny" in ask.choices) builder.addAction(0, context.getString(R.string.action_deny), answer(ask.askId, "deny"))
        }
        post(askNotificationId(ask.askId), builder.build())
    }

    fun cancelAsk(askId: String) = manager.cancel(askNotificationId(askId))

    fun showAnswer(chatId: String, title: String, text: String) {
        if (locked) {
            val generic = NotificationCompat.Builder(context, CHANNEL_ANSWERS)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle("AVEK: an answer is ready")
                .setAutoCancel(true)
                .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                .setVisibility(NotificationCompat.VISIBILITY_PRIVATE)
                .setContentIntent(open(chatId))
                .build()
            post(chatId.hashCode() xor ANSWER_SALT, generic)
            return
        }
        val notification = NotificationCompat.Builder(context, CHANNEL_ANSWERS)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title.ifBlank { "Answer ready" })
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setAutoCancel(true)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setContentIntent(open(chatId))
            .build()
        post(chatId.hashCode() xor ANSWER_SALT, notification)
    }

    fun showMessage(text: String) {
        val notification = NotificationCompat.Builder(context, CHANNEL_ANSWERS)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(context.getString(R.string.app_name))
            .setContentText(if (locked) "AVEK: something needs your attention" else text)
            .setAutoCancel(true)
            .setContentIntent(open(null))
            .build()
        post(MESSAGE_ID, notification)
    }

    // ------------------------------------------------------------------ internals

    private fun post(id: Int, notification: Notification) {
        // Without the permission (Android 13+) or with notifications switched off, there is nothing to show.
        if (!manager.areNotificationsEnabled()) return
        runCatching { manager.notify(id, notification) }
    }

    private fun open(chatId: String?): PendingIntent {
        val intent = Intent(context, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            .also { if (chatId != null) it.putExtra(EXTRA_CHAT_ID, chatId) }
        return PendingIntent.getActivity(context, chatId.hashCode(), intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    private fun answer(askId: String, decision: String): PendingIntent {
        val intent = Intent(context, AskActionReceiver::class.java)
            .setAction(ACTION_ANSWER)
            .putExtra(EXTRA_ASK_ID, askId)
            .putExtra(EXTRA_DECISION, decision)
        return PendingIntent.getBroadcast(
            context,
            (askId + decision).hashCode(),
            intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
    }

    private fun createChannels() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val system = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        system.createNotificationChannel(
            NotificationChannel(CHANNEL_CONNECTION, context.getString(R.string.channel_connection), NotificationManager.IMPORTANCE_LOW)
                .apply { description = context.getString(R.string.channel_connection_description) },
        )
        system.createNotificationChannel(
            NotificationChannel(CHANNEL_QUESTIONS, context.getString(R.string.channel_questions), NotificationManager.IMPORTANCE_HIGH)
                .apply { description = context.getString(R.string.channel_questions_description) },
        )
        system.createNotificationChannel(
            NotificationChannel(CHANNEL_ANSWERS, context.getString(R.string.channel_answers), NotificationManager.IMPORTANCE_DEFAULT)
                .apply { description = context.getString(R.string.channel_answers_description) },
        )
    }

    companion object {
        const val CHANNEL_CONNECTION = "connection"
        const val CHANNEL_QUESTIONS = "questions"
        const val CHANNEL_ANSWERS = "answers"

        const val FOREGROUND_ID = 1
        private const val MESSAGE_ID = 2
        private const val ASK_BASE = 1_000
        private const val ANSWER_SALT = 0x5A5A

        const val ACTION_ANSWER = "com.avek.chat.action.ANSWER_ASK"
        const val EXTRA_ASK_ID = "askId"
        const val EXTRA_DECISION = "decision"
        const val EXTRA_CHAT_ID = "chatId"

        private fun askNotificationId(askId: String) = ASK_BASE + (askId.hashCode() and 0x0FFFFFFF)
    }
}
