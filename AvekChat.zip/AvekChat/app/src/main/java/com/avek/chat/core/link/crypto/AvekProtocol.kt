package com.avek.chat.core.link.crypto

import com.avek.chat.core.link.crypto.SecureCrypto.concat
import com.avek.chat.core.link.crypto.SecureCrypto.utf8

/**
 * The byte-exact messages and derivations of AVEK-SEC/2 (UI-WIRE v3 sections 2 to 4).
 * Pure functions: shared by the client, the tests and the fake PC.
 */
object AvekProtocol {

    const val VERSION = 3
    private val ZERO = byteArrayOf(0)

    // ------------------------------------------------------------------ identities

    /** `SHA-256("AVEK/2 key" ‖ pub)`. */
    fun fingerprint(publicRaw: ByteArray): ByteArray = SecureCrypto.sha256(utf8("AVEK/2 key"), publicRaw)

    /** `"d_"` + the first 10 hex digits of the fingerprint. */
    fun deviceIdOf(publicRaw: ByteArray): String = "d_" + SecureCrypto.hex(fingerprint(publicRaw)).take(10)

    /** `"s_"` + the first 8 hex digits of the fingerprint. */
    fun serverIdOf(publicRaw: ByteArray): String = "s_" + SecureCrypto.hex(fingerprint(publicRaw)).take(8)

    /** "9171 961e a29e 9d7f": the first 16 hex digits in groups of four, for showing a key to a person. */
    fun fingerprintText(publicRaw: ByteArray): String =
        SecureCrypto.hex(fingerprint(publicRaw)).take(16).chunked(4).joinToString(" ")

    // ------------------------------------------------------------------ pairing (section 3)

    fun pairCommit(name: String, platform: String, devicePub: ByteArray, clientNonce: ByteArray): ByteArray =
        SecureCrypto.sha256(utf8("AVEK/2 pair commit"), ZERO, utf8(name), ZERO, utf8(platform), ZERO, devicePub, clientNonce)

    fun pairTranscript(
        commit: ByteArray,
        serverPub: ByteArray,
        serverNonce: ByteArray,
        devicePub: ByteArray,
        clientNonce: ByteArray,
    ): ByteArray = SecureCrypto.sha256(utf8("AVEK/2 pair"), ZERO, commit, serverPub, serverNonce, devicePub, clientNonce)

    /** The six digits both screens show: HKDF(transcript, empty salt, "avek2 sas"), first 4 bytes big-endian mod 1,000,000. */
    fun pairSas(transcript: ByteArray): String {
        val okm = SecureCrypto.hkdf(transcript, ByteArray(0), "avek2 sas", 32)
        val value = ((okm[0].toLong() and 0xFF) shl 24) or ((okm[1].toLong() and 0xFF) shl 16) or
            ((okm[2].toLong() and 0xFF) shl 8) or (okm[3].toLong() and 0xFF)
        return (value % 1_000_000L).toString().padStart(6, '0')
    }

    /** "250 752". */
    fun formatSas(sas: String): String = sas.take(3) + " " + sas.drop(3)

    fun pairClientMessage(transcript: ByteArray): ByteArray = concat(utf8("AVEK/2 pair client"), ZERO, transcript)

    fun pairServerMessage(transcript: ByteArray): ByteArray = concat(utf8("AVEK/2 pair server"), ZERO, transcript)

    // ------------------------------------------------------------------ session (section 4)

    class SessionKeysV3(
        val transcript: ByteArray,
        val macKey: ByteArray,
        val clientToServer: ByteArray,
        val serverToClient: ByteArray,
        val serverMessage: ByteArray,
        val clientMessage: ByteArray,
        val serverMac: ByteArray,
        val clientMac: ByteArray,
    )

    fun sessionKeys(
        shared: ByteArray,
        serverPub: ByteArray,
        devicePub: ByteArray,
        clientEpk: ByteArray,
        serverEpk: ByteArray,
        clientNonce: ByteArray,
        serverNonce: ByteArray,
    ): SessionKeysV3 {
        val transcript = SecureCrypto.sha256(
            utf8("AVEK/2 session"), ZERO, serverPub, devicePub, clientEpk, serverEpk, clientNonce, serverNonce,
        )
        val macKey = SecureCrypto.hkdf(shared, transcript, "avek2 mac")
        return SessionKeysV3(
            transcript = transcript,
            macKey = macKey,
            clientToServer = SecureCrypto.hkdf(shared, transcript, "avek2 c2s"),
            serverToClient = SecureCrypto.hkdf(shared, transcript, "avek2 s2c"),
            serverMessage = concat(utf8("AVEK/2 server sig"), ZERO, transcript),
            clientMessage = concat(utf8("AVEK/2 client sig"), ZERO, transcript),
            serverMac = SecureCrypto.hmacSha256(macKey, utf8("server"), transcript),
            clientMac = SecureCrypto.hmacSha256(macKey, utf8("client"), transcript),
        )
    }

    // ------------------------------------------------------------------ knock (section 2)

    fun knockMessage(deviceId: String, ts: Long, nonce: ByteArray): ByteArray =
        concat(utf8("AVEK/2 knock"), ZERO, utf8(deviceId), ZERO, utf8(ts.toString()), ZERO, nonce)

    fun hereMessage(serverId: String, port: Int, deviceId: String, nonce: ByteArray): ByteArray =
        concat(utf8("AVEK/2 here"), ZERO, utf8(serverId), ZERO, utf8(port.toString()), ZERO, utf8(deviceId), ZERO, nonce)
}
