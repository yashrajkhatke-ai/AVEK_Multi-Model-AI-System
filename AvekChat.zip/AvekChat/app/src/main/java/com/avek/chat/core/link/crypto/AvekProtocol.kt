package com.avek.chat.core.link.crypto

import com.avek.chat.core.link.crypto.SecureCrypto.concat
import com.avek.chat.core.link.crypto.SecureCrypto.utf8
import org.bouncycastle.crypto.generators.SCrypt
import java.util.Base64

/**
 * The byte-exact messages and derivations of AVEK-SEC/4 (UI-WIRE v4 sections 2 to 5).
 * Pure functions: shared by the client, the tests and the fake PC.
 */
object AvekProtocol {

    const val VERSION = 4
    private val ZERO = byteArrayOf(0)

    // ------------------------------------------------------------------ identities

    /** `SHA-256("AVEK/4 key" ‖ pub)`. */
    fun fingerprint(publicRaw: ByteArray): ByteArray = SecureCrypto.sha256(utf8("AVEK/4 key"), publicRaw)

    /** `"d_"` + the first 10 hex digits of the fingerprint (of the key the device was paired with). */
    fun deviceIdOf(publicRaw: ByteArray): String = "d_" + SecureCrypto.hex(fingerprint(publicRaw)).take(10)

    /** `"s_"` + the first 8 hex digits of the fingerprint. */
    fun serverIdOf(publicRaw: ByteArray): String = "s_" + SecureCrypto.hex(fingerprint(publicRaw)).take(8)

    /** "a1b2 c3d4 e5f6 0718": the first 8 bytes in groups of four hex digits. */
    fun fingerprintText(publicRaw: ByteArray): String =
        SecureCrypto.hex(fingerprint(publicRaw)).take(16).chunked(4).joinToString(" ")

    // ------------------------------------------------------------------ the code (section 3)

    const val SCRYPT_N = 131_072
    const val SCRYPT_R = 8
    const val SCRYPT_P = 1
    const val CODE_DIGITS = 12

    /** Exactly 12 digits; spaces and `-` are ignored; anything else (or another length) is rejected. */
    fun normalizeCode(text: CharSequence): String? {
        val chars = CharArray(text.length) { text[it] }
        val digits = normalizeCodeDigits(chars) ?: return null
        return String(digits, Charsets.US_ASCII).also { digits.fill(0) }
    }

    /**
     * The same rule over a [CharArray] (what the code field holds), giving the 12 digits as UTF-8
     * bytes that the caller wipes after use. Never builds an immutable String of the code.
     */
    fun normalizeCodeDigits(chars: CharArray): ByteArray? {
        val out = ByteArray(CODE_DIGITS)
        var count = 0
        for (c in chars) {
            when {
                c in '0'..'9' -> {
                    if (count == CODE_DIGITS) {
                        out.fill(0)
                        return null
                    }
                    out[count++] = c.code.toByte()
                }
                c == ' ' || c == '-' -> Unit
                else -> {
                    out.fill(0)
                    return null
                }
            }
        }
        if (count != CODE_DIGITS) {
            out.fill(0)
            return null
        }
        return out
    }

    /** The PC's check value of the key (`SHA-256("AVEK/4 key check" ‖ 00 ‖ scrypt(key))`): PC side only, tested against the vectors. */
    fun keyCheck(keyScrypt: ByteArray): ByteArray = SecureCrypto.sha256(utf8("AVEK/4 key check"), ZERO, keyScrypt)

    /** `scrypt(secret, salt, N=131072, r=8, p=1, 32)`: about 128 MiB, run it off the main thread. */
    fun scrypt(secret: ByteArray, salt: ByteArray, n: Int = SCRYPT_N, r: Int = SCRYPT_R, p: Int = SCRYPT_P): ByteArray =
        SCrypt.generate(secret, salt, n, r, p, 32)

    /** The code key: scrypt over the 12 digits as UTF-8. The caller wipes [digits] afterwards. */
    fun scryptCode(digits: ByteArray, salt: ByteArray, n: Int = SCRYPT_N): ByteArray = scrypt(digits, salt, n)

    // ------------------------------------------------------------------ pairing (section 3)

    fun pairTranscript(
        serverPub: ByteArray,
        devicePub: ByteArray,
        clientEpk: ByteArray,
        serverEpk: ByteArray,
        clientNonce: ByteArray,
        serverNonce: ByteArray,
        salt: ByteArray,
    ): ByteArray = SecureCrypto.sha256(utf8("AVEK/4 pair"), ZERO, serverPub, devicePub, clientEpk, serverEpk, clientNonce, serverNonce, salt)

    fun pairClientMessage(transcript: ByteArray): ByteArray = concat(utf8("AVEK/4 pair client sig"), ZERO, transcript)

    fun pairServerMessage(transcript: ByteArray): ByteArray = concat(utf8("AVEK/4 pair server sig"), ZERO, transcript)

    fun pairClientMac(codeKey: ByteArray, transcript: ByteArray): ByteArray =
        SecureCrypto.hmacSha256(codeKey, utf8("AVEK/4 pair client mac"), ZERO, transcript)

    fun pairServerMac(codeKey: ByteArray, transcript: ByteArray): ByteArray =
        SecureCrypto.hmacSha256(codeKey, utf8("AVEK/4 pair server mac"), ZERO, transcript)

    /** HKDF(ikm = shared ‖ codeKey, salt = transcript, "avek4 pair box", 32). */
    fun pairBoxKey(shared: ByteArray, codeKey: ByteArray, transcript: ByteArray): ByteArray =
        SecureCrypto.hkdf(concat(shared, codeKey), transcript, "avek4 pair box")

    /** Opens the pairing box (one frame, counter 0). Throws [FrameException] when the tag fails. */
    fun openBox(boxKey: ByteArray, frame: ByteArray): ByteArray {
        val (counter, plain) = Frames.open(boxKey, frame)
        if (counter != 0L) throw FrameException("The box must have counter 0")
        return plain
    }

    // ------------------------------------------------------------------ session (section 4)

    class SessionKeysV4(
        val transcript: ByteArray,
        val mix: ByteArray,
        val macKey: ByteArray,
        val clientToServer: ByteArray,
        val serverToClient: ByteArray,
        val serverMessage: ByteArray,
        val clientMessage: ByteArray,
        val serverMac: ByteArray,
        val clientMac: ByteArray,
    )

    fun sessionKeys(
        shared: ByteArray,
        serverPub: ByteArray,
        devicePub: ByteArray,
        clientEpk: ByteArray,
        serverEpk: ByteArray,
        clientNonce: ByteArray,
        serverNonce: ByteArray,
        dk: ByteArray,
    ): SessionKeysV4 {
        val transcript = SecureCrypto.sha256(utf8("AVEK/4 session"), ZERO, serverPub, devicePub, clientEpk, serverEpk, clientNonce, serverNonce)
        val mix = SecureCrypto.hmacSha256(dk, utf8("AVEK/4 mix"), ZERO, transcript)
        val macKey = SecureCrypto.hkdf(shared, mix, "avek4 mac")
        return SessionKeysV4(
            transcript = transcript,
            mix = mix,
            macKey = macKey,
            clientToServer = SecureCrypto.hkdf(shared, mix, "avek4 c2s"),
            serverToClient = SecureCrypto.hkdf(shared, mix, "avek4 s2c"),
            serverMessage = concat(utf8("AVEK/4 server sig"), ZERO, transcript),
            clientMessage = concat(utf8("AVEK/4 client sig"), ZERO, transcript),
            serverMac = SecureCrypto.hmacSha256(macKey, utf8("server"), transcript),
            clientMac = SecureCrypto.hmacSha256(macKey, utf8("client"), transcript),
        )
    }

    // ------------------------------------------------------------------ key rotation (section 4.1)

    fun rekeyMessage(deviceId: String, newPub: ByteArray): ByteArray = concat(utf8("AVEK/4 rekey"), ZERO, utf8(deviceId), ZERO, newPub)

    // ------------------------------------------------------------------ knock and route proof (section 2)

    fun knockMessage(deviceId: String, ts: Long, nonce: ByteArray): ByteArray =
        concat(utf8("AVEK/4 knock"), ZERO, utf8(deviceId), ZERO, utf8(ts.toString()), ZERO, nonce)

    fun hereMessage(serverId: String, port: Int, deviceId: String, nonce: ByteArray): ByteArray =
        concat(utf8("AVEK/4 here"), ZERO, utf8(serverId), ZERO, utf8(port.toString()), ZERO, utf8(deviceId), ZERO, nonce)

    private val b64url = Base64.getUrlEncoder().withoutPadding()

    /** `AVEK <deviceId>.<ts>.<nonce b64url>.<mac b64url>`: opens the tunnel door (ngrok) once. */
    fun routeHeader(rk: ByteArray, deviceId: String, ts: Long, nonce: ByteArray): String {
        val mac = SecureCrypto.hmacSha256(rk, utf8("AVEK/4 route"), ZERO, utf8(deviceId), ZERO, utf8(ts.toString()), ZERO, nonce)
        return "AVEK $deviceId.$ts.${b64url.encodeToString(nonce)}.${b64url.encodeToString(mac)}"
    }
}
