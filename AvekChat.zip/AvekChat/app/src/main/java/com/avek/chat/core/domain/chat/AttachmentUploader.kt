package com.avek.chat.core.domain.chat

import com.avek.chat.core.link.HarnessApi
import com.avek.chat.core.link.crypto.SecureCrypto
import com.avek.chat.core.link.rpc.RpcException
import com.avek.chat.core.link.wire.ErrorCodes
import com.avek.chat.core.link.wire.LimitsDto
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.InputStream
import java.security.MessageDigest

/** A file the person picked. The Android implementation wraps a content URI. */
interface AttachmentSource {
    val name: String
    val mime: String
    val size: Long
    fun open(): InputStream
}

/** Turns what the system picker returned (a content URI string) into a readable [AttachmentSource]. */
fun interface AttachmentSourceFactory {
    fun create(uri: String): AttachmentSource?
}

sealed interface UploadProgress {
    data class Sending(val sent: Long, val total: Long) : UploadProgress {
        val fraction: Float get() = if (total <= 0) 0f else (sent.toFloat() / total).coerceIn(0f, 1f)
    }

    data class Done(val attachmentId: String, val name: String, val size: Long) : UploadProgress
}

/**
 * Uploads a file in chunks (UI-WIRE section 8.7): `attach.begin`, `attach.chunk` (indices 0, 1, 2…),
 * `attach.end` with the SHA-256 of the whole file. Cancelling the collector sends `attach.abort`.
 */
class AttachmentUploader(
    private val api: HarnessApi,
    private val limits: () -> LimitsDto,
) {
    fun upload(source: AttachmentSource): Flow<UploadProgress> = flow {
        val limit = limits()
        if (source.size > limit.maxAttachmentBytes) {
            throw RpcException(ErrorCodes.TOO_LARGE, "${source.name} is larger than ${limit.maxAttachmentBytes / (1024 * 1024)} MB")
        }
        val begin = api.attachBegin(source.name, source.mime, source.size)
        val chunkBytes = minOf(begin.chunkBytes, limit.attachChunkBytes).coerceAtLeast(1)
        var finished = false
        try {
            val digest = MessageDigest.getInstance("SHA-256")
            var sent = 0L
            var index = 0
            emit(UploadProgress.Sending(0, source.size))
            source.open().use { input ->
                val buffer = ByteArray(chunkBytes)
                while (true) {
                    val read = readFully(input, buffer)
                    if (read <= 0) break
                    digest.update(buffer, 0, read)
                    api.attachChunk(begin.uploadId, index++, SecureCrypto.b64(buffer.copyOf(read)))
                    sent += read
                    emit(UploadProgress.Sending(sent, source.size))
                    if (read < chunkBytes) break
                }
            }
            val end = api.attachEnd(begin.uploadId, SecureCrypto.hex(digest.digest()))
            finished = true
            emit(UploadProgress.Done(end.attachmentId, end.name.ifEmpty { source.name }, end.size))
        } finally {
            if (!finished) withContext(NonCancellable) { runCatching { api.attachAbort(begin.uploadId) } }
        }
    }.flowOn(Dispatchers.IO)

    /** Reads until the buffer is full or the stream ends (a single `read` may return less). */
    private fun readFully(input: InputStream, buffer: ByteArray): Int {
        var total = 0
        while (total < buffer.size) {
            val n = input.read(buffer, total, buffer.size - total)
            if (n < 0) break
            total += n
        }
        return total
    }
}
