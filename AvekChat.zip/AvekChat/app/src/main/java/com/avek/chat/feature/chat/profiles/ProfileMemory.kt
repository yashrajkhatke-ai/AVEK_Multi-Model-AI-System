package com.avek.chat.feature.chat.profiles

import com.avek.chat.core.link.wire.LoadProfileDto
import com.avek.chat.core.link.wire.ProfilesChangedDto
import com.avek.chat.core.link.wire.ProfilesData
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import javax.inject.Inject
import javax.inject.Singleton

/**
 * The last `profiles.list` answer per model, kept for [keepMs] (the list-memory rule): it fills the
 * composer row "Where it runs" without fetching anything. `profiles.changed` updates the active one.
 */
@Singleton
class ProfileMemory(
    private val nowMs: () -> Long,
    private val keepMs: Long,
) {
    @Inject constructor() : this(System::currentTimeMillis, KEEP_MS)

    private class Entry(val data: ProfilesData, val at: Long)

    private val entries = MutableStateFlow<Map<String, Entry>>(emptyMap())

    /** Bumped on every change, so a screen can recompute its summary. */
    private val _version = MutableStateFlow(0)
    val version: StateFlow<Int> = _version

    fun put(data: ProfilesData) {
        entries.update { it + (data.modelId to Entry(data, nowMs())) }
        _version.value++
    }

    /** The remembered list, or null when it was never loaded or is older than [keepMs]. */
    fun get(modelId: String): ProfilesData? {
        val entry = entries.value[modelId] ?: return null
        if (nowMs() - entry.at > keepMs) {
            entries.update { it - modelId }
            return null
        }
        return entry.data
    }

    /**
     * `profiles.changed` from any device: `applied` moves the active one; `saved`/`deleted` may have
     * changed what we hold, so the memory of that model is dropped (the row shows "-" until the sheet
     * is opened again; nothing is fetched behind the person's back).
     */
    fun onChanged(change: ProfilesChangedDto) {
        val entry = entries.value[change.modelId] ?: return
        val activeId = change.activeId ?: entry.data.activeId
        val keep = change.change == "applied" && entry.data.profiles.any { it.id == activeId }
        entries.update {
            if (keep) it + (change.modelId to Entry(entry.data.withActive(activeId), entry.at)) else it - change.modelId
        }
        _version.value++
    }

    /** "Fast — RTX 38 · iGPU 27 · CPU 0 layers · 75K context", or null ("-") until loaded once. */
    fun summary(modelId: String?): ProfileSummary? {
        if (modelId == null) return null
        val data = get(modelId) ?: return null
        val active = data.profiles.firstOrNull { it.id == data.activeId } ?: data.profiles.firstOrNull { it.active } ?: return null
        return ProfileSummary(active.name, LayerPlan.summary(active.toLayers(), active.contextTokens))
    }

    companion object {
        const val KEEP_MS = 120_000L
    }
}

data class ProfileSummary(val name: String, val line: String)

fun LoadProfileDto.toLayers(): Layers = Layers(layers.rtx, layers.igpu, layers.cpu)

fun ProfilesData.withActive(activeId: String?): ProfilesData =
    copy(activeId = activeId, profiles = profiles.map { it.copy(active = it.id == activeId) })
