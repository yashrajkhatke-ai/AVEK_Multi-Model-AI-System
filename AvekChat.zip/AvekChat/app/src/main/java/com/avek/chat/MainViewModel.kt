package com.avek.chat

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.avek.chat.core.data.fake.DemoContentSeeder
import com.avek.chat.core.domain.repository.ConversationRepository
import com.avek.chat.core.domain.repository.SettingsRepository
import com.avek.chat.core.model.settings.AppearanceSettings
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

sealed interface MainUiState {
    data object Loading : MainUiState
    data class Ready(val appearance: AppearanceSettings) : MainUiState
}

/** App-scoped state: appearance for the root theme, plus one-time startup work. */
@HiltViewModel
class MainViewModel @Inject constructor(
    settings: SettingsRepository,
    conversations: ConversationRepository,
    seeder: DemoContentSeeder,
) : ViewModel() {

    val uiState: StateFlow<MainUiState> = settings.settings
        .map { MainUiState.Ready(it.appearance) }
        .stateIn(viewModelScope, SharingStarted.Eagerly, MainUiState.Loading)

    init {
        viewModelScope.launch {
            conversations.recoverInterruptedReplies()
            seeder.seedIfNeeded()
        }
    }
}
