package com.avek.chat.core.model.settings

import kotlinx.serialization.Serializable

@Serializable
enum class FontSource { SYSTEM, GOOGLE }

@Serializable
data class FontChoice(
    val name: String,
    val source: FontSource,
) {
    companion object {
        val SystemSans = FontChoice("System Sans", FontSource.SYSTEM)
        val SystemSerif = FontChoice("System Serif", FontSource.SYSTEM)
        val SystemMono = FontChoice("System Mono", FontSource.SYSTEM)
        val SystemCursive = FontChoice("System Cursive", FontSource.SYSTEM)
        val systemFonts = listOf(SystemSans, SystemSerif, SystemMono, SystemCursive)

        fun google(name: String) = FontChoice(name, FontSource.GOOGLE)
    }
}

/** The independently styleable text roles in the app. */
@Serializable
enum class FontRole(val label: String, val sample: String) {
    INTERFACE("Interface", "Sidebar, buttons and menus"),
    HEADING("Headings & greeting", "How can I help you this evening?"),
    USER_MESSAGE("Your messages", "Can you help me plan a trip to Kyoto?"),
    ANSWER("Final answer", "Absolutely. Here is a three-day plan that balances temples, food and quiet gardens."),
    THINKING("Thinking", "The user wants a balanced itinerary. Let me weigh travel time against…"),
    CODE("Code", "fun greet(name: String) = \"Hi, \$name\""),
}

@Serializable
data class TextStyleSettings(
    val font: FontChoice,
    val sizeSp: Float,
    val weight: Int = 400,
    val lineHeight: Float = 1.45f,
    val letterSpacing: Float = 0f,
    val italic: Boolean = false,
)

@Serializable
data class FontSettings(
    val interfaceText: TextStyleSettings = TextStyleSettings(FontChoice.google("Inter"), 15f),
    val heading: TextStyleSettings = TextStyleSettings(FontChoice.google("Newsreader"), 30f, weight = 400, lineHeight = 1.2f),
    val userMessage: TextStyleSettings = TextStyleSettings(FontChoice.google("Inter"), 16f, lineHeight = 1.45f),
    val answer: TextStyleSettings = TextStyleSettings(FontChoice.google("Source Serif 4"), 17f, lineHeight = 1.55f),
    val thinking: TextStyleSettings = TextStyleSettings(FontChoice.google("Inter"), 14f, lineHeight = 1.5f, italic = false),
    val code: TextStyleSettings = TextStyleSettings(FontChoice.google("JetBrains Mono"), 13.5f, lineHeight = 1.5f),
) {
    operator fun get(role: FontRole): TextStyleSettings = when (role) {
        FontRole.INTERFACE -> interfaceText
        FontRole.HEADING -> heading
        FontRole.USER_MESSAGE -> userMessage
        FontRole.ANSWER -> answer
        FontRole.THINKING -> thinking
        FontRole.CODE -> code
    }

    fun with(role: FontRole, style: TextStyleSettings): FontSettings = when (role) {
        FontRole.INTERFACE -> copy(interfaceText = style)
        FontRole.HEADING -> copy(heading = style)
        FontRole.USER_MESSAGE -> copy(userMessage = style)
        FontRole.ANSWER -> copy(answer = style)
        FontRole.THINKING -> copy(thinking = style)
        FontRole.CODE -> copy(code = style)
    }
}
