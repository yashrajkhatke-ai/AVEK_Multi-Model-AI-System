package com.avek.chat.di

import com.avek.chat.core.data.downloads.DownloadManager
import com.avek.chat.core.domain.chat.AskCoordinator
import com.avek.chat.core.link.LinkLifecycleController
import com.avek.chat.platform.android.NotificationRouter
import kotlinx.coroutines.CoroutineScope
import javax.inject.Inject
import javax.inject.Singleton

/** Starts everything that must work without a screen: the link rules, downloads, asks, notifications. */
@Singleton
class AppStarter @Inject constructor(
    private val lifecycle: LinkLifecycleController,
    private val downloads: DownloadManager,
    private val asks: AskCoordinator,
    private val router: NotificationRouter,
    private val modelStates: com.avek.chat.core.domain.models.ModelStateTracker,
    private val traces: com.avek.chat.core.domain.trace.TraceRepository,
    private val timelines: com.avek.chat.core.domain.timeline.TimelineRepository,
    private val contexts: com.avek.chat.core.domain.context.ContextRepository,
    @ApplicationScope private val scope: CoroutineScope,
) {
    private var started = false

    @Synchronized
    fun start() {
        if (started) return
        started = true
        modelStates.start()
        traces.start()
        timelines.start()
        contexts.start()
        downloads.start()
        asks.start()
        router.start(scope)
        lifecycle.start()
    }
}
