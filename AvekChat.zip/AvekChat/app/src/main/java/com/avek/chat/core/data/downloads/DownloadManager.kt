package com.avek.chat.core.data.downloads

import com.avek.chat.core.data.remote.parseInstant
import com.avek.chat.core.link.HarnessApi
import com.avek.chat.core.link.LinkRepository
import com.avek.chat.core.link.route.ConnectionState
import com.avek.chat.core.link.wire.ChatSummaryDto
import com.avek.chat.core.link.wire.LinkEvent
import com.avek.chat.core.link.wire.TurnViewDto
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.filterIsInstance
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * Keeps the downloaded chats in step with the PC (UI-WIRE section 8.6):
 *  - `downloads.set` whenever the set changes and after every connect,
 *  - `downloads.status` after connecting to refresh stale copies and drop chats deleted on the PC,
 *  - live `download.turn` / `download.chat` / `download.deleted` events.
 *
 * Chats created by the demo link are kept apart from real ones by their id prefix, so demo copies
 * are never sent to (or deleted because of) a real PC.
 */
class DownloadManager(
    private val api: HarnessApi,
    private val store: DownloadedChatStore,
    private val link: LinkRepository,
    private val demoMode: StateFlow<Boolean>,
    private val scope: CoroutineScope,
) {
    private val mutex = Mutex()

    /** Ids of every downloaded chat (for the "downloaded" marker in lists). */
    val downloadedIds: Flow<Set<String>> get() = store.observeIds()

    val info: Flow<List<DownloadedChatInfo>> get() = store.observeInfo()

    fun start() {
        scope.launch {
            link.state.map { it is ConnectionState.Connected }.distinctUntilChanged().collect { connected ->
                if (connected) runCatching { syncAfterConnect() }
            }
        }
        scope.launch { link.events.collect { event -> runCatching { onEvent(event) } } }
    }

    /** Downloads a complete copy of [chatId] and starts keeping it live. */
    suspend fun download(chatId: String) = mutex.withLock {
        val previous = relevantIds(store.ids())
        val updated = (previous + chatId).toList()
        api.downloadsSet(updated)
        try {
            fetchCopy(chatId)
        } catch (e: Throwable) {
            runCatching { api.downloadsSet(previous.toList()) }
            throw e
        }
    }

    /** Removes the local copy; the PC is told on the spot if reachable, otherwise on the next connect. */
    suspend fun remove(chatId: String) = mutex.withLock {
        store.delete(chatId)
        if (link.state.value is ConnectionState.Connected) {
            runCatching { api.downloadsSet(relevantIds(store.ids()).toList()) }
        }
    }

    /** Removes every local copy of the chats this mode owns (demo copies and real copies stay apart). */
    suspend fun removeAll() = mutex.withLock {
        val ids = relevantIds(store.ids())
        ids.forEach { store.delete(it) }
        if (link.state.value is ConnectionState.Connected) runCatching { api.downloadsSet(emptyList()) }
    }

    private suspend fun syncAfterConnect() = mutex.withLock {
        val ids = relevantIds(store.ids()).toList()
        if (ids.isEmpty()) {
            api.downloadsSet(emptyList())
            return@withLock
        }
        api.downloadsSet(ids)
        val status = api.downloadsStatus(ids)
        for (item in status.items) {
            if (!item.exists) {
                store.delete(item.chatId) // deleted on the PC while we were away
                continue
            }
            val local = store.chat(item.chatId)
            val stale = local == null || local.updatedAt != parseInstant(item.updatedAt) || local.turnCount != item.turnCount
            if (stale) runCatching { fetchCopy(item.chatId) }
        }
    }

    private suspend fun fetchCopy(chatId: String) {
        var summary: ChatSummaryDto? = null
        val turns = mutableListOf<TurnViewDto>()
        api.chatGetAll(chatId, HarnessApi.INCLUDE_THINKING_AND_TOOLS).collect { part ->
            if (summary == null) summary = part.chat
            turns += part.items
        }
        store.replace(checkNotNull(summary) { "The PC sent no chat summary" }, turns)
    }

    private suspend fun onEvent(event: LinkEvent) {
        when (event) {
            is LinkEvent.DownloadTurn -> if (isRelevant(event.data.chatId)) store.upsertTurn(event.data.chatId, event.data.turn)
            is LinkEvent.DownloadChat -> if (isRelevant(event.chat.chatId)) store.upsertChat(event.chat)
            is LinkEvent.DownloadDeleted -> if (isRelevant(event.chatId)) store.delete(event.chatId) // the PC deleted it: we MUST too
            else -> Unit
        }
    }

    private fun isRelevant(chatId: String) = DemoIds.isDemo(chatId) == demoMode.value

    private fun relevantIds(ids: Set<String>) = ids.filter(::isRelevant).toSet()
}

object DemoIds {
    const val PREFIX = "c_demo_"
    fun isDemo(chatId: String) = chatId.startsWith(PREFIX)
}
