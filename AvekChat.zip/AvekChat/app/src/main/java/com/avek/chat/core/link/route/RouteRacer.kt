package com.avek.chat.core.link.route

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

/** The three ways to the same PC (UI-WIRE v4 section 2.2). [wire] is the value of `ready.route`. */
enum class RouteKind(val wire: String, val label: String) {
    WIFI("wifi", "Wi-Fi"),
    TAILSCALE("tailscale", "Tailscale"),
    NGROK("tunnel", "ngrok");

    companion object {
        fun fromWire(value: String?): RouteKind? = entries.firstOrNull { it.wire == value }
    }
}

/** The person's route setting (section 2.3, item 8). */
enum class RouteMode(val label: String) {
    Auto("Auto"),
    WifiOnly("Wi-Fi only"),
    TailscaleOnly("Tailscale only"),
    NgrokOnly("ngrok only");

    val only: RouteKind?
        get() = when (this) {
            Auto -> null
            WifiOnly -> RouteKind.WIFI
            TailscaleOnly -> RouteKind.TAILSCALE
            NgrokOnly -> RouteKind.NGROK
        }
}

/** Why a route failed (section 2.3, item 5). */
enum class FailureReason { NotFound, Refused, Denied, Timeout, Skipped, Error }

/** Something only the person can fix: retrying the route cannot help. */
enum class Fatal {
    /** 4401 right after a valid knock or route proof: "This PC forgot this device. Pair again." */
    Forgotten,

    /** The PC that answered did not prove the pinned key and `dk`. */
    NotOurPc,
}

data class RouteFailure(
    val route: RouteKind,
    val reason: FailureReason,
    val message: String,
    val fatal: Fatal? = null,
)

/** Thrown by a [RouteAttempt] to report why it failed. */
class RouteFailedException(
    val reason: FailureReason,
    override val message: String,
    val fatal: Fatal? = null,
    cause: Throwable? = null,
) : Exception(message, cause)

/** One route of one race. [connect] must close what it opened when cancelled. */
interface RouteAttempt<T : Any> {
    val kind: RouteKind

    /** Non-null when the route cannot run on this phone now (`Skipped`, with the sentence to show). */
    fun skipReason(): String?

    /** Reaches the PC and completes the session handshake (and `ready`). Throws [RouteFailedException]. */
    suspend fun connect(): T
}

sealed interface RaceResult<out T : Any> {
    data class Winner<T : Any>(val route: RouteKind, val connection: T, val failures: List<RouteFailure>) : RaceResult<T>
    data class AllFailed(val failures: List<RouteFailure>) : RaceResult<Nothing>
}

/**
 * Section 2.3 exactly: in [RouteMode.Auto] Wi-Fi and Tailscale start at t = 0; ngrok starts at
 * t = 3 s only if nothing has finished its handshake yet (or at once when both earlier routes have
 * failed); the first route that completes wins and the others are cancelled; overall limit 20 s.
 * In a restricted mode only that route runs, immediately. Timing comes from the coroutine clock,
 * so tests run it on virtual time.
 */
class RouteRacer(
    private val ngrokDelayMs: Long = NGROK_DELAY_MS,
    private val overallMs: Long = OVERALL_MS,
) {
    private sealed interface Outcome<out T> {
        class Success<T>(val kind: RouteKind, val connection: T) : Outcome<T>
        class Failure(val failure: RouteFailure) : Outcome<Nothing>
        data object NgrokTime : Outcome<Nothing>
    }

    /**
     * Races [attempts] (at most one per kind). Connections that finish after the winner are passed
     * to [discard] (closed), so nothing stays open.
     */
    suspend fun <T : Any> race(
        mode: RouteMode,
        attempts: List<RouteAttempt<T>>,
        discard: (T) -> Unit,
    ): RaceResult<T> = coroutineScope {
        // Everything is launched here, not inside the timeout below (which would wait for its children).
        val raceScope = this
        val byKind = attempts.associateBy { it.kind }
        val outcomes = Channel<Outcome<T>>(Channel.UNLIMITED)
        val failures = LinkedHashMap<RouteKind, RouteFailure>()
        val jobs = LinkedHashMap<RouteKind, Job>()
        val running = LinkedHashSet<RouteKind>()

        fun start(kind: RouteKind) {
            val attempt = byKind[kind]
            val skip = if (attempt == null) NOT_SET_UP else attempt.skipReason()
            if (attempt == null || skip != null) {
                failures[kind] = RouteFailure(kind, FailureReason.Skipped, skip ?: NOT_SET_UP)
                return
            }
            running += kind
            jobs[kind] = raceScope.launch {
                val outcome: Outcome<T> = try {
                    Outcome.Success(kind, attempt.connect())
                } catch (e: CancellationException) {
                    throw e
                } catch (e: RouteFailedException) {
                    Outcome.Failure(RouteFailure(kind, e.reason, e.message, e.fatal))
                } catch (e: Exception) {
                    Outcome.Failure(RouteFailure(kind, FailureReason.Error, e.message ?: "Something went wrong"))
                }
                if (outcome is Outcome.Success && outcomes.trySend(outcome).isFailure) discard(outcome.connection)
                if (outcome is Outcome.Failure) outcomes.trySend(outcome)
            }
        }

        var winner: Outcome.Success<T>? = null
        var ngrokStarted = false
        var ngrokTime = false
        val only = mode.only

        val finished = withTimeoutOrNull(overallMs) {
            if (only != null) {
                start(only)
            } else {
                start(RouteKind.WIFI)
                start(RouteKind.TAILSCALE)
                jobs[RouteKind.NGROK] = raceScope.launch {
                    delay(ngrokDelayMs)
                    outcomes.trySend(Outcome.NgrokTime)
                }
            }
            while (true) {
                if (only == null && !ngrokStarted) {
                    val earlierFailed = RouteKind.WIFI in failures && RouteKind.TAILSCALE in failures
                    if (ngrokTime || earlierFailed) {
                        ngrokStarted = true
                        jobs.remove(RouteKind.NGROK)?.cancel()
                        start(RouteKind.NGROK)
                    }
                }
                if (running.isEmpty() && (only != null || ngrokStarted)) break
                when (val outcome = outcomes.receive()) {
                    is Outcome.Success -> {
                        winner = outcome
                        running -= outcome.kind
                        break
                    }
                    is Outcome.Failure -> {
                        running -= outcome.failure.route
                        failures[outcome.failure.route] = outcome.failure
                    }
                    Outcome.NgrokTime -> ngrokTime = true
                }
            }
            true
        }

        // Cancel the losers (their attempts close their sockets) and close any late winner.
        jobs.values.forEach { it.cancel() }
        jobs.values.forEach { it.join() }
        outcomes.close()
        while (true) {
            val late = outcomes.tryReceive().getOrNull() ?: break
            if (late is Outcome.Success) discard(late.connection)
        }

        if (finished == null) {
            running.forEach { failures[it] = RouteFailure(it, FailureReason.Timeout, "No answer within ${overallMs / 1000} s") }
            if (only == null && !ngrokStarted && RouteKind.NGROK !in failures) {
                failures[RouteKind.NGROK] = RouteFailure(RouteKind.NGROK, FailureReason.Timeout, "No answer within ${overallMs / 1000} s")
            }
        }
        val won = winner
        val ordered = RouteKind.entries.mapNotNull { failures[it] }
        if (won != null) RaceResult.Winner(won.kind, won.connection, ordered) else RaceResult.AllFailed(ordered)
    }

    companion object {
        const val NGROK_DELAY_MS = 3_000L
        const val OVERALL_MS = 20_000L
        const val NOT_SET_UP = "Not set up"
    }
}
