package com.avek.chat.core.link.crypto

import java.security.GeneralSecurityException

/** Thrown when a secure frame is malformed, replayed, out of order or fails authentication. */
class FrameException(message: String, cause: Throwable? = null) : Exception(message, cause)

/**
 * AVEK-SEC/1 frame layout (UI-WIRE section 5):
 * `counter(8, big-endian) || ciphertext || tag(16)`, AES-256-GCM, nonce = `00 00 00 00 || counter`, empty AAD.
 */
object Frames {
    private const val COUNTER_BYTES = 8
    const val MIN_FRAME_BYTES = COUNTER_BYTES + SecureCrypto.TAG_BYTES

    fun nonce(counter: Long): ByteArray {
        val nonce = ByteArray(SecureCrypto.GCM_NONCE_BYTES)
        for (i in 0 until COUNTER_BYTES) nonce[4 + i] = (counter ushr (8 * (COUNTER_BYTES - 1 - i))).toByte()
        return nonce
    }

    fun counterBytes(counter: Long): ByteArray =
        ByteArray(COUNTER_BYTES) { i -> (counter ushr (8 * (COUNTER_BYTES - 1 - i))).toByte() }

    fun readCounter(frame: ByteArray): Long {
        var value = 0L
        for (i in 0 until COUNTER_BYTES) value = (value shl 8) or (frame[i].toLong() and 0xFF)
        return value
    }

    /** Seals [plaintext] with an explicit [counter] (used by the test vectors). */
    fun seal(key: ByteArray, counter: Long, plaintext: ByteArray): ByteArray =
        counterBytes(counter) + SecureCrypto.aesGcmSeal(key, nonce(counter), ByteArray(0), plaintext)

    /** Opens a frame regardless of ordering; returns the counter and the plaintext. */
    fun open(key: ByteArray, frame: ByteArray): Pair<Long, ByteArray> {
        if (frame.size < MIN_FRAME_BYTES) throw FrameException("Frame too short")
        val counter = readCounter(frame)
        val plaintext = try {
            SecureCrypto.aesGcmOpen(key, nonce(counter), ByteArray(0), frame.copyOfRange(COUNTER_BYTES, frame.size))
        } catch (e: GeneralSecurityException) {
            throw FrameException("Frame failed authentication", e)
        }
        return counter to plaintext
    }
}

/** Sending side of one direction: the counter starts at 0 and increases by exactly 1 per frame. */
class FrameSealer(private val key: ByteArray) {
    private var next = 0L

    @Synchronized
    fun seal(plaintext: ByteArray): ByteArray = Frames.seal(key, next++, plaintext)
}

/**
 * Receiving side of one direction. Rejects any frame whose counter is not
 * strictly greater than the last accepted one, or whose tag fails.
 */
class FrameOpener(private val key: ByteArray) {
    private var lastAccepted = -1L

    @Synchronized
    fun open(frame: ByteArray): ByteArray {
        val (counter, plaintext) = Frames.open(key, frame)
        if (counter <= lastAccepted) throw FrameException("Replayed or out-of-order frame (counter $counter after $lastAccepted)")
        lastAccepted = counter
        return plaintext
    }
}
