package com.avek.chat.core.domain.usecase

import com.avek.chat.core.common.TimeProvider
import com.avek.chat.core.model.Conversation
import java.time.Instant
import java.time.format.TextStyle
import java.time.temporal.ChronoUnit
import java.util.Locale
import javax.inject.Inject

data class HistorySection(
    val key: String,
    val label: String,
    val conversations: List<Conversation>,
)

/** Buckets conversations the way people think about time: Today, Yesterday, Last week… */
class HistoryGrouper @Inject constructor(
    private val time: TimeProvider,
) {
    fun group(conversations: List<Conversation>, pinStarred: Boolean = true): List<HistorySection> {
        val zone = time.zone()
        val today = Instant.ofEpochMilli(time.now()).atZone(zone).toLocalDate()
        val sections = LinkedHashMap<String, Pair<String, MutableList<Conversation>>>()

        fun add(key: String, label: String, conversation: Conversation) {
            sections.getOrPut(key) { label to mutableListOf() }.second += conversation
        }

        if (pinStarred) {
            conversations.filter { it.isStarred }.forEach { add(KEY_STARRED, "Starred", it) }
        }

        conversations
            .filter { !pinStarred || !it.isStarred }
            .sortedByDescending { it.updatedAt }
            .forEach { conversation ->
                val date = Instant.ofEpochMilli(conversation.updatedAt).atZone(zone).toLocalDate()
                val days = ChronoUnit.DAYS.between(date, today)
                when {
                    days <= 0L -> add("today", "Today", conversation)
                    days == 1L -> add("yesterday", "Yesterday", conversation)
                    days < 7L -> add("week", "Previous 7 days", conversation)
                    days < 30L -> add("month", "Previous 30 days", conversation)
                    else -> {
                        val monthName = date.month.getDisplayName(TextStyle.FULL, Locale.getDefault())
                        val label = if (date.year == today.year) monthName else "$monthName ${date.year}"
                        add("m-${date.year}-${date.monthValue}", label, conversation)
                    }
                }
            }

        return sections.map { (key, value) -> HistorySection(key, value.first, value.second) }
    }

    companion object {
        const val KEY_STARRED = "starred"
    }
}
