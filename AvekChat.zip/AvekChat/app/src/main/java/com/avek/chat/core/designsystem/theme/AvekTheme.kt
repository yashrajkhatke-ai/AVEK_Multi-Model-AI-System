package com.avek.chat.core.designsystem.theme

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.avek.chat.core.model.settings.AppearanceSettings
import com.avek.chat.core.model.settings.ChatLayout
import com.avek.chat.core.model.settings.MotionSettings
import com.avek.chat.core.model.settings.ThemeMode

val LocalAvekColors = staticCompositionLocalOf { ThemeCatalog.resolve(ThemeCatalog.DEFAULT_ID).light }
val LocalAvekTypography = staticCompositionLocalOf { AvekTypography.resolve(com.avek.chat.core.model.settings.FontSettings(), SystemFontResolver) }
val LocalChatLayout = staticCompositionLocalOf { ChatLayout() }
val LocalMotion = staticCompositionLocalOf { MotionSettings() }

/** Convenience accessors: `AvekTheme.colors.accent`, `AvekTheme.type.answer`, … */
object AvekTheme {
    val colors: AvekColors
        @Composable @ReadOnlyComposable get() = LocalAvekColors.current
    val type: AvekTypography
        @Composable @ReadOnlyComposable get() = LocalAvekTypography.current
    val layout: ChatLayout
        @Composable @ReadOnlyComposable get() = LocalChatLayout.current
    val motion: MotionSettings
        @Composable @ReadOnlyComposable get() = LocalMotion.current
}

fun AppearanceSettings.isDark(systemDark: Boolean): Boolean = when (themeMode) {
    ThemeMode.SYSTEM -> systemDark
    ThemeMode.LIGHT -> false
    ThemeMode.DARK -> true
}

fun AppearanceSettings.resolveColors(dark: Boolean): AvekColors =
    ThemeCatalog.resolve(themeId).colors(dark).withOverrides(if (dark) darkOverrides else lightOverrides)

@Composable
fun AvekTheme(
    appearance: AppearanceSettings,
    fontResolver: FontResolver = LocalFontResolver.current,
    systemDark: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    val dark = appearance.isDark(systemDark)
    val target = remember(appearance.themeId, appearance.lightOverrides, appearance.darkOverrides, dark) {
        appearance.resolveColors(dark)
    }
    val colors = animateColors(target, enabled = !appearance.motion.reduceMotion)
    val typography = remember(appearance.fonts, fontResolver) { AvekTypography.resolve(appearance.fonts, fontResolver) }

    CompositionLocalProvider(
        LocalFontResolver provides fontResolver,
        LocalAvekColors provides colors,
        LocalAvekTypography provides typography,
        LocalChatLayout provides appearance.chat,
        LocalMotion provides appearance.motion,
    ) {
        MaterialTheme(
            colorScheme = colors.toMaterial(),
            typography = typography.toMaterial(),
            shapes = AvekShapes,
            content = content,
        )
    }
}

val AvekShapes = Shapes(
    extraSmall = RoundedCornerShape(6.dp),
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(20.dp),
    extraLarge = RoundedCornerShape(28.dp),
)

/** Smoothly cross-fades every token when the theme changes. */
@Composable
private fun animateColors(target: AvekColors, enabled: Boolean): AvekColors {
    if (!enabled) return target
    @Composable
    fun animate(color: Color): Color {
        val value by animateColorAsState(color, animationSpec = tween(450), label = "theme")
        return value
    }
    return AvekColors(
        isDark = target.isDark,
        chatBackground = animate(target.chatBackground),
        topBar = animate(target.topBar),
        surface = animate(target.surface),
        outline = animate(target.outline),
        userBubble = animate(target.userBubble),
        userText = animate(target.userText),
        assistantBubble = animate(target.assistantBubble),
        assistantText = animate(target.assistantText),
        thinkingSurface = animate(target.thinkingSurface),
        thinkingText = animate(target.thinkingText),
        codeSurface = animate(target.codeSurface),
        codeText = animate(target.codeText),
        sidebar = animate(target.sidebar),
        sidebarSelected = animate(target.sidebarSelected),
        sidebarText = animate(target.sidebarText),
        composer = animate(target.composer),
        composerBorder = animate(target.composerBorder),
        accent = animate(target.accent),
        onAccent = animate(target.onAccent),
        thinkingGlow = animate(target.thinkingGlow),
        textPrimary = animate(target.textPrimary),
        textSecondary = animate(target.textSecondary),
    )
}
