package com.avek.chat.core.designsystem.component

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.avek.chat.core.designsystem.theme.AvekTheme
import com.avek.chat.core.designsystem.theme.ColorMath
import com.avek.chat.core.designsystem.theme.Hsv

private val QuickSwatches = listOf(
    0xFFFAF9F5, 0xFFF0EDE4, 0xFFE8E4D9, 0xFF262624, 0xFF1A1A18, 0xFF000000, 0xFFFFFFFF, 0xFFC96442,
    0xFFD97757, 0xFFE5484D, 0xFFF76B15, 0xFFFFC53D, 0xFF46A758, 0xFF12A594, 0xFF0090FF, 0xFF3E63DD,
    0xFF6E56CF, 0xFFAB4ABA, 0xFFD6409F, 0xFF8D8D86, 0xFF5B5BD6, 0xFF29A383, 0xFFAD7F58, 0xFF978365,
).map { Color(it) }

/**
 * A full HSV colour picker: saturation/value field, hue rail, hex input,
 * colour harmonies and quick swatches, with a live before/after preview.
 */
@Composable
fun ColorPickerDialog(
    title: String,
    initial: Color,
    onDismiss: () -> Unit,
    onConfirm: (Color) -> Unit,
    onReset: (() -> Unit)? = null,
) {
    val colors = AvekTheme.colors
    var hsv by remember { mutableStateOf(Hsv.from(initial)) }
    var hexText by remember { mutableStateOf(ColorMath.toHex(initial)) }
    val current = hsv.toColor()

    fun update(newHsv: Hsv) {
        hsv = newHsv
        hexText = ColorMath.toHex(newHsv.toColor())
    }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(
            modifier = Modifier.padding(20.dp).fillMaxWidth(),
            shape = RoundedCornerShape(28.dp),
            color = colors.surface,
            tonalElevation = 0.dp,
            shadowElevation = 12.dp,
        ) {
            Column(
                Modifier
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp),
            ) {
                Text(title, style = AvekTheme.type.title, color = colors.textPrimary)
                Spacer(Modifier.height(16.dp))

                // Saturation × Value field.
                Canvas(
                    Modifier
                        .fillMaxWidth()
                        .height(190.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .pointerInput(Unit) {
                            fun pick(o: Offset) = update(
                                hsv.copy(
                                    saturation = (o.x / size.width).coerceIn(0f, 1f),
                                    value = 1f - (o.y / size.height).coerceIn(0f, 1f),
                                ),
                            )
                            detectTapGestures { pick(it) }
                        }
                        .pointerInput(Unit) {
                            detectDragGestures { change, _ ->
                                change.consume()
                                update(
                                    hsv.copy(
                                        saturation = (change.position.x / size.width).coerceIn(0f, 1f),
                                        value = 1f - (change.position.y / size.height).coerceIn(0f, 1f),
                                    ),
                                )
                            }
                        },
                ) {
                    drawRect(Hsv(hsv.hue, 1f, 1f).toColor())
                    drawRect(Brush.horizontalGradient(listOf(Color.White, Color.Transparent)))
                    drawRect(Brush.verticalGradient(listOf(Color.Transparent, Color.Black)))
                    val p = Offset(hsv.saturation * size.width, (1f - hsv.value) * size.height)
                    drawCircle(Color.White, radius = 11.dp.toPx(), center = p, style = Stroke(3.dp.toPx()))
                    drawCircle(Color.Black.copy(alpha = 0.35f), radius = 13.dp.toPx(), center = p, style = Stroke(1.dp.toPx()))
                }

                Spacer(Modifier.height(14.dp))

                // Hue rail.
                Canvas(
                    Modifier
                        .fillMaxWidth()
                        .height(26.dp)
                        .clip(RoundedCornerShape(13.dp))
                        .pointerInput(Unit) {
                            detectTapGestures { update(hsv.copy(hue = (it.x / size.width).coerceIn(0f, 1f) * 360f)) }
                        }
                        .pointerInput(Unit) {
                            detectDragGestures { change, _ ->
                                change.consume()
                                update(hsv.copy(hue = (change.position.x / size.width).coerceIn(0f, 1f) * 359.9f))
                            }
                        },
                ) {
                    drawRect(Brush.horizontalGradient((0..6).map { Hsv(it * 60f, 1f, 1f).toColor() }))
                    val x = hsv.hue / 360f * size.width
                    drawRoundRect(
                        Color.White,
                        topLeft = Offset(x - 4.dp.toPx(), 1.dp.toPx()),
                        size = androidx.compose.ui.geometry.Size(8.dp.toPx(), size.height - 2.dp.toPx()),
                        cornerRadius = CornerRadius(4.dp.toPx()),
                        style = Stroke(2.5.dp.toPx()),
                    )
                }

                Spacer(Modifier.height(16.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Row(
                        Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .border(1.dp, colors.outline, RoundedCornerShape(12.dp)),
                    ) {
                        Box(Modifier.size(44.dp).background(initial))
                        Box(Modifier.size(44.dp).background(current))
                    }
                    Spacer(Modifier.width(12.dp))
                    OutlinedTextField(
                        value = hexText,
                        onValueChange = { text ->
                            hexText = text.take(9)
                            ColorMath.parseHex(text)?.let { hsv = Hsv.from(it) }
                        },
                        singleLine = true,
                        label = { Text("Hex") },
                        keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Characters),
                        textStyle = AvekTheme.type.code.copy(color = colors.textPrimary),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = colors.accent,
                            unfocusedBorderColor = colors.outline,
                            focusedLabelColor = colors.accent,
                            cursorColor = colors.accent,
                        ),
                        modifier = Modifier.weight(1f),
                    )
                }

                Spacer(Modifier.height(16.dp))
                Text("Harmonies", style = AvekTheme.type.label, color = colors.textSecondary)
                Spacer(Modifier.height(8.dp))
                val harmonies = listOf(
                    "Complement" to hsv.copy(hue = hsv.hue + 180f),
                    "Analog −" to hsv.copy(hue = hsv.hue - 30f),
                    "Analog +" to hsv.copy(hue = hsv.hue + 30f),
                    "Triad" to hsv.copy(hue = hsv.hue + 120f),
                    "Lighter" to hsv.copy(value = (hsv.value + 0.15f).coerceAtMost(1f), saturation = hsv.saturation * 0.85f),
                    "Darker" to hsv.copy(value = hsv.value * 0.75f),
                    "Muted" to hsv.copy(saturation = hsv.saturation * 0.45f),
                )
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    harmonies.forEach { (name, value) ->
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(
                                Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(value.toColor())
                                    .border(1.dp, colors.outline, CircleShape)
                                    .clickable { update(value.copy(hue = ((value.hue % 360f) + 360f) % 360f)) },
                            )
                            Text(name, style = AvekTheme.type.caption, color = colors.textTertiary)
                        }
                    }
                }

                Spacer(Modifier.height(14.dp))
                Text("Swatches", style = AvekTheme.type.label, color = colors.textSecondary)
                Spacer(Modifier.height(8.dp))
                QuickSwatches.chunked(8).forEach { row ->
                    Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        row.forEach { swatch ->
                            Box(
                                Modifier
                                    .size(30.dp)
                                    .clip(CircleShape)
                                    .background(swatch)
                                    .border(1.dp, colors.outline, CircleShape)
                                    .clickable { update(Hsv.from(swatch)) },
                            )
                        }
                    }
                }

                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (onReset != null) {
                        TextButton(onClick = onReset) { Text("Reset", color = colors.textSecondary) }
                    }
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick = onDismiss) { Text("Cancel", color = colors.textSecondary) }
                    Spacer(Modifier.width(4.dp))
                    Box(
                        Modifier
                            .clip(RoundedCornerShape(50))
                            .background(colors.accent)
                            .clickable { onConfirm(current) }
                            .padding(horizontal = 20.dp, vertical = 10.dp),
                    ) {
                        Text("Apply", style = AvekTheme.type.label.copy(fontWeight = FontWeight.SemiBold), color = colors.onAccent)
                    }
                }
            }
        }
    }
}
