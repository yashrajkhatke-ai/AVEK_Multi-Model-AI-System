package com.avek.chat.core.link.rpc

import com.avek.chat.core.link.wire.ErrorBody
import com.avek.chat.core.link.wire.WireCodec
import com.avek.chat.core.link.wire.WireResponse
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.intOrNull
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong

/** Anything that makes a request fail. [code] is a protocol error code or one of the local ones below. */
class RpcException(val code: String, message: String, cause: Throwable? = null) : Exception(message, cause) {
    companion object {
        const val NOT_CONNECTED = "not-connected"
        const val TIMEOUT = "timeout"
        const val CONNECTION_LOST = "connection-lost"
        const val NOT_FOUND_LOCAL = "not-found"

        fun notConnected() = RpcException(NOT_CONNECTED, "PC not reachable")
    }
}

/** One part of a list reply: `total` and `next` are as described in UI-WIRE section 7. */
class ListPart(
    val items: List<JsonElement>,
    val total: Int?,
    val next: String?,
    val more: Boolean,
    /** The whole `data` object of the part (the first `chat.get` part also carries `chat`). */
    val raw: JsonObject = JsonObject(emptyMap()),
)

object RpcTimeouts {
    const val DEFAULT_MS = 15_000L
    const val PROMPT_MS = 20_000L
    const val ATTACH_END_MS = 60_000L

    fun forOp(op: String): Long = when (op) {
        "prompt" -> PROMPT_MS
        "attach.end" -> ATTACH_END_MS
        else -> DEFAULT_MS
    }
}

/**
 * Request ids, timeouts, multi-part replies and cancellation (UI-WIRE section 6).
 * [send] writes one JSON text message; the owner feeds replies to [onResponse].
 */
class RpcClient(private val send: suspend (String) -> Unit) {

    private val pending = ConcurrentHashMap<String, Channel<WireResponse>>()
    private val counter = AtomicLong()

    @Volatile
    private var failure: RpcException? = null

    fun onResponse(response: WireResponse) {
        pending[response.re]?.trySend(response)
    }

    /** Fails every waiting request and every request made afterwards. */
    fun failAll(cause: RpcException) {
        failure = cause
        pending.values.forEach { it.close(cause) }
        pending.clear()
    }

    /**
     * Sends one request and returns its `data`. A reply in several parts (a list that did not fit one
     * frame) is merged: `items` are concatenated in order, the first part's fields (`total`, `chat`)
     * are kept and the last part's `next` wins (UI-WIRE v3 section 7).
     */
    suspend fun call(op: String, args: JsonObject, timeoutMs: Long = RpcTimeouts.forOp(op)): JsonElement {
        val parts = mutableListOf<JsonElement?>()
        collectParts(op, args, timeoutMs) { response -> parts += response.data }
        return mergeParts(parts)
    }

    private fun mergeParts(parts: List<JsonElement?>): JsonElement {
        if (parts.size <= 1) return parts.firstOrNull() ?: JsonObject(emptyMap())
        val objects = parts.filterIsInstance<JsonObject>()
        if (objects.size != parts.size || objects.any { it["items"] !is JsonArray }) return parts.last() ?: JsonObject(emptyMap())
        val merged = LinkedHashMap<String, JsonElement>(objects.first())
        merged["items"] = JsonArray(objects.flatMap { (it["items"] as JsonArray).toList() })
        objects.last()["next"]?.let { merged["next"] = it } ?: merged.remove("next")
        return JsonObject(merged)
    }

    /** Sends a list request; every part is emitted as soon as it arrives. */
    fun callList(op: String, args: JsonObject, timeoutMs: Long = RpcTimeouts.forOp(op)): Flow<ListPart> = flow {
        collectParts(op, args, timeoutMs) { response ->
            val data = response.data as? JsonObject
            emit(
                ListPart(
                    items = (data?.get("items") as? JsonArray)?.toList().orEmpty(),
                    total = (data?.get("total") as? JsonPrimitive)?.intOrNull,
                    next = (data?.get("next") as? JsonPrimitive)?.takeIf { it !is kotlinx.serialization.json.JsonNull }?.contentOrNull,
                    more = response.more,
                    raw = data ?: JsonObject(emptyMap()),
                ),
            )
        }
    }

    private suspend fun collectParts(
        op: String,
        args: JsonObject,
        timeoutMs: Long,
        onPart: suspend (WireResponse) -> Unit,
    ) {
        failure?.let { throw it }
        val id = "r${counter.incrementAndGet()}"
        val inbox = Channel<WireResponse>(Channel.UNLIMITED)
        pending[id] = inbox
        try {
            try {
                send(WireCodec.encodeRequest(id, op, args))
            } catch (e: Exception) {
                if (e is kotlinx.coroutines.CancellationException) throw e
                throw RpcException(RpcException.CONNECTION_LOST, "Could not send $op", e)
            }
            while (true) {
                val response = try {
                    withTimeoutOrNull(timeoutMs) { inbox.receive() }
                } catch (e: RpcException) {
                    throw e
                } ?: throw RpcException(RpcException.TIMEOUT, "No reply to $op within ${timeoutMs / 1000}s")
                if (!response.ok) {
                    val error: ErrorBody = response.error ?: ErrorBody()
                    throw RpcException(error.code, error.message.ifEmpty { error.code })
                }
                onPart(response)
                if (!response.more) return
            }
        } catch (e: kotlinx.coroutines.channels.ClosedReceiveChannelException) {
            throw failure ?: RpcException(RpcException.CONNECTION_LOST, "Connection lost")
        } finally {
            pending.remove(id)
            inbox.close()
        }
    }
}
