package com.avek.chat.core.designsystem.theme

import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.Color
import kotlin.random.Random

@Immutable
data class ThemeDefinition(
    val id: String,
    val name: String,
    val subtitle: String,
    val light: AvekColors,
    val dark: AvekColors,
) {
    fun colors(dark: Boolean): AvekColors = if (dark) this.dark else light
}

data class AccentHue(val name: String, val hue: Float)

/** Filter for browsing the generated theme space. `null` means "any". */
data class ThemeFilter(
    val hueIndex: Int? = null,
    val family: NeutralFamily? = null,
    val tone: BubbleTone? = null,
    val contrast: ContrastLevel? = null,
)

/**
 * Every theme the app knows about:
 *  - hand-tuned presets (`preset:<slug>`)
 *  - a generated space of accent × neutral family × bubble tone × contrast
 *    (`gen:<hue>.<family>.<tone>.<contrast>`), 1,728 themes each with a light
 *    and a dark variant — 3,456 distinct colour schemes in total.
 */
object ThemeCatalog {

    const val DEFAULT_ID = "preset:parchment"

    val accentHues: List<AccentHue> = listOf(
        "Scarlet", "Vermilion", "Tangerine", "Amber", "Citrine", "Chartreuse", "Lime", "Fern",
        "Emerald", "Jade", "Mint", "Teal", "Cyan", "Lagoon", "Azure", "Cobalt",
        "Indigo", "Iris", "Violet", "Orchid", "Magenta", "Fuchsia", "Rose", "Crimson",
    ).mapIndexed { index, name -> AccentHue(name, index * 15f) }

    val generatedCount: Int =
        accentHues.size * NeutralFamily.entries.size * BubbleTone.entries.size * ContrastLevel.entries.size

    // ------------------------------------------------------------------ presets

    private fun hex(value: Long) = Color(value)

    private val parchment = ThemeDefinition(
        id = DEFAULT_ID,
        name = "Parchment",
        subtitle = "Warm paper, clay accent",
        light = AvekColors(
            isDark = false,
            chatBackground = hex(0xFFFAF9F5),
            topBar = hex(0xFFFAF9F5),
            surface = hex(0xFFFFFFFF),
            outline = hex(0xFFE3DFD4),
            userBubble = hex(0xFFF0EDE4),
            userText = hex(0xFF1F1E1D),
            assistantBubble = hex(0xFFFFFFFF),
            assistantText = hex(0xFF1F1E1D),
            thinkingSurface = hex(0xFFF4F2EB),
            thinkingText = hex(0xFF5E5A52),
            codeSurface = hex(0xFFF1EEE6),
            codeText = hex(0xFF2B2A27),
            sidebar = hex(0xFFF3F1EA),
            sidebarSelected = hex(0xFFE8E4D9),
            sidebarText = hex(0xFF2B2A27),
            composer = hex(0xFFFFFFFF),
            composerBorder = hex(0xFFDDD8CC),
            accent = hex(0xFFC96442),
            onAccent = hex(0xFFFFFFFF),
            thinkingGlow = hex(0xFFD97757),
            textPrimary = hex(0xFF1F1E1D),
            textSecondary = hex(0xFF6B6760),
        ),
        dark = AvekColors(
            isDark = true,
            chatBackground = hex(0xFF262624),
            topBar = hex(0xFF262624),
            surface = hex(0xFF30302E),
            outline = hex(0xFF3F3E3A),
            userBubble = hex(0xFF1A1A18),
            userText = hex(0xFFF2F0EA),
            assistantBubble = hex(0xFF30302E),
            assistantText = hex(0xFFF2F0EA),
            thinkingSurface = hex(0xFF2C2C2A),
            thinkingText = hex(0xFFB3AFA5),
            codeSurface = hex(0xFF1D1D1B),
            codeText = hex(0xFFE8E5DD),
            sidebar = hex(0xFF1F1E1D),
            sidebarSelected = hex(0xFF34332F),
            sidebarText = hex(0xFFE8E5DD),
            composer = hex(0xFF30302E),
            composerBorder = hex(0xFF45443F),
            accent = hex(0xFFD97757),
            onAccent = hex(0xFF1A1A18),
            thinkingGlow = hex(0xFFE08A6B),
            textPrimary = hex(0xFFF2F0EA),
            textSecondary = hex(0xFFA6A299),
        ),
    )

    private data class NamedSeed(val slug: String, val name: String, val subtitle: String, val seed: ThemeSeed)

    private fun s(
        accent: Float,
        neutralHue: Float,
        neutralSat: Float,
        tone: BubbleTone = BubbleTone.TONAL,
        contrast: ContrastLevel = ContrastLevel.STANDARD,
        accentSat: Float = 0.62f,
        air: Float = 0f,
    ) = ThemeSeed(accent, accentSat, neutralHue, neutralSat, tone, contrast, air)

    private val namedSeeds = listOf(
        NamedSeed("clay", "Clay", "Terracotta on sandstone", s(16f, 32f, 0.3f, BubbleTone.SUBTLE)),
        NamedSeed("midnight", "Midnight", "Deep navy, electric blue", s(225f, 230f, 0.35f, BubbleTone.VIVID, ContrastLevel.HIGH)),
        NamedSeed("nordic", "Nordic", "Frost, fjord and snow", s(205f, 215f, 0.2f, BubbleTone.SUBTLE)),
        NamedSeed("forest", "Forest", "Moss, bark and pine", s(140f, 95f, 0.16f, BubbleTone.TONAL)),
        NamedSeed("ocean", "Ocean", "Sea glass and surf", s(192f, 200f, 0.22f, BubbleTone.VIVID)),
        NamedSeed("rosewood", "Rosewood", "Dusty rose, warm wood", s(345f, 15f, 0.22f, BubbleTone.SUBTLE)),
        NamedSeed("sandstone", "Sandstone", "Desert dusk", s(28f, 38f, 0.34f, BubbleTone.TONAL, ContrastLevel.SOFT)),
        NamedSeed("graphite", "Graphite", "Quiet, focused, neutral", s(210f, 0f, 0f, BubbleTone.INVERSE, accentSat = 0.18f)),
        NamedSeed("lavender", "Lavender", "Soft violet haze", s(265f, 270f, 0.45f, BubbleTone.SUBTLE, air = 0.01f)),
        NamedSeed("matcha", "Matcha", "Green tea and rice paper", s(88f, 70f, 0.22f, BubbleTone.SUBTLE)),
        NamedSeed("sakura", "Sakura", "Cherry blossom spring", s(335f, 345f, 0.5f, BubbleTone.SUBTLE, air = 0.01f)),
        NamedSeed("ember", "Ember", "Glowing coals", s(12f, 10f, 0.3f, BubbleTone.VIVID, ContrastLevel.HIGH)),
        NamedSeed("glacier", "Glacier", "Crisp, icy, high-contrast", s(190f, 200f, 0.25f, BubbleTone.TONAL, ContrastLevel.HIGH)),
        NamedSeed("aurora", "Aurora", "Northern lights over ink", s(160f, 250f, 0.3f, BubbleTone.VIVID)),
        NamedSeed("terminal", "Terminal", "Phosphor green on black", s(130f, 120f, 0.08f, BubbleTone.INVERSE, ContrastLevel.HIGH, accentSat = 0.8f)),
        NamedSeed("mono", "Mono", "Pure black and white", s(0f, 0f, 0f, BubbleTone.INVERSE, ContrastLevel.HIGH, accentSat = 0f)),
        NamedSeed("cobalt", "Cobalt", "Bold, saturated blue", s(218f, 220f, 0.12f, BubbleTone.VIVID)),
        NamedSeed("espresso", "Espresso", "Coffee and cream", s(25f, 28f, 0.28f, BubbleTone.INVERSE, ContrastLevel.SOFT)),
        NamedSeed("ink", "Paper & Ink", "Editorial, bookish", s(220f, 45f, 0.18f, BubbleTone.INVERSE, accentSat = 0.35f)),
        NamedSeed("citrus", "Citrus", "Zesty and bright", s(42f, 50f, 0.35f, BubbleTone.VIVID)),
        NamedSeed("plum", "Plum", "Rich and velvety", s(290f, 300f, 0.2f, BubbleTone.VIVID)),
        NamedSeed("teal-bay", "Teal Bay", "Calm coastal teal", s(175f, 185f, 0.18f, BubbleTone.SUBTLE)),
        NamedSeed("dusk", "Dusk", "Purple hour", s(280f, 250f, 0.25f, BubbleTone.TONAL, ContrastLevel.SOFT)),
        NamedSeed("saffron", "Saffron", "Spice market gold", s(38f, 35f, 0.3f, BubbleTone.VIVID)),
        NamedSeed("mint", "Mint", "Cool, fresh, airy", s(155f, 165f, 0.4f, BubbleTone.SUBTLE, air = 0.01f)),
        NamedSeed("ruby", "Ruby", "Jewel-toned red", s(350f, 355f, 0.15f, BubbleTone.VIVID, ContrastLevel.HIGH)),
        NamedSeed("slate", "Slate", "Professional blue-gray", s(212f, 215f, 0.14f, BubbleTone.TONAL)),
        NamedSeed("copper", "Copper", "Patina and polish", s(22f, 30f, 0.2f, BubbleTone.TONAL)),
        NamedSeed("lagoon", "Lagoon", "Tropical turquoise", s(184f, 180f, 0.3f, BubbleTone.VIVID)),
        NamedSeed("orchid", "Orchid", "Floral pastel", s(300f, 310f, 0.45f, BubbleTone.SUBTLE, air = 0.01f)),
        NamedSeed("solar", "Solar", "Sunlit amber on charcoal", s(48f, 40f, 0.12f, BubbleTone.INVERSE, ContrastLevel.HIGH)),
        NamedSeed("neon", "Neon", "Night-city magenta", s(312f, 270f, 0.3f, BubbleTone.VIVID, ContrastLevel.HIGH, accentSat = 0.85f)),
        NamedSeed("olive", "Olive", "Earthy and grounded", s(72f, 60f, 0.2f, BubbleTone.TONAL)),
        NamedSeed("arctic", "Arctic", "Barely-there blue", s(200f, 205f, 0.3f, BubbleTone.SUBTLE, ContrastLevel.SOFT, air = 0.01f)),
        NamedSeed("sepia", "Sepia", "Old photographs", s(30f, 35f, 0.4f, BubbleTone.TONAL, ContrastLevel.SOFT, accentSat = 0.35f)),
    )

    val presets: List<ThemeDefinition> = listOf(parchment) + namedSeeds.map { named ->
        ThemeDefinition(
            id = "preset:${named.slug}",
            name = named.name,
            subtitle = named.subtitle,
            light = ThemeFactory.build(named.seed, dark = false),
            dark = ThemeFactory.build(named.seed, dark = true),
        )
    }

    private val presetsById = presets.associateBy { it.id }

    // ---------------------------------------------------------------- generated

    fun generatedId(hueIndex: Int, family: NeutralFamily, tone: BubbleTone, contrast: ContrastLevel) =
        "gen:$hueIndex.${family.ordinal}.${tone.ordinal}.${contrast.ordinal}"

    /** All generated theme ids that match [filter], in a stable, browsable order. */
    fun generatedIds(filter: ThemeFilter = ThemeFilter()): List<String> = buildList {
        for (contrast in ContrastLevel.entries) {
            if (filter.contrast != null && filter.contrast != contrast) continue
            for (family in NeutralFamily.entries) {
                if (filter.family != null && filter.family != family) continue
                for (tone in BubbleTone.entries) {
                    if (filter.tone != null && filter.tone != tone) continue
                    for (hue in accentHues.indices) {
                        if (filter.hueIndex != null && filter.hueIndex != hue) continue
                        add(generatedId(hue, family, tone, contrast))
                    }
                }
            }
        }
    }

    private val cache = HashMap<String, ThemeDefinition>()

    fun resolve(id: String): ThemeDefinition {
        presetsById[id]?.let { return it }
        synchronized(cache) {
            cache[id]?.let { return it }
            val built = buildGenerated(id) ?: parchment
            if (cache.size > MAX_CACHE) cache.clear()
            cache[id] = built
            return built
        }
    }

    fun random(random: Random = Random.Default): String =
        if (random.nextInt(5) == 0) {
            presets.random(random).id
        } else {
            generatedId(
                random.nextInt(accentHues.size),
                NeutralFamily.entries.random(random),
                BubbleTone.entries.random(random),
                ContrastLevel.entries.random(random),
            )
        }

    private fun buildGenerated(id: String): ThemeDefinition? {
        if (!id.startsWith("gen:")) return null
        val parts = id.removePrefix("gen:").split('.').mapNotNull { it.toIntOrNull() }
        if (parts.size != 4) return null
        val hue = accentHues.getOrNull(parts[0]) ?: return null
        val family = NeutralFamily.entries.getOrNull(parts[1]) ?: return null
        val tone = BubbleTone.entries.getOrNull(parts[2]) ?: return null
        val contrast = ContrastLevel.entries.getOrNull(parts[3]) ?: return null
        val seed = ThemeFactory.seed(hue.hue, family, tone, contrast)
        val contrastSuffix = if (contrast == ContrastLevel.STANDARD) "" else " · ${contrast.label} contrast"
        return ThemeDefinition(
            id = id,
            name = "${hue.name} ${family.short}",
            subtitle = "${tone.label} bubbles$contrastSuffix",
            light = ThemeFactory.build(seed, dark = false),
            dark = ThemeFactory.build(seed, dark = true),
        )
    }

    private const val MAX_CACHE = 512
}
