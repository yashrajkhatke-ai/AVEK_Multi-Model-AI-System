package com.avek.chat.feature.chat.thinking

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AccountTree
import androidx.compose.material.icons.outlined.Build
import androidx.compose.material.icons.outlined.ErrorOutline
import androidx.compose.material.icons.outlined.KeyboardArrowDown
import androidx.compose.material.icons.outlined.Psychology
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.avek.chat.core.designsystem.theme.AvekTheme
import com.avek.chat.core.designsystem.theme.avekShape
import com.avek.chat.feature.chat.components.ShimmerText
import com.avek.chat.feature.chat.thinking.panels.JsonTint
import com.avek.chat.feature.chat.thinking.panels.rememberThinkingPalette

/**
 * What happened before an answer, in order: thinking, tool calls, and work handed to the infra.
 * A turn can think several times (think → tool → think → answer): each one is its own item.
 */
@Immutable
sealed interface TimelineItem {
    val id: String
    val active: Boolean

    /** One stretch of the model's reasoning: [text] is exactly what the model wrote. */
    data class Thinking(override val id: String, val text: String, override val active: Boolean, val durationMs: Long? = null) : TimelineItem

    /** A tool call: [args] stream in while the model writes them, then the tool runs. */
    data class Tool(
        override val id: String,
        val name: String,
        val title: String?,
        val args: String,
        override val active: Boolean,
        val ok: Boolean? = null,
        val result: String? = null,
        val durationMs: Long? = null,
    ) : TimelineItem

    /** Work the main model handed to the infra: the working model and everything it does, nested. */
    data class Delegation(
        override val id: String,
        val agent: String,
        val modelName: String,
        val task: String,
        override val active: Boolean,
        val children: List<TimelineItem>,
    ) : TimelineItem
}

/** "Figuring out what to do": a bold title the model wrote, else its first sentence, else "Thinking". */
fun thinkingHeading(text: String, active: Boolean): String {
    val bold = Regex("\\*\\*(.{3,80}?)\\*\\*").find(text)?.groupValues?.get(1)?.trim()
    if (bold != null) return bold
    val plain = text.trim().replace(Regex("\\s+"), " ")
    if (plain.isEmpty()) return if (active) "Thinking" else "Thought"
    val sentence = plain.split(Regex("(?<=[.!?:])\\s")).first().trimEnd('.', ':', '!')
    return if (sentence.length <= 60) sentence else sentence.take(57).substringBeforeLast(' ') + "…"
}

/** Plain list: one row per item; tap a row to open its card. */
@Composable
fun TurnTimeline(items: List<TimelineItem>, modifier: Modifier = Modifier, opened: Set<String> = emptySet()) {
    Column(modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(2.dp)) {
        items.forEach { item -> androidx.compose.runtime.key(item.id) { TimelineRow(item, opened) } }
    }
}

@Composable
private fun TimelineRow(item: TimelineItem, opened: Set<String>) {
    when (item) {
        is TimelineItem.Thinking -> ThinkingRow(item, item.id in opened)
        is TimelineItem.Tool -> ToolRow(item, item.id in opened)
        is TimelineItem.Delegation -> DelegationRow(item, opened)
    }
}

@Composable
private fun ThinkingRow(item: TimelineItem.Thinking, open: Boolean) {
    var expanded by rememberSaveable(item.id) { mutableStateOf(open) }
    // A thinking stretch that was open while it streamed closes by itself when it ends.
    var wasActive by remember(item.id) { mutableStateOf(item.active) }
    LaunchedEffect(item.active) {
        if (wasActive && !item.active) expanded = false
        wasActive = item.active
    }
    val heading = thinkingHeading(item.text, item.active)
    Column(Modifier.fillMaxWidth()) {
        Heading(
            icon = Icons.Outlined.Psychology,
            text = heading,
            trailing = if (!item.active) item.durationMs?.let { ThinkingFormat.ms(it) } else null,
            active = item.active,
            expanded = expanded,
            onClick = { expanded = !expanded },
        )
        Expandable(expanded) {
            StreamingCard(follow = item.active, textKey = item.text.length) {
                // The row already shows the title the model wrote; the card shows everything else, exactly.
                val body = item.text.replaceFirst(Regex("^\\s*\\*\\*.{3,80}?\\*\\*\\s*"), "")
                Text(
                    body.ifEmpty { "…" },
                    style = AvekTheme.type.thinking,
                    color = AvekTheme.colors.thinkingText,
                )
            }
        }
    }
}

@Composable
private fun ToolRow(item: TimelineItem.Tool, open: Boolean) {
    var expanded by rememberSaveable(item.id) { mutableStateOf(open) }
    val palette = rememberThinkingPalette()
    val what = item.title?.takeIf { it.isNotBlank() }?.let { " · $it" }.orEmpty()
    val heading = when {
        item.active -> "Calling ${item.name}$what"
        item.ok == false -> "${item.name} failed$what"
        else -> "Called ${item.name}$what"
    }
    Column(Modifier.fillMaxWidth()) {
        Heading(
            icon = if (item.ok == false) Icons.Outlined.ErrorOutline else Icons.Outlined.Build,
            text = heading,
            trailing = if (!item.active) item.durationMs?.let { ThinkingFormat.ms(it) } else null,
            active = item.active,
            expanded = expanded,
            onClick = { expanded = !expanded },
        )
        Expandable(expanded) {
            StreamingCard(follow = item.active, textKey = item.args.length + (item.result?.length ?: 0)) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Label("Arguments")
                    Text(
                        if (item.args.isEmpty()) androidx.compose.ui.text.AnnotatedString("…") else JsonTint.color(item.args, palette),
                        style = AvekTheme.type.code.copy(fontSize = AvekTheme.type.caption.fontSize),
                    )
                    if (item.result != null) {
                        Label("Result")
                        Text(item.result, style = AvekTheme.type.code.copy(fontSize = AvekTheme.type.caption.fontSize), color = AvekTheme.colors.codeText)
                    }
                }
            }
        }
    }
}

@Composable
private fun DelegationRow(item: TimelineItem.Delegation, opened: Set<String>) {
    var expanded by rememberSaveable(item.id) { mutableStateOf(true) }
    val colors = AvekTheme.colors
    Column(Modifier.fillMaxWidth()) {
        Heading(
            icon = Icons.Outlined.AccountTree,
            text = if (item.active) "${item.agent}: ${item.modelName} is working on ${item.task}" else "${item.agent}: ${item.modelName} finished ${item.task}",
            trailing = null,
            active = item.active,
            expanded = expanded,
            onClick = { expanded = !expanded },
        )
        Expandable(expanded) {
            // The hierarchy: the infra model's own thinking and tool calls, indented under a guide line.
            Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min).padding(start = 9.dp, top = 2.dp)) {
                Box(Modifier.width(1.5.dp).fillMaxHeight().background(colors.outline))
                Spacer(Modifier.width(12.dp))
                TurnTimeline(item.children, Modifier.weight(1f), opened)
            }
        }
    }
}

@Composable
private fun Heading(icon: ImageVector, text: String, trailing: String?, active: Boolean, expanded: Boolean, onClick: () -> Unit) {
    val colors = AvekTheme.colors
    val chevron by animateFloatAsState(if (expanded) 180f else 0f, label = "chevron")
    Row(
        Modifier
            .fillMaxWidth()
            .clip(avekShape(8.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, null, tint = if (active) colors.thinkingGlow else colors.textTertiary, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(8.dp))
        Box(Modifier.weight(1f, fill = false)) {
            if (active) {
                ShimmerText(text, colors.textSecondary, colors.thinkingGlow)
            } else {
                Text(text, style = AvekTheme.type.label, color = colors.textSecondary, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
        if (trailing != null) {
            Spacer(Modifier.width(6.dp))
            Text(trailing, style = AvekTheme.type.caption, color = colors.textTertiary)
        }
        Icon(
            Icons.Outlined.KeyboardArrowDown,
            contentDescription = if (expanded) "Collapse" else "Expand",
            tint = colors.textTertiary,
            modifier = Modifier.size(18.dp).rotate(chevron),
        )
    }
}

@Composable
private fun Expandable(expanded: Boolean, content: @Composable () -> Unit) {
    AnimatedVisibility(visible = expanded, enter = expandVertically() + fadeIn(), exit = shrinkVertically() + fadeOut()) {
        Box(Modifier.padding(start = 26.dp, top = 2.dp, bottom = 8.dp)) { content() }
    }
}

/** The card under an opened row; while the item streams it keeps the newest text in view. */
@Composable
private fun StreamingCard(follow: Boolean, textKey: Int, content: @Composable () -> Unit) {
    val colors = AvekTheme.colors
    val scroll = rememberScrollState()
    LaunchedEffect(textKey, follow) { if (follow) scroll.scrollTo(scroll.maxValue) }
    Box(
        Modifier
            .fillMaxWidth()
            .clip(avekShape(14.dp))
            .background(colors.thinkingSurface)
            .border(1.dp, colors.outline.copy(alpha = 0.5f), avekShape(14.dp))
            .heightIn(max = 260.dp)
            .verticalScroll(scroll)
            .padding(12.dp),
    ) { content() }
}

@Composable
private fun Label(text: String) {
    Text(text.uppercase(), style = AvekTheme.type.caption.copy(fontWeight = FontWeight.SemiBold), color = AvekTheme.colors.textTertiary)
}
