package com.avek.chat.core.common

import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

object TimeFormat {
    private val timeFormatter = DateTimeFormatter.ofPattern("h:mm a", Locale.getDefault())
    private val dayFormatter = DateTimeFormatter.ofPattern("MMM d", Locale.getDefault())
    private val fullFormatter = DateTimeFormatter.ofPattern("MMM d, yyyy", Locale.getDefault())

    fun clock(epochMillis: Long, zone: ZoneId = ZoneId.systemDefault()): String =
        timeFormatter.format(Instant.ofEpochMilli(epochMillis).atZone(zone))

    fun relativeDay(epochMillis: Long, now: Long, zone: ZoneId = ZoneId.systemDefault()): String {
        val date = Instant.ofEpochMilli(epochMillis).atZone(zone).toLocalDate()
        val today = Instant.ofEpochMilli(now).atZone(zone).toLocalDate()
        return when {
            date == today -> clock(epochMillis, zone)
            date == today.minusDays(1) -> "Yesterday"
            date.year == today.year -> dayFormatter.format(date)
            else -> fullFormatter.format(date)
        }
    }

    /** "Thought for 12s", "Thought for 1m 4s". */
    fun duration(millis: Long): String {
        val totalSeconds = (millis / 1000).coerceAtLeast(1)
        val minutes = totalSeconds / 60
        val seconds = totalSeconds % 60
        return if (minutes > 0) "${minutes}m ${seconds}s" else "${seconds}s"
    }
}
