package com.avek.chat.core.data.fonts

/** Platform hook that yields the raw catalog lines (an Android asset in production). */
fun interface FontCatalogSource {
    suspend fun readLines(): List<String>
}
