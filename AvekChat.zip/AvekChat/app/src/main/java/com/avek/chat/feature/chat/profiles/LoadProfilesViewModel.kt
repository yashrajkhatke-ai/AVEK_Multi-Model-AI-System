package com.avek.chat.feature.chat.profiles

import androidx.compose.runtime.Immutable
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.avek.chat.core.link.HarnessApi
import com.avek.chat.core.link.LinkRepository
import com.avek.chat.core.link.route.ConnectionState
import com.avek.chat.core.link.rpc.RpcException
import com.avek.chat.core.link.wire.HardwareData
import com.avek.chat.core.link.wire.LayersDto
import com.avek.chat.core.link.wire.LinkEvent
import com.avek.chat.core.link.wire.LoadProfileDto
import com.avek.chat.core.link.wire.ProfileDraft
import com.avek.chat.core.link.wire.ProfileLimitsDto
import com.avek.chat.core.link.wire.ProfilesData
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

/** What the editor holds (New / Copy / Edit). [id] only when editing one of your own profiles. */
@Immutable
data class EditorDraft(
    val id: String?,
    val name: String,
    val layers: Layers,
    val contextTokens: Int,
    val slots: Int,
    val cacheType: String,
    val note: String,
    val total: Int,
    val limits: ProfileLimitsDto,
    val hasRtx: Boolean,
    val hasIgpu: Boolean,
    val saving: Boolean = false,
    val error: String? = null,
) {
    val canSave: Boolean get() = name.isNotBlank() && name.trim().length <= MAX_NAME && !saving && layers.total == total

    companion object {
        const val MAX_NAME = 40
    }
}

/** The sheet's explicit states (task D.5). */
sealed interface ProfilesPhase {
    data object Loading : ProfilesPhase
    data object Ready : ProfilesPhase
    data class Error(val message: String) : ProfilesPhase

    /** `profile.apply` sent: "Reloading <model> with <profile>..." until `model.state` says ready or error. */
    data class Applying(val profileId: String, val text: String) : ProfilesPhase
    data class Editing(val draft: EditorDraft) : ProfilesPhase
}

@Immutable
data class ProfilesUi(
    val modelId: String? = null,
    val modelName: String = "",
    val phase: ProfilesPhase = ProfilesPhase.Loading,
    /** The last list received (kept, greyed out, when the connection drops). */
    val data: ProfilesData? = null,
    val hardware: HardwareData? = null,
    val connected: Boolean = true,
    /** A one-line message under the list (busy, errors of apply/delete, the outcome of a reload). */
    val message: String? = null,
    /** "This probably does not fit in memory. Use it anyway?" for this profile id. */
    val confirmTooBig: String? = null,
)

/**
 * "Where it runs" (UI-WIRE v4 sections 8.10 and 13): `profiles.list` and `hardware.get` only when the
 * sheet opens; Use / Copy / Edit / Delete; follows `profiles.changed` and `model.state` so devices stay
 * in step. Every estimate shown is the PC's; the app computes none.
 */
@HiltViewModel
class LoadProfilesViewModel @Inject constructor(
    private val api: HarnessApi,
    private val link: LinkRepository,
    private val memory: ProfileMemory,
) : ViewModel() {

    private val _state = MutableStateFlow(ProfilesUi())
    val state: StateFlow<ProfilesUi> = _state

    private var loadJob: Job? = null

    init {
        viewModelScope.launch {
            link.events.collect { event ->
                val modelId = _state.value.modelId ?: return@collect
                when (event) {
                    is LinkEvent.ProfilesChanged -> if (event.data.modelId == modelId) onProfilesChanged()
                    is LinkEvent.ModelState -> if (event.data.modelId == modelId) onModelState(event.data.state, event.data.error)
                    else -> Unit
                }
            }
        }
        viewModelScope.launch {
            link.state.map { it is ConnectionState.Connected }.distinctUntilChanged().collect { connected ->
                _state.update { s ->
                    if (connected) {
                        s.copy(connected = true)
                    } else {
                        // Closes cleanly: the last list stays, greyed out; an edit or reload in progress stops.
                        val phase = when (s.phase) {
                            is ProfilesPhase.Applying, ProfilesPhase.Loading -> if (s.data != null) ProfilesPhase.Ready else ProfilesPhase.Error(NOT_CONNECTED)
                            is ProfilesPhase.Editing -> (s.phase as ProfilesPhase.Editing).let { ProfilesPhase.Editing(it.draft.copy(saving = false)) }
                            else -> s.phase
                        }
                        s.copy(connected = false, phase = phase)
                    }
                }
            }
        }
    }

    /** The sheet opened for the model shown in the chip. */
    fun open(modelId: String, modelName: String) {
        if (_state.value.modelId == modelId && _state.value.data != null && _state.value.phase !is ProfilesPhase.Error) return
        _state.value = ProfilesUi(modelId = modelId, modelName = modelName, connected = link.state.value is ConnectionState.Connected)
        load(withHardware = true)
    }

    fun refresh() = load(withHardware = true)

    private fun load(withHardware: Boolean) {
        val modelId = _state.value.modelId ?: return
        loadJob?.cancel()
        if (_state.value.data == null) _state.update { it.copy(phase = ProfilesPhase.Loading) }
        loadJob = viewModelScope.launch {
            try {
                val hardware = if (withHardware) async { runCatching { api.hardwareGet() }.getOrNull() } else null
                val data = api.profilesList(modelId)
                memory.put(data)
                val hw = hardware?.await() ?: data.hardware ?: _state.value.hardware
                _state.update { s ->
                    s.copy(
                        data = data,
                        hardware = hw,
                        phase = if (s.phase is ProfilesPhase.Editing || s.phase is ProfilesPhase.Applying) s.phase else ProfilesPhase.Ready,
                    )
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _state.update { s -> if (s.data == null) s.copy(phase = ProfilesPhase.Error(messageOf(e))) else s.copy(message = messageOf(e)) }
            }
        }
    }

    // ------------------------------------------------------------------ use

    /** "Use": disabled when `problems` is not empty; on `too-big` a confirmation first ([force] after it). */
    fun use(profile: LoadProfileDto, force: Boolean = false) {
        val s = _state.value
        val modelId = s.modelId ?: return
        if (profile.problems.isNotEmpty() || !s.connected) return
        if (profile.estimate?.verdict == VERDICT_TOO_BIG && !force) {
            _state.update { it.copy(confirmTooBig = profile.id) }
            return
        }
        _state.update { it.copy(confirmTooBig = null, message = null, phase = ProfilesPhase.Applying(profile.id, "Reloading ${it.modelName} with ${profile.name}...")) }
        viewModelScope.launch {
            try {
                val result = api.profileApply(modelId, profile.id)
                _state.update { st ->
                    val data = st.data?.withActive(result.activeId.ifEmpty { profile.id })
                    data?.let(memory::put)
                    if (result.reloading) st.copy(data = data) else st.copy(data = data, phase = ProfilesPhase.Ready, message = null)
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                val text = if (e is RpcException && e.code == "busy") BUSY else messageOf(e)
                _state.update { it.copy(phase = ProfilesPhase.Ready, message = text) }
            }
        }
    }

    fun dismissTooBig() = _state.update { it.copy(confirmTooBig = null) }

    private fun onModelState(state: String, error: String?) {
        val s = _state.value
        if (s.phase !is ProfilesPhase.Applying) return
        when (state) {
            "ready" -> {
                _state.update { it.copy(phase = ProfilesPhase.Ready, message = null) }
                load(withHardware = false) // the measured speed and estimate may have changed
            }
            "error" -> _state.update { it.copy(phase = ProfilesPhase.Ready, message = error?.takeIf { e -> e.isNotBlank() } ?: "The model could not be loaded with this profile.") }
            else -> Unit // unloaded (stopping) and loading: keep showing "Reloading..."
        }
    }

    /** Another device (or this one) saved, deleted or applied: refetch (an open editor keeps its draft). */
    private fun onProfilesChanged() = load(withHardware = false)

    // ------------------------------------------------------------------ editor

    fun newProfile() {
        val data = _state.value.data ?: return
        val source = data.profiles.firstOrNull { it.id == data.activeId } ?: data.profiles.firstOrNull()
        startEditing(source, id = null, name = "")
    }

    fun copy(profile: LoadProfileDto) = startEditing(profile, id = null, name = "Copy of ${profile.name}".take(EditorDraft.MAX_NAME))

    fun edit(profile: LoadProfileDto) {
        if (profile.builtin) return
        startEditing(profile, id = profile.id, name = profile.name)
    }

    private fun startEditing(source: LoadProfileDto?, id: String?, name: String) {
        val data = _state.value.data ?: return
        val hw = _state.value.hardware ?: data.hardware
        val total = data.layersTotal
        val limits = data.limits
        val hasRtx = hw?.rtx != null
        val hasIgpu = hw?.igpu != null
        val start = source?.toLayers() ?: Layers(0, 0, total)
        // A processor the PC does not have is fixed at 0 (its slider is hidden).
        val layers = LayerPlan.of(total, if (hasRtx) start.rtx else 0, if (hasIgpu) start.igpu else 0)
        val context = LayerPlan.snapContext(source?.contextTokens?.takeIf { it > 0 } ?: DEFAULT_CONTEXT, limits.minContext, limits.maxContext)
        val cache = source?.cacheType?.takeIf { it in limits.cacheTypes } ?: DEFAULT_CACHE.takeIf { it in limits.cacheTypes } ?: limits.cacheTypes.firstOrNull() ?: DEFAULT_CACHE
        val draft = EditorDraft(
            id = id,
            name = name,
            layers = layers,
            contextTokens = context,
            slots = (source?.slots ?: DEFAULT_SLOTS).coerceIn(1, limits.maxSlots.coerceAtLeast(1)),
            cacheType = cache,
            note = source?.note.orEmpty(),
            total = total,
            limits = limits,
            hasRtx = hasRtx,
            hasIgpu = hasIgpu,
        )
        _state.update { it.copy(phase = ProfilesPhase.Editing(draft), message = null) }
    }

    fun updateDraft(transform: (EditorDraft) -> EditorDraft) {
        _state.update { s ->
            val phase = s.phase as? ProfilesPhase.Editing ?: return@update s
            s.copy(phase = ProfilesPhase.Editing(transform(phase.draft.copy(error = null))))
        }
    }

    fun setName(name: String) = updateDraft { it.copy(name = name.filter { c -> !c.isISOControl() }.take(EditorDraft.MAX_NAME)) }
    fun setRtx(value: Int) = updateDraft { if (!it.hasRtx) it else it.copy(layers = LayerPlan.withRtx(it.layers, it.total, value)) }
    fun setIgpu(value: Int) = updateDraft { if (!it.hasIgpu) it else it.copy(layers = LayerPlan.withIgpu(it.layers, it.total, value)) }
    fun applyPreset(preset: LayerPreset) = updateDraft { it.copy(layers = LayerPlan.of(it.total, preset.layers.rtx, preset.layers.igpu)) }
    fun setContext(tokens: Int) = updateDraft { it.copy(contextTokens = LayerPlan.snapContext(tokens, it.limits.minContext, it.limits.maxContext)) }
    fun setSlots(slots: Int) = updateDraft { it.copy(slots = slots.coerceIn(1, it.limits.maxSlots.coerceAtLeast(1))) }
    fun setCacheType(type: String) = updateDraft { if (type in it.limits.cacheTypes) it.copy(cacheType = type) else it }
    fun setNote(note: String) = updateDraft { it.copy(note = note.take(MAX_NOTE)) }

    fun cancelEditing() = _state.update { it.copy(phase = if (it.data != null) ProfilesPhase.Ready else ProfilesPhase.Loading) }

    /** Save → `profile.save`; the PC's estimate and problems appear on the card at once. */
    fun save() {
        val s = _state.value
        val modelId = s.modelId ?: return
        val draft = (s.phase as? ProfilesPhase.Editing)?.draft ?: return
        if (!draft.canSave || !s.connected) return
        updateDraft { it.copy(saving = true) }
        viewModelScope.launch {
            try {
                val saved = api.profileSave(
                    modelId,
                    ProfileDraft(
                        id = draft.id,
                        name = draft.name.trim(),
                        layers = LayersDto(draft.layers.rtx, draft.layers.igpu, draft.layers.cpu),
                        contextTokens = draft.contextTokens,
                        slots = draft.slots,
                        cacheType = draft.cacheType,
                        note = draft.note.trim().ifBlank { null },
                    ),
                )
                _state.update { st ->
                    val data = st.data?.let { d ->
                        val list = if (d.profiles.any { it.id == saved.id }) d.profiles.map { if (it.id == saved.id) saved else it } else d.profiles + saved
                        d.copy(profiles = list)
                    }
                    data?.let(memory::put)
                    st.copy(data = data, phase = ProfilesPhase.Ready, message = null)
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                updateDraft { it.copy(saving = false, error = messageOf(e)) }
            }
        }
    }

    /** Delete one of your own profiles (after the confirm in the UI). */
    fun delete(profile: LoadProfileDto) {
        val modelId = _state.value.modelId ?: return
        if (profile.builtin) return
        viewModelScope.launch {
            try {
                api.profileDelete(modelId, profile.id)
                _state.update { st -> st.copy(data = st.data?.let { d -> d.copy(profiles = d.profiles.filterNot { it.id == profile.id }) }, message = null) }
                load(withHardware = false) // the active one may have changed back to the default
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _state.update { it.copy(message = messageOf(e)) }
            }
        }
    }

    fun clearMessage() = _state.update { it.copy(message = null) }

    private fun messageOf(e: Exception): String = when {
        e is RpcException && e.code == RpcException.NOT_CONNECTED -> NOT_CONNECTED
        e is RpcException && e.code == "busy" -> BUSY
        e is RpcException && e.code == "conflict" -> e.message?.takeIf { it.isNotBlank() } ?: "You already have 24 profiles of your own for this model."
        e is RpcException && e.code == "unsupported" -> e.message?.takeIf { it.isNotBlank() } ?: "The PC does not know how many layers this model has, so it cannot be edited."
        else -> e.message?.takeIf { it.isNotBlank() } ?: "Something went wrong."
    }

    companion object {
        const val BUSY = "The model is answering. Try again when it has finished."
        const val NOT_CONNECTED = "Not connected"
        const val VERDICT_TOO_BIG = "too-big"
        const val DEFAULT_CONTEXT = 32_768
        const val DEFAULT_SLOTS = 2
        const val DEFAULT_CACHE = "q4_0"
        private const val MAX_NOTE = 200
    }
}
