package com.avek.chat.core.model.settings

import kotlinx.serialization.Serializable

@Serializable
data class AppearanceSettings(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    /** See `ThemeCatalog` for the id format (`preset:*` or `gen:*`). */
    val themeId: String = "preset:parchment",
    /** Per-role colour overrides (ARGB) applied on top of the light scheme. */
    val lightOverrides: Map<ColorRole, Long> = emptyMap(),
    /** Per-role colour overrides (ARGB) applied on top of the dark scheme. */
    val darkOverrides: Map<ColorRole, Long> = emptyMap(),
    val fonts: FontSettings = FontSettings(),
    val chat: ChatLayout = ChatLayout(),
    val motion: MotionSettings = MotionSettings(),
    val shapes: ShapeSettings = ShapeSettings(),
)

@Serializable
enum class ThemeMode(val label: String) { SYSTEM("System"), LIGHT("Light"), DARK("Dark") }

@Serializable
enum class ColorGroup(val label: String) {
    WINDOW("Chat window"),
    MESSAGES("Messages"),
    SIDEBAR("Sidebar"),
    COMPOSER("Composer"),
    ACCENTS("Accents"),
    TEXT("Text"),
}

/** Every colour the user can individually override. */
@Serializable
enum class ColorRole(val label: String, val group: ColorGroup) {
    CHAT_BACKGROUND("Chat background", ColorGroup.WINDOW),
    TOP_BAR("Top bar", ColorGroup.WINDOW),
    SURFACE("Cards & sheets", ColorGroup.WINDOW),
    OUTLINE("Dividers & outlines", ColorGroup.WINDOW),

    USER_BUBBLE("Your bubble", ColorGroup.MESSAGES),
    USER_TEXT("Your text", ColorGroup.MESSAGES),
    ASSISTANT_BUBBLE("Answer surface", ColorGroup.MESSAGES),
    ASSISTANT_TEXT("Answer text", ColorGroup.MESSAGES),
    THINKING_SURFACE("Thinking panel", ColorGroup.MESSAGES),
    THINKING_TEXT("Thinking text", ColorGroup.MESSAGES),
    CODE_SURFACE("Code block", ColorGroup.MESSAGES),
    CODE_TEXT("Code text", ColorGroup.MESSAGES),

    SIDEBAR("Sidebar", ColorGroup.SIDEBAR),
    SIDEBAR_SELECTED("Selected chat", ColorGroup.SIDEBAR),
    SIDEBAR_TEXT("Sidebar text", ColorGroup.SIDEBAR),

    COMPOSER("Composer", ColorGroup.COMPOSER),
    COMPOSER_BORDER("Composer border", ColorGroup.COMPOSER),

    ACCENT("Accent", ColorGroup.ACCENTS),
    ON_ACCENT("On accent", ColorGroup.ACCENTS),
    THINKING_GLOW("Thinking animation", ColorGroup.ACCENTS),

    TEXT_PRIMARY("Primary text", ColorGroup.TEXT),
    TEXT_SECONDARY("Secondary text", ColorGroup.TEXT),
}
