package com.avek.chat.core.link.rpc

/** Why a link ended. [code] follows the WebSocket close codes of UI-WIRE section 1. */
data class CloseInfo(val code: Int, val reason: String, val error: Throwable? = null) {
    /** 4401: unknown / revoked device, wrong secret: retrying is pointless until the person re-pairs. */
    val isAuthFailure: Boolean get() = code == 4401
}

/** An established, verified link to a PC. */
interface LiveLink {
    val serverName: String
    suspend fun awaitClosed(): CloseInfo
    fun close(code: Int = 1000, reason: String = "")
}

/** Raised (instead of a plain timeout) when a connection closes before it became usable. */
class LinkClosedException(val info: CloseInfo) : Exception("Link closed (${info.code} ${info.reason})")
