package com.avek.chat.core.designsystem.motion

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.unit.dp
import com.avek.chat.core.designsystem.theme.ColorMath
import com.avek.chat.core.model.ThinkingDepth
import kotlin.math.PI
import kotlin.math.sin

private const val TAU = (2 * PI).toFloat()

/**
 * A distinct living emblem for every thinking depth. The higher the level,
 * the more energy: Instant is a still bolt, Maximum is a crackling star.
 */
@Composable
fun DepthGlyph(
    depth: ThinkingDepth,
    color: Color,
    modifier: Modifier = Modifier.size(28.dp),
    speed: Float = 1f,
    animate: Boolean = true,
) {
    val duration = when (depth) {
        ThinkingDepth.INSTANT -> 2600
        ThinkingDepth.LIGHT -> 2400
        ThinkingDepth.BALANCED -> 2800
        ThinkingDepth.DEEP -> 3600
        ThinkingDepth.EXTENDED -> 7000
        ThinkingDepth.MAXIMUM -> 2200
    }
    val phase = rememberPhase((duration / speed.coerceIn(0.25f, 3f)).toInt(), animate, label = "depth-${depth.name}")
    Canvas(modifier) {
        val t = phase.value
        when (depth) {
            ThinkingDepth.INSTANT -> drawBolt(t, color)
            ThinkingDepth.LIGHT -> drawPulse(t, color, rings = 1)
            ThinkingDepth.BALANCED -> drawOrbit(t, color, satellites = 3)
            ThinkingDepth.DEEP -> drawRings(t, color)
            ThinkingDepth.EXTENDED -> drawGalaxy(t, color, particles = 34)
            ThinkingDepth.MAXIMUM -> drawSupernova(t, color)
        }
    }
}

private fun DrawScope.drawBolt(t: Float, color: Color) {
    val w = size.width
    val h = size.height
    val breathe = 0.96f + 0.04f * sin(TAU * t)
    scale(breathe) {
        val path = Path().apply {
            moveTo(w * 0.58f, h * 0.06f)
            lineTo(w * 0.2f, h * 0.56f)
            lineTo(w * 0.47f, h * 0.56f)
            lineTo(w * 0.4f, h * 0.94f)
            lineTo(w * 0.8f, h * 0.42f)
            lineTo(w * 0.53f, h * 0.42f)
            close()
        }
        drawPath(path, color)
        // A glint that sweeps across the bolt.
        val x = (-0.3f + 1.6f * t) * w
        drawPath(
            path,
            Brush.linearGradient(
                listOf(Color.Transparent, Color.White.copy(alpha = 0.55f), Color.Transparent),
                start = Offset(x - w * 0.2f, 0f),
                end = Offset(x + w * 0.2f, h),
            ),
        )
    }
}

private fun DrawScope.drawRings(t: Float, color: Color) {
    val r = size.minDimension / 2f
    val stroke = r * 0.12f
    val dash = PathEffect.dashPathEffect(floatArrayOf(r * 0.5f, r * 0.25f))
    rotate(t * 360f) {
        drawCircle(color.copy(alpha = 0.9f), radius = r * 0.85f, center = center, style = Stroke(stroke, cap = StrokeCap.Round, pathEffect = dash))
    }
    rotate(-t * 540f) {
        drawCircle(color.copy(alpha = 0.6f), radius = r * 0.55f, center = center, style = Stroke(stroke * 0.85f, cap = StrokeCap.Round, pathEffect = dash))
    }
    drawCircle(color, radius = r * (0.2f + 0.04f * sin(TAU * t * 2)), center = center)
}

private fun DrawScope.drawSupernova(t: Float, color: Color) {
    val r = size.minDimension / 2f
    // Hue drifts toward a hotter, brighter tone and back.
    val hot = ColorMath.shift(color, lightnessDelta = 0.12f, hueDelta = 25f)
    val flicker = 0.5f + 0.5f * sin(TAU * t * 3)
    val tint = ColorMath.mix(color, hot, flicker)
    drawCircle(
        Brush.radialGradient(listOf(tint.copy(alpha = 0.45f), Color.Transparent), center = center, radius = r),
        radius = r,
        center = center,
    )
    rotate(-t * 360f) {
        drawCircle(tint.copy(alpha = 0.7f), radius = r * 0.88f, center = center, style = Stroke(r * 0.06f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(r * 0.12f, r * 0.18f))))
    }
    drawSpark(t, tint, intensity = 1f, rays = 16)
    drawCircle(Color.White.copy(alpha = 0.35f + 0.4f * flicker), radius = r * 0.08f, center = center)
}

/** Small static swatch used where animation would be distracting (e.g. menus). */
@Composable
fun DepthDots(depth: ThinkingDepth, color: Color, modifier: Modifier = Modifier.size(width = 30.dp, height = 8.dp)) {
    Canvas(modifier) {
        val count = ThinkingDepth.MAX_LEVEL
        val gap = size.width * 0.06f
        val w = (size.width - gap * (count - 1)) / count
        for (i in 0 until count) {
            val filled = i < depth.level
            drawRoundRect(
                color = if (filled) color else color.copy(alpha = 0.2f),
                topLeft = Offset(i * (w + gap), 0f),
                size = Size(w, size.height),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(size.height / 2),
            )
        }
    }
}
