package com.avek.chat.core.link.discovery

import com.avek.chat.core.link.transport.HostPort
import com.avek.chat.core.link.transport.MulticastGuard
import com.avek.chat.core.link.transport.WifiBinding
import com.avek.chat.core.link.wire.WireJson
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.isActive
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.intOrNull
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetSocketAddress
import java.net.SocketTimeoutException

/** A PC announcing itself (UI-WIRE section 2). A hint only: trust comes from the handshake. */
data class Beacon(val serverId: String, val name: String, val host: String, val port: Int)

fun interface BeaconSource {
    fun beacons(): Flow<Beacon>
}

object BeaconParser {
    /** Parses `{"avek":2,"serverId":"s_..","name":"..","port":7810}`; returns null for anything else. */
    fun parse(text: String, sourceHost: String): Beacon? = try {
        val obj = WireJson.parseToJsonElement(text) as? JsonObject
        val version = (obj?.get("avek") as? JsonPrimitive)?.intOrNull
        val serverId = (obj?.get("serverId") as? JsonPrimitive)?.contentOrNull
        val port = (obj?.get("port") as? JsonPrimitive)?.intOrNull
        if (version == null || serverId.isNullOrEmpty() || port == null || port !in 1..65535) null
        else Beacon(serverId, (obj["name"] as? JsonPrimitive)?.contentOrNull ?: serverId, sourceHost, port)
    } catch (_: Exception) {
        null
    }
}

/** Listens on UDP 7811 with SO_REUSEADDR, holding the multicast lock and binding to Wi-Fi when possible. */
class UdpBeaconSource(
    private val binding: WifiBinding,
    private val multicast: MulticastGuard,
    private val port: Int = BEACON_PORT,
) : BeaconSource {

    override fun beacons(): Flow<Beacon> = flow {
        multicast.acquire()
        binding.acquire()
        val socket = DatagramSocket(null)
        try {
            socket.reuseAddress = true
            binding.bind(socket)
            socket.bind(InetSocketAddress(port))
            socket.broadcast = true
            socket.soTimeout = POLL_MS
            val buffer = ByteArray(2048)
            while (currentCoroutineContext().isActive) {
                val packet = DatagramPacket(buffer, buffer.size)
                try {
                    socket.receive(packet)
                } catch (_: SocketTimeoutException) {
                    continue
                }
                val text = String(packet.data, 0, packet.length, Charsets.UTF_8)
                BeaconParser.parse(text, packet.address.hostAddress.orEmpty())?.let { emit(it) }
            }
        } finally {
            socket.close()
            binding.release()
            multicast.release()
        }
    }.flowOn(Dispatchers.IO)

    companion object {
        const val BEACON_PORT = 7811
        private const val POLL_MS = 500
    }
}

/** A PC found by discovery, for the pairing list. */
data class DiscoveredServer(val serverId: String, val name: String, val target: HostPort)
