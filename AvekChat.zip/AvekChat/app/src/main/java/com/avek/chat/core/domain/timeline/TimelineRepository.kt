package com.avek.chat.core.domain.timeline

import com.avek.chat.core.domain.trace.TurnKey
import com.avek.chat.core.link.HarnessApi
import com.avek.chat.core.link.LinkRepository
import com.avek.chat.core.link.wire.LinkEvent
import com.avek.chat.core.link.wire.TimelineBlockDto
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

/** Where the outline of saved turns goes when a chat is read (`chat.get {include:["outline"]}`). */
fun interface OutlineSink {
    fun outline(chatId: String, promptId: String, blocks: List<TimelineBlockDto>)
}

/**
 * One [StateFlow] of [TurnTimeline] per turn (the 8 most recent). A live turn is followed from
 * `turn.started` / the block events; a turn joined late or after a reconnect is fetched with
 * `timeline.get` first; a saved turn starts from its outline and fetches block texts when a row is
 * opened. Missed deltas and unknown ids are fetched again by id.
 */
class TimelineRepository(
    private val link: LinkRepository,
    private val api: HarnessApi,
    private val scope: CoroutineScope,
) : OutlineSink {
    private val turns = LinkedHashMap<TurnKey, MutableStateFlow<TurnTimeline>>(16, 0.75f, true)
    private val fetching = HashSet<Pair<TurnKey, String>>()

    fun start() {
        scope.launch { link.events.collect(::onEvent) }
    }

    /** The timeline of a turn; [fetchIfUnknown] = a running turn opened late: `timeline.get` first. */
    fun timeline(chatId: String, promptId: String, fetchIfUnknown: Boolean = false): StateFlow<TurnTimeline> {
        val key = TurnKey(chatId, promptId)
        var created = false
        val flow = synchronized(turns) {
            turns[key] ?: MutableStateFlow(TurnTimeline(key)).also { put(key, it); created = true }
        }
        if (created && fetchIfUnknown) scope.launch { loadAll(key) }
        return flow
    }

    fun known(chatId: String, promptId: String): StateFlow<TurnTimeline>? = synchronized(turns) { turns[TurnKey(chatId, promptId)] }

    override fun outline(chatId: String, promptId: String, blocks: List<TimelineBlockDto>) {
        if (blocks.isEmpty()) return
        val flow = timeline(chatId, promptId) as MutableStateFlow<TurnTimeline>
        // A turn followed live already knows more than its outline.
        if (flow.value.live) return
        flow.value = TimelineReducer.outline(flow.value, blocks)
    }

    /** Texts of blocks the person opened (saved turns: the outline has none). */
    fun loadTexts(chatId: String, promptId: String, ids: List<String>) {
        val key = TurnKey(chatId, promptId)
        val wanted = synchronized(fetching) { ids.filter { fetching.add(key to it) } }
        if (wanted.isEmpty()) return
        scope.launch {
            try {
                val dto = api.timelineGet(key.chatId, key.promptId, ids = wanted)
                apply(key) { TimelineReducer.reduce(it, dto) }
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
                // Not connected: the row keeps its heading; opening it again tries again.
            } finally {
                synchronized(fetching) { wanted.forEach { fetching.remove(key to it) } }
            }
        }
    }

    /** Everything of a turn (late join, reconnect). */
    suspend fun loadAll(key: TurnKey) {
        try {
            val dto = api.timelineGet(key.chatId, key.promptId)
            apply(key) { TimelineReducer.reduce(it, dto) }
        } catch (e: CancellationException) {
            throw e
        } catch (_: Exception) {
        }
    }

    private fun onEvent(event: LinkEvent) {
        val key = keyOf(event)
        if (key == null) {
            if (event is LinkEvent.Refresh) {
                val live = synchronized(turns) { turns.filterValues { it.value.live }.keys.toList() }
                live.forEach { scope.launch { loadAll(it) } }
            }
            return
        }
        val create = event is LinkEvent.TurnStarted || event is LinkEvent.BlockStart
        val existing = synchronized(turns) { turns[key] }
        if (existing == null && !create) {
            // Block events of a turn we never saw start: join it with `timeline.get`.
            if (event is LinkEvent.BlockDelta || event is LinkEvent.BlockTitle || event is LinkEvent.BlockState || event is LinkEvent.BlockEnd) {
                timeline(key.chatId, key.promptId, fetchIfUnknown = true)
            }
            return
        }
        apply(key) { TimelineReducer.reduce(it, event) }
    }

    private fun apply(key: TurnKey, transform: (TurnTimeline) -> TurnTimeline) {
        val flow = synchronized(turns) { turns[key] ?: MutableStateFlow(TurnTimeline(key)).also { put(key, it) } }
        val next = transform(flow.value)
        flow.value = next
        val reload = next.toReload
        if (reload.isNotEmpty()) loadTexts(key.chatId, key.promptId, reload.toList())
    }

    private fun put(key: TurnKey, flow: MutableStateFlow<TurnTimeline>) {
        turns[key] = flow
        while (turns.size > MAX_TURNS) turns.remove(turns.keys.first())
    }

    private fun keyOf(event: LinkEvent): TurnKey? = when (event) {
        is LinkEvent.TurnStarted -> TurnKey(event.data.chatId, event.data.promptId)
        is LinkEvent.TurnCompleted -> TurnKey(event.data.chatId, event.data.promptId)
        is LinkEvent.TurnCancelled -> TurnKey(event.data.chatId, event.data.promptId)
        is LinkEvent.TurnFailed -> TurnKey(event.data.chatId, event.data.promptId)
        is LinkEvent.BlockStart -> TurnKey(event.data.chatId, event.data.promptId)
        is LinkEvent.BlockTitle -> TurnKey(event.data.chatId, event.data.promptId)
        is LinkEvent.BlockDelta -> TurnKey(event.data.chatId, event.data.promptId)
        is LinkEvent.BlockState -> TurnKey(event.data.chatId, event.data.promptId)
        is LinkEvent.BlockEnd -> TurnKey(event.data.chatId, event.data.promptId)
        else -> null
    }

    companion object {
        const val MAX_TURNS = 8
    }
}
