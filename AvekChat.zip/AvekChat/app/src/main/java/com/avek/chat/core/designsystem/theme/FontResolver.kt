package com.avek.chat.core.designsystem.theme

import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.text.font.FontFamily
import com.avek.chat.core.model.settings.FontChoice
import com.avek.chat.core.model.settings.FontSource

/**
 * Turns a persisted [FontChoice] into a renderable [FontFamily]. The Android
 * implementation downloads Google Fonts on demand; this default handles the
 * built-in system families and falls back gracefully for everything else.
 */
interface FontResolver {
    fun resolve(choice: FontChoice): FontFamily
}

object SystemFontResolver : FontResolver {
    override fun resolve(choice: FontChoice): FontFamily = systemFamily(choice) ?: FontFamily.Default

    fun systemFamily(choice: FontChoice): FontFamily? {
        if (choice.source != FontSource.SYSTEM) return null
        return when (choice) {
            FontChoice.SystemSerif -> FontFamily.Serif
            FontChoice.SystemMono -> FontFamily.Monospace
            FontChoice.SystemCursive -> FontFamily.Cursive
            else -> FontFamily.SansSerif
        }
    }
}

val LocalFontResolver = staticCompositionLocalOf<FontResolver> { SystemFontResolver }
