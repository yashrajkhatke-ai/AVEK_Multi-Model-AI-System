package com.avek.chat.feature.customize.tabs

import androidx.compose.animation.AnimatedVisibility
import com.avek.chat.core.designsystem.theme.avekShape
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.outlined.ChevronRight
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.avek.chat.core.designsystem.component.ChipRow
import com.avek.chat.core.designsystem.component.SectionHeader
import com.avek.chat.core.designsystem.component.SettingsCard
import com.avek.chat.core.designsystem.component.SliderRow
import com.avek.chat.core.designsystem.component.SwitchRow
import com.avek.chat.core.designsystem.theme.AvekTheme
import com.avek.chat.core.designsystem.theme.LocalFontResolver
import com.avek.chat.core.model.settings.FontChoice
import com.avek.chat.core.model.settings.FontRole
import com.avek.chat.core.model.settings.FontSettings
import com.avek.chat.core.model.settings.TextStyleSettings
import com.avek.chat.feature.customize.FontFilter
import com.avek.chat.feature.customize.FontPairing
import com.avek.chat.feature.customize.FontPairings
import com.avek.chat.feature.customize.FontResults
import java.text.NumberFormat
import kotlin.math.roundToInt

@Composable
fun FontsTab(
    fonts: FontSettings,
    onStyle: (FontRole, TextStyleSettings) -> Unit,
    onPickFont: (FontRole) -> Unit,
    onPairing: (FontPairing) -> Unit,
    onReset: () -> Unit,
) {
    val colors = AvekTheme.colors
    LazyColumn(contentPadding = PaddingValues(bottom = 40.dp)) {
        item { SectionHeader("Pairings", subtitle = "One tap restyles every role") }
        item {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                items(FontPairings.all, key = { it.name }) { pairing -> PairingCard(pairing) { onPairing(pairing) } }
            }
        }
        FontRole.entries.forEach { role ->
            item(key = role.name) {
                SectionHeader(role.label)
                RoleCard(role, fonts[role], onChange = { onStyle(role, it) }, onPickFont = { onPickFont(role) })
            }
        }
        item {
            Spacer(Modifier.height(20.dp))
            Text(
                "Reset all fonts",
                style = AvekTheme.type.body.copy(fontWeight = FontWeight.Medium),
                color = colors.danger,
                modifier = Modifier
                    .padding(horizontal = 16.dp)
                    .clip(avekShape(12.dp))
                    .clickable(onClick = onReset)
                    .padding(horizontal = 12.dp, vertical = 10.dp),
            )
        }
    }
}

@Composable
private fun PairingCard(pairing: FontPairing, onClick: () -> Unit) {
    val colors = AvekTheme.colors
    val resolver = LocalFontResolver.current
    Surface(
        shape = avekShape(18.dp),
        color = colors.surface,
        border = BorderStroke(1.dp, colors.outline.copy(alpha = 0.7f)),
        modifier = Modifier
            .width(168.dp)
            .clickable(onClick = onClick),
    ) {
        Column(Modifier.padding(14.dp)) {
            Text(
                "Aa",
                style = TextStyle(fontFamily = resolver.resolve(pairing.fonts.getValue(FontRole.HEADING)), fontSize = 30.sp),
                color = colors.textPrimary,
            )
            Text(
                "The quick brown fox",
                style = TextStyle(fontFamily = resolver.resolve(pairing.fonts.getValue(FontRole.ANSWER)), fontSize = 14.sp),
                color = colors.textSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Spacer(Modifier.height(8.dp))
            Text(pairing.name, style = AvekTheme.type.label.copy(fontWeight = FontWeight.SemiBold), color = colors.textPrimary)
            Text(pairing.description, style = AvekTheme.type.caption, color = colors.textTertiary, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun RoleCard(
    role: FontRole,
    style: TextStyleSettings,
    onChange: (TextStyleSettings) -> Unit,
    onPickFont: () -> Unit,
) {
    val colors = AvekTheme.colors
    var advanced by rememberSaveable(role) { mutableStateOf(false) }
    val sizeRange = if (role == FontRole.HEADING) 20f..48f else 10f..26f
    SettingsCard {
        Row(
            Modifier
                .fillMaxWidth()
                .clickable(onClick = onPickFont)
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text(style.font.name, style = AvekTheme.type.body.copy(fontWeight = FontWeight.Medium), color = colors.textPrimary)
                Text("Tap to browse 1,800+ fonts", style = AvekTheme.type.caption, color = colors.textTertiary, maxLines = 1)
            }
            Icon(Icons.Outlined.ChevronRight, null, tint = colors.textSecondary)
        }
        HorizontalDivider(color = colors.outline.copy(alpha = 0.4f))
        Box(
            Modifier
                .fillMaxWidth()
                .background(colors.chatBackground.copy(alpha = 0.6f))
                .padding(16.dp),
        ) {
            Text(role.sample, style = AvekTheme.type[role], color = colors.textPrimary)
        }
        HorizontalDivider(color = colors.outline.copy(alpha = 0.4f))
        SliderRow(
            "Size",
            style.sizeSp,
            { onChange(style.copy(sizeSp = (it * 2).roundToInt() / 2f)) },
            sizeRange,
            "${"%.1f".format(style.sizeSp)} sp",
        )
        SliderRow(
            "Weight",
            style.weight.toFloat(),
            { onChange(style.copy(weight = ((it / 100).roundToInt() * 100).coerceIn(100, 900))) },
            100f..900f,
            weightName(style.weight),
            steps = 7,
        )
        Row(
            Modifier
                .fillMaxWidth()
                .clickable { advanced = !advanced }
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Outlined.Tune, null, tint = colors.textSecondary, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(10.dp))
            Text(if (advanced) "Fewer options" else "Line height, spacing, italic", style = AvekTheme.type.label, color = colors.textSecondary)
        }
        AnimatedVisibility(advanced) {
            Column {
                SliderRow("Line height", style.lineHeight, { onChange(style.copy(lineHeight = (it * 20).roundToInt() / 20f)) }, 1f..2.2f, "${"%.2f".format(style.lineHeight)}×")
                SliderRow("Letter spacing", style.letterSpacing, { onChange(style.copy(letterSpacing = (it * 200).roundToInt() / 200f)) }, -0.05f..0.2f, "${"%.3f".format(style.letterSpacing)} em")
                SwitchRow("Italic", style.italic, { onChange(style.copy(italic = it)) })
            }
        }
    }
}

private fun weightName(weight: Int) = when (weight) {
    100 -> "Thin"
    200 -> "Extra light"
    300 -> "Light"
    400 -> "Regular"
    500 -> "Medium"
    600 -> "Semibold"
    700 -> "Bold"
    800 -> "Extra bold"
    else -> "Black"
}

/** Searchable browser over the full Google Fonts catalogue, each row rendered in its own face. */
@Composable
fun FontPickerSheet(
    role: FontRole,
    current: FontChoice,
    query: String,
    filter: FontFilter,
    results: FontResults,
    onQuery: (String) -> Unit,
    onFilter: (FontFilter) -> Unit,
    onPick: (FontChoice) -> Unit,
    onDismiss: () -> Unit,
) {
    val colors = AvekTheme.colors
    val resolver = LocalFontResolver.current
    val number = remember { NumberFormat.getIntegerInstance() }
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = colors.chatBackground,
        scrimColor = colors.scrim,
    ) {
        Column(Modifier.fillMaxHeight(0.92f).navigationBarsPadding()) {
            Text("Font for ${role.label.lowercase()}", style = AvekTheme.type.headline, color = colors.textPrimary, modifier = Modifier.padding(horizontal = 20.dp))
            Text(
                "${number.format(results.total)} fonts · downloaded on demand from Google Fonts",
                style = AvekTheme.type.caption,
                color = colors.textSecondary,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp),
            )
            Row(
                Modifier
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .fillMaxWidth()
                    .clip(avekShape(14.dp))
                    .background(colors.surface)
                    .border(1.dp, colors.outline, avekShape(14.dp))
                    .padding(horizontal = 12.dp, vertical = 11.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Outlined.Search, null, tint = colors.textSecondary, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Box(Modifier.weight(1f)) {
                    if (query.isEmpty()) Text("Search fonts", style = AvekTheme.type.body, color = colors.textTertiary)
                    BasicTextField(
                        value = query,
                        onValueChange = onQuery,
                        singleLine = true,
                        textStyle = AvekTheme.type.body.copy(color = colors.textPrimary),
                        cursorBrush = SolidColor(colors.accent),
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
                if (query.isNotEmpty()) {
                    Icon(Icons.Outlined.Close, "Clear", tint = colors.textSecondary, modifier = Modifier.size(18.dp).clickable { onQuery("") })
                }
            }
            ChipRow(FontFilter.entries, filter, onFilter, { it.label })
            Text(
                if (results.loading) "Loading catalogue…" else "${number.format(results.options.size)} matches",
                style = AvekTheme.type.caption,
                color = colors.textTertiary,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp),
            )
            LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 24.dp)) {
                items(results.options, key = { "${it.choice.source}-${it.choice.name}" }) { option ->
                    val selected = option.choice == current
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable { onPick(option.choice) }
                            .background(if (selected) colors.accentContainer else androidx.compose.ui.graphics.Color.Transparent)
                            .padding(horizontal = 20.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(
                                option.choice.name,
                                style = TextStyle(fontFamily = resolver.resolve(option.choice), fontSize = 21.sp),
                                color = colors.textPrimary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                            Text(option.subtitle, style = AvekTheme.type.caption, color = colors.textTertiary)
                        }
                        if (selected) Icon(Icons.Filled.CheckCircle, "Selected", tint = colors.accent)
                    }
                }
            }
        }
    }
}
