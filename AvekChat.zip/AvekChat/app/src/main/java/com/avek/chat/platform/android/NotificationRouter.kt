package com.avek.chat.platform.android

import com.avek.chat.core.link.AppVisibility
import com.avek.chat.core.link.LinkRepository
import com.avek.chat.core.link.wire.LinkEvent
import com.avek.chat.core.data.remote.toDomain
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Turns link events into notifications while the app is not on screen (UI-WIRE section 13):
 * a question becomes a high-priority notification with Allow / Deny, a finished or failed turn
 * becomes "<title>: <preview>". When the app is visible the UI shows these itself.
 */
@Singleton
class NotificationRouter @Inject constructor(
    private val link: LinkRepository,
    private val visibility: AppVisibility,
    private val notifications: AvekNotifications,
) {
    fun start(scope: CoroutineScope) {
        scope.launch {
            link.events.collect { event ->
                when (event) {
                    is LinkEvent.AskRequest -> if (!visibility.visible.value) notifications.showAsk(event.data.toDomain())
                    is LinkEvent.AskResolved -> notifications.cancelAsk(event.data.askId)
                    is LinkEvent.TurnCompleted -> if (!visibility.visible.value) {
                        notifications.showAnswer(event.data.chatId, event.data.title, event.data.preview.ifBlank { "Answer ready" })
                    }
                    is LinkEvent.TurnFailed -> if (!visibility.visible.value) {
                        notifications.showAnswer(event.data.chatId, "Could not answer", event.data.message.ifBlank { "Something went wrong" })
                    }
                    else -> Unit
                }
            }
        }
    }
}
