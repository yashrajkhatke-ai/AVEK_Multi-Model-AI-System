package com.avek.chat.core.model

/** A (simulated) model the user can talk to. */
data class AiModel(
    val id: String,
    val name: String,
    val version: String,
    val tagline: String,
    val description: String,
    val contextWindowK: Int,
    val maxDepth: ThinkingDepth,
    /** 1..5 */
    val speed: Int,
    /** 1..5 */
    val intelligence: Int,
    val strengths: Set<TaskMode>,
    val tokensPerSecond: Int,
    val badge: String? = null,
) {
    val displayName: String get() = "$name $version"

    val contextLabel: String
        get() = if (contextWindowK >= 1000) "${contextWindowK / 1000}M context" else "${contextWindowK}K context"

    fun clampDepth(depth: ThinkingDepth): ThinkingDepth =
        if (depth.level > maxDepth.level) maxDepth else depth
}
