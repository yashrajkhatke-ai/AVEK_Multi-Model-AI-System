package com.avek.chat.core.model

/** A chat as listed by the PC (`ChatSummary`). */
data class Conversation(
    val id: String,
    val title: String,
    val createdAt: Long,
    val updatedAt: Long,
    val isStarred: Boolean,
    val isArchived: Boolean,
    val modelId: String?,
    val taskMode: TaskMode,
    val preview: String,
    val turnCount: Int,
    /** A complete copy is kept on this device. */
    val isDownloaded: Boolean = false,
)
