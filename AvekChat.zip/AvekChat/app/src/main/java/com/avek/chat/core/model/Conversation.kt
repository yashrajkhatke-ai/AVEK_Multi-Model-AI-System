package com.avek.chat.core.model

data class Conversation(
    val id: String,
    val title: String,
    val createdAt: Long,
    val updatedAt: Long,
    val isStarred: Boolean,
    val isArchived: Boolean,
    val modelId: String,
    val taskMode: TaskMode,
    val preview: String,
    val messageCount: Int,
)
