package com.avek.chat.core.link.rpc

import com.avek.chat.core.link.crypto.FrameException
import com.avek.chat.core.link.crypto.FrameOpener
import com.avek.chat.core.link.crypto.FrameSealer
import com.avek.chat.core.link.crypto.SessionKeys
import com.avek.chat.core.link.transport.RawChannel
import com.avek.chat.core.link.transport.RawMessage
import com.avek.chat.core.link.wire.EventDecoder
import com.avek.chat.core.link.wire.ReadyDto
import com.avek.chat.core.link.wire.WireCodec
import com.avek.chat.core.link.wire.WireEvent
import com.avek.chat.core.link.wire.WireResponse
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.serialization.SerializationException
import kotlinx.serialization.json.JsonObject

/**
 * Phase 2 of a connection: binary AVEK-SEC/4 frames carrying JSON messages.
 * Owns the reader loop, the 15 s ping and the 40 s silence watchdog (UI-WIRE section 1).
 */
class SecureLinkSession(
    private val channel: RawChannel,
    keys: SessionKeys,
    scope: CoroutineScope,
    private val onEvent: suspend (WireEvent) -> Unit,
    /** `waking` arrived (true) / the PC answered again (false): "Waking up your PC...". */
    private val onWaking: (Boolean) -> Unit = {},
    private val nowMs: () -> Long = System::currentTimeMillis,
    private val pingIntervalMs: Long = PING_INTERVAL_MS,
    private val silenceLimitMs: Long = SILENCE_LIMIT_MS,
) : LiveLink {

    private val sealer = FrameSealer(keys.clientToServer)
    private val opener = FrameOpener(keys.serverToClient)
    private val sendLock = Mutex()
    private val job = SupervisorJob(scope.coroutineContext[Job])
    private val sessionScope = CoroutineScope(scope.coroutineContext + job)
    private val closed = CompletableDeferred<CloseInfo>()

    @Volatile
    private var lastFrameAt = nowMs()

    /** Completed with the first secure frame, which must be the `ready` event. */
    val ready = CompletableDeferred<ReadyDto>()

    val rpc = RpcClient(::sendJson)

    @Volatile
    override var serverName: String = ""
        private set

    val remote get() = channel.remote

    fun start() {
        sessionScope.launch { readLoop() }
        sessionScope.launch { pingLoop() }
        sessionScope.launch { watchdog() }
    }

    /**
     * Waits for `ready` (the first secure frame) and records the server name.
     * A connection that closes first makes [ready] fail, so no separate watcher is needed.
     */
    suspend fun awaitReady(timeoutMs: Long): ReadyDto {
        // `waking` may come first: the PC's heavy part is starting, so wait at least 30 s then.
        val dto = withTimeoutOrNull(timeoutMs) { ready.await() }
            ?: withTimeout(if (rpc.waking) (RpcClient.WAKING_MIN_MS - timeoutMs).coerceAtLeast(1) else 1) { ready.await() }
        serverName = dto.server.name
        return dto
    }

    override suspend fun awaitClosed(): CloseInfo = closed.await()

    override fun close(code: Int, reason: String) {
        channel.close(code, reason)
        finish(CloseInfo(code, reason))
    }

    private suspend fun sendJson(text: String) {
        val bytes = text.toByteArray(Charsets.UTF_8)
        // Sealing and sending are one atomic step: frame counters must hit the wire in order.
        sendLock.withLock { channel.sendBinary(sealer.seal(bytes)) }
    }

    private suspend fun readLoop() {
        try {
            for (message in channel.incoming) {
                when (message) {
                    is RawMessage.Binary -> {
                        lastFrameAt = nowMs()
                        if (message.bytes.size > MAX_FRAME_BYTES + FRAME_OVERHEAD) {
                            protocolError("Oversized frame")
                            return
                        }
                        val plaintext = opener.open(message.bytes)
                        handle(plaintext.toString(Charsets.UTF_8))
                    }
                    is RawMessage.Text -> {
                        protocolError("Text frame in the secure phase")
                        return
                    }
                    is RawMessage.Closed -> {
                        finish(CloseInfo(message.code, message.reason))
                        return
                    }
                }
            }
            finish(CloseInfo(1006, "Channel ended"))
        } catch (e: FrameException) {
            channel.close(4400, "bad frame")
            finish(CloseInfo(4400, "bad frame", e))
        } catch (e: SerializationException) {
            protocolError("Malformed message")
        } catch (e: IllegalArgumentException) {
            protocolError("Malformed message")
        }
    }

    private suspend fun handle(text: String) {
        when (val parsed = WireCodec.parse(text)) {
            is WireResponse -> {
                val op = rpc.onResponse(parsed)
                if (rpc.waking && op !in RpcClient.NEVER_WAKE) {
                    rpc.waking = false
                    onWaking(false)
                }
            }
            is WireEvent -> when (parsed.ev) {
                EventDecoder.READY -> {
                    if (rpc.waking) {
                        rpc.waking = false
                        onWaking(false)
                    }
                    ready.complete(EventDecoder.decodeReady(parsed.data as JsonObject))
                }
                EventDecoder.WAKING -> {
                    // The heavy part is starting: requests are answered later (never time out before 30 s).
                    rpc.waking = true
                    onWaking(true)
                }
                else -> onEvent(parsed)
            }
            else -> Unit
        }
    }

    private fun protocolError(reason: String) {
        channel.close(4400, reason)
        finish(CloseInfo(4400, reason))
    }

    private suspend fun pingLoop() {
        while (sessionScope.isActive) {
            delay(pingIntervalMs)
            sessionScope.launch { runCatching { rpc.call("ping", JsonObject(emptyMap()), pingIntervalMs) } }
        }
    }

    private suspend fun watchdog() {
        while (sessionScope.isActive) {
            delay(WATCHDOG_TICK_MS)
            if (nowMs() - lastFrameAt >= silenceLimitMs) {
                channel.close(4408, "silence")
                finish(CloseInfo(1006, "No frame for ${silenceLimitMs / 1000}s"))
                return
            }
        }
    }

    private fun finish(info: CloseInfo) {
        if (closed.complete(info)) {
            rpc.failAll(RpcException(RpcException.CONNECTION_LOST, "Connection closed (${info.code})"))
            ready.completeExceptionally(LinkClosedException(info))
            job.cancel()
        }
    }

    companion object {
        const val PING_INTERVAL_MS = 15_000L
        const val SILENCE_LIMIT_MS = 40_000L
        const val MAX_FRAME_BYTES = 1_048_576
        private const val FRAME_OVERHEAD = 64
        private const val WATCHDOG_TICK_MS = 5_000L
    }
}
