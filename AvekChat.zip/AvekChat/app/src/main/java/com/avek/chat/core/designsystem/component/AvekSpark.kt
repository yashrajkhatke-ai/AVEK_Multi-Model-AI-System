package com.avek.chat.core.designsystem.component

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.dp
import com.avek.chat.core.designsystem.motion.rememberPhase
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/** The Avek brand mark: a twelve-ray spark with alternating ray lengths. */
@Composable
fun AvekSpark(
    color: Color,
    modifier: Modifier = Modifier.size(28.dp),
    animated: Boolean = false,
) {
    val phase = rememberPhase(9000, animate = animated, label = "spark")
    Canvas(modifier) {
        val t = phase.value
        val r = size.minDimension / 2f
        val rays = 12
        rotate(if (animated) t * 360f else 0f) {
            for (i in 0 until rays) {
                val a = (2 * PI * i / rays - PI / 2).toFloat()
                val breathe = if (animated) 0.92f + 0.08f * sin((2 * PI * (t * 3 + i / 12.0)).toFloat()) else 1f
                val length = r * (if (i % 2 == 0) 1f else 0.72f) * breathe
                val inner = r * 0.12f
                val half = r * 0.105f
                val dir = Offset(cos(a), sin(a))
                val normal = Offset(-dir.y, dir.x)
                val base = center + dir * inner
                val tip = center + dir * length
                val path = Path().apply {
                    moveTo(base.x + normal.x * half, base.y + normal.y * half)
                    lineTo(tip.x, tip.y)
                    lineTo(base.x - normal.x * half, base.y - normal.y * half)
                    close()
                }
                drawPath(path, color)
            }
        }
        drawCircle(color, radius = r * 0.17f, center = center)
    }
}
