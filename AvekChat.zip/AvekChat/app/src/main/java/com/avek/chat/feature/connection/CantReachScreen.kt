package com.avek.chat.feature.connection

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AccessTime
import androidx.compose.material.icons.outlined.CloudOff
import androidx.compose.material.icons.outlined.Public
import androidx.compose.material.icons.outlined.VpnLock
import androidx.compose.material.icons.outlined.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.avek.chat.core.designsystem.theme.AvekTheme
import com.avek.chat.core.designsystem.theme.avekShape
import com.avek.chat.core.link.route.FailureReason
import com.avek.chat.core.link.route.RouteKind

/**
 * "Can't reach your PC" (UI-WIRE v4 section 2.3, item 5): one line per route with the reason in plain
 * words, the clock hint (the knock is time-checked), when it last connected, Retry, Connection settings,
 * and "Read chats" (the chat list and downloaded chats stay readable).
 */
@Composable
fun CantReachScreen(
    info: UnreachableUi,
    onRetry: () -> Unit,
    onSettings: () -> Unit,
    onReadChats: () -> Unit,
    modifier: Modifier = Modifier,
    nowMs: Long = System.currentTimeMillis(),
) {
    val colors = AvekTheme.colors
    Box(modifier.fillMaxSize().background(colors.chatBackground)) {
        Column(
            Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp, vertical = 24.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Spacer(Modifier.height(24.dp))
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                Box(Modifier.size(72.dp).clip(CircleShape).background(colors.surface), contentAlignment = Alignment.Center) {
                    Icon(Icons.Outlined.CloudOff, null, tint = colors.textSecondary, modifier = Modifier.size(36.dp))
                }
            }
            Text(
                "Can't reach your PC",
                style = AvekTheme.type.display,
                color = colors.textPrimary,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth(),
            )
            Text(
                info.pcName,
                style = AvekTheme.type.body,
                color = colors.textSecondary,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth(),
            )
            Column(
                Modifier
                    .fillMaxWidth()
                    .clip(avekShape(16.dp))
                    .background(colors.surface)
                    .border(1.dp, colors.outline.copy(alpha = 0.6f), avekShape(16.dp))
                    .padding(vertical = 6.dp),
            ) {
                info.lines.forEach { line -> RouteFailureRow(line) }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.AccessTime, null, tint = colors.textTertiary, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(8.dp))
                Text("Check that your phone's clock is correct", style = AvekTheme.type.bodySmall, color = colors.textTertiary)
            }
            Text(lastConnectedText(info.lastConnectedAt, nowMs), style = AvekTheme.type.bodySmall, color = colors.textTertiary)
            Button(
                onClick = onRetry,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = colors.accent, contentColor = colors.onAccent),
            ) { Text("Retry") }
            OutlinedButton(onClick = onSettings, modifier = Modifier.fillMaxWidth()) { Text("Connection settings", color = colors.textPrimary) }
            TextButton(onClick = onReadChats, modifier = Modifier.fillMaxWidth()) { Text("Read chats", color = colors.accent) }
        }
    }
}

@Composable
private fun RouteFailureRow(line: RouteLine) {
    val colors = AvekTheme.colors
    val icon: ImageVector = when (line.route) {
        RouteKind.WIFI -> Icons.Outlined.Wifi
        RouteKind.TAILSCALE -> Icons.Outlined.VpnLock
        RouteKind.NGROK -> Icons.Outlined.Public
    }
    val label = when (line.reason) {
        FailureReason.NotFound -> "not found"
        FailureReason.Refused -> "refused"
        FailureReason.Denied -> "denied"
        FailureReason.Timeout -> "timeout"
        FailureReason.Skipped -> "skipped"
        FailureReason.Error -> "error"
    }
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 10.dp)
            .semantics { contentDescription = "${line.route.label}: $label. ${line.text}" },
        verticalAlignment = Alignment.Top,
    ) {
        Icon(icon, null, tint = colors.textSecondary, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(line.route.label, style = AvekTheme.type.title, color = colors.textPrimary)
                Spacer(Modifier.width(8.dp))
                Text(
                    label,
                    style = AvekTheme.type.caption,
                    color = if (line.reason == FailureReason.Skipped) colors.textTertiary else colors.danger,
                )
            }
            Text(line.text, style = AvekTheme.type.bodySmall, color = colors.textSecondary)
        }
    }
}
