package com.avek.chat.core.designsystem.component

import androidx.compose.animation.animateColorAsState
import com.avek.chat.core.designsystem.theme.avekShape
import com.avek.chat.core.designsystem.theme.avekPill
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.avek.chat.core.designsystem.theme.AvekTheme

@Composable
fun SectionHeader(title: String, modifier: Modifier = Modifier, subtitle: String? = null) {
    Column(modifier.padding(start = 20.dp, end = 20.dp, top = 24.dp, bottom = 8.dp)) {
        Text(
            title.uppercase(),
            style = AvekTheme.type.caption.copy(fontWeight = FontWeight.SemiBold, letterSpacing = AvekTheme.type.caption.fontSize * 0.08f),
            color = AvekTheme.colors.textSecondary,
        )
        if (subtitle != null) {
            Spacer(Modifier.height(2.dp))
            Text(subtitle, style = AvekTheme.type.bodySmall, color = AvekTheme.colors.textTertiary)
        }
    }
}

/** A rounded container grouping related settings rows, iOS/Claude style. */
@Composable
fun SettingsCard(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Surface(
        modifier = modifier.padding(horizontal = 16.dp).fillMaxWidth(),
        shape = avekShape(18.dp),
        color = AvekTheme.colors.surface,
        border = BorderStroke(1.dp, AvekTheme.colors.outline.copy(alpha = 0.6f)),
    ) {
        Column { content() }
    }
}

@Composable
fun SettingRow(
    title: String,
    modifier: Modifier = Modifier,
    subtitle: String? = null,
    icon: ImageVector? = null,
    onClick: (() -> Unit)? = null,
    trailing: @Composable (() -> Unit)? = null,
) {
    Row(
        modifier
            .fillMaxWidth()
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (icon != null) {
            Icon(icon, contentDescription = null, tint = AvekTheme.colors.textSecondary, modifier = Modifier.size(22.dp))
            Spacer(Modifier.width(14.dp))
        }
        Column(Modifier.weight(1f)) {
            Text(title, style = AvekTheme.type.body, color = AvekTheme.colors.textPrimary, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (subtitle != null) {
                Text(subtitle, style = AvekTheme.type.bodySmall, color = AvekTheme.colors.textSecondary, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
        }
        if (trailing != null) {
            Spacer(Modifier.width(12.dp))
            trailing()
        }
    }
}

@Composable
fun SwitchRow(
    title: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier,
    subtitle: String? = null,
    icon: ImageVector? = null,
) {
    SettingRow(title, modifier, subtitle, icon, onClick = { onCheckedChange(!checked) }) {
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = AvekTheme.colors.onAccent,
                checkedTrackColor = AvekTheme.colors.accent,
                uncheckedThumbColor = AvekTheme.colors.textSecondary,
                uncheckedTrackColor = AvekTheme.colors.sidebarSelected,
                uncheckedBorderColor = AvekTheme.colors.outline,
            ),
        )
    }
}

@Composable
fun SliderRow(
    title: String,
    value: Float,
    onValueChange: (Float) -> Unit,
    valueRange: ClosedFloatingPointRange<Float>,
    valueLabel: String,
    modifier: Modifier = Modifier,
    steps: Int = 0,
) {
    Column(modifier.padding(horizontal = 16.dp, vertical = 10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(title, style = AvekTheme.type.body, color = AvekTheme.colors.textPrimary, modifier = Modifier.weight(1f))
            Text(valueLabel, style = AvekTheme.type.label, color = AvekTheme.colors.textSecondary)
        }
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = valueRange,
            steps = steps,
            colors = SliderDefaults.colors(
                thumbColor = AvekTheme.colors.accent,
                activeTrackColor = AvekTheme.colors.accent,
                inactiveTrackColor = AvekTheme.colors.sidebarSelected,
                activeTickColor = AvekTheme.colors.onAccent.copy(alpha = 0.6f),
                inactiveTickColor = AvekTheme.colors.textTertiary,
            ),
        )
    }
}

/** A pill-shaped segmented control with an accent-filled selection. */
@Composable
fun <T> SegmentedPicker(
    options: List<T>,
    selected: T,
    onSelect: (T) -> Unit,
    label: (T) -> String,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier
            .fillMaxWidth()
            .clip(avekShape(14.dp))
            .background(AvekTheme.colors.sidebarSelected.copy(alpha = 0.6f))
            .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        options.forEach { option ->
            val isSelected = option == selected
            val bg by animateColorAsState(if (isSelected) AvekTheme.colors.surface else Color.Transparent, label = "seg")
            Box(
                Modifier
                    .weight(1f)
                    .clip(avekShape(10.dp))
                    .background(bg)
                    .clickable { onSelect(option) }
                    .padding(vertical = 9.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    label(option),
                    style = AvekTheme.type.label,
                    color = if (isSelected) AvekTheme.colors.textPrimary else AvekTheme.colors.textSecondary,
                    maxLines = 1,
                )
            }
        }
    }
}

/** Horizontally scrolling single-select chips. */
@Composable
fun <T> ChipRow(
    options: List<T>,
    selected: T?,
    onSelect: (T) -> Unit,
    label: (T) -> String,
    modifier: Modifier = Modifier,
    contentPadding: PaddingValues = PaddingValues(horizontal = 16.dp),
    leading: (@Composable (T) -> Unit)? = null,
) {
    Row(
        modifier
            .horizontalScroll(rememberScrollState())
            .padding(contentPadding),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        options.forEach { option ->
            AvekChip(
                text = label(option),
                selected = option == selected,
                onClick = { onSelect(option) },
                leading = leading?.let { { it(option) } },
            )
        }
    }
}

@Composable
fun AvekChip(
    text: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    leading: (@Composable () -> Unit)? = null,
) {
    val colors = AvekTheme.colors
    val bg by animateColorAsState(if (selected) colors.accentContainer else colors.surface, label = "chip-bg")
    val border by animateColorAsState(if (selected) colors.accent else colors.outline, label = "chip-border")
    Row(
        modifier
            .clip(avekPill())
            .background(bg)
            .border(1.dp, border, avekPill())
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (leading != null) {
            leading()
            Spacer(Modifier.width(6.dp))
        }
        Text(text, style = AvekTheme.type.label, color = if (selected) colors.textPrimary else colors.textSecondary, maxLines = 1)
    }
}

@Composable
fun ColorDot(color: Color, modifier: Modifier = Modifier, size: Int = 22, selected: Boolean = false) {
    Box(
        modifier
            .size(size.dp)
            .clip(CircleShape)
            .background(color)
            .border(
                width = if (selected) 2.dp else 1.dp,
                color = if (selected) AvekTheme.colors.textPrimary else AvekTheme.colors.outline,
                shape = CircleShape,
            ),
    )
}
