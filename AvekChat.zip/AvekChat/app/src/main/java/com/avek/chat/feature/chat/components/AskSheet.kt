package com.avek.chat.feature.chat.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.HelpOutline
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import com.avek.chat.core.designsystem.theme.AvekTheme
import com.avek.chat.core.designsystem.theme.avekShape
import com.avek.chat.core.model.AskKind
import com.avek.chat.core.model.AskRequest

/**
 * A question from the PC ("doubt"). An approval shows the summary and detail and one button per
 * choice (Allow / Deny / Allow for this session); a question shows a text field. It closes when the
 * PC reports `ask.resolved`, which removes the ask from the list that drives it.
 */
@Composable
fun AskSheet(
    ask: AskRequest,
    onDecision: (String) -> Unit,
    onText: (String) -> Unit,
) {
    val colors = AvekTheme.colors
    // The person must answer: swiping the sheet away would leave the PC waiting, so it is not dismissible by gesture.
    ModalBottomSheet(
        onDismissRequest = {},
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true, confirmValueChange = { false }),
        containerColor = colors.chatBackground,
        scrimColor = colors.scrim,
    ) {
        Column(
            Modifier
                .navigationBarsPadding()
                .padding(horizontal = 20.dp)
                .padding(bottom = 20.dp)
                .verticalScroll(rememberScrollState()),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    if (ask.kind == AskKind.QUESTION) Icons.Outlined.HelpOutline else Icons.Outlined.Shield,
                    contentDescription = null,
                    tint = colors.accent,
                    modifier = Modifier.size(22.dp),
                )
                Spacer(Modifier.width(10.dp))
                Text(
                    if (ask.kind == AskKind.QUESTION) "Your PC has a question" else "Your PC is asking permission",
                    style = AvekTheme.type.title,
                    color = colors.textPrimary,
                )
            }
            Spacer(Modifier.height(12.dp))
            Text(ask.summary, style = AvekTheme.type.headline, color = colors.textPrimary)
            if (!ask.tool.isNullOrBlank()) {
                Text("Tool: ${ask.tool}", style = AvekTheme.type.caption, color = colors.textTertiary, modifier = Modifier.padding(top = 2.dp))
            }
            if (!ask.detail.isNullOrBlank()) {
                Spacer(Modifier.height(10.dp))
                Text(
                    ask.detail,
                    style = AvekTheme.type.code,
                    fontFamily = FontFamily.Monospace,
                    color = colors.textSecondary,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(avekShape(12.dp))
                        .background(colors.codeSurface)
                        .padding(12.dp),
                )
            }
            Spacer(Modifier.height(16.dp))
            if (ask.kind == AskKind.QUESTION) QuestionAnswer(onText) else ChoiceButtons(ask.choices, onDecision)
        }
    }
}

@Composable
private fun ChoiceButtons(choices: List<String>, onDecision: (String) -> Unit) {
    val colors = AvekTheme.colors
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        choices.forEach { choice ->
            val allow = choice == "allow"
            val deny = choice == "deny"
            val label = when (choice) {
                "allow" -> "Allow"
                "deny" -> "Deny"
                "allow-session" -> "Allow for this session"
                else -> choice.replaceFirstChar { it.uppercase() }
            }
            if (allow) {
                Button(
                    onClick = { onDecision(choice) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = colors.accent, contentColor = colors.onAccent),
                ) { Text(label) }
            } else {
                OutlinedButton(
                    onClick = { onDecision(choice) },
                    modifier = Modifier.fillMaxWidth(),
                    border = androidx.compose.foundation.BorderStroke(1.dp, if (deny) colors.danger.copy(alpha = 0.6f) else colors.outline),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = if (deny) colors.danger else colors.textPrimary),
                ) { Text(label) }
            }
        }
    }
}

@Composable
private fun QuestionAnswer(onText: (String) -> Unit) {
    val colors = AvekTheme.colors
    var text by remember { mutableStateOf("") }
    OutlinedTextField(
        value = text,
        onValueChange = { text = it },
        placeholder = { Text("Your answer", color = colors.textTertiary) },
        modifier = Modifier.fillMaxWidth(),
        textStyle = AvekTheme.type.body.copy(color = colors.textPrimary),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = colors.accent,
            unfocusedBorderColor = colors.outline,
            cursorColor = colors.accent,
        ),
        minLines = 2,
        maxLines = 6,
    )
    Spacer(Modifier.height(10.dp))
    Button(
        onClick = { onText(text.trim()) },
        enabled = text.isNotBlank(),
        modifier = Modifier.fillMaxWidth(),
        colors = ButtonDefaults.buttonColors(containerColor = colors.accent, contentColor = colors.onAccent),
    ) { Text("Send answer") }
}
