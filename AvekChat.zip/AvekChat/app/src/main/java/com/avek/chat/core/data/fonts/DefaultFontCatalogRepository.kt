package com.avek.chat.core.data.fonts

import com.avek.chat.core.common.AppDispatchers
import com.avek.chat.core.domain.repository.FontCatalogRepository
import com.avek.chat.core.model.FontCategory
import com.avek.chat.core.model.FontInfo
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class DefaultFontCatalogRepository @Inject constructor(
    private val source: FontCatalogSource,
    private val dispatchers: AppDispatchers,
) : FontCatalogRepository {

    private val mutex = Mutex()
    private var cache: List<FontInfo>? = null

    override suspend fun all(): List<FontInfo> = mutex.withLock {
        cache ?: withContext(dispatchers.io) {
            FontCatalogParser.parse(source.readLines().asSequence())
        }.also { cache = it }
    }

    override suspend fun featured(): List<FontInfo> {
        val byName = all().associateBy { it.name }
        return FEATURED.mapNotNull { byName[it] }
    }

    override suspend fun search(query: String, category: FontCategory?): List<FontInfo> {
        val q = query.trim()
        return withContext(dispatchers.default) {
            all().asSequence()
                .filter { category == null || it.category == category }
                .filter { q.isEmpty() || it.name.contains(q, ignoreCase = true) }
                .sortedWith(compareBy({ !it.name.startsWith(q, ignoreCase = true) }, { it.name }))
                .toList()
        }
    }

    companion object {
        /** Hand-picked fonts that read well in a chat UI. All exist in the catalog. */
        val FEATURED = listOf(
            "Inter", "Source Serif 4", "Newsreader", "Lora", "Literata", "Fraunces", "Instrument Serif",
            "DM Sans", "Manrope", "Plus Jakarta Sans", "Figtree", "Geist", "Onest", "Outfit", "Sora",
            "Space Grotesk", "Bricolage Grotesque", "IBM Plex Sans", "IBM Plex Serif", "Atkinson Hyperlegible",
            "Lexend", "Nunito", "Quicksand", "Merriweather", "Crimson Pro", "EB Garamond", "Cormorant Garamond",
            "Libre Baskerville", "Spectral", "Playfair Display", "Young Serif", "Gloock", "JetBrains Mono",
            "Fira Code", "IBM Plex Mono", "Geist Mono", "Martian Mono", "Victor Mono", "Recursive",
            "Caveat", "Kalam", "Shantell Sans", "Patrick Hand", "Comfortaa",
        )
    }
}
