package com.avek.chat.core.data.remote

import com.avek.chat.core.domain.repository.ChatListQuery
import com.avek.chat.core.domain.repository.ChatRepository
import com.avek.chat.core.domain.repository.ChatTurns
import com.avek.chat.core.domain.repository.Page
import com.avek.chat.core.domain.repository.TurnMessages
import com.avek.chat.core.link.HarnessApi
import com.avek.chat.core.model.Conversation
import com.avek.chat.core.model.Feedback
import com.avek.chat.core.model.TaskMode
import com.avek.chat.core.model.ToolView

/** The live chats of the PC: a thin, typed mapping over `chats.list`, `chat.get`, `turn.get`, … */
class RemoteChatRepository(private val api: HarnessApi) : ChatRepository {

    override suspend fun list(query: ChatListQuery, limit: Int, after: String?): Page<Conversation> {
        val part = api.chatsList(limit, after, query.text.takeIf { it.isNotBlank() }, query.archived, query.starred)
        return Page(part.items.map { it.toDomain() }, part.total, part.next)
    }

    override suspend fun open(chatId: String, limit: Int, after: String?): ChatTurns {
        val part = api.chatGet(chatId, limit, after)
        // The PC sends turns newest first; screens want them oldest first.
        val messages = part.items.reversed().flatMap { turn -> turn.toMessages(chatId).let { listOf(it.user, it.assistant) } }
        return ChatTurns(part.chat?.toDomain(), messages, part.total, part.next)
    }

    override suspend fun turn(chatId: String, promptId: String, withThinking: Boolean): TurnMessages =
        api.turnGet(chatId, promptId, if (withThinking) HarnessApi.INCLUDE_THINKING else emptySet()).turn.toMessages(chatId)

    override suspend fun tool(chatId: String, promptId: String, callId: String): ToolView {
        val result = api.toolGet(chatId, promptId, callId)
        return ToolView(
            callId = result.callId.ifEmpty { callId },
            title = result.view.title,
            detail = result.view.detail,
            body = result.view.body,
            style = result.view.style,
        )
    }

    override suspend fun setChat(
        chatId: String,
        title: String?,
        mode: TaskMode?,
        starred: Boolean?,
        archived: Boolean?,
        modelId: String?,
    ): Conversation =
        api.chatSet(chatId, title, modelId, mode?.wire, starred, archived).chat.toDomain()

    override suspend fun delete(chatId: String) = api.chatDelete(chatId)

    override suspend fun rewind(chatId: String, fromPromptId: String) {
        api.chatRewind(chatId, fromPromptId)
    }

    override suspend fun feedback(chatId: String, promptId: String, value: Feedback) =
        api.turnFeedback(chatId, promptId, value.toWire())
}
