package com.avek.chat.feature.customize.tabs

import androidx.compose.foundation.background
import com.avek.chat.core.designsystem.theme.avekShape
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.avek.chat.core.designsystem.component.SectionHeader
import com.avek.chat.core.designsystem.component.SegmentedPicker
import com.avek.chat.core.designsystem.component.SettingsCard
import com.avek.chat.core.designsystem.component.SliderRow
import com.avek.chat.core.designsystem.component.SwitchRow
import com.avek.chat.core.designsystem.theme.AvekTheme
import com.avek.chat.core.model.settings.AssistantStyle
import com.avek.chat.core.model.settings.BubbleStyle
import com.avek.chat.core.model.settings.ChatLayout
import com.avek.chat.core.model.settings.Density
import com.avek.chat.core.model.settings.UserAlignment
import com.avek.chat.feature.customize.PreviewUserBubble
import kotlin.math.roundToInt

@Composable
fun ChatTab(layout: ChatLayout, onChange: ((ChatLayout) -> ChatLayout) -> Unit) {
    val colors = AvekTheme.colors
    LazyColumn(contentPadding = PaddingValues(bottom = 40.dp)) {
        item { SectionHeader("Your bubble") }
        item {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                items(BubbleStyle.entries) { style ->
                    val selected = style == layout.bubbleStyle
                    Column(
                        Modifier
                            .width(150.dp)
                            .clip(avekShape(18.dp))
                            .background(colors.chatBackground)
                            .border(if (selected) 2.dp else 1.dp, if (selected) colors.accent else colors.outline, avekShape(18.dp))
                            .clickable { onChange { it.copy(bubbleStyle = style) } }
                            .padding(12.dp),
                    ) {
                        PreviewUserBubble("Hello there!", Modifier.fillMaxWidth(), style)
                        Spacer(Modifier.height(10.dp))
                        Text(
                            style.label,
                            style = AvekTheme.type.label.copy(fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal),
                            color = colors.textPrimary,
                        )
                    }
                }
            }
        }
        item {
            Spacer(Modifier.height(12.dp))
            SettingsCard {
                SliderRow("Corner radius", layout.bubbleCornerDp.toFloat(), { v -> onChange { it.copy(bubbleCornerDp = v.roundToInt()) } }, 0f..32f, "${layout.bubbleCornerDp} dp")
                HorizontalDivider(color = colors.outline.copy(alpha = 0.4f))
                SliderRow(
                    "Max bubble width",
                    layout.bubbleWidthFraction,
                    { v -> onChange { it.copy(bubbleWidthFraction = (v * 100).roundToInt() / 100f) } },
                    0.55f..0.98f,
                    "${(layout.bubbleWidthFraction * 100).roundToInt()}%",
                )
                HorizontalDivider(color = colors.outline.copy(alpha = 0.4f))
                Column(Modifier.padding(16.dp)) {
                    Text("Alignment", style = AvekTheme.type.body, color = colors.textPrimary)
                    Spacer(Modifier.height(8.dp))
                    SegmentedPicker(UserAlignment.entries, layout.userAlignment, { a -> onChange { it.copy(userAlignment = a) } }, { it.label })
                }
            }
        }

        item { SectionHeader("Answers") }
        item {
            SettingsCard {
                Column(Modifier.padding(16.dp)) {
                    Text("Answer style", style = AvekTheme.type.body, color = colors.textPrimary)
                    Spacer(Modifier.height(8.dp))
                    SegmentedPicker(AssistantStyle.entries, layout.assistantStyle, { s -> onChange { it.copy(assistantStyle = s) } }, { it.label })
                }
                HorizontalDivider(color = colors.outline.copy(alpha = 0.4f))
                SwitchRow("Show avatar", layout.showAvatars, { v -> onChange { it.copy(showAvatars = v) } })
                SwitchRow("Show model & task", layout.showModelBadge, { v -> onChange { it.copy(showModelBadge = v) } })
                SwitchRow("Line numbers in code", layout.codeLineNumbers, { v -> onChange { it.copy(codeLineNumbers = v) } })
            }
        }

        item { SectionHeader("Window") }
        item {
            SettingsCard {
                Column(Modifier.padding(16.dp), horizontalAlignment = Alignment.Start) {
                    Text("Density", style = AvekTheme.type.body, color = colors.textPrimary)
                    Spacer(Modifier.height(8.dp))
                    SegmentedPicker(Density.entries, layout.density, { d -> onChange { it.copy(density = d) } }, { it.label })
                }
                HorizontalDivider(color = colors.outline.copy(alpha = 0.4f))
                SwitchRow("Show timestamps", layout.showTimestamps, { v -> onChange { it.copy(showTimestamps = v) } })
            }
        }
    }
}
