package com.avek.chat.core.markdown

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle

data class SyntaxColors(
    val plain: Color,
    val keyword: Color,
    val string: Color,
    val comment: Color,
    val number: Color,
    val type: Color,
    val annotation: Color,
)

/** Language-agnostic regex highlighter good enough for chat code blocks. */
object SyntaxHighlighter {

    private val keywords = setOf(
        // Kotlin / Java / Swift
        "fun", "val", "var", "class", "object", "interface", "data", "sealed", "enum", "return", "if", "else",
        "when", "for", "while", "do", "try", "catch", "finally", "throw", "import", "package", "private", "public",
        "protected", "internal", "override", "suspend", "inline", "reified", "companion", "init", "this", "super",
        "null", "true", "false", "is", "in", "as", "by", "const", "lateinit", "static", "final", "void", "new",
        "extends", "implements", "abstract", "open", "typealias", "let", "func", "struct", "guard",
        // Python
        "def", "lambda", "from", "with", "yield", "pass", "None", "True", "False", "and", "or", "not", "elif",
        "async", "await", "self", "raise", "except", "global",
        // JS / TS
        "function", "const", "let", "export", "default", "type", "extends", "typeof", "instanceof", "undefined",
        // Rust / Go
        "pub", "mut", "impl", "trait", "match", "loop", "use", "mod", "crate", "go", "chan", "defer", "package",
        // SQL
        "SELECT", "FROM", "WHERE", "GROUP", "BY", "ORDER", "WITH", "AS", "JOIN", "LEFT", "RIGHT", "ON", "LIMIT",
        "COUNT", "DISTINCT", "OVER", "AND", "OR", "NOT", "NULL", "INSERT", "UPDATE", "DELETE", "INTO", "VALUES",
    )

    private val token = Regex(
        """(?<comment>//[^\n]*|#(?!\[)[^\n]*|--[^\n]*|/\*[\s\S]*?\*/)""" +
            """|(?<string>"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*')""" +
            """|(?<annotation>@\w+)""" +
            """|(?<number>\b\d+(?:\.\d+)?[fFLu]?\b)""" +
            """|(?<word>\b[A-Za-z_]\w*\b)""",
    )

    fun highlight(code: String, language: String, colors: SyntaxColors): AnnotatedString = buildAnnotatedString {
        val hashComments = language.lowercase() in setOf("python", "py", "bash", "sh", "shell", "yaml", "ruby", "r", "")
        var last = 0
        for (match in token.findAll(code)) {
            if (match.range.first > last) append(code.substring(last, match.range.first))
            val text = match.value
            val groups = match.groups
            val style = when {
                groups["comment"] != null -> {
                    if (text.startsWith("#") && !hashComments) null
                    else SpanStyle(color = colors.comment, fontStyle = FontStyle.Italic)
                }
                groups["string"] != null -> SpanStyle(color = colors.string)
                groups["annotation"] != null -> SpanStyle(color = colors.annotation)
                groups["number"] != null -> SpanStyle(color = colors.number)
                text in keywords -> SpanStyle(color = colors.keyword, fontWeight = FontWeight.Medium)
                text.first().isUpperCase() && text.length > 1 -> SpanStyle(color = colors.type)
                else -> null
            }
            if (style != null) withStyle(style) { append(text) } else append(text)
            last = match.range.last + 1
        }
        if (last < code.length) append(code.substring(last))
    }
}
