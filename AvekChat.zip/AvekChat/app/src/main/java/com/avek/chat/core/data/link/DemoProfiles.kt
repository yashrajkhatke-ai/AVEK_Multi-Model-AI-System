package com.avek.chat.core.data.link

import com.avek.chat.core.link.rpc.RpcException
import com.avek.chat.core.link.wire.CpuDto
import com.avek.chat.core.link.wire.EstimateDto
import com.avek.chat.core.link.wire.HardwareData
import com.avek.chat.core.link.wire.HardwareGpuDto
import com.avek.chat.core.link.wire.LayersDto
import com.avek.chat.core.link.wire.LoadProfileDto
import com.avek.chat.core.link.wire.MeasuredDto
import com.avek.chat.core.link.wire.ProfileApplyResultDto
import com.avek.chat.core.link.wire.ProfileLimitsDto
import com.avek.chat.core.link.wire.ProfileSaveResultDto
import com.avek.chat.core.link.wire.ProfilesData
import com.avek.chat.core.link.wire.RoutesData
import com.avek.chat.core.link.wire.WifiAddressDto
import com.avek.chat.core.link.wire.WifiRoutesDto
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.intOrNull

/**
 * Demo mode's "Where it runs": two fake profiles per model, clearly marked "Demo", so the sheet can be
 * tried without a PC. Their estimates are labelled as demo data (they are not computed by anything).
 */
class DemoProfiles {
    private val layersTotal = 65
    private val limits = ProfileLimitsDto(minContext = 4096, maxContext = 131_072, maxSlots = 8, cacheTypes = listOf("f16", "q8_0", "q4_0"))

    val hardware = HardwareData(
        rtx = HardwareGpuDto(id = "demo-rtx", name = "Demo RTX", totalMb = 8192, freeMb = 7000),
        igpu = HardwareGpuDto(id = "demo-igpu", name = "Demo iGPU", totalMb = 0, freeMb = 0),
        cpu = CpuDto(threads = 16, ramTotalMb = 16_384, ramFreeMb = 7_200),
    )

    private val byModel = mutableMapOf<String, MutableList<LoadProfileDto>>()
    private val active = mutableMapOf<String, String>()
    private var counter = 0

    fun routes(): RoutesData = RoutesData(wifi = WifiRoutesDto(listOf(WifiAddressDto("Wi-Fi", "demo")), 7810, 7811), updatedAt = null)

    @Synchronized
    private fun profiles(modelId: String): MutableList<LoadProfileDto> = byModel.getOrPut(modelId) {
        mutableListOf(
            LoadProfileDto(
                id = "demo-fast",
                modelId = modelId,
                name = "Demo: Fast",
                builtin = true,
                layers = LayersDto(38, 27, 0),
                contextTokens = 75_000,
                slots = 2,
                cacheType = "q4_0",
                note = "Demo profile: not a real PC.",
                measured = MeasuredDto(decodeTps = 12.4),
                estimate = EstimateDto(verdict = "fits", notes = listOf("Demo data: no real estimate.")),
            ),
            LoadProfileDto(
                id = "demo-cpu",
                modelId = modelId,
                name = "Demo: All on CPU",
                builtin = true,
                layers = LayersDto(0, 0, layersTotal),
                contextTokens = 32_768,
                slots = 1,
                cacheType = "q8_0",
                note = "Demo profile: not a real PC.",
                estimate = EstimateDto(verdict = "unknown", notes = listOf("Demo data: no real estimate.")),
            ),
        ).also { active[modelId] = "demo-fast" }
    }

    @Synchronized
    fun list(modelId: String): ProfilesData {
        val list = profiles(modelId)
        val activeId = active[modelId]
        return ProfilesData(
            modelId = modelId,
            layersTotal = layersTotal,
            activeId = activeId,
            hardware = hardware,
            limits = limits,
            profiles = list.map { it.copy(active = it.id == activeId) },
        )
    }

    @Synchronized
    fun save(args: JsonObject): ProfileSaveResultDto {
        val modelId = args.string("modelId")
        val list = profiles(modelId)
        val name = args.string("name").trim()
        if (name.isEmpty() || name.length > 40) throw RpcException("bad-request", "The name must have 1 to 40 characters.")
        val layers = (args["layers"] as? JsonObject)?.let { LayersDto(it.int("rtx"), it.int("igpu"), it.int("cpu")) } ?: LayersDto()
        if (layers.rtx + layers.igpu + layers.cpu != layersTotal) throw RpcException("bad-request", "The layers must add up to $layersTotal.")
        val id = args.string("id").ifBlank { null }
        val existing = id?.let { i -> list.firstOrNull { it.id == i } }
        if (existing?.builtin == true) throw RpcException("denied", "Built-in profiles cannot be changed.")
        val profile = LoadProfileDto(
            id = existing?.id ?: "demo-own-${++counter}",
            modelId = modelId,
            name = name,
            builtin = false,
            layers = layers,
            contextTokens = (args["contextTokens"] as? JsonPrimitive)?.intOrNull ?: 32_768,
            slots = (args["slots"] as? JsonPrimitive)?.intOrNull ?: 2,
            cacheType = args.string("cacheType").ifBlank { "q4_0" },
            note = args.string("note").ifBlank { null },
            estimate = EstimateDto(verdict = "unknown", notes = listOf("Demo data: no real estimate.")),
        )
        if (existing != null) list[list.indexOf(existing)] = profile else list += profile
        return ProfileSaveResultDto(profile)
    }

    @Synchronized
    fun delete(modelId: String, id: String) {
        val list = profiles(modelId)
        val profile = list.firstOrNull { it.id == id } ?: throw RpcException("not-found", "No such profile.")
        if (profile.builtin) throw RpcException("denied", "Built-in profiles cannot be deleted.")
        list.remove(profile)
        if (active[modelId] == id) active[modelId] = "demo-fast"
    }

    @Synchronized
    fun apply(modelId: String, id: String): ProfileApplyResultDto {
        if (profiles(modelId).none { it.id == id }) throw RpcException("not-found", "No such profile.")
        active[modelId] = id
        return ProfileApplyResultDto(modelId, id, reloading = false)
    }

    private fun JsonObject.string(key: String): String = (this[key] as? JsonPrimitive)?.contentOrNull.orEmpty()
    private fun JsonObject.int(key: String): Int = (this[key] as? JsonPrimitive)?.intOrNull ?: 0
}
