package com.avek.chat.core.domain.repository

import com.avek.chat.core.model.FontCategory
import com.avek.chat.core.model.FontInfo

interface FontCatalogRepository {
    /** All fonts available for download, alphabetically. Cached after the first call. */
    suspend fun all(): List<FontInfo>

    /** A curated short-list shown first in the picker. */
    suspend fun featured(): List<FontInfo>

    suspend fun search(query: String, category: FontCategory?): List<FontInfo>
}
