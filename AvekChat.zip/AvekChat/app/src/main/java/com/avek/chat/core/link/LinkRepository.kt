package com.avek.chat.core.link

import com.avek.chat.core.link.route.ConnectionState
import com.avek.chat.core.link.rpc.ListPart
import com.avek.chat.core.link.rpc.RpcTimeouts
import com.avek.chat.core.link.wire.EmptyArgs
import com.avek.chat.core.link.wire.LinkEvent
import com.avek.chat.core.link.wire.ReadyDto
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject

/** Which event topics the app wants (UI-WIRE sections 8.1 and 13). */
enum class LinkProfile(val topics: List<String>) {
    /** App visible: everything. */
    FOREGROUND(listOf("stream", "turn", "ask", "chats", "models", "downloads")),

    /** App off screen with "Work in background": only what notifications and offline copies need. */
    BACKGROUND(listOf("ask", "turn", "downloads")),
}

/**
 * The one facade the rest of the app uses to talk to the PC (or to the built-in demo).
 * After every connection it subscribes (and resumes when possible) by itself.
 */
interface LinkRepository {
    val state: StateFlow<ConnectionState>

    /** Server events, plus the synthetic [LinkEvent.Refresh] after every (re)connection. */
    val events: SharedFlow<LinkEvent>

    /** Limits and identity from the last `ready`, or null when not connected. */
    val ready: StateFlow<ReadyDto?>

    val profile: StateFlow<LinkProfile>

    /** The app wants a connection (connects now, reconnects with back-off, until [disconnect]). */
    fun connect()

    /** The app does not want a connection: closes it and stops all network activity. */
    fun disconnect()

    fun setProfile(profile: LinkProfile)

    /** Drops the current connection (if any) and starts over with every route, without waiting for back-off. */
    fun reconnect() {
        disconnect()
        connect()
    }

    suspend fun call(op: String, args: JsonObject = EmptyArgs, timeoutMs: Long = RpcTimeouts.forOp(op)): JsonElement

    fun callList(op: String, args: JsonObject = EmptyArgs, timeoutMs: Long = RpcTimeouts.forOp(op)): Flow<ListPart>
}
