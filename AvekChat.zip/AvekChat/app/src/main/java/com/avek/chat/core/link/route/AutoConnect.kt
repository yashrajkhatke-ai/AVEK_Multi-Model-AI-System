package com.avek.chat.core.link.route

import com.avek.chat.core.link.rpc.CloseInfo
import com.avek.chat.core.link.rpc.LiveLink
import com.avek.chat.core.link.store.PairedPc
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

/** Where the link is (UI-WIRE v4 sections 2.3 and 13). */
sealed interface ConnectionState {
    /** Not wanted (off screen without background work, Demo mode, stopped). */
    data object Disconnected : ConnectionState

    /** No PC is paired. [notice] explains why when an old pairing was wiped. */
    data class NeedsPairing(val notice: String? = null) : ConnectionState

    /** Racing the routes. */
    data class Looking(val pcName: String) : ConnectionState

    /** The PC's heavy part is starting (event `waking` before `ready`): "Waking up your PC...". */
    data class WakingPc(val pcName: String) : ConnectionState

    /** [waking]: the PC's heavy part is starting after a request ("Waking up your PC..."); requests are answered later. */
    data class Connected(val pcName: String, val route: RouteKind, val address: String, val waking: Boolean = false) : ConnectionState

    /** Every route failed; the next try is at [retryAtMs] (null = trying now). */
    data class Unreachable(
        val pcName: String,
        val sinceMs: Long,
        val retryAtMs: Long? = null,
        val failures: List<RouteFailure> = emptyList(),
        val lastConnectedAt: Long? = null,
    ) : ConnectionState

    /** The PC does not know this device any more (close 4401 right after a valid knock or route proof). */
    data object Forgotten : ConnectionState

    /** Something only the person can fix (for example: the PC that answered is not the paired one). */
    data class Failed(val reason: String) : ConnectionState
}

/** What a winning race hands over. */
class Won(val link: LiveLink, val route: RouteKind, val credentials: RouteCredentials)

/**
 * The auto-connect loop (section 13): race the routes (section 2.3) → `ready`, then wait for the link
 * to close and start again. Failures wait 2, 4, 8, then 15 s; [kick] cuts a wait short (app opened,
 * network changed, Retry). A 4401 after a valid knock or proof stops the loop ([ConnectionState.Forgotten]);
 * a route whose PC does not prove the pinned key is not retried automatically (only after [kick] with
 * `clearBlocked`).
 *
 * [candidates] are the credentials to try in order (during a key replacement: the new key with
 * `slot:"next"`, then the new key alone); the next one is tried only when the previous one was
 * refused as unknown (4401).
 */
class AutoConnect(
    private val scope: CoroutineScope,
    private val pc: () -> PairedPc?,
    private val mode: () -> RouteMode,
    private val candidates: (PairedPc) -> List<RouteCredentials>,
    private val attempts: (PairedPc, RouteCredentials) -> List<RouteAttempt<LiveLink>>,
    private val describe: (LiveLink) -> String,
    private val onWinner: (Won) -> Unit = {},
    private val onLost: (CloseInfo) -> Unit = {},
    private val nowMs: () -> Long = System::currentTimeMillis,
    private val backoffMs: List<Long> = BACKOFF_MS,
    private val racer: RouteRacer = RouteRacer(),
) {
    private val _state = MutableStateFlow<ConnectionState>(ConnectionState.Disconnected)
    val state: StateFlow<ConnectionState> = _state

    private var job: Job? = null
    private val kicks = Channel<Unit>(Channel.CONFLATED)
    private val blocked = java.util.Collections.synchronizedSet(mutableSetOf<RouteKind>())

    @Volatile
    private var link: LiveLink? = null

    val isRunning: Boolean get() = job?.isActive == true

    @Synchronized
    fun start() {
        if (job?.isActive == true) return
        job = scope.launch { run() }
    }

    @Synchronized
    fun stop() {
        job?.cancel()
        job = null
        val live = link
        link = null
        if (live != null) {
            live.close()
            onLost(CloseInfo(1000, "stopped"))
        }
        _state.value = ConnectionState.Disconnected
    }

    /** Try now: cuts a back-off wait short, or (re)starts a loop that stopped. */
    fun kick(clearBlocked: Boolean = false) {
        if (clearBlocked) blocked.clear()
        if (job?.isActive != true) start() else kicks.trySend(Unit)
    }

    /** Drops the current link (if any) and starts over at once. */
    fun restart(clearBlocked: Boolean = false) {
        stop()
        if (clearBlocked) blocked.clear()
        start()
    }

    private suspend fun run() {
        var failures = 0
        var unreachableSince: Long? = null
        while (true) {
            val paired = pc()
            if (paired == null) {
                _state.value = ConnectionState.NeedsPairing()
                return
            }
            val name = paired.serverName
            _state.value = ConnectionState.Looking(name)
            val options = try {
                candidates(paired)
            } catch (e: Exception) {
                emptyList()
            }
            if (options.isEmpty()) {
                _state.value = ConnectionState.Failed(RouteMessages.GRANT_UNREADABLE)
                return
            }
            val result = try {
                raceAll(paired, options)
            } finally {
                options.forEach { it.wipe() }
            }
            when (result) {
                is RaceResult.Winner -> {
                    failures = 0
                    unreachableSince = null
                    val won = result.connection
                    link = won.link
                    onWinner(won)
                    _state.value = ConnectionState.Connected(name, won.route, describe(won.link))
                    val info = won.link.awaitClosed()
                    link = null
                    onLost(info)
                    if (info.isAuthFailure) {
                        _state.value = ConnectionState.Forgotten
                        return
                    }
                    // Lost while wanted: race the routes again at once.
                }
                is RaceResult.AllFailed -> {
                    val all = result.failures
                    if (all.any { it.fatal == Fatal.Forgotten }) {
                        _state.value = ConnectionState.Forgotten
                        return
                    }
                    all.filter { it.fatal == Fatal.NotOurPc }.forEach { blocked += it.route }
                    val usable = all.filter { it.reason != FailureReason.Skipped }
                    if (usable.isNotEmpty() && usable.all { it.fatal == Fatal.NotOurPc }) {
                        _state.value = ConnectionState.Failed(RouteMessages.NOT_OUR_PC)
                        return
                    }
                    val since = unreachableSince ?: nowMs().also { unreachableSince = it }
                    val wait = backoffMs[minOf(failures, backoffMs.size - 1)]
                    failures++
                    _state.value = ConnectionState.Unreachable(name, since, nowMs() + wait, all, pc()?.lastConnectedAt)
                    while (kicks.tryReceive().isSuccess) Unit
                    withTimeoutOrNull(wait) { kicks.receive() }
                }
            }
        }
    }

    /** One race per credential candidate; the next candidate only after a 4401 everywhere. */
    private suspend fun raceAll(paired: PairedPc, options: List<RouteCredentials>): RaceResult<Won> {
        var last: RaceResult<Won> = RaceResult.AllFailed(emptyList())
        for ((index, credentials) in options.withIndex()) {
            val list = attempts(paired, credentials).map { attempt ->
                if (attempt.kind in blocked) BlockedAttempt(attempt.kind) else attempt
            }
            val result = racer.race(mode(), list.map { WonAttempt(it, credentials) }) { it.link.close() }
            if (result is RaceResult.Winner) return result
            last = result
            val forgotten = (result as RaceResult.AllFailed).failures.any { it.fatal == Fatal.Forgotten }
            if (!forgotten || index == options.lastIndex) return result
        }
        return last
    }

    private class WonAttempt(private val inner: RouteAttempt<LiveLink>, private val credentials: RouteCredentials) : RouteAttempt<Won> {
        override val kind: RouteKind get() = inner.kind
        override fun skipReason(): String? = inner.skipReason()
        override suspend fun connect(): Won = Won(inner.connect(), inner.kind, credentials)
    }

    private class BlockedAttempt(override val kind: RouteKind) : RouteAttempt<LiveLink> {
        override fun skipReason(): String? = null
        override suspend fun connect(): LiveLink =
            throw RouteFailedException(FailureReason.Denied, RouteMessages.NOT_OUR_PC, Fatal.NotOurPc)
    }

    companion object {
        /** "2, 4, 8 s, then every 15 s while the app is visible." */
        val BACKOFF_MS = listOf(2_000L, 4_000L, 8_000L, 15_000L)
    }
}
