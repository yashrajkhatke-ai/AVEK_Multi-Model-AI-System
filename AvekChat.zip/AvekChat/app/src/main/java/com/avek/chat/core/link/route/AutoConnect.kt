package com.avek.chat.core.link.route

import com.avek.chat.core.link.crypto.HandshakeException
import com.avek.chat.core.link.rpc.CloseInfo
import com.avek.chat.core.link.rpc.LinkClosedException
import com.avek.chat.core.link.rpc.LiveLink
import com.avek.chat.core.link.store.PairedPc
import com.avek.chat.core.link.transport.RawChannel
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.withTimeoutOrNull

/** Where the link is (UI-WIRE v3 section 13). */
sealed interface ConnectionState {
    /** Not wanted (off screen without background work, Demo mode, stopped). */
    data object Disconnected : ConnectionState

    /** No PC is paired. [notice] explains why when an old pairing was wiped. */
    data class NeedsPairing(val notice: String? = null) : ConnectionState

    /** Knocking. */
    data class Looking(val pcName: String) : ConnectionState

    /** The PC answered; handshake in progress. */
    data class Connecting(val pcName: String, val address: String) : ConnectionState

    data class Connected(val pcName: String, val address: String) : ConnectionState

    /** Nothing answered (or the connection failed); the next try is at [retryAtMs] (null = trying now). */
    data class Unreachable(val pcName: String, val sinceMs: Long, val retryAtMs: Long? = null) : ConnectionState

    /** The PC does not know this device any more (close 4401 right after a knock). */
    data object Forgotten : ConnectionState

    /** Something only the person can fix (for example: the PC that answered is not the paired one). */
    data class Failed(val reason: String) : ConnectionState
}

/**
 * The auto-connect loop (section 13): knock → WebSocket → session handshake → `ready`, then wait for
 * the link to close and start again. Failures wait 2, 4, 8, then 15 s; [kick] cuts a wait short
 * (app opened, Wi-Fi came back, the person tapped Reconnect). A PC that fails to prove the pinned
 * key, or a 4401 (forgotten device), stops the loop: retrying cannot help.
 */
class AutoConnect(
    private val scope: CoroutineScope,
    private val route: () -> Route,
    private val pc: () -> PairedPc?,
    private val establish: suspend (RawChannel) -> LiveLink,
    private val onWinner: (LiveLink, Reached) -> Unit = { _, _ -> },
    private val onLost: (CloseInfo) -> Unit = {},
    private val nowMs: () -> Long = System::currentTimeMillis,
    private val backoffMs: List<Long> = BACKOFF_MS,
    private val attemptTimeoutMs: Long = ATTEMPT_TIMEOUT_MS,
) {
    private val _state = MutableStateFlow<ConnectionState>(ConnectionState.Disconnected)
    val state: StateFlow<ConnectionState> = _state

    private var job: Job? = null
    private val kicks = Channel<Unit>(Channel.CONFLATED)

    @Volatile
    private var link: LiveLink? = null

    val isRunning: Boolean get() = job?.isActive == true

    @Synchronized
    fun start() {
        if (job?.isActive == true) return
        job = scope.launch { run() }
    }

    @Synchronized
    fun stop() {
        job?.cancel()
        job = null
        val live = link
        link = null
        if (live != null) {
            live.close()
            onLost(CloseInfo(1000, "stopped"))
        }
        _state.value = ConnectionState.Disconnected
    }

    /** Try now: cuts a back-off wait short, or (re)starts a loop that stopped. */
    fun kick() {
        if (job?.isActive != true) start() else kicks.trySend(Unit)
    }

    /** Drops the current link (if any) and starts over at once. */
    fun restart() {
        stop()
        start()
    }

    private suspend fun run() {
        var failures = 0
        var unreachableSince: Long? = null
        while (true) {
            val paired = pc()
            if (paired == null) {
                _state.value = ConnectionState.NeedsPairing()
                return
            }
            val name = paired.serverName
            _state.value = ConnectionState.Looking(name)
            when (val outcome = attempt(paired)) {
                is Outcome.Stop -> {
                    _state.value = outcome.state
                    return
                }
                is Outcome.Connected -> {
                    failures = 0
                    unreachableSince = null
                    link = outcome.link
                    onWinner(outcome.link, outcome.reached)
                    _state.value = ConnectionState.Connected(name, outcome.reached.address)
                    val info = outcome.link.awaitClosed()
                    link = null
                    onLost(info)
                    if (info.isAuthFailure) {
                        _state.value = ConnectionState.Forgotten
                        return
                    }
                    // Lost while wanted: look for the PC again at once.
                }
                Outcome.Failed -> {
                    val since = unreachableSince ?: nowMs().also { unreachableSince = it }
                    val wait = backoffMs[minOf(failures, backoffMs.size - 1)]
                    failures++
                    _state.value = ConnectionState.Unreachable(name, since, nowMs() + wait)
                    while (kicks.tryReceive().isSuccess) Unit
                    withTimeoutOrNull(wait) { kicks.receive() }
                }
            }
        }
    }

    private sealed interface Outcome {
        class Connected(val link: LiveLink, val reached: Reached) : Outcome
        class Stop(val state: ConnectionState) : Outcome
        data object Failed : Outcome
    }

    private suspend fun attempt(paired: PairedPc): Outcome {
        var reached: Reached? = null
        return try {
            withTimeout(attemptTimeoutMs) {
                reached = route().reach(paired) ?: return@withTimeout Outcome.Failed
                val target = reached!!
                _state.value = ConnectionState.Connecting(paired.serverName, target.address)
                Outcome.Connected(establish(target.channel), target)
            }
        } catch (e: TimeoutCancellationException) {
            reached?.channel?.close()
            Outcome.Failed
        } catch (e: CancellationException) {
            reached?.channel?.close()
            throw e
        } catch (e: HandshakeException.NotOurPc) {
            Outcome.Stop(ConnectionState.Failed("This is not the PC you paired with"))
        } catch (e: HandshakeException.Forgotten) {
            Outcome.Stop(ConnectionState.Forgotten)
        } catch (e: LinkClosedException) {
            reached?.channel?.close()
            if (e.info.isAuthFailure) Outcome.Stop(ConnectionState.Forgotten) else Outcome.Failed
        } catch (e: Exception) {
            reached?.channel?.close()
            Outcome.Failed
        }
    }

    companion object {
        val BACKOFF_MS = listOf(2_000L, 4_000L, 8_000L, 15_000L)

        /** Knock (about 5 s at most), WebSocket, handshake (10 s) and `ready`. */
        const val ATTEMPT_TIMEOUT_MS = 25_000L
    }
}
