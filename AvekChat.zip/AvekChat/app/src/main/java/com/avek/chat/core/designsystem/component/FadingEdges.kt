package com.avek.chat.core.designsystem.component

import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Fades scrolling content into whatever is behind it instead of clipping it
 * with a hard line — the same effect as CSS `mask-image: linear-gradient(...)`
 * that chat apps use under their headers.
 *
 * Content is drawn into an offscreen layer, then an alpha gradient is applied
 * with [BlendMode.DstIn]: where the mask is transparent the content disappears,
 * revealing the real background; where it is opaque the content is untouched.
 *
 * @param topHidden band at the very top where content is fully invisible
 *   (e.g. under the status bar and top app bar icons).
 * @param topFade length of the soft ramp after [topHidden].
 * @param bottomFade soft ramp at the bottom edge (e.g. above the composer).
 */
fun Modifier.fadingEdges(
    topHidden: Dp = 0.dp,
    topFade: Dp = 0.dp,
    bottomFade: Dp = 0.dp,
): Modifier = this
    .graphicsLayer(compositingStrategy = CompositingStrategy.Offscreen)
    .drawWithContent {
        drawContent()
        val h = size.height
        if (h <= 0f) return@drawWithContent
        val hidden = (topHidden.toPx() / h).coerceIn(0f, 1f)
        val fadeEnd = ((topHidden + topFade).toPx() / h).coerceIn(hidden, 1f)
        val bottomStart = (1f - bottomFade.toPx() / h).coerceIn(fadeEnd, 1f)
        // An eased ramp (more stops) reads smoother than a straight linear fade.
        val stops = buildList {
            add(0f to Color.Transparent)
            if (hidden > 0f) add(hidden to Color.Transparent)
            val ramp = fadeEnd - hidden
            if (ramp > 0f) {
                listOf(0.25f to 0.08f, 0.5f to 0.32f, 0.75f to 0.7f).forEach { (t, a) ->
                    add(hidden + ramp * t to Color.Black.copy(alpha = a))
                }
            }
            add(fadeEnd to Color.Black)
            add(bottomStart to Color.Black)
            add(1f to if (bottomFade > 0.dp) Color.Transparent else Color.Black)
        }
        drawRect(Brush.verticalGradient(*stops.toTypedArray()), blendMode = BlendMode.DstIn)
    }
