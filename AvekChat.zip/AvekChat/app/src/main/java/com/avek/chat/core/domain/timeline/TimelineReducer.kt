package com.avek.chat.core.domain.timeline

import com.avek.chat.core.link.rpc.TextAssembler
import com.avek.chat.core.link.wire.LinkEvent
import com.avek.chat.core.link.wire.TimelineBlockDto
import com.avek.chat.core.link.wire.TimelineDto

/**
 * Pure reducer of a turn's timeline (UI-WIRE section 9a). Idempotent: a `block.start` of a known id
 * is ignored, deltas follow the offset rule per block and channel, a state never moves back, and
 * `block.end` is final (a later `block.title` may still change the heading).
 */
object TimelineReducer {

    fun reduce(state: TurnTimeline, event: LinkEvent): TurnTimeline = when (event) {
        is LinkEvent.TurnStarted -> if (matches(state, event.data.chatId, event.data.promptId)) state.copy(live = true) else state
        is LinkEvent.TurnCompleted -> if (matches(state, event.data.chatId, event.data.promptId)) state.copy(live = false) else state
        is LinkEvent.TurnCancelled -> if (matches(state, event.data.chatId, event.data.promptId)) endAll(state, "cancelled") else state
        is LinkEvent.TurnFailed -> if (matches(state, event.data.chatId, event.data.promptId)) endAll(state, "error") else state
        is LinkEvent.BlockStart -> {
            val d = event.data
            if (!matches(state, d.chatId, d.promptId) || d.id in state.blocks) state
            else state.copy(
                blocks = state.blocks + (d.id to TimelineBlock(
                    id = d.id, parentId = d.parent, kind = d.kind, state = d.state, title = d.title, t0 = d.t.takeIf { it > 0 },
                    step = d.step, tool = d.tool, agent = d.agent, from = d.from,
                )),
                order = state.order + d.id,
                unknown = state.unknown - d.id,
                live = true,
            )
        }
        is LinkEvent.BlockTitle -> {
            val d = event.data
            if (!matches(state, d.chatId, d.promptId)) state
            else update(state, d.id) { it.copy(title = d.title.ifEmpty { it.title }, tool = d.tool ?: it.tool) }
        }
        is LinkEvent.BlockDelta -> {
            val d = event.data
            if (!matches(state, d.chatId, d.promptId)) state
            else update(state, d.id) { block ->
                if (block.needsReload) return@update block
                if (d.channel == "args") {
                    val merged = TextAssembler.merge(block.args, d.offset, d.text)
                    if (merged == null) block.copy(needsReload = true) else block.copy(args = merged)
                } else {
                    val merged = TextAssembler.merge(block.text, d.offset, d.text)
                    if (merged == null) block.copy(needsReload = true) else block.copy(text = merged)
                }
            }
        }
        is LinkEvent.BlockState -> {
            val d = event.data
            if (!matches(state, d.chatId, d.promptId)) state
            else update(state, d.id) { block ->
                if (block.ended || rank(block.kind, d.state) < rank(block.kind, block.state)) block
                else block.copy(state = d.state, detail = d.detail ?: block.detail, title = d.title ?: block.title)
            }
        }
        is LinkEvent.BlockEnd -> {
            val d = event.data
            if (!matches(state, d.chatId, d.promptId)) state
            else update(state, d.id) { block ->
                if (block.ended) block.copy(title = d.title ?: block.title)
                else block.copy(
                    state = d.state, ended = true, title = d.title ?: block.title, ms = d.ms ?: block.ms,
                    summary = d.summary ?: block.summary, ok = d.ok ?: block.ok, tokens = d.tokens ?: block.tokens,
                    to = d.to ?: block.to, t1 = d.t.takeIf { it > 0 } ?: block.t1,
                )
            }
        }
        else -> state
    }

    /** A `timeline.get` answer replaces what it covers; live events continue on top of it. */
    fun reduce(state: TurnTimeline, dto: TimelineDto): TurnTimeline {
        var blocks = state.blocks
        val order = state.order.toMutableList()
        for (item in dto.items) {
            val previous = blocks[item.id]
            blocks = blocks + (item.id to fromDto(item, previous))
            if (item.id !in order) order += item.id
        }
        // Start order (stable: blocks that started in the same millisecond keep the order they came in).
        val sorted = order.sortedBy { blocks[it]?.t0 ?: Long.MAX_VALUE }
        return state.copy(
            blocks = blocks,
            order = sorted,
            unknown = state.unknown - dto.items.map { it.id }.toSet(),
            live = dto.live ?: state.live,
            dropped = dto.dropped ?: state.dropped,
        )
    }

    /** The outline of a saved turn (headings, states, sizes; no texts). */
    fun outline(state: TurnTimeline, outline: List<TimelineBlockDto>): TurnTimeline =
        reduce(state.copy(live = false), TimelineDto(items = outline, live = false))

    // ------------------------------------------------------------------ helpers

    private fun fromDto(item: TimelineBlockDto, previous: TimelineBlock?): TimelineBlock {
        val hasTexts = item.text != null || item.args != null
        // A live block keeps the longer text it already streamed; a fetch fills what was missing.
        val text = listOfNotNull(item.text, previous?.text).maxByOrNull { it.length }.orEmpty()
        val args = listOfNotNull(item.args, previous?.args).maxByOrNull { it.length }.orEmpty()
        val ended = item.state in FINAL || previous?.ended == true
        return TimelineBlock(
            id = item.id,
            parentId = item.parent,
            kind = item.kind,
            state = if (previous != null && previous.ended && item.state !in FINAL) previous.state else item.state,
            title = item.title.ifEmpty { previous?.title.orEmpty() },
            t0 = item.t0 ?: previous?.t0,
            t1 = item.t1 ?: previous?.t1,
            ms = item.ms ?: previous?.ms,
            step = item.step ?: previous?.step,
            tool = item.tool ?: previous?.tool,
            agent = item.agent ?: previous?.agent,
            from = item.from ?: previous?.from,
            to = item.to ?: previous?.to,
            summary = item.summary ?: previous?.summary,
            tokens = item.tokens ?: previous?.tokens,
            ok = item.ok ?: previous?.ok,
            detail = item.detail ?: previous?.detail,
            text = text,
            args = args,
            textChars = item.textChars ?: previous?.textChars,
            argsChars = item.argsChars ?: previous?.argsChars,
            truncated = item.truncated || previous?.truncated == true,
            ended = ended,
            needsReload = false,
            textLoaded = hasTexts || (previous?.textLoaded == true && previous.text.isNotEmpty()) || ((item.textChars ?: 0) == 0 && (item.argsChars ?: 0) == 0),
        )
    }

    private fun update(state: TurnTimeline, id: String, transform: (TimelineBlock) -> TimelineBlock): TurnTimeline {
        val block = state.blocks[id] ?: return if (id in state.unknown) state else state.copy(unknown = state.unknown + id)
        val next = transform(block)
        return if (next == block) state else state.copy(blocks = state.blocks + (id to next))
    }

    private fun endAll(state: TurnTimeline, final: String): TurnTimeline = state.copy(
        live = false,
        blocks = state.blocks.mapValues { (_, b) -> if (b.ended) b else b.copy(state = final, ended = true) },
    )

    private fun matches(state: TurnTimeline, chatId: String, promptId: String) = state.key.chatId == chatId && state.key.promptId == promptId

    private val FINAL = setOf("done", "error", "cancelled")

    /** Position of a state in a block's life; a block never moves back. */
    fun rank(kind: String, state: String): Int = when (state) {
        "done", "error", "cancelled" -> 9
        "running" -> if (kind == BlockKind.TOOL) 2 else 1
        "writing", "waiting" -> 1
        "working" -> 2
        else -> 0
    }
}
