package com.avek.chat.feature.chat.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.avek.chat.core.designsystem.icon.icon
import com.avek.chat.core.designsystem.motion.DepthDots
import com.avek.chat.core.designsystem.theme.AvekTheme
import com.avek.chat.core.model.AiModel
import com.avek.chat.core.model.TaskMode

@Composable
fun ModelPickerSheet(
    models: List<AiModel>,
    selectedId: String,
    onSelect: (AiModel) -> Unit,
    onDismiss: () -> Unit,
) {
    val colors = AvekTheme.colors
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = colors.chatBackground,
        scrimColor = colors.scrim,
    ) {
        Text(
            "Choose a model",
            style = AvekTheme.type.headline,
            color = colors.textPrimary,
            modifier = Modifier.padding(horizontal = 20.dp),
        )
        Text(
            "All models are simulated in this build — responses are generated locally.",
            style = AvekTheme.type.bodySmall,
            color = colors.textSecondary,
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp),
        )
        Spacer(Modifier.height(8.dp))
        LazyColumn(
            Modifier.navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 24.dp),
        ) {
            items(models, key = { it.id }) { model ->
                ModelCard(model, selected = model.id == selectedId) { onSelect(model) }
            }
        }
    }
}

@Composable
private fun ModelCard(model: AiModel, selected: Boolean, onClick: () -> Unit) {
    val colors = AvekTheme.colors
    val border by animateColorAsState(if (selected) colors.accent else colors.outline.copy(alpha = 0.7f), label = "model-border")
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(if (selected) colors.accentContainer else colors.surface)
            .border(if (selected) 1.5.dp else 1.dp, border, RoundedCornerShape(20.dp))
            .clickable(onClick = onClick)
            .padding(16.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(model.displayName, style = AvekTheme.type.title, color = colors.textPrimary)
            if (model.badge != null) {
                Spacer(Modifier.width(8.dp))
                Text(
                    model.badge,
                    style = AvekTheme.type.caption.copy(fontWeight = FontWeight.SemiBold),
                    color = colors.accent,
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .background(colors.accentContainer)
                        .padding(horizontal = 8.dp, vertical = 2.dp),
                )
            }
            Spacer(Modifier.weight(1f))
            if (selected) Icon(Icons.Filled.CheckCircle, contentDescription = "Selected", tint = colors.accent)
        }
        Spacer(Modifier.height(2.dp))
        Text(model.tagline, style = AvekTheme.type.body, color = colors.textSecondary)
        AnimatedVisibility(selected) {
            Text(model.description, style = AvekTheme.type.bodySmall, color = colors.textSecondary, modifier = Modifier.padding(top = 6.dp))
        }
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
            Stat("Intelligence", model.intelligence)
            Stat("Speed", model.speed)
            Column {
                MetaLabel("Thinking")
                Spacer(Modifier.height(5.dp))
                DepthDots(model.maxDepth, colors.thinkingGlow)
            }
        }
        Spacer(Modifier.height(10.dp))
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Tag(model.contextLabel)
            model.strengths.forEach { task ->
                Row(
                    Modifier
                        .clip(RoundedCornerShape(50))
                        .background(colors.textPrimary.copy(alpha = 0.05f))
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(task.icon, null, tint = colors.textSecondary, modifier = Modifier.size(12.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(task.label, style = AvekTheme.type.caption, color = colors.textSecondary)
                }
            }
        }
    }
}

@Composable
private fun Stat(label: String, value: Int) {
    val colors = AvekTheme.colors
    Column {
        MetaLabel(label)
        Spacer(Modifier.height(5.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
            repeat(5) { i ->
                Box(
                    Modifier
                        .size(width = 10.dp, height = 8.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (i < value) colors.accent else colors.accent.copy(alpha = 0.18f)),
                )
            }
        }
    }
}

@Composable
private fun Tag(text: String) {
    Text(
        text,
        style = AvekTheme.type.caption,
        color = AvekTheme.colors.textSecondary,
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(AvekTheme.colors.textPrimary.copy(alpha = 0.05f))
            .padding(horizontal = 8.dp, vertical = 4.dp),
    )
}

@Composable
fun TaskPickerSheet(
    selected: TaskMode,
    detected: TaskMode?,
    onSelect: (TaskMode) -> Unit,
    onDismiss: () -> Unit,
) {
    val colors = AvekTheme.colors
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = colors.chatBackground,
        scrimColor = colors.scrim,
    ) {
        Column(
            Modifier
                .navigationBarsPadding()
                .padding(horizontal = 16.dp)
                .padding(bottom = 24.dp),
        ) {
            Text("What are we doing?", style = AvekTheme.type.headline, color = colors.textPrimary, modifier = Modifier.padding(horizontal = 4.dp))
            Spacer(Modifier.height(12.dp))

            // Auto gets a hero card explaining routing.
            val autoSelected = selected == TaskMode.AUTO
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(if (autoSelected) colors.accentContainer else colors.surface)
                    .border(if (autoSelected) 1.5.dp else 1.dp, if (autoSelected) colors.accent else colors.outline, RoundedCornerShape(20.dp))
                    .clickable { onSelect(TaskMode.AUTO) }
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(
                    Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(colors.accent),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(TaskMode.AUTO.icon, null, tint = colors.onAccent)
                }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text("Auto", style = AvekTheme.type.title, color = colors.textPrimary)
                    Text(TaskMode.AUTO.tagline, style = AvekTheme.type.bodySmall, color = colors.textSecondary)
                    if (detected != null) {
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "Your draft looks like: ${detected.label}",
                            style = AvekTheme.type.caption.copy(fontWeight = FontWeight.Medium),
                            color = colors.accent,
                        )
                    }
                }
                if (autoSelected) Icon(Icons.Filled.CheckCircle, null, tint = colors.accent)
            }

            Spacer(Modifier.height(12.dp))
            TaskMode.concrete.chunked(2).forEach { row ->
                Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    row.forEach { task ->
                        TaskCard(task, selected = task == selected, highlighted = task == detected, modifier = Modifier.weight(1f)) { onSelect(task) }
                    }
                    if (row.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
private fun TaskCard(task: TaskMode, selected: Boolean, highlighted: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val colors = AvekTheme.colors
    Column(
        modifier
            .clip(RoundedCornerShape(18.dp))
            .background(if (selected) colors.accentContainer else colors.surface)
            .border(
                if (selected) 1.5.dp else 1.dp,
                when {
                    selected -> colors.accent
                    highlighted -> colors.accent.copy(alpha = 0.4f)
                    else -> colors.outline
                },
                RoundedCornerShape(18.dp),
            )
            .clickable(onClick = onClick)
            .padding(14.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(task.icon, null, tint = if (selected) colors.accent else colors.textPrimary, modifier = Modifier.size(22.dp))
            Spacer(Modifier.weight(1f))
            if (highlighted && !selected) {
                Box(Modifier.size(8.dp).clip(CircleShape).background(colors.accent))
            }
        }
        Spacer(Modifier.height(10.dp))
        Text(task.label, style = AvekTheme.type.body.copy(fontWeight = FontWeight.SemiBold), color = colors.textPrimary)
        Text(task.tagline, style = AvekTheme.type.caption, color = colors.textSecondary, minLines = 2, maxLines = 2)
    }
}

