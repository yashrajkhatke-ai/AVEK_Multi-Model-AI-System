package com.avek.chat.feature.chat.components

import androidx.compose.animation.AnimatedVisibility
import com.avek.chat.core.designsystem.theme.avekShape
import com.avek.chat.core.designsystem.theme.avekPill
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.avek.chat.core.designsystem.icon.icon
import com.avek.chat.core.designsystem.theme.AvekTheme
import com.avek.chat.core.domain.lists.ModelPickerState
import com.avek.chat.core.model.RemoteModel
import com.avek.chat.core.model.TaskMode

/**
 * The model sheet: opens at once with skeleton cards and fills one card per part as the PC's
 * `models.list {limit:"all"}` parts arrive. Every card uses the same template ([ModelCard]).
 */
@Composable
fun ModelPickerSheet(
    state: ModelPickerState,
    selectedId: String?,
    pcName: String?,
    onSelect: (RemoteModel) -> Unit,
    onRetry: () -> Unit,
    onDismiss: () -> Unit,
) {
    val colors = AvekTheme.colors
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = colors.chatBackground,
        scrimColor = colors.scrim,
    ) {
        ModelPickerContent(state, selectedId, pcName, onSelect, onRetry)
    }
}

/** The body of the model sheet (also rendered on its own in previews). */
@Composable
fun ModelPickerContent(
    state: ModelPickerState,
    selectedId: String?,
    pcName: String?,
    onSelect: (RemoteModel) -> Unit,
    onRetry: () -> Unit,
) {
    val colors = AvekTheme.colors
    Column {
        Text(
            "Choose a model",
            style = AvekTheme.type.display,
            color = colors.textPrimary,
            modifier = Modifier.padding(horizontal = 20.dp),
        )
        Text(
            if (pcName != null) "Models on $pcName" else "Models on your PC",
            style = AvekTheme.type.body,
            color = colors.textSecondary,
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp),
        )
        Spacer(Modifier.height(8.dp))
        LazyColumn(
            Modifier.navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 24.dp),
        ) {
            items(state.models, key = { it.id }) { model ->
                ModelCard(model, selected = model.id == selectedId, onClick = { onSelect(model) })
            }
            if (state.loading) {
                items(if (state.models.isEmpty()) 3 else 1, key = { "skeleton-$it" }) { SkeletonModelCard() }
            }
            if (state.error != null && state.models.isEmpty()) {
                item(key = "error") {
                    Column(Modifier.padding(horizontal = 4.dp)) {
                        Text(state.error, style = AvekTheme.type.body, color = colors.textSecondary)
                        TextButton(onClick = onRetry) { Text("Try again", color = colors.accent) }
                    }
                }
            } else if (!state.loading && state.models.isEmpty()) {
                item(key = "empty") {
                    Text("No model is ready on the PC.", style = AvekTheme.type.body, color = colors.textSecondary, modifier = Modifier.padding(horizontal = 4.dp))
                }
            }
        }
    }
}

/** A grey stand-in shown while models are still arriving (same shape as a card). */
@Composable
private fun SkeletonModelCard() {
    val colors = AvekTheme.colors
    val bar = colors.outline.copy(alpha = 0.35f)
    Column(
        Modifier
            .fillMaxWidth()
            .clip(avekShape(20.dp))
            .background(colors.surface)
            .border(1.dp, colors.outline.copy(alpha = 0.4f), avekShape(20.dp))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Box(Modifier.fillMaxWidth(0.45f).height(20.dp).clip(avekShape(6.dp)).background(bar))
        Box(Modifier.fillMaxWidth(0.7f).height(14.dp).clip(avekShape(6.dp)).background(bar))
        Row(horizontalArrangement = Arrangement.spacedBy(28.dp)) {
            repeat(3) { Box(Modifier.width(90.dp).height(30.dp).clip(avekShape(6.dp)).background(bar)) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            repeat(3) { Box(Modifier.width(84.dp).height(28.dp).clip(avekPill()).background(bar)) }
        }
    }
}

@Composable
private fun Tag(text: String) {
    Text(
        text,
        style = AvekTheme.type.caption,
        color = AvekTheme.colors.textSecondary,
        modifier = Modifier
            .clip(avekPill())
            .background(AvekTheme.colors.textPrimary.copy(alpha = 0.05f))
            .padding(horizontal = 8.dp, vertical = 4.dp),
    )
}

@Composable
fun TaskPickerSheet(
    selected: TaskMode,
    onSelect: (TaskMode) -> Unit,
    onDismiss: () -> Unit,
) {
    val colors = AvekTheme.colors
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = colors.chatBackground,
        scrimColor = colors.scrim,
    ) {
        Column(
            Modifier
                .navigationBarsPadding()
                .padding(horizontal = 16.dp)
                .padding(bottom = 24.dp),
        ) {
            Text("What are we doing?", style = AvekTheme.type.headline, color = colors.textPrimary, modifier = Modifier.padding(horizontal = 4.dp))
            Spacer(Modifier.height(12.dp))

            // Auto gets a hero card explaining routing.
            val autoSelected = selected == TaskMode.AUTO
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(avekShape(20.dp))
                    .background(if (autoSelected) colors.accentContainer else colors.surface)
                    .border(if (autoSelected) 1.5.dp else 1.dp, if (autoSelected) colors.accent else colors.outline, avekShape(20.dp))
                    .clickable { onSelect(TaskMode.AUTO) }
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(
                    Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(colors.accent),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(TaskMode.AUTO.icon, null, tint = colors.onAccent)
                }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text("Auto", style = AvekTheme.type.title, color = colors.textPrimary)
                    Text(TaskMode.AUTO.tagline, style = AvekTheme.type.bodySmall, color = colors.textSecondary)
                }
                if (autoSelected) Icon(Icons.Filled.CheckCircle, null, tint = colors.accent)
            }

            Spacer(Modifier.height(12.dp))
            TaskMode.concrete.chunked(2).forEach { row ->
                Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    row.forEach { task ->
                        TaskCard(task, selected = task == selected, modifier = Modifier.weight(1f)) { onSelect(task) }
                    }
                    if (row.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
private fun TaskCard(task: TaskMode, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val colors = AvekTheme.colors
    Column(
        modifier
            .clip(avekShape(18.dp))
            .background(if (selected) colors.accentContainer else colors.surface)
            .border(if (selected) 1.5.dp else 1.dp, if (selected) colors.accent else colors.outline, avekShape(18.dp))
            .clickable(onClick = onClick)
            .padding(14.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(task.icon, null, tint = if (selected) colors.accent else colors.textPrimary, modifier = Modifier.size(22.dp))
            Spacer(Modifier.weight(1f))
        }
        Spacer(Modifier.height(10.dp))
        Text(task.label, style = AvekTheme.type.body.copy(fontWeight = FontWeight.SemiBold), color = colors.textPrimary)
        Text(task.tagline, style = AvekTheme.type.caption, color = colors.textSecondary, minLines = 2, maxLines = 2)
    }
}

