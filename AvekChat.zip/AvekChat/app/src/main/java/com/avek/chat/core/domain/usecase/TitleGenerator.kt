package com.avek.chat.core.domain.usecase

import javax.inject.Inject

/** Produces a short, human-looking conversation title from the first prompt. */
class TitleGenerator @Inject constructor() {

    private val fillerPrefixes = listOf(
        "hey there", "hi there", "hello", "hey", "hi", "please", "pls", "can you please", "could you please",
        "can you", "could you", "would you", "will you", "i want you to", "i need you to", "i'd like you to",
        "i would like you to", "help me", "i need help with", "i need", "i want", "tell me",
    )

    fun generate(prompt: String): String {
        var text = prompt
            .replace(Regex("```[\\s\\S]*?```"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
        val firstSentence = text.split(Regex("(?<=[.!?])\\s|\\n")).firstOrNull { it.isNotBlank() } ?: text
        text = firstSentence.trim()

        var changed = true
        while (changed) {
            changed = false
            for (prefix in fillerPrefixes) {
                val lower = text.lowercase().trimEnd('.', '!', '?', ',')
                if (lower == prefix) {
                    text = ""
                    changed = false
                    break
                }
                if (lower.startsWith("$prefix ") || lower.startsWith("$prefix,")) {
                    text = text.substring(prefix.length).trimStart(' ', ',')
                    changed = true
                }
            }
        }

        val words = text.trim().trimEnd('.', '!', '?', ',', ':', ';').split(' ').filter { it.isNotBlank() }
        if (words.isEmpty()) return DEFAULT_TITLE
        val title = words.take(MAX_WORDS).joinToString(" ")
            .replaceFirstChar { it.titlecase() }
        return if (title.length > MAX_CHARS) title.take(MAX_CHARS - 1).trimEnd() + "…" else title
    }

    companion object {
        const val DEFAULT_TITLE = "New conversation"
        private const val MAX_WORDS = 7
        private const val MAX_CHARS = 48
    }
}
