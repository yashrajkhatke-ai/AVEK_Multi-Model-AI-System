package com.avek.chat.core.link

import com.avek.chat.core.link.route.RouteKind

/**
 * What only the real link can do with the grant: replace the device's keys (section 4.1) and
 * forget the PC. The pairing screen and these two are the only places that touch the vault.
 */
interface PcControl {
    /** The route of the live connection, or null. */
    val currentRoute: RouteKind?

    suspend fun replaceKeys(): RekeyOutcome

    /** Tells the PC (`device.unpair`) when connected, then deletes the keys, the sealed secrets and the stored PC. */
    suspend fun forget()
}
