package com.avek.chat.core.designsystem.motion

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import com.avek.chat.core.model.settings.EntranceAnimation

/**
 * Plays a one-shot entrance animation the first time the element is composed.
 * Pass `enabled = false` for items that were already on screen (e.g. history).
 */
fun Modifier.entrance(style: EntranceAnimation, enabled: Boolean, fromEnd: Boolean = false): Modifier = composed {
    if (!enabled || style == EntranceAnimation.NONE) return@composed this
    val progress = remember { Animatable(0f) }
    val distance = with(LocalDensity.current) { 28.dp.toPx() }
    LaunchedEffect(Unit) {
        progress.animateTo(1f, spring(dampingRatio = 0.82f, stiffness = Spring.StiffnessMediumLow))
    }
    graphicsLayer {
        val p = progress.value
        alpha = p.coerceIn(0f, 1f)
        when (style) {
            EntranceAnimation.FADE, EntranceAnimation.NONE -> Unit
            EntranceAnimation.RISE -> translationY = (1f - p) * distance
            EntranceAnimation.SCALE -> {
                transformOrigin = TransformOrigin(if (fromEnd) 1f else 0f, 1f)
                scaleX = 0.9f + 0.1f * p
                scaleY = 0.9f + 0.1f * p
            }
            EntranceAnimation.SLIDE -> translationX = (1f - p) * distance * (if (fromEnd) 1.5f else -1.5f)
        }
    }
}
