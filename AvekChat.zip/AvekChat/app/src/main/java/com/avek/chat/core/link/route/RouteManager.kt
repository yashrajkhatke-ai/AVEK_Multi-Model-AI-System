package com.avek.chat.core.link.route

import com.avek.chat.core.link.rpc.CloseInfo
import com.avek.chat.core.link.rpc.LiveLink
import com.avek.chat.core.link.transport.RawChannel
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeout
import java.util.concurrent.atomic.AtomicInteger

sealed interface ConnectionState {
    /** Not wanted (app in the background without background mode, demo mode, user disconnected). */
    data object Disconnected : ConnectionState

    /** No PC is paired: nothing to connect to. */
    data object NotPaired : ConnectionState

    /** Trying. [tried] lists route kinds ("last", "discover", "host", ...); [retryInMs] is set while waiting between attempts. */
    data class Connecting(val tried: List<String>, val attempt: Int, val retryInMs: Long? = null) : ConnectionState {
        /** "last, discover, 2 hosts" */
        val summary: String
            get() = tried.groupingBy { it }.eachCount().entries.joinToString(", ") { (kind, n) ->
                if (kind == "host" && n > 1) "$n hosts" else if (kind == "host") "host" else kind
            }
    }

    data class Connected(val routeName: String, val serverName: String) : ConnectionState

    /** Fatal: retrying cannot help until the person acts (revoked, unknown device, wrong secret). */
    data class Failed(val reason: String) : ConnectionState
}

/**
 * Runs all routes in parallel (route i starts i * [staggerMs] after the first); the first one that
 * completes the handshake AND receives `ready` wins and the rest are cancelled and closed.
 * When everything fails it waits 1, 2, 4, 8, then 15 s repeatedly (UI-WIRE section 13, "Routes").
 */
class RouteManager(
    private val scope: CoroutineScope,
    private val routes: () -> List<Route>,
    private val establish: suspend (RawChannel, Route) -> LiveLink,
    private val onWinner: (LiveLink, Route) -> Unit = { _, _ -> },
    private val onLost: (CloseInfo) -> Unit = {},
    private val fatalReason: (Throwable) -> String? = { null },
    private val staggerMs: Long = STAGGER_MS,
    private val attemptTimeoutMs: Long = ATTEMPT_TIMEOUT_MS,
    private val backoffMs: List<Long> = BACKOFF_MS,
) {
    private class Winner(val route: Route, val link: LiveLink)

    private val _state = MutableStateFlow<ConnectionState>(ConnectionState.Disconnected)
    val state: StateFlow<ConnectionState> = _state

    private var job: Job? = null

    @Volatile
    private var link: LiveLink? = null

    @Synchronized
    fun start() {
        if (job?.isActive == true) return
        job = scope.launch { run() }
    }

    @Synchronized
    fun stop() {
        job?.cancel()
        job = null
        val live = link
        link = null
        if (live != null) {
            live.close()
            onLost(CloseInfo(1000, "stopped"))
        }
        _state.value = ConnectionState.Disconnected
    }

    /** Closes the current link (if any) so the loop reconnects; used when routes or credentials change. */
    fun restart() {
        stop()
        start()
    }

    private suspend fun run() {
        var failures = 0
        while (true) {
            val candidates = routes()
            val kinds = candidates.map { it.kind }
            if (candidates.isEmpty()) {
                _state.value = ConnectionState.Failed("No routes configured")
                return
            }
            _state.value = ConnectionState.Connecting(kinds, failures + 1)

            val outcome = attempt(candidates)
            if (outcome is Attempt.Fatal) {
                _state.value = ConnectionState.Failed(outcome.reason)
                return
            }
            if (outcome is Attempt.Success) {
                failures = 0
                val winner = outcome.winner
                link = winner.link
                onWinner(winner.link, winner.route)
                _state.value = ConnectionState.Connected(winner.route.label, winner.link.serverName)
                val info = winner.link.awaitClosed()
                link = null
                onLost(info)
                if (info.isAuthFailure) {
                    _state.value = ConnectionState.Failed("This device is not authorised on the PC any more. Pair again.")
                    return
                }
                val wait = backoffMs.first()
                _state.value = ConnectionState.Connecting(kinds, 1, retryInMs = wait)
                delay(wait)
            } else {
                val wait = backoffMs[minOf(failures, backoffMs.size - 1)]
                failures++
                _state.value = ConnectionState.Connecting(kinds, failures, retryInMs = wait)
                delay(wait)
            }
        }
    }

    private sealed interface Attempt {
        class Success(val winner: Winner) : Attempt
        class Fatal(val reason: String) : Attempt
        data object AllFailed : Attempt
    }

    private suspend fun attempt(candidates: List<Route>): Attempt = coroutineScope {
        val result = CompletableDeferred<Attempt>()
        val remaining = AtomicInteger(candidates.size)

        val jobs = candidates.mapIndexed { index, route ->
            launch {
                var channel: RawChannel? = null
                var won = false
                try {
                    delay(index * staggerMs)
                    val established = withTimeout(attemptTimeoutMs) {
                        val opened = route.open()
                        channel = opened
                        establish(opened, route)
                    }
                    if (result.complete(Attempt.Success(Winner(route, established)))) {
                        won = true
                    } else {
                        established.close() // lost the race
                    }
                } catch (e: TimeoutCancellationException) {
                    // withTimeout's exception is a CancellationException, but here it means "this route took too long".
                    if (remaining.decrementAndGet() == 0) result.complete(Attempt.AllFailed)
                } catch (e: CancellationException) {
                    throw e // cancelled because another route won
                } catch (e: Throwable) {
                    fatalReason(e)?.let { result.complete(Attempt.Fatal(it)) }
                    if (remaining.decrementAndGet() == 0) result.complete(Attempt.AllFailed)
                } finally {
                    if (!won) channel?.close()
                }
            }
        }
        val outcome = result.await()
        jobs.forEach { it.cancel() }
        outcome
    }

    companion object {
        const val STAGGER_MS = 200L
        const val ATTEMPT_TIMEOUT_MS = 12_000L
        val BACKOFF_MS = listOf(1_000L, 2_000L, 4_000L, 8_000L, 15_000L)
    }
}
