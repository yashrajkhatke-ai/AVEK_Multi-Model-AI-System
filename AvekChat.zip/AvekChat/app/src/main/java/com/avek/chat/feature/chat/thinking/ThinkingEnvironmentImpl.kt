package com.avek.chat.feature.chat.thinking

import com.avek.chat.core.domain.repository.SettingsRepository
import com.avek.chat.core.domain.trace.TraceRepository
import com.avek.chat.core.domain.trace.TurnKey
import com.avek.chat.core.domain.trace.TurnTelemetry
import com.avek.chat.core.link.wire.TraceRuntimeDto
import com.avek.chat.core.model.settings.ThinkingSettings
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/** The thinking block's data and choices, backed by the [TraceRepository] and the user settings. */
class ThinkingEnvironmentImpl(
    private val traces: TraceRepository,
    private val settingsRepository: SettingsRepository,
    private val scope: CoroutineScope,
    private val demoMode: () -> Boolean,
) : ThinkingEnvironment {

    override val settings: StateFlow<ThinkingSettings> =
        settingsRepository.settings.map { it.thinking }.stateIn(scope, SharingStarted.Eagerly, ThinkingSettings())

    override val runtime: StateFlow<TraceRuntimeDto?> get() = traces.runtime

    override val demo: Boolean get() = demoMode()

    override fun telemetry(chatId: String, promptId: String, fetch: Boolean): StateFlow<TurnTelemetry> =
        traces.telemetry(chatId, promptId, fetch = fetch && !demoMode())

    override fun load(chatId: String, promptId: String) {
        if (demoMode()) return
        scope.launch { traces.load(TurnKey(chatId, promptId)) }
    }

    override fun viewing(): () -> Unit = traces.viewing()

    override fun chooseStyle(id: String) {
        scope.launch { settingsRepository.update { it.copy(thinking = it.thinking.copy(style = id)) } }
    }

    override fun refreshRuntime() {
        scope.launch { traces.refreshRuntime() }
    }
}
