package com.avek.chat.core.domain.trace

import com.avek.chat.core.link.HarnessApi
import com.avek.chat.core.link.LinkRepository
import com.avek.chat.core.link.wire.LinkEvent
import com.avek.chat.core.link.wire.TraceRuntimeDto
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicInteger

/**
 * One [StateFlow] of [TurnTelemetry] per turn (v3 task D.4). A turn's flow is created when it
 * starts (`turn.started`), when a chat with a running turn is opened (`trace.get`, then live
 * events), or on demand for a finished turn (`trace.get`). The 6 most recent turns are kept.
 * The `trace` topic is subscribed only while at least one thinking block or the inspector is on
 * screen ([viewing]); after a reconnect every live turn is fetched again with `trace.get`.
 */
class TraceRepository(
    private val link: LinkRepository,
    private val api: HarnessApi,
    private val scope: CoroutineScope,
    private val demoMode: () -> Boolean = { false },
    private val nowMs: () -> Long = System::currentTimeMillis,
) {
    private val turns = LinkedHashMap<TurnKey, MutableStateFlow<TurnTelemetry>>(8, 0.75f, true)
    private val viewers = AtomicInteger(0)

    private val _latest = MutableStateFlow<TurnKey?>(null)

    /** The person's most recent turn (Customize → Thinking previews use it; null = none yet). */
    val latest: StateFlow<TurnKey?> = _latest

    private val _runtime = MutableStateFlow<TraceRuntimeDto?>(null)

    /** The latest `trace.runtime` / `runtime.get` (the inspector's Runtime panel). */
    val runtime: StateFlow<TraceRuntimeDto?> = _runtime

    fun start() {
        scope.launch { link.events.collect(::onEvent) }
    }

    /** The telemetry of a turn; creates it (and fetches `trace.get` when [fetch]) if it is not known. */
    fun telemetry(chatId: String, promptId: String, fetch: Boolean = true): StateFlow<TurnTelemetry> {
        val key = TurnKey(chatId, promptId)
        val (flow, created) = synchronized(turns) {
            turns[key]?.let { it to false } ?: (MutableStateFlow(TraceReducer.empty(key, demoMode())).also { put(key, it) } to true)
        }
        if (created && fetch && !demoMode()) scope.launch { load(key, flow) }
        return flow
    }

    /** `trace.get` for a turn: the snapshot replaces what it covers; live events continue on top. */
    suspend fun load(key: TurnKey) {
        val flow = synchronized(turns) { turns[key] } ?: return
        load(key, flow)
    }

    private suspend fun load(key: TurnKey, flow: MutableStateFlow<TurnTelemetry>) {
        try {
            val snapshot = api.traceGet(key.chatId, key.promptId)
            flow.value = TraceReducer.reduce(flow.value, snapshot, nowMs())
            snapshot.runtime?.let(::offerRuntime)
        } catch (e: CancellationException) {
            throw e
        } catch (_: Exception) {
            // Not connected, unknown turn, or an older harness: the block shows what live events gave.
        }
    }

    /** `runtime.get`: the Runtime panel when no turn is running. */
    suspend fun refreshRuntime() {
        if (demoMode()) return
        try {
            offerRuntime(api.runtimeGet())
        } catch (e: CancellationException) {
            throw e
        } catch (_: Exception) {
        }
    }

    /**
     * A thinking block or the inspector became visible; call the returned function when it leaves.
     * The `trace` topic is wanted while at least one is visible.
     */
    fun viewing(): () -> Unit {
        if (viewers.incrementAndGet() == 1) link.setTraceWanted(true)
        var released = false
        return {
            if (!released) {
                released = true
                if (viewers.decrementAndGet() == 0) link.setTraceWanted(false)
            }
        }
    }

    val viewerCount: Int get() = viewers.get()

    // ------------------------------------------------------------------ events

    private fun onEvent(event: LinkEvent) {
        val now = nowMs()
        when (event) {
            is LinkEvent.TurnStarted -> {
                val key = TurnKey(event.data.chatId, event.data.promptId)
                _latest.value = key
                update(key, create = true) { TraceReducer.reduce(it, event, now) }
            }
            is LinkEvent.Refresh -> {
                // After a reconnect: fetch every turn that was live again.
                val live = synchronized(turns) { turns.filterValues { it.value.live }.keys.toList() }
                live.forEach { key -> scope.launch { load(key) } }
            }
            is LinkEvent.TraceRuntime -> {
                offerRuntime(event.data)
                synchronized(turns) { turns.values.filter { it.value.live }.toList() }
                    .forEach { flow -> flow.value = TraceReducer.reduce(flow.value, event, now) }
            }
            else -> {
                val key = keyOf(event) ?: return
                // Telemetry of a turn we have not seen start (joined late): follow it from now on.
                val create = event is LinkEvent.TracePhase || event is LinkEvent.TraceGen
                update(key, create) { TraceReducer.reduce(it, event, now) }
            }
        }
    }

    private fun offerRuntime(r: TraceRuntimeDto) {
        val current = _runtime.value
        if (current == null || r.t >= current.t) _runtime.value = r
    }

    private fun update(key: TurnKey, create: Boolean, transform: (TurnTelemetry) -> TurnTelemetry) {
        var createdNow = false
        val flow = synchronized(turns) {
            turns[key] ?: if (create) {
                createdNow = true
                MutableStateFlow(TraceReducer.empty(key, demoMode())).also { put(key, it) }
            } else null
        } ?: return
        if (createdNow) {
            // Trace events only flow while a turn runs.
            _latest.value = key
            flow.value = flow.value.copy(live = true)
        }
        flow.value = transform(flow.value)
    }

    private fun put(key: TurnKey, flow: MutableStateFlow<TurnTelemetry>) {
        turns[key] = flow
        while (turns.size > MAX_TURNS) {
            val eldest = turns.keys.first()
            turns.remove(eldest)
        }
    }

    private fun keyOf(event: LinkEvent): TurnKey? = when (event) {
        is LinkEvent.TracePhase -> TurnKey(event.data.chatId, event.data.promptId)
        is LinkEvent.TraceContext -> TurnKey(event.data.chatId, event.data.promptId)
        is LinkEvent.TraceGen -> TurnKey(event.data.chatId, event.data.promptId)
        is LinkEvent.TraceTool -> TurnKey(event.data.chatId, event.data.promptId)
        is LinkEvent.TraceLog -> TurnKey(event.data.chatId, event.data.promptId)
        is LinkEvent.ThinkingDelta -> TurnKey(event.data.chatId, event.data.promptId)
        is LinkEvent.AnswerDelta -> TurnKey(event.data.chatId, event.data.promptId)
        is LinkEvent.ToolCallDelta -> TurnKey(event.data.chatId, event.data.promptId)
        is LinkEvent.TurnCompleted -> TurnKey(event.data.chatId, event.data.promptId)
        is LinkEvent.TurnCancelled -> TurnKey(event.data.chatId, event.data.promptId)
        is LinkEvent.TurnFailed -> TurnKey(event.data.chatId, event.data.promptId)
        else -> null
    }?.takeIf { it.chatId.isNotEmpty() && it.promptId.isNotEmpty() }

    companion object {
        const val MAX_TURNS = 6
    }
}
