package com.avek.chat.core.data.fake

import com.avek.chat.core.model.SourceRef
import com.avek.chat.core.model.TaskMode
import com.avek.chat.core.model.ThinkingDepth
import javax.inject.Inject
import kotlin.random.Random

/** A fully planned reply: what the model "thinks", which sources it "finds", and what it answers. */
data class ReplyScript(
    val thinking: List<ThinkingStepScript>,
    val sources: List<SourceRef>,
    val answer: String,
)

data class ThinkingStepScript(val title: String, val text: String)

/**
 * Builds believable, task-shaped replies without a real model. Output is
 * deterministic per prompt so regenerating the same message is stable-ish
 * but still varies between prompts.
 */
class ResponseComposer @Inject constructor() {

    fun compose(prompt: String, task: TaskMode, depth: ThinkingDepth, variant: Int = 0): ReplyScript {
        val random = Random(prompt.hashCode() * 31 + task.ordinal * 7 + variant)
        val topic = Topic.from(prompt)
        val sources = if (task == TaskMode.DEEP_RESEARCH) researchSources(topic, depth, random) else emptyList()
        return ReplyScript(
            thinking = thinking(topic, task, depth, random),
            sources = sources,
            answer = answer(topic, task, depth, sources, random),
        )
    }

    // ---------------------------------------------------------------- thinking

    private fun thinking(topic: Topic, task: TaskMode, depth: ThinkingDepth, random: Random): List<ThinkingStepScript> {
        if (!depth.thinks) return emptyList()
        val titles = stepTitles.getValue(task)
        val count = depth.thinkingSteps
        return (0 until count).map { index ->
            val title = titles[index % titles.size]
            val paragraphs = if (depth.level >= ThinkingDepth.EXTENDED.level) 2 else 1
            val text = (0 until paragraphs).joinToString("\n\n") {
                thoughtFor(task, index, topic, random)
            }
            ThinkingStepScript(title, text)
        }
    }

    private fun thoughtFor(task: TaskMode, step: Int, topic: Topic, random: Random): String {
        val pool = taskThoughts[task].orEmpty() + genericThoughts
        val template = if (step == 0) openingThoughts.random(random) else pool.random(random)
        return template.fill(topic)
    }

    private val openingThoughts = listOf(
        "The user is asking about {topic}. Before answering, I want to pin down what they actually need — a quick overview, or something they can act on right away?",
        "Okay, {topic}. Let me restate the request in my own words so I don't drift: they want a clear, useful answer about {topic}, not a lecture.",
        "First pass at {topic}: the question has a surface reading and a deeper one. I'll make sure I address both, starting with the one that matters most.",
    )

    private val genericThoughts = listOf(
        "One risk here is over-generalising. I should anchor the explanation in a concrete example related to {topic} so it lands.",
        "I'm weighing two framings. The first is simpler; the second is more accurate but needs more setup. Simpler first, then add nuance.",
        "Let me check my assumptions: am I assuming context the user hasn't given? If so, I should state those assumptions explicitly in the answer.",
        "There's an edge case worth flagging around {keyword}. It's not the main point, but leaving it out could mislead.",
        "Structure-wise, a short summary up top, then detail, then a next step. That respects the reader's time.",
        "Double-checking consistency: the claims I'm about to make about {keyword} shouldn't contradict each other. They hold up.",
        "I could go much deeper, but depth for its own sake isn't helpful. I'll keep the answer tight and offer to expand.",
    )

    private val taskThoughts = mapOf(
        TaskMode.CODING to listOf(
            "Inputs, outputs, failure modes. What happens on empty input, on concurrency, on cancellation? I'll handle those explicitly.",
            "Idiomatic first, clever second. A reader should understand the function from its signature and a two-line doc comment.",
            "Complexity check: this should be linear in the input. Anything quadratic needs a justification.",
            "I'll include a small test so the behaviour is pinned down, especially the edge case around {keyword}.",
        ),
        TaskMode.DEEP_RESEARCH to listOf(
            "Searching broadly first: background on {topic}, then recent developments, then dissenting views.",
            "Two sources disagree on the magnitude of the effect. I'll present the range rather than pick one.",
            "Cross-referencing: claims that appear in only one source get flagged as lower confidence.",
            "I should separate what's well established about {keyword} from what's still speculative.",
        ),
        TaskMode.WRITING to listOf(
            "Voice: warm but not saccharine. Short sentences where emphasis matters; longer ones to carry the reader.",
            "The opening line has to earn the second. Let me try three openings and keep the strongest.",
            "Cutting adjectives. Every word about {keyword} should be doing work.",
        ),
        TaskMode.ANALYSIS to listOf(
            "Laying out the options side by side with the criteria that actually matter: cost, risk, reversibility, time.",
            "What would change my recommendation? If I can name that, the analysis is honest.",
            "Second-order effects: what happens six months after choosing each option?",
        ),
        TaskMode.MATH to listOf(
            "Define the variables carefully before manipulating anything. Sloppy setup is where most errors come from.",
            "Sanity check with a small case: plug in simple numbers and see if the result behaves.",
            "Units and bounds: the answer must be non-negative and finite here. Good.",
        ),
        TaskMode.BRAINSTORM to listOf(
            "Quantity first, judgement later. I'll generate widely and then cluster into themes.",
            "Some ideas should be deliberately unusual — the safe ones are easy to come up with on your own.",
            "Clustering: practical, playful, and ambitious. That gives the user a spread to react to.",
        ),
        TaskMode.LEARN to listOf(
            "What's the one mental model that makes {topic} click? Start there, then add precision.",
            "An analogy helps, but I must say where it breaks down — otherwise it becomes a misconception.",
            "I'll end with a couple of check-your-understanding questions to make it stick.",
        ),
    )

    private val stepTitles: Map<TaskMode, List<String>> = mapOf(
        TaskMode.GENERAL to listOf("Understanding the question", "Gathering what I know", "Considering angles", "Choosing a structure", "Checking for gaps", "Refining the answer", "Final read-through"),
        TaskMode.CODING to listOf("Reading the requirements", "Considering edge cases", "Choosing an approach", "Sketching the implementation", "Reviewing for bugs", "Checking complexity", "Writing tests", "Polishing the explanation", "Final review"),
        TaskMode.DEEP_RESEARCH to listOf("Planning the investigation", "Searching the literature", "Reading primary sources", "Cross-checking claims", "Resolving contradictions", "Synthesising findings", "Assessing confidence", "Drafting the brief", "Verifying citations"),
        TaskMode.WRITING to listOf("Finding the voice", "Outlining", "Drafting the opening", "Shaping the middle", "Landing the ending", "Line editing", "Reading it aloud"),
        TaskMode.ANALYSIS to listOf("Framing the decision", "Listing the options", "Defining criteria", "Scoring trade-offs", "Stress-testing assumptions", "Second-order effects", "Forming a recommendation"),
        TaskMode.MATH to listOf("Setting up the problem", "Choosing a method", "Working the algebra", "Checking a small case", "Verifying the result", "Considering alternatives", "Writing it up cleanly"),
        TaskMode.BRAINSTORM to listOf("Diverging widely", "Pushing past the obvious", "Clustering ideas", "Adding wildcards", "Picking favourites", "Shaping next steps"),
        TaskMode.LEARN to listOf("Finding the core intuition", "Choosing an analogy", "Building up step by step", "Anticipating confusion", "Adding a worked example", "Writing check questions"),
    ).let { it + (TaskMode.AUTO to it.getValue(TaskMode.GENERAL)) }

    // ---------------------------------------------------------------- sources

    private val domains = listOf(
        "journals.example.org", "research.example.edu", "datahub.example.com", "policy.example.int",
        "engineering.example.dev", "review.example.net", "archive.example.org", "insights.example.co",
        "lab.example.edu", "news.example.com", "stats.example.gov", "papers.example.ai",
    )

    private fun researchSources(topic: Topic, depth: ThinkingDepth, random: Random): List<SourceRef> {
        val count = 4 + depth.level * 2
        val kinds = listOf(
            "A systematic review of %s", "%s: what the data says", "The state of %s in 2026",
            "Rethinking %s — a critical perspective", "Measuring %s at scale", "%s: methods and pitfalls",
            "Field notes on %s", "An economic view of %s", "Open problems in %s", "%s — a primer",
            "Longitudinal evidence on %s", "Case studies in %s", "Benchmarks for %s", "The history of %s",
        ).shuffled(random)
        return (0 until count).map { i ->
            SourceRef(
                title = kinds[i % kinds.size].format(topic.titleCase),
                domain = domains[(i + random.nextInt(domains.size)) % domains.size],
                snippet = "Discusses ${topic.phrase} with a focus on ${topic.keyword}; cited for background and quantitative context.",
            )
        }
    }

    // ---------------------------------------------------------------- answers

    private fun answer(
        topic: Topic,
        task: TaskMode,
        depth: ThinkingDepth,
        sources: List<SourceRef>,
        random: Random,
    ): String = when (task) {
        TaskMode.CODING -> coding(topic, random)
        TaskMode.DEEP_RESEARCH -> research(topic, depth, sources)
        TaskMode.WRITING -> writing(topic, random)
        TaskMode.ANALYSIS -> analysis(topic)
        TaskMode.MATH -> math(topic)
        TaskMode.BRAINSTORM -> brainstorm(topic, random)
        TaskMode.LEARN -> learn(topic)
        TaskMode.GENERAL, TaskMode.AUTO -> general(topic, random)
    }

    private fun general(topic: Topic, random: Random): String {
        val opener = listOf(
            "Good question — here's a clear take on **${topic.phrase}**.",
            "Happy to help with **${topic.phrase}**. Here's the short version first, then the detail.",
            "Let's break **${topic.phrase}** down.",
        ).random(random)
        return """
$opener

${topic.titleCase} comes down to three things: understanding the goal, knowing the constraints, and picking the simplest approach that respects both. Most of the confusion around it comes from mixing those up.

### The short version
- **Start with the outcome.** Decide what "done" looks like for ${topic.keyword} before choosing tools or tactics.
- **Mind the constraints.** Time, budget and context shape the right answer more than any general rule.
- **Iterate in small steps.** A quick first attempt teaches you more than a perfect plan.

### A bit more detail
When people get stuck on ${topic.keyword}, it's usually because the first step feels too big. Shrink it until it's obvious, take it, then reassess. You'll find the second step is much clearer once the first is behind you.

> **Tip:** If you share a little more context — your goal, what you've tried, and any constraints — I can tailor this to your exact situation.

Want me to go deeper on any of these points?
        """.trimIndent()
    }

    private fun coding(topic: Topic, random: Random): String {
        val language = Language.detect(topic.raw)
        val snippet = language.snippets.random(random)
        return """
Here's a clean, production-ready approach for **${topic.phrase}** in ${language.displayName}.

### Approach
1. Keep the core logic **pure** so it's trivial to test.
2. Make failure explicit — no silent catches.
3. Expose a small, well-named API and hide the details.

```${language.fence}
$snippet
```

### Why this works
- **Predictable:** every branch is handled, including empty input and cancellation.
- **Efficient:** runs in `O(n)` time with `O(1)` extra space for the hot path.
- **Testable:** dependencies are passed in, so you can fake them in unit tests.

### Edge cases to watch
| Case | Behaviour |
|---|---|
| Empty input | Returns early with a sensible default |
| Repeated calls | Idempotent — safe to retry |
| Concurrent access | Guarded; no shared mutable state leaks |

Want me to add tests, wire this into your existing code, or walk through it line by line?
        """.trimIndent()
    }

    private fun research(topic: Topic, depth: ThinkingDepth, sources: List<SourceRef>): String {
        fun cite(i: Int) = if (sources.isEmpty()) "" else " [${(i % sources.size) + 1}]"
        return """
# Research brief: ${topic.titleCase}

**Bottom line:** The evidence on ${topic.phrase} is broadly consistent on direction but varies on magnitude. The strongest findings come from longitudinal and large-sample work; the weakest from single-site case studies.${cite(0)}

## 1. Background
${topic.titleCase} has moved from a niche concern to a mainstream one over the past decade, driven by better measurement and wider adoption.${cite(1)} Early work focused on feasibility; recent work focuses on outcomes and trade-offs.${cite(2)}

## 2. Key findings
| Finding | Confidence | Evidence |
|---|---|---|
| Effects are real but context-dependent | High | Multiple independent replications${cite(3)} |
| Benefits concentrate in the first phase | Medium | Strong in two datasets, weaker in a third${cite(4)} |
| Costs are often under-reported | Medium | Methodological critiques${cite(5)} |
| Long-term impact on ${topic.keyword} | Low | Few studies beyond 3 years${cite(6)} |

## 3. Where sources disagree
- **Magnitude.** Estimates differ by roughly 2–3× depending on how ${topic.keyword} is measured.${cite(7)}
- **Generalisability.** Results from one setting don't always transfer.${cite(2)}

## 4. Open questions
1. How durable are the effects over longer horizons?
2. Which conditions predict success versus failure?
3. What's the true cost once indirect effects are counted?

---
*Method: ${sources.size} sources reviewed across ${depth.level + 1} search passes; claims supported by a single source are marked lower confidence.*
        """.trimIndent()
    }

    private fun writing(topic: Topic, random: Random): String {
        val opening = listOf(
            "There's a moment, just before anything begins, when everything still feels possible.",
            "Nobody tells you that the hardest part is the first sentence.",
            "It started, as the best things do, with a question nobody had thought to ask.",
        ).random(random)
        return """
Here's a first draft on **${topic.phrase}** — warm, direct, and easy to read aloud.

---

**${topic.titleCase}**

$opening ${topic.titleCase} lives in that moment. It asks us to slow down long enough to notice what we usually rush past.

We tend to treat ${topic.keyword} as a problem to be solved. But the more time you spend with it, the more it looks like an invitation — to pay attention, to be honest about what matters, and to choose deliberately.

So start small. Pick one thing. Do it well. Then let the next step reveal itself.

---

### Notes on the choices
- **Short opening line** to earn attention before asking for it.
- **Second person** in the close to make it feel like a conversation.
- **No jargon** — it should read well to anyone.

Want it more formal, shorter, or in a different voice?
        """.trimIndent()
    }

    private fun analysis(topic: Topic): String = """
Let's structure the decision around **${topic.phrase}**.

### Options at a glance
| Option | Upside | Downside | Reversible? |
|---|---|---|---|
| **A — Move fast** | Captures momentum early | Higher risk of rework | Mostly |
| **B — Phased rollout** | Learn before committing | Slower payoff | Yes |
| **C — Wait and watch** | No cost today | Opportunity cost grows | Yes |

### What matters most
1. **Reversibility.** Prefer choices you can undo cheaply while uncertainty is high.
2. **Time to signal.** How quickly will you know if it's working?
3. **Downside protection.** What's the worst realistic outcome, and can you live with it?

### Recommendation
Go with **Option B**. It keeps most of the upside of moving fast while capping the downside, and it gives you real data on ${topic.keyword} within a few weeks.

> **What would change my mind:** if the cost of delay is much higher than it looks — for example, a hard deadline or a competitor about to move — Option A becomes the better bet.
    """.trimIndent()

    private fun math(topic: Topic): String = """
Let's work through **${topic.phrase}** step by step.

### 1. Set up
Let the unknown be `x`. From the problem statement we can write:

```
2x + 6 = 14
```

### 2. Isolate the variable
Subtract 6 from both sides, then divide by 2:

```
2x = 8
 x = 4
```

### 3. Check
Substitute back: `2(4) + 6 = 14` ✓

### Why this method
Linear problems like this reward doing the **same operation to both sides** — it keeps the equation balanced and every step reversible.

**Answer:** `x = 4`

Want to try a harder variant, or see the same idea applied to a system of equations?
    """.trimIndent()

    private fun brainstorm(topic: Topic, random: Random): String {
        val practical = listOf("Start a 7-day mini challenge", "Create a one-page checklist", "Pair up with a buddy for accountability", "Run a tiny pilot first", "Turn it into a weekly ritual").shuffled(random)
        val playful = listOf("Gamify it with streaks and badges", "Make a mood board", "Host a themed evening", "Tell the story as a comic strip", "Swap roles for a day").shuffled(random)
        val ambitious = listOf("Build a small community around it", "Launch a public 30-day build log", "Partner with a local organisation", "Turn the best idea into a product", "Write a short guide others can use").shuffled(random)
        return """
Here's a spread of ideas for **${topic.phrase}** — from easy wins to big swings.

### Practical
${practical.take(4).joinToString("\n") { "- **$it** — low effort, quick feedback." }}

### Playful
${playful.take(4).joinToString("\n") { "- **$it** — keeps it fun and memorable." }}

### Ambitious
${ambitious.take(4).joinToString("\n") { "- **$it** — bigger payoff, more commitment." }}

### My top three
1. **${practical[0]}** — the fastest way to learn what works.
2. **${playful[0]}** — makes it stick.
3. **${ambitious[0]}** — if the first two go well.

Want me to develop any of these into a concrete plan?
        """.trimIndent()
    }

    private fun learn(topic: Topic): String = """
## The intuition
Think of **${topic.phrase}** like a recipe: there are a few essential ingredients, an order that matters, and a lot of room for personal taste once you know the basics.

## How it works
1. **The core idea.** At its heart, ${topic.keyword} is about turning an input into a useful output through a small number of well-defined steps.
2. **Why the order matters.** Each step depends on the one before it — skip one and the result falls apart.
3. **Where the nuance lives.** Experts differ mostly in the *details* of each step, not the overall shape.

## A worked example
Imagine you're explaining ${topic.keyword} to a friend over coffee. You'd start with the "why", sketch the steps on a napkin, then walk through one real case. That's exactly the structure above.

> **Where the analogy breaks down:** unlike a recipe, small changes early on can have outsized effects later — so precision matters more than it seems.

## Check your understanding
- Can you describe ${topic.keyword} in one sentence without jargon?
- Which step would fail first if the input were unusual?
- How would you explain it to someone ten years younger?
    """.trimIndent()

    private fun String.fill(topic: Topic) = replace("{topic}", topic.phrase).replace("{keyword}", topic.keyword)
}

/** A cheap "what is this about" extraction from the prompt. */
internal data class Topic(val raw: String, val phrase: String, val keyword: String) {
    val titleCase: String get() = phrase.split(' ').joinToString(" ") { w -> w.replaceFirstChar { it.titlecase() } }

    companion object {
        private val stopWords = setOf(
            "a", "an", "the", "and", "or", "but", "to", "of", "in", "on", "for", "with", "about", "is", "are",
            "was", "be", "can", "could", "would", "you", "me", "my", "i", "please", "how", "what", "why", "when",
            "do", "does", "it", "this", "that", "write", "explain", "help", "give", "make", "some", "tell",
            "need", "want", "should", "any", "into", "from", "at", "by", "as", "we", "our", "your", "us",
            "create", "build", "brainstorm", "ideas", "research", "analyze", "analyse", "solve", "draft", "let's",
        )

        fun from(prompt: String): Topic {
            val words = prompt.lowercase()
                .replace(Regex("```[\\s\\S]*?```"), " ")
                .replace(Regex("[^a-z0-9\\s'-]"), " ")
                .split(Regex("\\s+"))
                .filter { it.length > 2 && it !in stopWords }
            val phrase = words.take(4).joinToString(" ").ifBlank { "your question" }
            val keyword = words.maxByOrNull { it.length } ?: "the topic"
            return Topic(prompt, phrase, keyword)
        }
    }
}

private enum class Language(val displayName: String, val fence: String, vararg val snippets: String) {
    KOTLIN(
        "Kotlin", "kotlin",
        """
/**
 * Retries [block] with exponential backoff and jitter.
 * Cancellation is respected between attempts.
 */
suspend fun <T> retryWithBackoff(
    times: Int = 3,
    initialDelay: Duration = 200.milliseconds,
    maxDelay: Duration = 5.seconds,
    factor: Double = 2.0,
    block: suspend (attempt: Int) -> T,
): T {
    var delay = initialDelay
    repeat(times - 1) { attempt ->
        try {
            return block(attempt)
        } catch (e: IOException) {
            val jitter = Random.nextLong(delay.inWholeMilliseconds / 4 + 1)
            delay(delay + jitter.milliseconds)
            delay = (delay * factor).coerceAtMost(maxDelay)
        }
    }
    return block(times - 1) // last attempt propagates the error
}
        """.trimIndent(),
        """
/** A tiny, thread-safe LRU cache. */
class LruCache<K, V>(private val capacity: Int) {
    init { require(capacity > 0) { "capacity must be positive" } }

    private val map = object : LinkedHashMap<K, V>(capacity, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<K, V>) = size > capacity
    }

    @Synchronized fun get(key: K): V? = map[key]

    @Synchronized fun put(key: K, value: V) { map[key] = value }

    @Synchronized fun getOrPut(key: K, compute: () -> V): V = map.getOrPut(key, compute)

    val size: Int @Synchronized get() = map.size
}
        """.trimIndent(),
    ),
    PYTHON(
        "Python", "python",
        """
from __future__ import annotations

import time
from collections import deque
from dataclasses import dataclass, field


@dataclass
class RateLimiter:
    "Sliding-window rate limiter: at most `limit` calls per `window` seconds."
    limit: int
    window: float
    _calls: deque[float] = field(default_factory=deque)

    def allow(self, now: float | None = None) -> bool:
        now = time.monotonic() if now is None else now
        while self._calls and now - self._calls[0] >= self.window:
            self._calls.popleft()
        if len(self._calls) < self.limit:
            self._calls.append(now)
            return True
        return False
        """.trimIndent(),
    ),
    TYPESCRIPT(
        "TypeScript", "typescript",
        """
/** Debounce that also exposes `flush` and `cancel`. */
export function debounce<A extends unknown[]>(fn: (...args: A) => void, wait = 250) {
  let timer: ReturnType<typeof setTimeout> | undefined;
  let lastArgs: A | undefined;

  const debounced = (...args: A) => {
    lastArgs = args;
    if (timer) clearTimeout(timer);
    timer = setTimeout(() => {
      timer = undefined;
      fn(...(lastArgs as A));
    }, wait);
  };

  debounced.cancel = () => { if (timer) clearTimeout(timer); timer = undefined; };
  debounced.flush = () => { if (timer && lastArgs) { debounced.cancel(); fn(...lastArgs); } };
  return debounced;
}
        """.trimIndent(),
    ),
    SQL(
        "SQL", "sql",
        """
-- Monthly active users with month-over-month growth
WITH monthly AS (
    SELECT date_trunc('month', event_time) AS month,
           COUNT(DISTINCT user_id)          AS mau
    FROM events
    WHERE event_time >= now() - interval '12 months'
    GROUP BY 1
)
SELECT month,
       mau,
       ROUND(100.0 * (mau - LAG(mau) OVER (ORDER BY month))
             / NULLIF(LAG(mau) OVER (ORDER BY month), 0), 1) AS growth_pct
FROM monthly
ORDER BY month;
        """.trimIndent(),
    ),
    RUST(
        "Rust", "rust",
        """
/// Splits `input` into words and counts them, case-insensitively.
pub fn word_counts(input: &str) -> std::collections::HashMap<String, usize> {
    let mut counts = std::collections::HashMap::new();
    for word in input
        .split(|c: char| !c.is_alphanumeric())
        .filter(|w| !w.is_empty())
    {
        *counts.entry(word.to_lowercase()).or_insert(0) += 1;
    }
    counts
}
        """.trimIndent(),
    );

    companion object {
        fun detect(prompt: String): Language {
            val p = prompt.lowercase()
            return when {
                "python" in p || "django" in p || "pandas" in p -> PYTHON
                "typescript" in p || "javascript" in p || "react" in p || " js" in p || "node" in p -> TYPESCRIPT
                "sql" in p || "query" in p || "database" in p -> SQL
                "rust" in p -> RUST
                else -> KOTLIN
            }
        }
    }
}
