package com.avek.chat.feature.connection

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.outlined.Computer
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.avek.chat.core.designsystem.theme.AvekTheme
import com.avek.chat.core.designsystem.theme.avekShape

@Composable
fun PairingRoute(onboarding: Boolean, onClose: () -> Unit, viewModel: PairingViewModel = hiltViewModel()) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    PairingScreen(
        state = state,
        onboarding = onboarding,
        onClose = {
            if (onboarding) viewModel.skip()
            onClose()
        },
        onSelect = viewModel::select,
        onDeviceName = viewModel::onDeviceName,
        onPair = viewModel::pair,
        onDigits = viewModel::answerDigits,
        onCancel = viewModel::cancel,
        onDemo = {
            viewModel.useDemo()
            onClose()
        },
    )
}

/** Pair with a PC (section 13): find, pick, compare six digits, approve on the PC. Nothing is typed but a device name. */
@Composable
fun PairingScreen(
    state: PairingUiState,
    onboarding: Boolean,
    onClose: () -> Unit,
    onSelect: (String) -> Unit,
    onDeviceName: (String) -> Unit,
    onPair: () -> Unit,
    onDigits: (Boolean) -> Unit,
    onCancel: () -> Unit,
    onDemo: () -> Unit,
) {
    val colors = AvekTheme.colors
    Scaffold(
        containerColor = colors.chatBackground,
        topBar = {
            TopAppBar(
                title = { Text(if (onboarding) "Welcome" else "Pair with a PC", style = AvekTheme.type.headline, color = colors.textPrimary) },
                navigationIcon = {
                    if (!onboarding) IconButton(onClick = onClose) { Icon(Icons.AutoMirrored.Outlined.ArrowBack, "Back", tint = colors.textPrimary) }
                },
                actions = {
                    if (onboarding && state.step != PairingStep.DONE) TextButton(onClick = onClose) { Text("Later", color = colors.textSecondary) }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = colors.chatBackground),
            )
        },
    ) { padding ->
        AnimatedContent(
            targetState = state.step,
            transitionSpec = { fadeIn() togetherWith fadeOut() },
            label = "pairing-step",
            modifier = Modifier.fillMaxSize().padding(padding),
        ) { step ->
            Column(
                Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .imePadding()
                    .padding(horizontal = 24.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                when (step) {
                    PairingStep.SEARCHING -> SearchingStep(state, onboarding, onSelect, onDeviceName, onPair, onDemo)
                    PairingStep.PAIRING -> CenteredProgress("Connecting to ${state.selected?.name ?: "your PC"}...")
                    PairingStep.DIGITS -> DigitsStep(state, onDigits)
                    PairingStep.APPROVING -> ApprovingStep(state, onCancel)
                    PairingStep.DONE -> DoneStep(state, onClose)
                }
            }
        }
    }
}

@Composable
private fun SearchingStep(
    state: PairingUiState,
    onboarding: Boolean,
    onSelect: (String) -> Unit,
    onDeviceName: (String) -> Unit,
    onPair: () -> Unit,
    onDemo: () -> Unit,
) {
    val colors = AvekTheme.colors
    if (onboarding) {
        Text("Connect this app to your PC", style = AvekTheme.type.display, color = colors.textPrimary)
    }
    Text(
        "On your PC run  python avek_tui.py  and press  p  to open the pairing window. Keep both on the same Wi-Fi.",
        style = AvekTheme.type.body,
        color = colors.textSecondary,
    )
    Row(verticalAlignment = Alignment.CenterVertically) {
        CircularProgressIndicator(Modifier.size(16.dp), color = colors.accent, strokeWidth = 2.dp)
        Spacer(Modifier.width(10.dp))
        Text(
            if (state.found.isEmpty()) "Looking for a PC with its pairing window open..." else "Found ${state.found.size} ${if (state.found.size == 1) "PC" else "PCs"}",
            style = AvekTheme.type.bodySmall,
            color = colors.textSecondary,
        )
    }
    if (state.found.isEmpty() && state.emptyRounds >= HINT_AFTER_ROUNDS) {
        Text(
            "No PC found yet. Check that the pairing window is open on the PC (it closes after 2 minutes) and that this device uses the same Wi-Fi or hotspot.",
            style = AvekTheme.type.bodySmall,
            color = colors.textTertiary,
        )
    }
    state.found.forEach { pc ->
        val selected = pc.serverId == state.selectedId
        Row(
            Modifier
                .fillMaxWidth()
                .clip(avekShape(14.dp))
                .border(if (selected) 1.5.dp else 1.dp, if (selected) colors.accent else colors.outline, avekShape(14.dp))
                .background(if (selected) colors.accentContainer else colors.surface)
                .clickable { onSelect(pc.serverId) }
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Outlined.Computer, null, tint = if (selected) colors.accent else colors.textSecondary)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(pc.name, style = AvekTheme.type.title, color = colors.textPrimary)
                Text(pc.host, style = AvekTheme.type.caption, color = colors.textTertiary)
            }
            if (selected) Icon(Icons.Filled.CheckCircle, "Selected", tint = colors.accent)
        }
    }
    OutlinedTextField(
        value = state.deviceName,
        onValueChange = onDeviceName,
        label = { Text("Name of this device") },
        singleLine = true,
        textStyle = AvekTheme.type.body.copy(color = colors.textPrimary),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = colors.accent,
            unfocusedBorderColor = colors.outline,
            focusedLabelColor = colors.accent,
            cursorColor = colors.accent,
        ),
        modifier = Modifier.fillMaxWidth(),
    )
    state.error?.let { Text(it, style = AvekTheme.type.bodySmall, color = colors.danger) }
    Button(
        onClick = onPair,
        enabled = state.canPair,
        modifier = Modifier.fillMaxWidth(),
        colors = ButtonDefaults.buttonColors(containerColor = colors.accent, contentColor = colors.onAccent),
    ) { Text(state.selected?.let { "Pair with ${it.name}" } ?: "Pair") }
    if (onboarding) {
        TextButton(onClick = onDemo, modifier = Modifier.fillMaxWidth()) {
            Text("No PC at hand? Try Demo mode", color = colors.textSecondary)
        }
    }
}

@Composable
private fun DigitsStep(state: PairingUiState, onDigits: (Boolean) -> Unit) {
    val colors = AvekTheme.colors
    val digits = state.digits ?: return
    Spacer(Modifier.height(24.dp))
    Text("Your PC ${digits.serverName} shows six digits.", style = AvekTheme.type.body, color = colors.textSecondary, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
    Row(
        Modifier
            .fillMaxWidth()
            .semantics { contentDescription = "Digits ${digits.sas.toCharArray().joinToString(" ")}" },
        horizontalArrangement = Arrangement.Center,
    ) {
        DigitGroup(digits.sas.take(3))
        Spacer(Modifier.width(22.dp))
        DigitGroup(digits.sas.drop(3))
    }
    Text(
        "Do these digits match the ones on your PC?",
        style = AvekTheme.type.title,
        color = colors.textPrimary,
        modifier = Modifier.fillMaxWidth(),
        textAlign = TextAlign.Center,
    )
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        OutlinedButton(onClick = { onDigits(false) }, modifier = Modifier.weight(1f)) { Text("No", color = colors.danger) }
        Button(
            onClick = { onDigits(true) },
            modifier = Modifier.weight(1f),
            colors = ButtonDefaults.buttonColors(containerColor = colors.accent, contentColor = colors.onAccent),
        ) { Text("Yes, they match") }
    }
}

@Composable
private fun DigitGroup(text: String) {
    val colors = AvekTheme.colors
    Text(
        text,
        fontSize = 52.sp,
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.SemiBold,
        color = colors.textPrimary,
        letterSpacing = 6.sp,
        modifier = Modifier
            .clip(avekShape(16.dp))
            .background(colors.surface)
            .border(1.dp, colors.outline, avekShape(16.dp))
            .padding(horizontal = 16.dp, vertical = 10.dp),
    )
}

@Composable
private fun ApprovingStep(state: PairingUiState, onCancel: () -> Unit) {
    val colors = AvekTheme.colors
    Spacer(Modifier.height(32.dp))
    Text("Now approve on your PC...", style = AvekTheme.type.headline, color = colors.textPrimary, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
    Text(
        "Press  y  in avek_tui.py on ${state.digits?.serverName ?: "your PC"}.",
        style = AvekTheme.type.body,
        color = colors.textSecondary,
        modifier = Modifier.fillMaxWidth(),
        textAlign = TextAlign.Center,
    )
    LinearProgressIndicator(Modifier.fillMaxWidth(), color = colors.accent, trackColor = colors.outline.copy(alpha = 0.4f))
    TextButton(onClick = onCancel, modifier = Modifier.fillMaxWidth()) { Text("Cancel", color = colors.textSecondary) }
}

@Composable
private fun DoneStep(state: PairingUiState, onClose: () -> Unit) {
    val colors = AvekTheme.colors
    Spacer(Modifier.height(40.dp))
    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        Box(Modifier.size(72.dp).clip(CircleShape).background(colors.accentContainer), contentAlignment = Alignment.Center) {
            Icon(Icons.Filled.CheckCircle, null, tint = colors.accent, modifier = Modifier.size(44.dp))
        }
    }
    Text("Paired with ${state.pairedWith}", style = AvekTheme.type.headline, color = colors.textPrimary, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
    Text(
        "From now on the app finds your PC by itself whenever it is on the same Wi-Fi.",
        style = AvekTheme.type.body,
        color = colors.textSecondary,
        modifier = Modifier.fillMaxWidth(),
        textAlign = TextAlign.Center,
    )
    Button(
        onClick = onClose,
        modifier = Modifier.fillMaxWidth(),
        colors = ButtonDefaults.buttonColors(containerColor = colors.accent, contentColor = colors.onAccent),
    ) { Text("Start chatting") }
}

@Composable
private fun CenteredProgress(text: String) {
    val colors = AvekTheme.colors
    Spacer(Modifier.height(60.dp))
    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = colors.accent) }
    Text(text, style = AvekTheme.type.body, color = colors.textSecondary, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
}

private const val HINT_AFTER_ROUNDS = 3
