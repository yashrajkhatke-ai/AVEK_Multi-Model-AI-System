package com.avek.chat.feature.chat.profiles

import kotlin.math.roundToInt

/** Layers on the three processors. Always `rtx + igpu + cpu == total` when made by [LayerPlan]. */
data class Layers(val rtx: Int, val igpu: Int, val cpu: Int) {
    val total: Int get() = rtx + igpu + cpu
}

/** A starting point for the editor; the person can change everything afterwards. */
data class LayerPreset(val name: String, val layers: Layers)

/**
 * Where a model's layers run (UI-WIRE v4 section 8.10): pure arithmetic, no estimates. The app never
 * decides where layers go by itself and never hard-codes a layer count: [total] is `layersTotal` from the PC.
 */
object LayerPlan {

    /** Clamps to `0..total`: RTX first, then iGPU within what is left, the CPU takes the rest. */
    fun of(total: Int, rtx: Int, igpu: Int): Layers {
        val t = total.coerceAtLeast(0)
        val r = rtx.coerceIn(0, t)
        val i = igpu.coerceIn(0, t - r)
        return Layers(r, i, t - r - i)
    }

    /** The RTX slider moved: the CPU gives first; beyond `total - igpu` the iGPU is pushed down (never negative). */
    fun withRtx(current: Layers, total: Int, rtx: Int): Layers {
        val t = total.coerceAtLeast(0)
        val r = rtx.coerceIn(0, t)
        val i = current.igpu.coerceIn(0, t - r)
        return Layers(r, i, t - r - i)
    }

    /** The iGPU slider moved: the CPU gives first; beyond `total - rtx` the RTX is pushed down (never negative). */
    fun withIgpu(current: Layers, total: Int, igpu: Int): Layers {
        val t = total.coerceAtLeast(0)
        val i = igpu.coerceIn(0, t)
        val r = current.rtx.coerceIn(0, t - i)
        return Layers(r, i, t - r - i)
    }

    /**
     * "All on RTX", "RTX + iGPU", "RTX + CPU", "All on CPU". A preset needing a processor the PC does
     * not have is left out.
     */
    fun presets(total: Int, hasRtx: Boolean, hasIgpu: Boolean): List<LayerPreset> {
        val t = total.coerceAtLeast(0)
        val main = (0.6 * t).roundToInt().coerceIn(0, t)
        return buildList {
            if (hasRtx) add(LayerPreset("All on RTX", Layers(t, 0, 0)))
            if (hasRtx && hasIgpu) add(LayerPreset("RTX + iGPU", Layers(main, t - main, 0)))
            if (hasRtx) add(LayerPreset("RTX + CPU", Layers(main, 0, t - main)))
            add(LayerPreset("All on CPU", Layers(0, 0, t)))
        }
    }

    /** "RTX 38 · iGPU 27 · CPU 0" */
    fun numbers(layers: Layers): String = "RTX ${layers.rtx} · iGPU ${layers.igpu} · CPU ${layers.cpu}"

    /** "RTX 38 · iGPU 27 · CPU 0 layers · 75K context" (the composer row). */
    fun summary(layers: Layers, contextTokens: Int? = null): String = buildString {
        append(numbers(layers)).append(" layers")
        if (contextTokens != null && contextTokens > 0) append(" · ").append(contextK(contextTokens)).append(" context")
    }

    /** The bar's content description: "RTX 38 layers, iGPU 27, CPU 0". */
    fun description(layers: Layers): String = "RTX ${layers.rtx} layers, iGPU ${layers.igpu}, CPU ${layers.cpu}"

    /** Context sizes in K: multiples of 1,024 as binary K (32,768 → "32K"), anything else in thousands (75,000 → "75K"). */
    fun contextK(tokens: Int): String = if (tokens % 1024 == 0) "${tokens / 1024}K" else "${(tokens / 1000.0).roundToInt()}K"

    /** The context slider: steps of 1,024 between the PC's limits. */
    fun snapContext(tokens: Int, min: Int, max: Int): Int {
        val lo = min.coerceAtLeast(1024)
        val hi = max.coerceAtLeast(lo)
        val loSnap = ((lo + 1023) / 1024) * 1024
        val hiSnap = maxOf(loSnap, (hi / 1024) * 1024)
        val snapped = ((tokens.toLong() + 512) / 1024 * 1024).coerceIn(loSnap.toLong(), hiSnap.toLong())
        return snapped.toInt()
    }
}
