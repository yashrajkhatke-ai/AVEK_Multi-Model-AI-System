package com.avek.chat.feature.connection

import androidx.compose.runtime.Immutable
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.avek.chat.core.common.DeviceInfo
import com.avek.chat.core.domain.repository.SettingsRepository
import com.avek.chat.core.link.LinkRepository
import com.avek.chat.core.link.crypto.HandshakeException
import com.avek.chat.core.link.crypto.PairingDigits
import com.avek.chat.core.link.discovery.FoundPc
import com.avek.chat.core.link.pairing.PairingManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.IOException
import javax.inject.Inject

/** Where the pairing is (UI-WIRE v3 section 13, "Pairing (once)"). */
enum class PairingStep { SEARCHING, PAIRING, DIGITS, APPROVING, DONE }

@Immutable
data class PairingUiState(
    val step: PairingStep = PairingStep.SEARCHING,
    /** PCs with their pairing window open, by name. */
    val found: List<FoundPc> = emptyList(),
    val selectedId: String? = null,
    val deviceName: String = "",
    /** Rounds of `find` without an answer (a hint is shown after a few). */
    val emptyRounds: Int = 0,
    val digits: PairingDigits? = null,
    val pairedWith: String? = null,
    val error: String? = null,
) {
    val selected: FoundPc? get() = found.firstOrNull { it.serverId == selectedId }
    val canPair: Boolean get() = step == PairingStep.SEARCHING && selected != null && deviceName.isNotBlank()
}

@HiltViewModel
class PairingViewModel @Inject constructor(
    private val pairing: PairingManager,
    private val link: LinkRepository,
    private val settings: SettingsRepository,
    device: DeviceInfo,
) : ViewModel() {

    private val _state = MutableStateFlow(PairingUiState(deviceName = device.model.take(40)))
    val state: StateFlow<PairingUiState> = _state

    private var searchJob: Job? = null
    private var pairJob: Job? = null
    private var decision: CompletableDeferred<Boolean>? = null

    init {
        startSearching()
    }

    // ------------------------------------------------------------------ finding

    /** Sends `find` round after round until the person picks a PC (the list refreshes meanwhile). */
    fun startSearching() {
        searchJob?.cancel()
        searchJob = viewModelScope.launch {
            while (isActive) {
                val found = try {
                    pairing.find()
                } catch (e: CancellationException) {
                    throw e
                } catch (_: Exception) {
                    emptyList()
                }
                _state.update { s ->
                    if (s.step != PairingStep.SEARCHING) return@update s
                    val selected = s.selectedId?.takeIf { id -> found.any { it.serverId == id } }
                        ?: found.singleOrNull()?.serverId
                    s.copy(found = found, selectedId = selected, emptyRounds = if (found.isEmpty()) s.emptyRounds + 1 else 0)
                }
                if (_state.value.step != PairingStep.SEARCHING) return@launch
                delay(SEARCH_PAUSE_MS)
            }
        }
    }

    /** The screen left (or a test ended): no more `find` rounds. */
    fun stopSearching() {
        searchJob?.cancel()
        searchJob = null
    }

    fun select(serverId: String) = _state.update { it.copy(selectedId = serverId, error = null) }

    fun onDeviceName(text: String) = _state.update { it.copy(deviceName = text.filter { c -> !c.isISOControl() }.take(40), error = null) }

    // ------------------------------------------------------------------ pairing

    fun pair() {
        val current = _state.value
        val pc = current.selected ?: return
        if (!current.canPair) return
        searchJob?.cancel()
        _state.update { it.copy(step = PairingStep.PAIRING, error = null) }
        pairJob = viewModelScope.launch {
            try {
                val paired = pairing.pair(
                    pc = pc,
                    deviceName = current.deviceName.trim(),
                    confirm = { digits ->
                        val answer = CompletableDeferred<Boolean>()
                        decision = answer
                        _state.update { it.copy(step = PairingStep.DIGITS, digits = digits) }
                        answer.await()
                    },
                    onAwaitingApproval = { _state.update { it.copy(step = PairingStep.APPROVING) } },
                )
                settings.update { it.copy(connection = it.connection.copy(onboardingDone = true)) }
                _state.update { it.copy(step = PairingStep.DONE, pairedWith = paired.serverName, digits = null) }
                link.reconnect()
            } catch (e: CancellationException) {
                _state.update { it.copy(step = PairingStep.SEARCHING, digits = null) }
                throw e
            } catch (e: Exception) {
                _state.update { it.copy(step = PairingStep.SEARCHING, digits = null, error = explain(e)) }
                startSearching()
            }
        }
    }

    /** "Do these digits match?" Yes continues; No cancels at once. */
    fun answerDigits(match: Boolean) {
        decision?.complete(match)
        decision = null
    }

    /** Cancel while waiting for the approval on the PC (closes the connection). */
    fun cancel() {
        decision?.complete(false)
        decision = null
        pairJob?.cancel()
        pairJob = null
        _state.update { it.copy(step = PairingStep.SEARCHING, digits = null, error = "Pairing cancelled. Nothing was stored.") }
        startSearching()
    }

    /** The first-launch screen was dismissed without pairing (Demo mode or later). */
    fun skip() {
        viewModelScope.launch { settings.update { it.copy(connection = it.connection.copy(onboardingDone = true)) } }
    }

    fun useDemo() {
        viewModelScope.launch { settings.update { it.copy(connection = it.connection.copy(onboardingDone = true, demoMode = true)) } }
    }

    override fun onCleared() {
        decision?.complete(false)
        super.onCleared()
    }

    private fun explain(e: Throwable): String = when (e) {
        is HandshakeException.WindowClosed -> "The pairing window on your PC is closed. Press p in avek_tui.py and try again."
        is HandshakeException.Denied -> if (e.reason == "closed") "The pairing window closed before you approved on the PC." else "Your PC refused the pairing."
        is HandshakeException.Busy -> "Another device is pairing with your PC right now. Try again in a moment."
        is HandshakeException.NotOurPc -> "That PC could not prove its identity, so nothing was stored."
        is HandshakeException.Cancelled -> "The digits did not match, so pairing was cancelled. Nothing was stored."
        is HandshakeException.Timeout -> "Your PC did not answer in time. Is its pairing window still open?"
        is HandshakeException.ClosedByPeer -> "Your PC closed the connection."
        is HandshakeException -> "Pairing failed: ${e.message}"
        is IOException -> "Could not reach the PC. Are both on the same Wi-Fi?"
        else -> e.message ?: "Pairing failed."
    }

    private companion object {
        const val SEARCH_PAUSE_MS = 500L
    }
}
