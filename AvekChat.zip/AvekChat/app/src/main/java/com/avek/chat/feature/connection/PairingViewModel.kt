package com.avek.chat.feature.connection

import androidx.compose.runtime.Immutable
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.avek.chat.core.common.DeviceInfo
import com.avek.chat.core.domain.repository.SettingsRepository
import com.avek.chat.core.link.LinkRepository
import com.avek.chat.core.link.crypto.AvekProtocol
import com.avek.chat.core.link.crypto.PairingResult
import com.avek.chat.core.link.discovery.FoundPc
import com.avek.chat.core.link.pairing.PairTarget
import com.avek.chat.core.link.pairing.PairingManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import javax.inject.Inject

/** Where the pairing is (UI-WIRE v4 section 13, "Pairing (once)"). */
enum class PairingStep { SEARCHING, CHECKING, DONE }

@Immutable
data class PairingUiState(
    val step: PairingStep = PairingStep.SEARCHING,
    /** PCs with their pairing window open, by name. */
    val found: List<FoundPc> = emptyList(),
    val selectedId: String? = null,
    val deviceName: String = "",
    /** Rounds of `find` without an answer (a hint is shown after a few). */
    val emptyRounds: Int = 0,
    /** How many digits the code field holds (the digits themselves stay in the view model's CharArray). */
    val codeDigits: Int = 0,
    /** The code text has something that is not a digit, space or `-`. */
    val codeInvalid: Boolean = false,
    /** "Can't find your PC? Enter its Tailscale name or address." */
    val manualHost: String = "",
    val pairedWith: String? = null,
    val error: String? = null,
) {
    val selected: FoundPc? get() = found.firstOrNull { it.serverId == selectedId }
    val codeComplete: Boolean get() = codeDigits == AvekProtocol.CODE_DIGITS && !codeInvalid
    val target: PairTarget?
        get() = when {
            manualHost.isNotBlank() -> PairTarget.Manual(manualHost.trim())
            selected != null -> PairTarget.Found(selected!!)
            else -> null
        }
    val canPair: Boolean get() = step == PairingStep.SEARCHING && target != null && codeComplete && deviceName.isNotBlank()

    /** "The code has 12 digits" under the field while it is filled but not complete. */
    val codeHint: String? get() = if ((codeDigits > 0 || codeInvalid) && !codeComplete) CODE_HINT else null

    companion object {
        const val CODE_HINT = "The code has 12 digits"
    }
}

/**
 * Pair with a PC: `find` until a PC answers, the 12-digit code, the device name, then the two-secret
 * exchange. The code lives only in [code] (a CharArray), never in the UI state or a SavedStateHandle,
 * and is wiped on every exit.
 */
@HiltViewModel
class PairingViewModel @Inject constructor(
    private val pairing: PairingManager,
    private val link: LinkRepository,
    private val settings: SettingsRepository,
    device: DeviceInfo,
) : ViewModel() {

    private val _state = MutableStateFlow(PairingUiState(deviceName = device.model.take(40)))
    val state: StateFlow<PairingUiState> = _state

    private var code = CharArray(0)
    private var searchJob: Job? = null
    private var pairJob: Job? = null

    init {
        startSearching()
    }

    // ------------------------------------------------------------------ finding

    /** Sends `find` round after round until the person pairs (the list refreshes meanwhile). */
    fun startSearching() {
        searchJob?.cancel()
        searchJob = viewModelScope.launch {
            while (isActive) {
                val found = try {
                    pairing.find()
                } catch (e: CancellationException) {
                    throw e
                } catch (_: Exception) {
                    emptyList()
                }
                _state.update { s ->
                    if (s.step != PairingStep.SEARCHING) return@update s
                    val selected = s.selectedId?.takeIf { id -> found.any { it.serverId == id } }
                        ?: found.singleOrNull()?.serverId
                    s.copy(found = found, selectedId = selected, emptyRounds = if (found.isEmpty()) s.emptyRounds + 1 else 0)
                }
                if (_state.value.step != PairingStep.SEARCHING) return@launch
                delay(SEARCH_PAUSE_MS)
            }
        }
    }

    /** The screen left (or a test ended): no more `find` rounds. */
    fun stopSearching() {
        searchJob?.cancel()
        searchJob = null
    }

    fun select(serverId: String) = _state.update { it.copy(selectedId = serverId, error = null) }

    fun onDeviceName(text: String) = _state.update { it.copy(deviceName = text.filter { c -> !c.isISOControl() }.take(40), error = null) }

    fun onManualHost(text: String) = _state.update { it.copy(manualHost = text.filter { c -> !c.isWhitespace() && !c.isISOControl() }.take(253), error = null) }

    // ------------------------------------------------------------------ the code

    /** The code field changed. Only digits are kept (paste with spaces or `-` works); the old buffer is wiped. */
    fun onCode(text: CharSequence) {
        val next = CharArray(minOf(text.length, MAX_CODE_CHARS)) { text[it] }
        val invalid = next.any { it !in '0'..'9' && it != ' ' && it != '-' }
        code.fill('\u0000')
        code = next
        _state.update { it.copy(codeDigits = next.count { c -> c in '0'..'9' }, codeInvalid = invalid, error = null) }
    }

    /** Every exit from the screen: the typed code is wiped. */
    fun clearCode() {
        code.fill('\u0000')
        code = CharArray(0)
        _state.update { it.copy(codeDigits = 0, codeInvalid = false) }
    }

    // ------------------------------------------------------------------ pairing

    fun pair() {
        val current = _state.value
        val target = current.target ?: return
        if (!current.canPair) return
        val typed = code.copyOf()
        searchJob?.cancel()
        _state.update { it.copy(step = PairingStep.CHECKING, error = null) }
        pairJob = viewModelScope.launch {
            val result = try {
                pairing.pair(target, typed, current.deviceName.trim())
            } finally {
                typed.fill('\u0000')
            }
            when (result) {
                is PairingResult.Paired -> {
                    clearCode()
                    settings.update { it.copy(connection = it.connection.copy(onboardingDone = true)) }
                    _state.update { it.copy(step = PairingStep.DONE, pairedWith = result.grant.serverName) }
                    link.reconnect()
                }
                else -> {
                    _state.update { it.copy(step = PairingStep.SEARCHING, error = explain(result)) }
                    startSearching()
                }
            }
        }
    }

    /** "Cancel" while checking the code: closes the connection; nothing is stored. */
    fun cancel() {
        pairJob?.cancel()
        pairJob = null
        _state.update { it.copy(step = PairingStep.SEARCHING, error = null) }
        startSearching()
    }

    /** The first-launch screen was dismissed without pairing (Demo mode or later). */
    fun skip() {
        clearCode()
        viewModelScope.launch { settings.update { it.copy(connection = it.connection.copy(onboardingDone = true)) } }
    }

    fun useDemo() {
        clearCode()
        viewModelScope.launch { settings.update { it.copy(connection = it.connection.copy(onboardingDone = true, demoMode = true)) } }
    }

    override fun onCleared() {
        code.fill('\u0000')
        super.onCleared()
    }

    companion object {
        const val NOT_PAIRED = "Not paired. Check that the PC's pairing window is open and the code is right."
        const val WINDOW_BUSY = "Another device is pairing right now. Try again in a moment."
        const val NO_ROUTE = "Could not reach the PC. Check that it is on and on the same network."
        const val NOT_ENOUGH_MEMORY = "This phone does not have enough free memory to pair. Close other apps and try again."
        private const val SEARCH_PAUSE_MS = 500L
        private const val MAX_CODE_CHARS = 32

        fun explain(result: PairingResult): String = when (result) {
            PairingResult.WindowBusy -> WINDOW_BUSY
            PairingResult.NoRoute -> NO_ROUTE
            PairingResult.NotEnoughMemory -> NOT_ENOUGH_MEMORY
            else -> NOT_PAIRED
        }
    }
}
