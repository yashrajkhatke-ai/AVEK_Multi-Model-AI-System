package com.avek.chat.core.model

enum class FontCategory(val label: String) {
    SANS("Sans"),
    SERIF("Serif"),
    DISPLAY("Display"),
    HANDWRITING("Handwriting"),
    MONO("Mono"),
}

data class FontInfo(
    val name: String,
    val category: FontCategory,
    val weights: List<Int>,
    val hasItalic: Boolean,
)
