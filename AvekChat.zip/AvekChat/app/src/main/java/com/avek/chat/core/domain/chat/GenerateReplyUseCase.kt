package com.avek.chat.core.domain.chat

import com.avek.chat.core.common.TimeProvider
import com.avek.chat.core.data.remote.assistantMessageId
import com.avek.chat.core.data.remote.toDomain
import com.avek.chat.core.data.remote.userMessageId
import com.avek.chat.core.link.HarnessApi
import com.avek.chat.core.link.LinkRepository
import com.avek.chat.core.model.AttachmentInfo
import com.avek.chat.core.model.Message
import com.avek.chat.core.model.MessageStatus
import com.avek.chat.core.model.Role
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.channelFlow
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.launch

/** What the person sent. [chatId] = null starts a new chat (the PC titles it). */
data class PromptRequest(
    val chatId: String?,
    val text: String,
    val options: ChatOptions,
    /** Ids returned by `attach.end`. */
    val attachmentIds: List<String> = emptyList(),
    val attachments: List<AttachmentInfo> = emptyList(),
    /** Key of the optimistic user message, kept so the list does not flicker when the real one arrives. */
    val uiKey: String,
)

/**
 * Sends `prompt`, waits for the acknowledgement, then follows the turn's events into
 * [StreamingReply] snapshots. The app sends only the new text, never the history.
 *
 * Events are collected from before the request is sent, so nothing that follows the
 * acknowledgement can be missed.
 */
class GenerateReplyUseCase(
    private val api: HarnessApi,
    private val link: LinkRepository,
    private val follower: TurnFollower,
    private val time: TimeProvider,
) {
    operator fun invoke(request: PromptRequest): Flow<StreamingReply> = channelFlow {
        val buffer = Channel<com.avek.chat.core.link.wire.LinkEvent>(Channel.UNLIMITED)
        val collector = launch(start = CoroutineStart.UNDISPATCHED) { link.events.collect { buffer.send(it) } }

        val ack = try {
            api.prompt(
                chatId = request.chatId,
                text = request.text,
                modelId = request.options.modelId,
                attachments = request.attachmentIds,
                depth = request.options.depth.level,
                mode = request.options.task.wire,
            )
        } catch (e: Throwable) {
            collector.cancel()
            buffer.close()
            throw e
        }

        val now = time.now()
        val chatId = ack.chatId
        val user = Message(
            id = userMessageId(ack.promptId),
            conversationId = chatId,
            role = Role.USER,
            content = request.text,
            createdAt = now,
            promptId = ack.promptId,
            uiKey = request.uiKey,
            modelId = request.options.modelId,
            requestedTask = request.options.task,
            depth = request.options.depth,
            attachments = request.attachments,
        )
        val assistant = Message(
            id = assistantMessageId(ack.promptId),
            conversationId = chatId,
            role = Role.ASSISTANT,
            content = "",
            createdAt = now + 1,
            promptId = ack.promptId,
            uiKey = request.uiKey + ":a",
            hasThinking = request.options.depth.thinks,
            modelId = request.options.modelId,
            requestedTask = request.options.task,
            resolvedTask = request.options.task.takeUnless { it.isAuto },
            depth = request.options.depth,
            status = MessageStatus.STREAMING,
        )
        val initial = StreamingReply(
            user = user,
            message = assistant,
            phase = if (request.options.depth.thinks) ReplyPhase.THINKING else ReplyPhase.ANSWERING,
            activity = null,
            chat = ack.chat?.toDomain(),
        )
        try {
            follower.follow(initial, buffer.receiveAsFlow()).collect { send(it) }
        } finally {
            collector.cancel()
            buffer.close()
        }
    }
}
