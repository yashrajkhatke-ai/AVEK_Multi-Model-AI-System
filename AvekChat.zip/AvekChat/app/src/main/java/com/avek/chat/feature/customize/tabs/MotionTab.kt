package com.avek.chat.feature.customize.tabs

import androidx.compose.foundation.background
import com.avek.chat.core.designsystem.theme.avekShape
import com.avek.chat.core.designsystem.theme.avekPill
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Replay
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.avek.chat.core.designsystem.component.ChipRow
import com.avek.chat.core.designsystem.component.SectionHeader
import com.avek.chat.core.designsystem.component.SettingsCard
import com.avek.chat.core.designsystem.component.SliderRow
import com.avek.chat.core.designsystem.component.SwitchRow
import com.avek.chat.core.designsystem.motion.DepthGlyph
import com.avek.chat.core.designsystem.motion.StreamingCursor
import com.avek.chat.core.designsystem.motion.ThinkingIndicator
import com.avek.chat.core.designsystem.motion.entrance
import com.avek.chat.core.designsystem.theme.AvekTheme
import com.avek.chat.core.model.ThinkingDepth
import com.avek.chat.core.model.settings.CursorStyle
import com.avek.chat.core.model.settings.EntranceAnimation
import com.avek.chat.core.model.settings.MotionSettings
import com.avek.chat.core.model.settings.ThinkingAnimation
import com.avek.chat.feature.customize.PreviewUserBubble
import kotlin.math.roundToInt

@Composable
fun MotionTab(motion: MotionSettings, onChange: ((MotionSettings) -> MotionSettings) -> Unit) {
    val colors = AvekTheme.colors
    var replay by remember { mutableIntStateOf(0) }

    LazyColumn(contentPadding = PaddingValues(bottom = 40.dp)) {
        item { SectionHeader("Thinking animation", subtitle = "Shown while a model reasons") }
        item {
            FlowRow(
                Modifier.padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                maxItemsInEachRow = 2,
            ) {
                ThinkingAnimation.entries.forEach { style ->
                    val selected = style == motion.thinkingAnimation
                    Column(
                        Modifier
                            .weight(1f)
                            .clip(avekShape(18.dp))
                            .background(if (selected) colors.accentContainer else colors.surface)
                            .border(if (selected) 2.dp else 1.dp, if (selected) colors.accent else colors.outline, avekShape(18.dp))
                            .clickable { onChange { it.copy(thinkingAnimation = style) } }
                            .padding(vertical = 16.dp, horizontal = 8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        ThinkingIndicator(
                            style,
                            colors.thinkingGlow,
                            Modifier.size(40.dp),
                            intensity = 0.6f,
                            speed = motion.animationSpeed,
                            animate = !motion.reduceMotion,
                        )
                        Spacer(Modifier.height(10.dp))
                        Text(style.label, style = AvekTheme.type.label.copy(fontWeight = FontWeight.SemiBold), color = colors.textPrimary)
                        Text(style.description, style = AvekTheme.type.caption, color = colors.textTertiary, textAlign = TextAlign.Center, maxLines = 2)
                    }
                }
            }
        }

        item { SectionHeader("Depth emblems", subtitle = "Each thinking level has its own living mark") }
        item {
            SettingsCard {
                Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    ThinkingDepth.entries.forEach { depth ->
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            DepthGlyph(depth, colors.thinkingGlow, Modifier.size(34.dp), motion.animationSpeed, animate = !motion.reduceMotion)
                            Spacer(Modifier.height(6.dp))
                            Text(depth.label, style = AvekTheme.type.caption, color = colors.textSecondary)
                        }
                    }
                }
            }
        }

        item { SectionHeader("Pace") }
        item {
            SettingsCard {
                SliderRow(
                    "Animation speed",
                    motion.animationSpeed,
                    { v -> onChange { it.copy(animationSpeed = (v * 10).roundToInt() / 10f) } },
                    0.5f..2f,
                    "${"%.1f".format(motion.animationSpeed)}×",
                )
                HorizontalDivider(color = colors.outline.copy(alpha = 0.4f))
                SliderRow(
                    "Streaming speed",
                    motion.streamingSpeed,
                    { v -> onChange { it.copy(streamingSpeed = (v * 10).roundToInt() / 10f) } },
                    0.5f..3f,
                    "${"%.1f".format(motion.streamingSpeed)}×",
                )
                HorizontalDivider(color = colors.outline.copy(alpha = 0.4f))
                SwitchRow("Reduce motion", motion.reduceMotion, { v -> onChange { it.copy(reduceMotion = v) } }, subtitle = "Freezes decorative animation")
                SwitchRow("Haptics", motion.haptics, { v -> onChange { it.copy(haptics = v) } }, subtitle = "Ticks on the depth bar")
            }
        }

        item { SectionHeader("Message entrance") }
        item {
            ChipRow(EntranceAnimation.entries, motion.entrance, { e ->
                onChange { it.copy(entrance = e) }
                replay++
            }, { it.label })
        }
        item {
            Row(
                Modifier
                    .padding(16.dp)
                    .fillMaxWidth()
                    .clip(avekShape(18.dp))
                    .background(colors.chatBackground)
                    .border(1.dp, colors.outline, avekShape(18.dp))
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(Modifier.weight(1f)) {
                    key(replay, motion.entrance) {
                        PreviewUserBubble(
                            "Watch me arrive ✨",
                            Modifier
                                .fillMaxWidth()
                                .entrance(motion.entrance, enabled = !motion.reduceMotion, fromEnd = true),
                        )
                    }
                }
                Spacer(Modifier.width(12.dp))
                Icon(
                    Icons.Outlined.Replay,
                    contentDescription = "Replay",
                    tint = colors.textSecondary,
                    modifier = Modifier
                        .clip(avekPill())
                        .clickable { replay++ }
                        .padding(6.dp),
                )
            }
        }

        item { SectionHeader("Streaming cursor") }
        item {
            ChipRow(CursorStyle.entries, motion.cursor, { c -> onChange { it.copy(cursor = c) } }, { it.label }, leading = { style ->
                StreamingCursor(style, colors.thinkingGlow, Modifier.size(10.dp, 14.dp))
            })
        }
    }
}
