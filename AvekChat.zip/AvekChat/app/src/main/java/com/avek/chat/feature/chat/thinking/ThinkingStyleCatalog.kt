package com.avek.chat.feature.chat.thinking

import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.ui.Modifier
import com.avek.chat.core.domain.trace.TurnTelemetry
import com.avek.chat.core.model.settings.ThinkingSettings
import com.avek.chat.feature.chat.thinking.styles.AgentLoopStyle
import com.avek.chat.feature.chat.thinking.styles.ContextBarStyle
import com.avek.chat.feature.chat.thinking.styles.DashboardStyle
import com.avek.chat.feature.chat.thinking.styles.HarnessConsoleStyle
import com.avek.chat.feature.chat.thinking.styles.HeatStripStyle
import com.avek.chat.feature.chat.thinking.styles.MinimalLineStyle
import com.avek.chat.feature.chat.thinking.styles.PhaseTimelineStyle
import com.avek.chat.feature.chat.thinking.styles.PipelineStyle
import com.avek.chat.feature.chat.thinking.styles.RadialRingsStyle
import com.avek.chat.feature.chat.thinking.styles.RuntimeStyle
import com.avek.chat.feature.chat.thinking.styles.ThoughtStreamStyle
import com.avek.chat.feature.chat.thinking.styles.ThroughputStyle
import com.avek.chat.feature.chat.thinking.styles.TokenLedgerStyle
import com.avek.chat.feature.chat.thinking.styles.TokenTickerStyle
import com.avek.chat.feature.chat.thinking.styles.ToolInspectorStyle
import com.avek.chat.feature.chat.thinking.styles.WaterfallStyle

/** The shared signature of every style. */
typealias ThinkingStyleContent = @Composable (t: TurnTelemetry, thinkingText: String, mode: ThinkingMode, modifier: Modifier) -> Unit

@Immutable
class ThinkingStyle(val id: String, val name: String, val description: String, val content: ThinkingStyleContent)

/** Every display style, in the order the switcher lists them (v3 task E, styles 1 to 16). */
object ThinkingStyleCatalog {
    val styles: List<ThinkingStyle> = listOf(
        ThinkingStyle("minimal", "Minimal line", "One line: model, phase, time and speed") { t, s, m, mod -> MinimalLineStyle(t, s, m, mod) },
        ThinkingStyle("ticker", "Live token ticker", "The newest reasoning tokens scrolling by") { t, s, m, mod -> TokenTickerStyle(t, s, m, mod) },
        ThinkingStyle("timeline", "Phase timeline", "Every phase with its measured duration") { t, s, m, mod -> PhaseTimelineStyle(t, s, m, mod) },
        ThinkingStyle("pipeline", "Pipeline diagram", "Context, prefill, thinking, tool and answer as a flow") { t, s, m, mod -> PipelineStyle(t, s, m, mod) },
        ThinkingStyle("context", "Context window bar", "How the context window is filled, by category") { t, s, m, mod -> ContextBarStyle(t, s, m, mod) },
        ThinkingStyle("ledger", "Token ledger", "Prompt and generated tokens per step and for the turn") { t, s, m, mod -> TokenLedgerStyle(t, s, m, mod) },
        ThinkingStyle("gauge", "Throughput gauge", "Tokens per second with the last minute") { t, s, m, mod -> ThroughputStyle(t, s, m, mod) },
        ThinkingStyle("tools", "Tool-call inspector", "Each tool call with its arguments as they are written") { t, s, m, mod -> ToolInspectorStyle(t, s, m, mod) },
        ThinkingStyle("console", "Harness console", "The harness's own log lines") { t, s, m, mod -> HarnessConsoleStyle(t, s, m, mod) },
        ThinkingStyle("runtime", "Runtime panel", "Loaded models, memory, GPU and plug-ins") { t, s, m, mod -> RuntimeStyle(t, s, m, mod) },
        ThinkingStyle("waterfall", "Waterfall", "Steps, tool calls and phases on a time axis") { t, s, m, mod -> WaterfallStyle(t, s, m, mod) },
        ThinkingStyle("heat", "Token heat strip", "Every token in order, spaced by real timing") { t, s, m, mod -> HeatStripStyle(t, s, m, mod) },
        ThinkingStyle("dashboard", "Dashboard grid", "Tiles for every live number") { t, s, m, mod -> DashboardStyle(t, s, m, mod) },
        ThinkingStyle("thoughts", "Thought stream", "The reasoning text with phase markers") { t, s, m, mod -> ThoughtStreamStyle(t, s, m, mod) },
        ThinkingStyle("loop", "Agent-loop graph", "Model calls and tool round trips as a graph") { t, s, m, mod -> AgentLoopStyle(t, s, m, mod) },
        ThinkingStyle("rings", "Radial rings", "Context, tokens and progress as rings") { t, s, m, mod -> RadialRingsStyle(t, s, m, mod) },
    )

    const val AUTO = ThinkingSettings.AUTO
    const val AUTO_NAME = "Auto"
    const val AUTO_DESCRIPTION = "Timeline while thinking, tools while a tool runs, context during prefill, ledger after"

    fun byId(id: String): ThinkingStyle? = styles.firstOrNull { it.id == id }

    fun nameOf(id: String): String = if (id == AUTO) AUTO_NAME else byId(id)?.name ?: AUTO_NAME

    /**
     * Auto: Phase timeline while thinking, Tool inspector while a tool is written or runs, Context
     * bar during prefill or compaction, Token ledger after the turn.
     */
    fun resolve(id: String, t: TurnTelemetry): ThinkingStyle {
        byId(id)?.let { return it }
        val phase = t.currentPhase?.phase
        val toolBusy = t.tools.values.any { it.state == "writing" || it.state == "running" }
        val styleId = when {
            !t.live && t.hasTrace -> "ledger"
            toolBusy || phase == "writing-tool-call" || phase == "running-tool" -> "tools"
            phase == "prefill" || phase == "compacting" || phase == "fitting-context" || phase == "growing-window" -> "context"
            else -> "timeline"
        }
        return byId(styleId)!!
    }
}
