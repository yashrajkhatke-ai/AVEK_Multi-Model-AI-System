package com.avek.chat.core.data.remote

import com.avek.chat.core.domain.repository.TurnMessages
import com.avek.chat.core.link.wire.AskRequestDto
import com.avek.chat.core.link.wire.ChatSummaryDto
import com.avek.chat.core.link.wire.ModelDto
import com.avek.chat.core.link.wire.SourceDto
import com.avek.chat.core.link.wire.ToolDto
import com.avek.chat.core.link.wire.TurnViewDto
import com.avek.chat.core.model.AskKind
import com.avek.chat.core.model.AskRequest
import com.avek.chat.core.model.AttachmentInfo
import com.avek.chat.core.model.Conversation
import com.avek.chat.core.model.Feedback
import com.avek.chat.core.model.Message
import com.avek.chat.core.model.MessageStatus
import com.avek.chat.core.model.ModelKind
import com.avek.chat.core.model.RemoteModel
import com.avek.chat.core.model.Role
import com.avek.chat.core.model.SourceRef
import com.avek.chat.core.model.TaskMode
import com.avek.chat.core.model.ThinkingDepth
import com.avek.chat.core.model.ToolCall
import java.time.Instant

/** ISO-8601 UTC string to epoch millis; 0 for anything unparsable. */
fun parseInstant(iso: String): Long = try {
    if (iso.isBlank()) 0L else Instant.parse(iso).toEpochMilli()
} catch (_: Exception) {
    0L
}

fun ModelDto.toDomain() = RemoteModel(
    id = id,
    name = name.ifBlank { id },
    kind = if (kind.equals("vision", ignoreCase = true)) ModelKind.VISION else ModelKind.TEXT,
    note = note,
    contextTokens = contextTokens,
    rank = rank,
)

fun ChatSummaryDto.toDomain(isDownloaded: Boolean = false) = Conversation(
    id = chatId,
    title = title.ifBlank { "New chat" },
    createdAt = parseInstant(createdAt),
    updatedAt = parseInstant(updatedAt),
    isStarred = starred,
    isArchived = archived,
    modelId = modelId,
    taskMode = TaskMode.fromWire(mode),
    preview = preview,
    turnCount = turnCount,
    isDownloaded = isDownloaded,
)

fun SourceDto.toDomain() = SourceRef(title = title, domain = domain, snippet = snippet, url = url)

fun ToolDto.toDomain() = ToolCall(callId = callId, name = name, title = title, ok = ok, body = body)

fun AskRequestDto.toDomain() = AskRequest(
    askId = askId,
    chatId = chatId,
    promptId = promptId,
    kind = if (kind == "question") AskKind.QUESTION else AskKind.APPROVAL,
    tool = tool,
    summary = summary,
    detail = detail,
    choices = choices,
)

fun statusOf(wire: String): MessageStatus = when (wire) {
    "in-progress" -> MessageStatus.STREAMING
    "waiting" -> MessageStatus.WAITING
    "cancelled" -> MessageStatus.STOPPED
    "failed" -> MessageStatus.ERROR
    else -> MessageStatus.COMPLETE
}

fun feedbackOf(wire: String): Feedback = when (wire) {
    "up" -> Feedback.POSITIVE
    "down" -> Feedback.NEGATIVE
    else -> Feedback.NONE
}

fun Feedback.toWire(): String = when (this) {
    Feedback.POSITIVE -> "up"
    Feedback.NEGATIVE -> "down"
    Feedback.NONE -> "none"
}

fun userMessageId(promptId: String) = "$promptId:u"
fun assistantMessageId(promptId: String) = "$promptId:a"

/** A protocol turn becomes a user message and an assistant message sharing the `promptId`. */
fun TurnViewDto.toMessages(chatId: String): TurnMessages {
    val created = parseInstant(createdAt)
    val mode = TaskMode.fromWire(mode)
    val depthLevel = ThinkingDepth.fromLevel(depth)
    val user = Message(
        id = userMessageId(promptId),
        conversationId = chatId,
        role = Role.USER,
        content = user.text,
        createdAt = created,
        promptId = promptId,
        modelId = modelId,
        requestedTask = mode,
        depth = depthLevel,
        attachments = user.attachments.map { AttachmentInfo(it.name, it.mime, it.size) },
    )
    val assistant = Message(
        id = assistantMessageId(promptId),
        conversationId = chatId,
        role = Role.ASSISTANT,
        content = assistant.text,
        createdAt = created + 1,
        promptId = promptId,
        thinking = thinking?.text,
        hasThinking = thinking != null,
        thinkingDurationMs = thinking?.ms ?: 0L,
        modelId = modelId,
        requestedTask = mode,
        resolvedTask = mode.takeUnless { it.isAuto },
        depth = depthLevel,
        status = statusOf(status),
        feedback = feedbackOf(feedback),
        sources = sources.map { it.toDomain() },
        tools = tools.map { it.toDomain() },
        error = error,
    )
    return TurnMessages(user, assistant)
}
