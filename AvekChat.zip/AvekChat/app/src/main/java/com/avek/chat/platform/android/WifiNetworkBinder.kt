package com.avek.chat.platform.android

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.wifi.WifiManager
import com.avek.chat.core.link.transport.MulticastGuard
import com.avek.chat.core.link.transport.WifiBinding
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import com.avek.chat.core.link.transport.LocalAddress
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withTimeoutOrNull
import java.net.DatagramSocket
import javax.inject.Inject
import javax.inject.Singleton
import javax.net.SocketFactory

/**
 * Makes sockets go through the Wi-Fi network (UI-WIRE section 13, "Network"). A phone hotspot has no
 * internet, so Android would otherwise prefer mobile data, or drop the Wi-Fi, for our traffic.
 *
 * `requestNetwork` with `TRANSPORT_WIFI` and *without* the internet capability matches Wi-Fi
 * networks that cannot reach the internet; the callback keeps the network available (and the
 * Wi-Fi radio up) until [release]. Reference-counted.
 */
@Singleton
class WifiNetworkBinder @Inject constructor(
    @ApplicationContext context: Context,
) : WifiBinding {

    private val connectivity = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    private val network = MutableStateFlow<Network?>(null)
    private val _available = MutableStateFlow(false)
    override val available: StateFlow<Boolean> = _available
    private var holders = 0
    private var callback: ConnectivityManager.NetworkCallback? = null

    private val request = NetworkRequest.Builder()
        .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
        .removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        .build()

    @Synchronized
    override fun acquire() {
        if (holders++ > 0) return
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(available: Network) {
                network.value = available
                _available.value = true
            }

            override fun onLost(lost: Network) {
                if (network.value == lost) {
                    network.value = null
                    _available.value = false
                }
            }

            override fun onUnavailable() {
                network.value = null
                _available.value = false
            }
        }
        callback = cb
        try {
            connectivity.requestNetwork(request, cb)
        } catch (_: SecurityException) {
            // CHANGE_NETWORK_STATE missing or too many requests: fall back to the default route.
            callback = null
        } catch (_: RuntimeException) {
            callback = null
        }
    }

    @Synchronized
    override fun release() {
        if (holders == 0) return
        if (--holders > 0) return
        callback?.let { runCatching { connectivity.unregisterNetworkCallback(it) } }
        callback = null
        network.value = null
        _available.value = false
    }

    override suspend fun socketFactory(): SocketFactory? {
        val wifi = network.value ?: withTimeoutOrNull(WAIT_MS) { network.first { it != null } } ?: return null
        return wifi.socketFactory
    }

    override fun bind(socket: DatagramSocket) {
        network.value?.let { runCatching { it.bindSocket(socket) } }
    }

    /** The device's IPv4 address and prefix on the Wi-Fi network (for the subnet broadcast and the /24 sweep). */
    fun localAddress(): LocalAddress? {
        val wifi = network.value ?: return null
        val properties = connectivity.getLinkProperties(wifi) ?: return null
        val address = properties.linkAddresses.firstOrNull { it.address is java.net.Inet4Address } ?: return null
        return LocalAddress(address.address.hostAddress ?: return null, address.prefixLength)
    }

    private companion object {
        const val WAIT_MS = 1_500L
    }
}

/** Holds a `WifiManager.MulticastLock` so the radio delivers broadcast beacons while we listen. */
@Singleton
class AndroidMulticastGuard @Inject constructor(
    @ApplicationContext context: Context,
) : MulticastGuard {

    private val lock = (context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager)
        .createMulticastLock("avek-beacons")
        .apply { setReferenceCounted(true) }

    override fun acquire() {
        runCatching { lock.acquire() }
    }

    override fun release() {
        runCatching { if (lock.isHeld) lock.release() }
    }
}
