package com.avek.chat.core.data.downloads

import com.avek.chat.core.common.TimeProvider
import com.avek.chat.core.data.remote.parseInstant
import com.avek.chat.core.link.wire.ChatSummaryDto
import com.avek.chat.core.link.wire.TurnViewDto
import com.avek.chat.core.link.wire.WireJson
import com.avek.chat.core.model.Conversation
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map

class RoomDownloadedChatStore(
    database: DownloadDatabase,
    private val time: TimeProvider,
) : DownloadedChatStore {

    private val dao = database.downloadedDao()

    override fun observeInfo(): Flow<List<DownloadedChatInfo>> =
        combine(dao.observeChats(), dao.observeSizes()) { chats, sizes ->
            val bySize = sizes.associate { it.chatId to it.bytes }
            chats.map { DownloadedChatInfo(it.toConversation(), bySize[it.chatId] ?: 0L, it.downloadedAt) }
        }

    override fun observeIds(): Flow<Set<String>> = dao.observeIds().map { it.toSet() }.distinctUntilChanged()

    override suspend fun ids(): Set<String> = dao.ids().toSet()

    override suspend fun chat(chatId: String): Conversation? = dao.chat(chatId)?.toConversation()

    override suspend fun turns(chatId: String): List<TurnViewDto> =
        dao.turns(chatId).mapNotNull { runCatching { WireJson.decodeFromString(TurnViewDto.serializer(), it.json) }.getOrNull() }

    override suspend fun replace(chat: ChatSummaryDto, turns: List<TurnViewDto>) {
        dao.replace(chat.toEntity(time.now()), turns.map { it.toEntity(chat.chatId) })
    }

    override suspend fun upsertTurn(chatId: String, turn: TurnViewDto) {
        if (dao.chat(chatId) != null) dao.upsertTurn(turn.toEntity(chatId))
    }

    override suspend fun upsertChat(chat: ChatSummaryDto) {
        val existing = dao.chat(chat.chatId) ?: return
        dao.upsertChat(chat.toEntity(existing.downloadedAt))
    }

    override suspend fun delete(chatId: String) {
        dao.deleteChat(chatId)
    }

    private fun ChatSummaryDto.toEntity(downloadedAt: Long) = DownloadedChatEntity(
        chatId = chatId,
        title = title,
        createdAt = parseInstant(createdAt),
        updatedAt = parseInstant(updatedAt),
        modelId = modelId,
        mode = mode,
        turnCount = turnCount,
        preview = preview,
        starred = starred,
        archived = archived,
        downloadedAt = downloadedAt,
    )

    private fun TurnViewDto.toEntity(chatId: String) = DownloadedTurnEntity(
        chatId = chatId,
        promptId = promptId,
        createdAt = parseInstant(createdAt),
        json = WireJson.encodeToString(TurnViewDto.serializer(), this),
    )

    private fun DownloadedChatEntity.toConversation() = Conversation(
        id = chatId,
        title = title,
        createdAt = createdAt,
        updatedAt = updatedAt,
        isStarred = starred,
        isArchived = archived,
        modelId = modelId,
        taskMode = com.avek.chat.core.model.TaskMode.fromWire(mode),
        preview = preview,
        turnCount = turnCount,
        isDownloaded = true,
    )
}
