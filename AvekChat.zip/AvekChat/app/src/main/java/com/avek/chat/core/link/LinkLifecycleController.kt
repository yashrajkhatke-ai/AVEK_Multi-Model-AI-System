package com.avek.chat.core.link

import com.avek.chat.core.link.store.PairedPc
import com.avek.chat.core.model.settings.ConnectionSettings
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

/** Whether the app is on screen. The Android implementation counts started activities. */
interface AppVisibility {
    val visible: StateFlow<Boolean>
}

/** Starts / stops the foreground service that keeps the link alive off screen. */
fun interface BackgroundHost {
    fun setActive(active: Boolean)
}

/**
 * The foreground / background contract of UI-WIRE section 13:
 *  - visible: connected, all six topics;
 *  - off screen, "Work in background" off: close the connection after 30 s;
 *  - off screen, "Work in background" on: stay connected from the foreground service with the
 *    background profile (ask, turn, downloads).
 * Returning cancels a pending close and re-subscribes everything.
 */
class LinkLifecycleController(
    private val scope: CoroutineScope,
    private val visibility: StateFlow<Boolean>,
    private val settings: Flow<ConnectionSettings>,
    private val pairing: StateFlow<PairedPc?>,
    private val link: LinkRepository,
    private val background: BackgroundHost,
    private val graceMs: Long = GRACE_MS,
) {
    private data class Inputs(val visible: Boolean, val settings: ConnectionSettings, val paired: Boolean)

    fun start() {
        scope.launch {
            combine(visibility, settings, pairing) { visible, s, pc -> Inputs(visible, s, pc != null) }
                .collectLatest(::apply)
        }
    }

    private suspend fun apply(inputs: Inputs) {
        val wantsLink = !inputs.settings.demoMode && inputs.paired
        background.setActive(wantsLink && inputs.settings.workInBackground)
        when {
            !wantsLink -> link.disconnect()
            inputs.visible -> {
                link.connect()
                link.setProfile(LinkProfile.FOREGROUND)
            }
            inputs.settings.workInBackground -> {
                link.connect()
                link.setProfile(LinkProfile.BACKGROUND)
            }
            else -> {
                delay(graceMs) // cancelled by collectLatest if the app comes back first
                link.disconnect()
            }
        }
    }

    companion object {
        const val GRACE_MS = 30_000L
    }
}
