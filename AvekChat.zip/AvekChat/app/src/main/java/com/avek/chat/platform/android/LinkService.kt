package com.avek.chat.platform.android

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.ServiceCompat
import com.avek.chat.core.link.LinkRepository
import com.avek.chat.core.link.route.ConnectionState
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * Keeps the app (and with it the link to the PC) alive while it is off screen and "Work in
 * background" is on. The link itself is owned by the app; this service only holds the foreground
 * notification ("Connected to <PC>") and a Wi-Fi lock so the radio stays up.
 */
@AndroidEntryPoint
class LinkService : Service() {

    @Inject lateinit var link: LinkRepository
    @Inject lateinit var notifications: AvekNotifications

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var wifiLock: WifiManager.WifiLock? = null

    override fun onCreate() {
        super.onCreate()
        enterForeground(notifications.foreground("Connecting…"))
        acquireWifiLock()
        scope.launch {
            link.state.map(::describe).distinctUntilChanged().collect { notifications.updateForeground(it) }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        scope.cancel()
        runCatching { wifiLock?.takeIf { it.isHeld }?.release() }
        wifiLock = null
        super.onDestroy()
    }

    private fun enterForeground(notification: android.app.Notification) {
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        ServiceCompat.startForeground(this, AvekNotifications.FOREGROUND_ID, notification, type)
    }

    private fun acquireWifiLock() {
        val wifi = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) WifiManager.WIFI_MODE_FULL_LOW_LATENCY else WifiManager.WIFI_MODE_FULL_HIGH_PERF
        wifiLock = wifi.createWifiLock(mode, "avek-link").apply {
            setReferenceCounted(false)
            runCatching { acquire() }
        }
    }

    private fun describe(state: ConnectionState): String = when (state) {
        is ConnectionState.Connected -> "Connected to ${state.serverName}"
        is ConnectionState.Connecting -> "Reconnecting to your PC…"
        ConnectionState.NotPaired -> "No PC paired"
        ConnectionState.Disconnected -> "Waiting"
        is ConnectionState.Failed -> state.reason
    }
}
