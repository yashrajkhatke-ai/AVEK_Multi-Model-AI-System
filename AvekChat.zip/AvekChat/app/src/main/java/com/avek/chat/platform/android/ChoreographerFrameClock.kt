package com.avek.chat.platform.android

import android.view.Choreographer
import com.avek.chat.core.domain.chat.FrameClock
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume

/** Waits for the next display frame (vsync), so streamed text reaches the screen once per frame. */
class ChoreographerFrameClock : FrameClock {
    override suspend fun awaitFrame() = withContext(Dispatchers.Main.immediate) {
        suspendCancellableCoroutine { continuation ->
            val choreographer = Choreographer.getInstance()
            val callback = Choreographer.FrameCallback { if (continuation.isActive) continuation.resume(Unit) }
            choreographer.postFrameCallback(callback)
            continuation.invokeOnCancellation { choreographer.removeFrameCallback(callback) }
        }
    }
}
