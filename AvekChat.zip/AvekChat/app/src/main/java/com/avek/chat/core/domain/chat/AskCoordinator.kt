package com.avek.chat.core.domain.chat

import com.avek.chat.core.data.remote.toDomain
import com.avek.chat.core.link.HarnessApi
import com.avek.chat.core.link.LinkRepository
import com.avek.chat.core.link.rpc.RpcException
import com.avek.chat.core.link.route.ConnectionState
import com.avek.chat.core.link.wire.ErrorCodes
import com.avek.chat.core.link.wire.LinkEvent
import com.avek.chat.core.model.AskRequest
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/**
 * Questions from the PC ("doubts", UI-WIRE section 8.5). Holds the open ones, answers them,
 * and drops one when `ask.resolved` arrives (someone else answered) or the PC says `expired`.
 * A pending ask is never lost: after any reconnect the PC re-sends it in `ready.pendingAsks`.
 */
class AskCoordinator(
    private val api: HarnessApi,
    private val link: LinkRepository,
    private val scope: CoroutineScope,
) {
    private val _pending = MutableStateFlow<List<AskRequest>>(emptyList())
    val pending: StateFlow<List<AskRequest>> = _pending

    fun start() {
        scope.launch {
            // Each connection re-delivers what is still open; start from a clean slate.
            link.state.map { it is ConnectionState.Connected }.distinctUntilChanged().collect { connected ->
                if (connected) _pending.value = emptyList()
            }
        }
        scope.launch {
            link.events.collect { event ->
                when (event) {
                    is LinkEvent.AskRequest -> {
                        val ask = event.data.toDomain()
                        _pending.update { list -> if (list.any { it.askId == ask.askId }) list else list + ask }
                    }
                    is LinkEvent.AskResolved -> remove(event.data.askId)
                    else -> Unit
                }
            }
        }
    }

    suspend fun decide(ask: AskRequest, decision: String) = answer(ask) { api.askAnswerDecision(ask.askId, decision) }

    suspend fun reply(ask: AskRequest, text: String) = answer(ask) { api.askAnswerText(ask.askId, text) }

    private suspend fun answer(ask: AskRequest, send: suspend () -> Unit) {
        try {
            send()
            remove(ask.askId)
        } catch (e: RpcException) {
            if (e.code == ErrorCodes.EXPIRED || e.code == ErrorCodes.NOT_FOUND) remove(ask.askId) else throw e
        }
    }

    private fun remove(askId: String) = _pending.update { list -> list.filterNot { it.askId == askId } }
}
