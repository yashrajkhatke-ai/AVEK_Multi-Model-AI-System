package com.avek.chat.platform.android

import androidx.biometric.BiometricManager
import android.os.Build
import androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_STRONG
import androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_WEAK
import androidx.biometric.BiometricManager.Authenticators.DEVICE_CREDENTIAL
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import com.avek.chat.feature.lock.PhoneAuthenticator

/**
 * The phone's own check (UI-WIRE v4 section 13, "App lock"): BiometricPrompt with
 * `BIOMETRIC_STRONG or DEVICE_CREDENTIAL` (fingerprint/face, or the phone's PIN, pattern or password).
 * Local only: no Google services. [onPromptShowing] tells the activity that the system credential
 * screen may stop it for a moment, so that is not counted as leaving the app.
 */
class BiometricAuthenticator(
    private val activity: FragmentActivity,
    private val onPromptShowing: (Boolean) -> Unit,
) : PhoneAuthenticator {

    /**
     * `BIOMETRIC_STRONG or DEVICE_CREDENTIAL` as the spec says. Android 9 and 10 (API 28-29) refuse that
     * combination, so there the prompt accepts any enrolled biometric or the screen lock instead.
     */
    private val allowed = if (Build.VERSION.SDK_INT in 28..29) BIOMETRIC_WEAK or DEVICE_CREDENTIAL else BIOMETRIC_STRONG or DEVICE_CREDENTIAL

    override fun available(): Boolean =
        BiometricManager.from(activity).canAuthenticate(allowed) == BiometricManager.BIOMETRIC_SUCCESS

    override fun authenticate(onResult: (Boolean) -> Unit) {
        val prompt = BiometricPrompt(
            activity,
            ContextCompat.getMainExecutor(activity),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    onPromptShowing(false)
                    onResult(true)
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    onPromptShowing(false)
                    onResult(false)
                }

                // onAuthenticationFailed: one wrong finger; the prompt stays open and lets the person retry.
            },
        )
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Unlock AVEK")
            .setSubtitle("Use your fingerprint or your phone's screen lock")
            .setAllowedAuthenticators(allowed)
            .build()
        onPromptShowing(true)
        try {
            prompt.authenticate(info)
        } catch (e: Exception) {
            onPromptShowing(false)
            onResult(false)
        }
    }
}
