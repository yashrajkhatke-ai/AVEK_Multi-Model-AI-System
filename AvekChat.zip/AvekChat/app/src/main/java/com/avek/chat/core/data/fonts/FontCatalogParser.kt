package com.avek.chat.core.data.fonts

import com.avek.chat.core.model.FontCategory
import com.avek.chat.core.model.FontInfo

/**
 * Parses the bundled `font_catalog.tsv` asset:
 * `family<TAB>category<TAB>weights(csv)<TAB>hasItalic(0|1)`.
 */
object FontCatalogParser {

    fun parse(lines: Sequence<String>): List<FontInfo> = lines
        .filter { it.isNotBlank() && !it.startsWith("#") }
        .mapNotNull(::parseLine)
        .toList()

    private fun parseLine(line: String): FontInfo? {
        val parts = line.split('\t')
        if (parts.size < 4) return null
        val category = when (parts[1]) {
            "sans" -> FontCategory.SANS
            "serif" -> FontCategory.SERIF
            "display" -> FontCategory.DISPLAY
            "handwriting" -> FontCategory.HANDWRITING
            "mono" -> FontCategory.MONO
            else -> return null
        }
        val weights = parts[2].split(',').mapNotNull { it.trim().toIntOrNull() }.ifEmpty { listOf(400) }
        return FontInfo(parts[0], category, weights, parts[3].trim() == "1")
    }
}
