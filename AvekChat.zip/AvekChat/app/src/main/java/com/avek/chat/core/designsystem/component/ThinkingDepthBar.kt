package com.avek.chat.core.designsystem.component

import androidx.compose.animation.AnimatedContent
import com.avek.chat.core.designsystem.theme.avekPill
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.Layout
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import com.avek.chat.core.designsystem.motion.DepthGlyph
import com.avek.chat.core.designsystem.motion.rememberPhase
import com.avek.chat.core.designsystem.theme.AvekTheme
import com.avek.chat.core.designsystem.theme.ColorMath
import com.avek.chat.core.model.ThinkingDepth
import kotlin.math.PI
import kotlin.math.roundToInt
import kotlin.math.sin

private val ShortLabels = listOf("Instant", "Light", "Balanced", "Deep", "Extended", "Max")

/**
 * A draggable reasoning-depth control. Every level has its own emblem
 * animation, the filled track carries a flow of "energy" that speeds up with
 * depth, and levels the current model can't reach are fenced off.
 */
@Composable
fun ThinkingDepthBar(
    depth: ThinkingDepth,
    onDepthChange: (ThinkingDepth) -> Unit,
    maxDepth: ThinkingDepth,
    modelName: String,
    modifier: Modifier = Modifier,
) {
    val colors = AvekTheme.colors
    val motion = AvekTheme.motion
    val haptics = LocalHapticFeedback.current
    val maxLevel = ThinkingDepth.MAX_LEVEL.toFloat()

    val currentDepth by rememberUpdatedState(depth)
    val currentOnChange by rememberUpdatedState(onDepthChange)
    var dragging by remember { mutableStateOf(false) }
    var dragFraction by remember { mutableFloatStateOf(depth.level / maxLevel) }
    val settled by animateFloatAsState(
        targetValue = depth.level / maxLevel,
        animationSpec = spring(dampingRatio = 0.7f, stiffness = Spring.StiffnessMediumLow),
        label = "depth-thumb",
    )
    val fraction = if (dragging) dragFraction else settled
    val capFraction = maxDepth.level / maxLevel

    fun select(rawFraction: Float) {
        val level = (rawFraction.coerceIn(0f, capFraction) * maxLevel).roundToInt()
        if (level != currentDepth.level) {
            if (motion.haptics) haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
            currentOnChange(ThinkingDepth.fromLevel(level))
        }
    }

    Column(modifier) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(54.dp)
                    .clip(CircleShape)
                    .background(colors.accentContainer),
                contentAlignment = Alignment.Center,
            ) {
                AnimatedContent(
                    targetState = depth,
                    transitionSpec = { (fadeIn() + scaleIn(initialScale = 0.5f)) togetherWith (fadeOut() + scaleOut(targetScale = 1.5f)) },
                    label = "depth-glyph",
                ) { level ->
                    DepthGlyph(level, colors.thinkingGlow, Modifier.size(34.dp), motion.animationSpeed, animate = !motion.reduceMotion)
                }
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    AnimatedContent(
                        targetState = depth,
                        transitionSpec = {
                            val up = targetState.level >= initialState.level
                            (slideInVertically { if (up) it else -it } + fadeIn()) togetherWith
                                (slideOutVertically { if (up) -it else it } + fadeOut())
                        },
                        label = "depth-label",
                    ) { level ->
                        Text(level.label, style = AvekTheme.type.title, color = colors.textPrimary)
                    }
                    Spacer(Modifier.width(8.dp))
                    Text(
                        depth.budgetLabel,
                        style = AvekTheme.type.caption.copy(fontWeight = FontWeight.Medium),
                        color = colors.accent,
                        modifier = Modifier
                            .clip(avekPill())
                            .background(colors.accentContainer)
                            .padding(horizontal = 8.dp, vertical = 2.dp),
                    )
                }
                AnimatedContent(targetState = depth.description, label = "depth-desc") { text ->
                    Text(text, style = AvekTheme.type.bodySmall, color = colors.textSecondary)
                }
            }
        }

        Spacer(Modifier.height(18.dp))

        val density = LocalDensity.current
        val thumbSize = 44.dp
        val insetPx = with(density) { (thumbSize / 2).toPx() }
        val energy = rememberPhase(
            durationMillis = (2600 / (1f + depth.level * 0.6f) / motion.animationSpeed.coerceIn(0.25f, 3f)).toInt(),
            animate = !motion.reduceMotion && depth.thinks,
            label = "depth-energy",
        )

        BoxWithConstraints(
            Modifier
                .fillMaxWidth()
                .height(thumbSize)
                .pointerInput(maxDepth) {
                    detectTapGestures { offset ->
                        select((offset.x - insetPx) / (size.width - 2 * insetPx))
                    }
                }
                .pointerInput(maxDepth) {
                    detectHorizontalDragGestures(
                        onDragStart = { offset ->
                            dragging = true
                            dragFraction = ((offset.x - insetPx) / (size.width - 2 * insetPx)).coerceIn(0f, capFraction)
                        },
                        onDragEnd = { dragging = false },
                        onDragCancel = { dragging = false },
                    ) { change, _ ->
                        change.consume()
                        dragFraction = ((change.position.x - insetPx) / (size.width - 2 * insetPx)).coerceIn(0f, capFraction)
                        select(dragFraction)
                    }
                },
        ) {
            val widthPx = with(density) { maxWidth.toPx() }
            val usable = widthPx - 2 * insetPx

            Canvas(Modifier.fillMaxSize()) {
                val y = size.height / 2
                val trackH = 6.dp.toPx()
                val start = insetPx
                val end = size.width - insetPx
                val thumbX = start + usable * fraction
                val capX = start + usable * capFraction

                // Base track.
                drawRoundRect(
                    color = colors.outline.copy(alpha = 0.55f),
                    topLeft = Offset(start, y - trackH / 2),
                    size = Size(capX - start, trackH),
                    cornerRadius = CornerRadius(trackH / 2),
                )
                // Locked levels for this model.
                if (capX < end) {
                    drawLine(
                        color = colors.outline,
                        start = Offset(capX + trackH, y),
                        end = Offset(end, y),
                        strokeWidth = trackH * 0.6f,
                        cap = StrokeCap.Round,
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(trackH * 0.8f, trackH * 1.4f)),
                    )
                }
                // Active, energised segment.
                if (thumbX > start) {
                    val hot = ColorMath.shift(colors.thinkingGlow, lightnessDelta = 0.1f, hueDelta = 18f)
                    drawRoundRect(
                        brush = Brush.horizontalGradient(
                            listOf(colors.accent.copy(alpha = 0.45f), colors.thinkingGlow, if (depth.level >= 4) hot else colors.thinkingGlow),
                            startX = start,
                            endX = thumbX,
                        ),
                        topLeft = Offset(start, y - trackH / 2),
                        size = Size(thumbX - start, trackH),
                        cornerRadius = CornerRadius(trackH / 2),
                    )
                    if (depth.thinks) {
                        val t = energy.value
                        val active = thumbX - start
                        val glowX = start + active * t
                        drawRoundRect(
                            brush = Brush.horizontalGradient(
                                listOf(Color.Transparent, Color.White.copy(alpha = 0.55f), Color.Transparent),
                                startX = glowX - 40.dp.toPx(),
                                endX = glowX + 40.dp.toPx(),
                            ),
                            topLeft = Offset(start, y - trackH / 2),
                            size = Size(active, trackH),
                            cornerRadius = CornerRadius(trackH / 2),
                        )
                        // Extended and Maximum throw sparks along the track.
                        if (depth.level >= 4) {
                            val sparks = if (depth == ThinkingDepth.MAXIMUM) 10 else 5
                            for (i in 0 until sparks) {
                                val p = (t + i.toFloat() / sparks) % 1f
                                val sx = start + active * p
                                val sy = y + sin((p * 6 * PI + i).toFloat()) * trackH * 1.6f
                                drawCircle(hot.copy(alpha = 1f - p * 0.6f), radius = trackH * 0.38f, center = Offset(sx, sy))
                            }
                        }
                    }
                }
                // Notches.
                for (i in 0..ThinkingDepth.MAX_LEVEL) {
                    val x = start + usable * (i / maxLevel)
                    val reached = i <= depth.level
                    val locked = i > maxDepth.level
                    drawCircle(
                        color = when {
                            locked -> colors.outline
                            reached -> colors.onAccent
                            else -> colors.textTertiary
                        },
                        radius = if (locked) trackH * 0.35f else trackH * 0.42f,
                        center = Offset(x, y),
                    )
                }
            }

            val thumbPx = with(density) { thumbSize.toPx() }
            Box(
                Modifier
                    .offset { IntOffset((insetPx + usable * fraction - thumbPx / 2).roundToInt(), 0) }
                    .size(thumbSize)
                    .shadow(if (dragging) 10.dp else 4.dp, CircleShape)
                    .clip(CircleShape)
                    .background(colors.surface)
                    .border(2.dp, colors.thinkingGlow, CircleShape),
                contentAlignment = Alignment.Center,
            ) {
                DepthGlyph(depth, colors.thinkingGlow, Modifier.size(26.dp), motion.animationSpeed, animate = !motion.reduceMotion)
            }
        }

        Spacer(Modifier.height(6.dp))
        val insetDp = thumbSize / 2
        Layout(
            content = {
                ThinkingDepth.entries.forEach { level ->
                    val locked = level.level > maxDepth.level
                    Text(
                        ShortLabels[level.level],
                        style = AvekTheme.type.caption.copy(fontWeight = if (level == depth) FontWeight.SemiBold else FontWeight.Normal),
                        color = when {
                            level == depth -> colors.accent
                            locked -> colors.textTertiary.copy(alpha = 0.6f)
                            else -> colors.textSecondary
                        },
                    )
                }
            },
            modifier = Modifier.fillMaxWidth(),
        ) { measurables, constraints ->
            val placeables = measurables.map { it.measure(Constraints()) }
            val width = constraints.maxWidth
            val inset = insetDp.roundToPx()
            val height = placeables.maxOfOrNull { it.height } ?: 0
            layout(width, height) {
                placeables.forEachIndexed { i, p ->
                    val cx = inset + (width - 2 * inset) * i / ThinkingDepth.MAX_LEVEL
                    p.place((cx - p.width / 2).coerceIn(0, (width - p.width).coerceAtLeast(0)), 0)
                }
            }
        }

        if (maxDepth != ThinkingDepth.MAXIMUM) {
            Spacer(Modifier.height(10.dp))
            Text(
                "$modelName reasons up to ${maxDepth.label}. Pick Atlas or Sage for Maximum.",
                style = AvekTheme.type.caption,
                color = colors.textTertiary,
            )
        }
    }
}
