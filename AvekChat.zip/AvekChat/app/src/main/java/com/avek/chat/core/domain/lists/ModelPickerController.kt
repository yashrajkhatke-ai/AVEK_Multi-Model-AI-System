package com.avek.chat.core.domain.lists

import com.avek.chat.core.domain.repository.ModelRepository
import com.avek.chat.core.model.RemoteModel
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class ModelPickerState(
    val models: List<RemoteModel> = emptyList(),
    /** True until the last part arrived: with no models yet the sheet shows a skeleton. */
    val loading: Boolean = false,
    val error: String? = null,
)

/**
 * Backs the model sheet: `models.list {limit:"all"}` is requested only when the sheet opens and
 * fills one model at a time. Memory follows the same countdown as the chat list.
 */
class ModelPickerController(
    private val scope: CoroutineScope,
    private val models: ModelRepository,
    keepSeconds: () -> Int,
    registry: ListMemoryRegistry? = null,
) {
    private val _state = MutableStateFlow(ModelPickerState())
    val state: StateFlow<ModelPickerState> = _state

    private val memory = ListMemoryController(scope, keepSeconds, ::onDrop).also { registry?.register(it) }
    private var job: Job? = null

    @Synchronized
    fun opened() {
        memory.inUse()
        if (_state.value.models.isEmpty() && job?.isActive != true) load()
    }

    fun closed() = memory.idle()

    fun trim() = memory.trim()

    @Synchronized
    fun reload() {
        reset()
        load()
    }

    private fun onDrop() {
        reset()
        if (memory.isActive) load()
    }

    @Synchronized
    private fun reset() {
        job?.cancel()
        job = null
        _state.value = ModelPickerState()
    }

    private fun load() {
        _state.value = ModelPickerState(loading = true)
        job = scope.launch {
            try {
                models.allModels().collect { model ->
                    _state.update { it.copy(models = it.models + model) }
                }
                _state.update { it.copy(loading = false) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _state.update { it.copy(loading = false, error = e.message ?: "Could not load models") }
            }
        }
    }
}
