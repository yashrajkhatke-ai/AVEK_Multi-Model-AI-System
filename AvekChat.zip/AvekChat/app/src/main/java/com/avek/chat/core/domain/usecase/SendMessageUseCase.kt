package com.avek.chat.core.domain.usecase

import com.avek.chat.core.common.IdGenerator
import com.avek.chat.core.common.TimeProvider
import com.avek.chat.core.domain.repository.ConversationRepository
import com.avek.chat.core.model.Message
import com.avek.chat.core.model.Role
import javax.inject.Inject

/**
 * Persists a new user turn, creating the conversation on first message.
 * Returns the id of the conversation the message landed in.
 */
class SendMessageUseCase @Inject constructor(
    private val repository: ConversationRepository,
    private val titleGenerator: TitleGenerator,
    private val ids: IdGenerator,
    private val time: TimeProvider,
) {
    suspend operator fun invoke(
        conversationId: String?,
        text: String,
        options: ChatOptions,
        autoTitle: Boolean,
    ): String {
        val content = text.trim()
        require(content.isNotEmpty()) { "Cannot send an empty message" }

        val id = conversationId ?: repository.createConversation(
            title = if (autoTitle) titleGenerator.generate(content) else TitleGenerator.DEFAULT_TITLE,
            modelId = options.modelId,
            taskMode = options.task,
        ).id

        val previous = repository.getMessages(id).lastOrNull()
        repository.upsertMessage(
            Message(
                id = ids.newId(),
                conversationId = id,
                role = Role.USER,
                content = content,
                createdAt = maxOf(time.now(), (previous?.createdAt ?: 0L) + 1),
                modelId = options.modelId,
                requestedTask = options.task,
                depth = options.depth,
            ),
        )
        repository.refreshSummary(id, options.modelId, options.task)
        return id
    }
}
