package com.avek.chat.platform.android

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import com.avek.chat.core.link.store.Seal
import com.avek.chat.core.link.store.SecretVault
import com.avek.chat.core.link.store.VaultException
import java.security.KeyStore
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Seals `dk`, `rk` and the stored routes (UI-WIRE v4 section 13) with the AES-256-GCM Keystore key
 * `avek.seal`: hardware-backed (StrongBox when available), no user-authentication requirement (the
 * app reconnects in the background), a random 12-byte IV chosen by the Keystore and prepended.
 */
@Singleton
class AndroidSecretVault @Inject constructor() : SecretVault {

    private fun keyStore(): KeyStore = KeyStore.getInstance(PROVIDER).apply { load(null) }

    @Synchronized
    private fun key(): SecretKey {
        (keyStore().getKey(ALIAS, null) as? SecretKey)?.let { return it }
        return try {
            generate(strongBox = true)
        } catch (_: Exception) {
            runCatching { keyStore().deleteEntry(ALIAS) }
            try {
                generate(strongBox = false)
            } catch (e: Exception) {
                throw VaultException("Could not create the sealing key", e)
            }
        }
    }

    private fun generate(strongBox: Boolean): SecretKey {
        val builder = KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .setRandomizedEncryptionRequired(true)
            .setUserAuthenticationRequired(false)
        if (strongBox && android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.P) builder.setIsStrongBoxBacked(true)
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, PROVIDER)
        generator.init(builder.build())
        return generator.generateKey()
    }

    override fun seal(plain: ByteArray): ByteArray = Seal.seal(key(), plain, random = null)

    override fun open(sealed: ByteArray): ByteArray = Seal.open(key(), sealed)

    @Synchronized
    override fun destroy() {
        runCatching { keyStore().deleteEntry(ALIAS) }
    }

    private companion object {
        const val PROVIDER = "AndroidKeyStore"
        const val ALIAS = "avek.seal"
    }
}
