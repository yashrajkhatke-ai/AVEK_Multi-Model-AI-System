package com.avek.chat.core.data.link

import com.avek.chat.core.link.LinkProfile
import com.avek.chat.core.link.LinkRepository
import com.avek.chat.core.link.rpc.ListPart
import com.avek.chat.core.link.rpc.RpcTimeouts
import com.avek.chat.core.link.route.ConnectionState
import com.avek.chat.core.link.wire.EmptyArgs
import com.avek.chat.core.link.wire.LinkEvent
import com.avek.chat.core.link.wire.ReadyDto
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject

/**
 * The link the rest of the app sees: the real one, or the built-in demo while "Demo mode" is on.
 * Flipping the switch disconnects the one that is leaving, connects the one that is arriving,
 * and raises [LinkEvent.Refresh] so every screen reloads from the new source.
 */
@OptIn(ExperimentalCoroutinesApi::class)
class SwitchingLinkRepository(
    private val real: LinkRepository,
    private val demo: LinkRepository,
    demoMode: Flow<Boolean>,
    private val scope: CoroutineScope,
) : LinkRepository {

    private val useDemo = MutableStateFlow(false)
    private val activeFlow = MutableStateFlow(real)
    private val active: StateFlow<LinkRepository> get() = activeFlow

    private val _events = MutableSharedFlow<LinkEvent>(extraBufferCapacity = 1024)
    private val _profile = MutableStateFlow(LinkProfile.FOREGROUND)
    private var wanted = false

    init {
        scope.launch { activeFlow.flatMapLatest { it.events }.collect { _events.emit(it) } }
        scope.launch {
            demoMode.distinctUntilChanged().collect { demoOn ->
                val previous = activeFlow.value
                val next = if (demoOn) demo else real
                useDemo.value = demoOn
                if (previous !== next) {
                    previous.disconnect()
                    activeFlow.value = next
                    next.setProfile(_profile.value)
                    if (wanted) next.connect()
                    _events.emit(LinkEvent.Refresh)
                }
            }
        }
    }

    override val state: StateFlow<ConnectionState> =
        activeFlow.flatMapLatest { it.state }.stateIn(scope, SharingStarted.Eagerly, real.state.value)

    override val events: SharedFlow<LinkEvent> = _events.asSharedFlow()

    override val ready: StateFlow<ReadyDto?> =
        activeFlow.flatMapLatest { it.ready }.stateIn(scope, SharingStarted.Eagerly, real.ready.value)

    override val profile: StateFlow<LinkProfile> = _profile

    override fun connect() {
        wanted = true
        active.value.connect()
    }

    override fun disconnect() {
        wanted = false
        active.value.disconnect()
    }

    override fun reconnect() {
        wanted = true
        active.value.reconnect()
    }

    override fun setProfile(profile: LinkProfile) {
        _profile.value = profile
        active.value.setProfile(profile)
    }

    override suspend fun call(op: String, args: JsonObject, timeoutMs: Long): JsonElement =
        active.value.call(op, args, timeoutMs)

    override fun callList(op: String, args: JsonObject, timeoutMs: Long): Flow<ListPart> =
        active.value.callList(op, args, timeoutMs)

    /** True while the built-in demo is the active link. */
    val isDemo: StateFlow<Boolean> get() = useDemo
}
