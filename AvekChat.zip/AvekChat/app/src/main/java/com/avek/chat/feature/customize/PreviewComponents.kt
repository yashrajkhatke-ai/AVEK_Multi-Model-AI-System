package com.avek.chat.feature.customize

import androidx.compose.animation.animateColorAsState
import com.avek.chat.core.designsystem.theme.avekShape
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.avek.chat.core.designsystem.component.AvekSpark
import com.avek.chat.core.designsystem.motion.ThinkingIndicator
import com.avek.chat.core.designsystem.theme.AvekColors
import com.avek.chat.core.designsystem.theme.AvekTheme
import com.avek.chat.core.designsystem.theme.ColorMath
import com.avek.chat.core.designsystem.theme.ThemeDefinition
import com.avek.chat.core.markdown.MarkdownContent
import com.avek.chat.core.model.settings.AssistantStyle
import com.avek.chat.core.model.settings.BubbleStyle
import com.avek.chat.core.model.settings.UserAlignment

/**
 * A miniature, fully themed chat that reflects every customisation instantly:
 * sidebar, bubbles, thinking panel with its live animation, answer, composer.
 */
@Composable
fun LivePreview(modifier: Modifier = Modifier) {
    val colors = AvekTheme.colors
    val layout = AvekTheme.layout
    val motion = AvekTheme.motion
    Row(
        modifier
            .clip(avekShape(24.dp))
            .background(colors.chatBackground)
            .border(1.dp, colors.outline, avekShape(24.dp)),
    ) {
        // Sidebar sliver.
        Column(
            Modifier
                .width(64.dp)
                .fillMaxHeight()
                .background(colors.sidebar)
                .padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            AvekSpark(colors.thinkingGlow, Modifier.size(18.dp))
            Spacer(Modifier.height(2.dp))
            repeat(4) { i ->
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(14.dp)
                        .clip(avekShape(5.dp))
                        .background(if (i == 1) colors.sidebarSelected else colors.sidebarText.copy(alpha = 0.08f)),
                )
            }
        }

        Column(
            Modifier
                .weight(1f)
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            PreviewUserBubble("Plan a calm weekend in Kyoto?", Modifier.fillMaxWidth())

            Row(
                Modifier
                    .clip(avekShape(12.dp))
                    .background(colors.thinkingSurface)
                    .padding(horizontal = 10.dp, vertical = 7.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                ThinkingIndicator(
                    motion.thinkingAnimation,
                    colors.thinkingGlow,
                    Modifier.size(16.dp),
                    intensity = 0.6f,
                    speed = motion.animationSpeed,
                    animate = !motion.reduceMotion,
                )
                Spacer(Modifier.width(8.dp))
                Text("Weighing temples vs. gardens…", style = AvekTheme.type.thinking.copy(fontSize = AvekTheme.type.caption.fontSize), color = colors.thinkingText, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }

            val answer = "**Day 1** — Arashiyama at dawn, then a slow lunch by the river. Keep afternoons light."
            val answerModifier = when (layout.assistantStyle) {
                AssistantStyle.PLAIN -> Modifier
                AssistantStyle.CARD -> Modifier
                    .clip(avekShape(14.dp))
                    .background(colors.assistantBubble)
                    .border(1.dp, colors.outline, avekShape(14.dp))
                    .padding(10.dp)
                AssistantStyle.BUBBLE -> Modifier
                    .clip(avekShape(14.dp))
                    .background(colors.assistantBubble)
                    .padding(10.dp)
            }
            MarkdownContent(
                markdown = answer,
                textStyle = AvekTheme.type.answer.copy(fontSize = AvekTheme.type.answer.fontSize * 0.85f, lineHeight = AvekTheme.type.answer.lineHeight * 0.85f),
                color = colors.assistantText,
                modifier = answerModifier,
            )

            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(avekShape(18.dp))
                    .background(colors.composer)
                    .border(1.dp, colors.composerBorder, avekShape(18.dp))
                    .padding(start = 12.dp, end = 6.dp, top = 6.dp, bottom = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("Reply…", style = AvekTheme.type.userMessage.copy(fontSize = AvekTheme.type.caption.fontSize), color = colors.textTertiary, modifier = Modifier.weight(1f))
                Box(Modifier.size(22.dp).clip(CircleShape).background(colors.accent))
            }
        }
    }
}

@Composable
fun PreviewUserBubble(text: String, modifier: Modifier = Modifier, style: BubbleStyle = AvekTheme.layout.bubbleStyle) {
    val colors = AvekTheme.colors
    val layout = AvekTheme.layout
    val corner = (layout.bubbleCornerDp * 0.8f).dp
    val shape = avekShape(corner, corner, corner, corner, scaled = false)
    val (bg, fg) = bubbleColors(style, colors)
    Box(modifier, contentAlignment = if (layout.userAlignment == UserAlignment.END) Alignment.CenterEnd else Alignment.CenterStart) {
        Box(
            Modifier
                .widthIn(max = 220.dp)
                .clip(shape)
                .then(
                    when (style) {
                        BubbleStyle.OUTLINED -> Modifier.border(1.5.dp, colors.accent.copy(alpha = 0.55f), shape)
                        BubbleStyle.GRADIENT -> Modifier.background(Brush.linearGradient(listOf(colors.accent, ColorMath.shift(colors.accent, hueDelta = 38f, lightnessDelta = -0.04f))))
                        BubbleStyle.MINIMAL -> Modifier
                        else -> Modifier.background(bg)
                    },
                )
                .padding(horizontal = if (style == BubbleStyle.MINIMAL) 0.dp else 12.dp, vertical = 7.dp),
        ) {
            Text(
                text,
                style = AvekTheme.type.userMessage.copy(fontSize = AvekTheme.type.userMessage.fontSize * 0.82f, lineHeight = AvekTheme.type.userMessage.lineHeight * 0.82f),
                color = fg,
            )
        }
    }
}

private fun bubbleColors(style: BubbleStyle, colors: AvekColors) = when (style) {
    BubbleStyle.FILLED -> colors.userBubble to colors.userText
    BubbleStyle.TINTED -> colors.accentContainer to colors.textPrimary
    BubbleStyle.OUTLINED -> colors.chatBackground to colors.textPrimary
    BubbleStyle.GRADIENT -> colors.accent to colors.onAccent
    BubbleStyle.MINIMAL -> colors.chatBackground to colors.textPrimary
}

/** A gallery tile drawing a theme's palette as a tiny chat window. */
@Composable
fun ThemeSwatch(
    theme: ThemeDefinition,
    dark: Boolean,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val c = theme.colors(dark)
    val ui = AvekTheme.colors
    val ring by animateColorAsState(if (selected) ui.accent else ui.outline.copy(alpha = 0.6f), label = "swatch-ring")
    Column(
        modifier
            .clip(avekShape(18.dp))
            .clickable(onClick = onClick)
            .padding(4.dp),
    ) {
        Canvas(
            Modifier
                .fillMaxWidth()
                .height(92.dp)
                .clip(avekShape(14.dp))
                .border(if (selected) 2.5.dp else 1.dp, ring, avekShape(14.dp)),
        ) {
            val w = size.width
            val h = size.height
            drawRect(c.chatBackground)
            // sidebar
            drawRect(c.sidebar, size = Size(w * 0.24f, h))
            for (i in 0 until 4) {
                drawRoundRect(
                    if (i == 1) c.sidebarSelected else c.sidebarText.copy(alpha = 0.12f),
                    topLeft = Offset(w * 0.03f, h * (0.18f + i * 0.16f)),
                    size = Size(w * 0.18f, h * 0.09f),
                    cornerRadius = CornerRadius(h * 0.04f),
                )
            }
            // user bubble
            drawRoundRect(c.userBubble, topLeft = Offset(w * 0.56f, h * 0.1f), size = Size(w * 0.38f, h * 0.17f), cornerRadius = CornerRadius(h * 0.085f))
            // thinking chip
            drawRoundRect(c.thinkingSurface, topLeft = Offset(w * 0.3f, h * 0.34f), size = Size(w * 0.34f, h * 0.12f), cornerRadius = CornerRadius(h * 0.06f))
            drawCircle(c.thinkingGlow, radius = h * 0.035f, center = Offset(w * 0.335f, h * 0.4f))
            // answer lines
            for (i in 0 until 2) {
                drawRoundRect(c.assistantText.copy(alpha = 0.55f), topLeft = Offset(w * 0.3f, h * (0.53f + i * 0.1f)), size = Size(w * (0.6f - i * 0.18f), h * 0.045f), cornerRadius = CornerRadius(h * 0.02f))
            }
            // composer
            drawRoundRect(c.composer, topLeft = Offset(w * 0.28f, h * 0.76f), size = Size(w * 0.68f, h * 0.17f), cornerRadius = CornerRadius(h * 0.085f))
            drawRoundRect(c.composerBorder, topLeft = Offset(w * 0.28f, h * 0.76f), size = Size(w * 0.68f, h * 0.17f), cornerRadius = CornerRadius(h * 0.085f), style = Stroke(1.dp.toPx()))
            drawCircle(c.accent, radius = h * 0.055f, center = Offset(w * 0.9f, h * 0.845f))
        }
        Spacer(Modifier.height(6.dp))
        Text(
            theme.name,
            style = AvekTheme.type.label.copy(fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium),
            color = ui.textPrimary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(horizontal = 4.dp),
        )
        Text(
            theme.subtitle,
            style = AvekTheme.type.caption,
            color = ui.textSecondary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(horizontal = 4.dp),
        )
    }
}
