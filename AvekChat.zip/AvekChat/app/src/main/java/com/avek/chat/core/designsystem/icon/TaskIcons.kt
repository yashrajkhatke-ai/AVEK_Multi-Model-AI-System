package com.avek.chat.core.designsystem.icon

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Chat
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.Code
import androidx.compose.material.icons.outlined.EditNote
import androidx.compose.material.icons.outlined.Functions
import androidx.compose.material.icons.outlined.Insights
import androidx.compose.material.icons.outlined.Lightbulb
import androidx.compose.material.icons.outlined.School
import androidx.compose.material.icons.outlined.TravelExplore
import androidx.compose.ui.graphics.vector.ImageVector
import com.avek.chat.core.model.TaskMode

val TaskMode.icon: ImageVector
    get() = when (this) {
        TaskMode.AUTO -> Icons.Outlined.AutoAwesome
        TaskMode.GENERAL -> Icons.AutoMirrored.Outlined.Chat
        TaskMode.DEEP_RESEARCH -> Icons.Outlined.TravelExplore
        TaskMode.CODING -> Icons.Outlined.Code
        TaskMode.WRITING -> Icons.Outlined.EditNote
        TaskMode.ANALYSIS -> Icons.Outlined.Insights
        TaskMode.MATH -> Icons.Outlined.Functions
        TaskMode.BRAINSTORM -> Icons.Outlined.Lightbulb
        TaskMode.LEARN -> Icons.Outlined.School
    }
