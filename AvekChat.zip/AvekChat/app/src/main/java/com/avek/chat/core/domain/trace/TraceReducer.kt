package com.avek.chat.core.domain.trace

import com.avek.chat.core.link.rpc.TextAssembler
import com.avek.chat.core.link.wire.LinkEvent
import com.avek.chat.core.link.wire.TraceContextDto
import com.avek.chat.core.link.wire.TraceGenDto
import com.avek.chat.core.link.wire.TraceLogDto
import com.avek.chat.core.link.wire.TracePhaseDto
import com.avek.chat.core.link.wire.TraceRuntimeDto
import com.avek.chat.core.link.wire.TraceSnapshotDto
import com.avek.chat.core.link.wire.TraceToolDto

/**
 * Pure reducer of a turn's telemetry (v3 task D.3). Events may arrive twice or out of order (a
 * resume replays them): every rule is idempotent and ordered by the event's own `t`, `step` and
 * `id`, so applying the same events in any order, any number of times, gives the same result.
 * [receivedAt] is the device time the event arrived (only used for stale detection and token cells).
 */
object TraceReducer {

    fun reduce(state: TurnTelemetry, event: LinkEvent, receivedAt: Long): TurnTelemetry {
        val key = state.key
        return when (event) {
            is LinkEvent.TurnStarted -> if (event.data.chatId == key.chatId && event.data.promptId == key.promptId) {
                state.copy(live = true, modelId = event.data.modelId ?: state.modelId, firstSeenAt = state.firstSeenAt ?: receivedAt)
            } else state
            is LinkEvent.TurnCompleted -> if (matches(key, event.data.chatId, event.data.promptId)) state.copy(live = false) else state
            is LinkEvent.TurnCancelled -> if (matches(key, event.data.chatId, event.data.promptId)) state.copy(live = false) else state
            is LinkEvent.TurnFailed -> if (matches(key, event.data.chatId, event.data.promptId)) state.copy(live = false) else state
            is LinkEvent.TracePhase -> if (matches(key, event.data.chatId, event.data.promptId)) touched(phase(state, event.data), receivedAt) else state
            is LinkEvent.TraceContext -> if (matches(key, event.data.chatId, event.data.promptId)) touched(context(state, event.data), receivedAt) else state
            is LinkEvent.TraceGen -> if (matches(key, event.data.chatId, event.data.promptId)) touched(gen(state, event.data), receivedAt) else state
            is LinkEvent.TraceTool -> if (matches(key, event.data.chatId, event.data.promptId)) touched(tool(state, event.data), receivedAt) else state
            is LinkEvent.TraceLog -> if (matches(key, event.data.chatId, event.data.promptId)) touched(log(state, event.data), receivedAt) else state
            // trace.runtime may carry no turn ids: it describes the PC; it is kept for the live turn.
            is LinkEvent.TraceRuntime -> {
                val d = event.data
                val forThis = (d.chatId == null && d.promptId == null && state.live) || matches(key, d.chatId.orEmpty(), d.promptId.orEmpty())
                if (forThis) touched(runtime(state, d), receivedAt) else state
            }
            is LinkEvent.ThinkingDelta -> if (matches(key, event.data.chatId, event.data.promptId)) {
                delta(state, TokenKind.REASONING, event.data.offset, event.data.text, receivedAt)
            } else state
            is LinkEvent.AnswerDelta -> if (matches(key, event.data.chatId, event.data.promptId)) {
                delta(state, TokenKind.ANSWER, event.data.offset, event.data.text, receivedAt)
            } else state
            is LinkEvent.ToolCallDelta -> if (matches(key, event.data.chatId, event.data.promptId)) toolDelta(state, event, receivedAt) else state
            else -> state
        }
    }

    /**
     * A `trace.get` snapshot replaces the state it covers (phases, steps, tools, context, runtime,
     * logs); streamed text and token cells are kept, then live events continue on top.
     */
    fun reduce(state: TurnTelemetry, snapshot: TraceSnapshotDto, receivedAt: Long): TurnTelemetry {
        var next = state.copy(
            modelId = snapshot.modelId.ifEmpty { state.modelId },
            modelName = snapshot.modelName.ifEmpty { state.modelName },
            live = snapshot.live,
            startedAt = snapshot.startedAt.takeIf { it > 0 } ?: state.startedAt,
            endedAt = snapshot.endedAt,
            phases = emptyList(),
            phaseHistory = emptyList(),
            context = null,
            contexts = emptyList(),
            steps = emptyList(),
            tools = emptyMap(),
            runtime = null,
            logs = emptyList(),
            tpsSamples = emptyList(),
            fromSnapshot = true,
            lastEventAt = if (snapshot.live) receivedAt else state.lastEventAt,
        )
        snapshot.phases.forEach { next = phase(next, it) }
        snapshot.context?.let { next = context(next, it) }
        snapshot.steps.forEach { next = gen(next, it) }
        snapshot.tools.forEach { next = tool(next, it) }
        snapshot.logs.forEach { next = log(next, it) }
        snapshot.runtime?.let { next = runtime(next, it) }
        return next
    }

    fun empty(key: TurnKey, demo: Boolean = false) = TurnTelemetry(key = key, demo = demo)

    // ------------------------------------------------------------------ rules

    private fun matches(key: TurnKey, chatId: String, promptId: String) = key.chatId == chatId && key.promptId == promptId

    private fun touched(state: TurnTelemetry, receivedAt: Long): TurnTelemetry =
        state.copy(lastEventAt = maxOf(state.lastEventAt ?: receivedAt, receivedAt), firstSeenAt = state.firstSeenAt ?: receivedAt)

    private fun withStart(state: TurnTelemetry, t: Long): TurnTelemetry =
        if (t > 0 && (state.startedAt == null || (!state.fromSnapshot && t < state.startedAt))) state.copy(startedAt = t) else state

    private fun phase(state: TurnTelemetry, p: TracePhaseDto): TurnTelemetry {
        if (p.id.isEmpty()) return state
        val existing = state.phases.firstOrNull { it.id == p.id }
        val span = if (p.state == "end") {
            (existing ?: PhaseSpan(p.id, p.phase, p.label, p.detail, p.step, startT = null, endT = null, ms = null)).let {
                it.copy(endT = maxOf(it.endT ?: p.t, p.t), ms = p.ms ?: it.ms, detail = it.detail ?: p.detail, step = it.step ?: p.step,
                    label = it.label.ifEmpty { p.label })
            }
        } else {
            (existing ?: PhaseSpan(p.id, p.phase, p.label, p.detail, p.step, startT = null, endT = null, ms = null)).let {
                // The start's label is the person-facing one ("Saving the chat"), keep it over the end's.
                it.copy(startT = minOf(it.startT ?: p.t, p.t), label = p.label.ifEmpty { it.label }, detail = p.detail ?: it.detail, step = p.step ?: it.step)
            }
        }
        val phases = (state.phases.filter { it.id != p.id } + span).sortedWith(PHASE_ORDER)
        val mark = PhaseMark(p.id, p.phase, p.state, p.label, p.step, p.t)
        val history = if (state.phaseHistory.any { it.id == mark.id && it.state == mark.state }) state.phaseHistory
        else (state.phaseHistory + mark).sortedWith(compareBy<PhaseMark>({ it.t }, { idNumber(it.id) }, { if (it.state == "end") 1 else 0 })).takeLast(TurnTelemetry.MAX_PHASE_HISTORY)
        return withStart(state.copy(phases = phases, phaseHistory = history), p.t)
    }

    private fun context(state: TurnTelemetry, c: TraceContextDto): TurnTelemetry {
        val contexts = (state.contexts.filter { it.step != c.step } + (state.contexts.firstOrNull { it.step == c.step }?.takeIf { it.t > c.t } ?: c))
            .sortedBy { it.step }
        val latest = if (state.context == null || c.t >= state.context.t) c else state.context
        return withStart(state.copy(context = latest, contexts = contexts), c.t)
    }

    private fun gen(state: TurnTelemetry, g: TraceGenDto): TurnTelemetry {
        val previous = state.steps.firstOrNull { it.step == g.step }
        val keep = previous != null && (previous.t > g.t || (previous.t == g.t && rank(previous.state) > rank(g.state)))
        val steps = if (keep) state.steps else (state.steps.filter { it.step != g.step } + g).sortedBy { it.step }
        val sample = TpsSample(g.t, g.step, g.tps, g.tokens.total)
        val samples = if (g.state == "prefill" || state.tpsSamples.any { it.t == sample.t && it.step == sample.step }) state.tpsSamples
        else {
            val all = (state.tpsSamples + sample).sortedWith(compareBy({ it.t }, { it.step }))
            val newest = all.last().t
            all.filter { newest - it.t <= TurnTelemetry.TPS_WINDOW_MS }.takeLast(TurnTelemetry.MAX_TPS_SAMPLES)
        }
        return withStart(
            state.copy(
                steps = steps,
                tpsSamples = samples,
                modelId = g.modelId.ifEmpty { state.modelId },
                modelName = g.modelName.ifEmpty { state.modelName },
            ),
            g.t,
        )
    }

    private fun tool(state: TurnTelemetry, t: TraceToolDto): TurnTelemetry {
        val key = CallKey(t.step, t.index)
        val previous = state.tools[key]
        val merged = when {
            previous == null -> t
            previous.t > t.t || (previous.t == t.t && rank(previous.state) > rank(t.state)) -> fill(previous, t)
            else -> fill(t, previous)
        }
        return withStart(state.copy(tools = state.tools + (key to merged)), t.t)
    }

    /** [newer] wins; a field it does not carry (e.g. `argTokens` on `done`) keeps the older value. */
    private fun fill(newer: TraceToolDto, older: TraceToolDto) = newer.copy(
        callId = newer.callId.ifEmpty { older.callId },
        name = newer.name.ifEmpty { older.name },
        argTokens = newer.argTokens ?: older.argTokens,
        startedAt = newer.startedAt ?: older.startedAt,
        ms = newer.ms ?: older.ms,
        resultChars = newer.resultChars ?: older.resultChars,
        resultTokens = newer.resultTokens ?: older.resultTokens,
    )

    private fun log(state: TurnTelemetry, l: TraceLogDto): TurnTelemetry {
        if (state.logs.any { it.t == l.t && it.source == l.source && it.text == l.text && it.level == l.level }) return state
        val logs = (state.logs + l).sortedBy { it.t }.takeLast(TurnTelemetry.MAX_LOGS)
        return withStart(state.copy(logs = logs), l.t)
    }

    private fun runtime(state: TurnTelemetry, r: TraceRuntimeDto): TurnTelemetry =
        if (state.runtime == null || r.t >= state.runtime.t) state.copy(runtime = r) else state

    private fun delta(state: TurnTelemetry, kind: TokenKind, offset: Int, text: String, receivedAt: Long): TurnTelemetry {
        val length = if (kind == TokenKind.REASONING) state.thinkingLength else state.answerLength
        // The offset rule: only text that is new counts as a token; duplicates and gaps add nothing.
        if (offset > length) return state
        val added = text.length - (length - offset)
        if (added <= 0) return state
        val cell = TokenCell(state.tokenCount, kind, receivedAt, added)
        val next = state.copy(
            tokens = (state.tokens + cell).takeLast(TurnTelemetry.MAX_TOKEN_CELLS),
            tokenCount = state.tokenCount + 1,
            firstSeenAt = state.firstSeenAt ?: receivedAt,
        )
        return if (kind == TokenKind.REASONING) next.copy(thinkingLength = length + added) else next.copy(answerLength = length + added)
    }

    private fun toolDelta(state: TurnTelemetry, event: LinkEvent.ToolCallDelta, receivedAt: Long): TurnTelemetry {
        val d = event.data
        val key = CallKey(d.step, d.index)
        val existing = state.toolArgs[key]
        val current = existing ?: ToolArgs(null, null, "")
        if (current.gap) return state
        val merged = TextAssembler.merge(current.text, d.offset, d.text)
        val args = if (merged == null) current.copy(gap = true) else current.copy(
            text = merged,
            callId = d.callId ?: current.callId,
            name = d.name ?: current.name,
        )
        if (args == existing) return state
        val added = (merged?.length ?: 0) - current.text.length
        val withCell = if (added > 0) state.copy(
            tokens = (state.tokens + TokenCell(state.tokenCount, TokenKind.TOOL_CALL, receivedAt, added)).takeLast(TurnTelemetry.MAX_TOKEN_CELLS),
            tokenCount = state.tokenCount + 1,
        ) else state
        return withCell.copy(toolArgs = state.toolArgs + (key to args))
    }

    private fun rank(state: String): Int = when (state) {
        "prefill" -> 0
        "reasoning", "writing" -> 1
        "answering", "running" -> 2
        "tool-call" -> 3
        "step-done", "done", "error" -> 4
        else -> 0
    }

    /** `plugins:1` -> 1: the harness numbers phases in the order it starts them. */
    private fun idNumber(id: String): Int = id.substringAfterLast(':').toIntOrNull() ?: Int.MAX_VALUE

    private val PHASE_ORDER = compareBy<PhaseSpan>({ it.startT ?: it.endT ?: Long.MAX_VALUE }, { idNumber(it.id) }, { it.id })
}
