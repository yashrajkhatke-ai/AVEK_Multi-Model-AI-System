package com.avek.chat.core.data.fake

import com.avek.chat.core.common.IdGenerator
import com.avek.chat.core.common.TimeProvider
import com.avek.chat.core.domain.repository.ConversationRepository
import com.avek.chat.core.domain.repository.ModelRepository
import com.avek.chat.core.domain.repository.SettingsRepository
import com.avek.chat.core.domain.usecase.TitleGenerator
import com.avek.chat.core.model.Conversation
import com.avek.chat.core.model.Feedback
import com.avek.chat.core.model.Message
import com.avek.chat.core.model.Role
import com.avek.chat.core.model.TaskMode
import com.avek.chat.core.model.ThinkingDepth
import kotlinx.coroutines.flow.first
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Fills the history with realistic sample conversations on first launch so
 * the sidebar, search and grouping have something to show.
 */
@Singleton
class DemoContentSeeder @Inject constructor(
    private val conversations: ConversationRepository,
    private val settings: SettingsRepository,
    private val models: ModelRepository,
    private val composer: ResponseComposer,
    private val titles: TitleGenerator,
    private val ids: IdGenerator,
    private val time: TimeProvider,
) {
    private data class Seed(
        val prompt: String,
        val task: TaskMode,
        val modelId: String,
        val depth: ThinkingDepth,
        val hoursAgo: Long,
        val starred: Boolean = false,
        val archived: Boolean = false,
        val followUp: String? = null,
        val title: String? = null,
    )

    private val seeds = listOf(
        Seed("Write a Kotlin retry helper with exponential backoff for flaky network calls", TaskMode.CODING, "avek-forge", ThinkingDepth.DEEP, 1, starred = true, followUp = "Can you add jitter and make it cancellation-safe?"),
        Seed("Research the impact of remote work on team productivity", TaskMode.DEEP_RESEARCH, "avek-sage", ThinkingDepth.EXTENDED, 3, title = "Remote work & productivity"),
        Seed("Brainstorm names for a cozy neighbourhood coffee shop", TaskMode.BRAINSTORM, "avek-muse", ThinkingDepth.LIGHT, 5),
        Seed("Explain how transformers use attention, like I'm new to ML", TaskMode.LEARN, "avek-lumen", ThinkingDepth.BALANCED, 26, followUp = "What's the difference between self-attention and cross-attention?"),
        Seed("Help me decide between renting and buying an apartment this year", TaskMode.ANALYSIS, "avek-atlas", ThinkingDepth.DEEP, 30, starred = true),
        Seed("Draft a warm welcome email for new members of our book club", TaskMode.WRITING, "avek-muse", ThinkingDepth.BALANCED, 52),
        Seed("Solve 2x + 6 = 14 and show each step", TaskMode.MATH, "avek-nova", ThinkingDepth.LIGHT, 75),
        Seed("Write a Python rate limiter for an API client", TaskMode.CODING, "avek-forge", ThinkingDepth.BALANCED, 98),
        Seed("Plan a relaxed three-day itinerary for Kyoto in autumn", TaskMode.GENERAL, "avek-nova", ThinkingDepth.BALANCED, 120, title = "Kyoto autumn itinerary"),
        Seed("What is the state of solid-state batteries for electric vehicles", TaskMode.DEEP_RESEARCH, "avek-atlas", ThinkingDepth.MAXIMUM, 160, starred = true),
        Seed("Explain the difference between TCP and UDP", TaskMode.LEARN, "avek-flash", ThinkingDepth.INSTANT, 260),
        Seed("Write a short poem about the first rain of the monsoon", TaskMode.WRITING, "avek-muse", ThinkingDepth.LIGHT, 400),
        Seed("Write a SQL query for monthly active users with growth", TaskMode.CODING, "avek-forge", ThinkingDepth.BALANCED, 520),
        Seed("Analyze the pros and cons of a four-day work week", TaskMode.ANALYSIS, "avek-atlas", ThinkingDepth.EXTENDED, 720),
        Seed("Brainstorm weekend project ideas to learn Jetpack Compose", TaskMode.BRAINSTORM, "avek-nova", ThinkingDepth.BALANCED, 1100),
        Seed("Give me a beginner's overview of index funds", TaskMode.GENERAL, "avek-nova", ThinkingDepth.LIGHT, 1500, archived = true),
        Seed("Summarize the history of the printing press", TaskMode.LEARN, "avek-sage", ThinkingDepth.DEEP, 2200),
    )

    suspend fun seedIfNeeded() {
        if (settings.settings.first().hasSeededDemoContent) return
        seed()
        settings.update { it.copy(hasSeededDemoContent = true) }
    }

    suspend fun seed() {
        val now = time.now()
        val allConversations = mutableListOf<Conversation>()
        val allMessages = mutableListOf<Message>()

        seeds.forEach { seed ->
            val conversationId = ids.newId()
            val model = models.find(seed.modelId)
            var cursor = now - seed.hoursAgo * HOUR
            val turns = listOfNotNull(seed.prompt, seed.followUp)
            turns.forEachIndexed { turn, prompt ->
                allMessages += Message(
                    id = ids.newId(),
                    conversationId = conversationId,
                    role = Role.USER,
                    content = prompt,
                    createdAt = cursor,
                    modelId = model.id,
                    requestedTask = seed.task,
                    depth = seed.depth,
                )
                cursor += 4_000
                val depth = model.clampDepth(seed.depth)
                val script = composer.compose(prompt, seed.task, depth, model, variant = turn)
                val thinking = script.thinking.takeIf { it.isNotEmpty() }
                    ?.joinToString("\n\n") { "**${it.title}**\n${it.text}" }
                allMessages += Message(
                    id = ids.newId(),
                    conversationId = conversationId,
                    role = Role.ASSISTANT,
                    content = script.answer,
                    createdAt = cursor,
                    thinking = thinking,
                    thinkingDurationMs = if (thinking == null) 0 else 2_500L + depth.level * 4_100L,
                    modelId = model.id,
                    requestedTask = seed.task,
                    resolvedTask = seed.task,
                    depth = depth,
                    feedback = if (seed.starred && turn == 0) Feedback.POSITIVE else Feedback.NONE,
                    sources = script.sources,
                )
                cursor += 60_000
            }
            val last = allMessages.last()
            allConversations += Conversation(
                id = conversationId,
                title = seed.title ?: titles.generate(seed.prompt),
                createdAt = now - seed.hoursAgo * HOUR,
                updatedAt = last.createdAt,
                isStarred = seed.starred,
                isArchived = seed.archived,
                modelId = model.id,
                taskMode = seed.task,
                preview = last.content.replace(Regex("[#*`>|_]"), "").replace(Regex("\\s+"), " ").trim().take(140),
                messageCount = turns.size * 2,
            )
        }
        conversations.insertAll(allConversations, allMessages)
    }

    private companion object {
        const val HOUR = 3_600_000L
    }
}
