package com.avek.chat.feature.chat.thinking

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.KeyboardArrowDown
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.avek.chat.core.designsystem.theme.AvekTheme
import com.avek.chat.core.designsystem.theme.avekPill
import com.avek.chat.core.designsystem.theme.avekShape
import com.avek.chat.core.domain.trace.TraceReducer
import com.avek.chat.core.domain.trace.TurnKey
import com.avek.chat.core.domain.trace.TurnTelemetry
import com.avek.chat.core.link.wire.TraceRuntimeDto
import com.avek.chat.core.markdown.MarkdownContent
import com.avek.chat.core.model.settings.ThinkingSettings
import com.avek.chat.feature.chat.thinking.panels.Dot
import com.avek.chat.feature.chat.thinking.panels.rememberNow
import com.avek.chat.feature.chat.thinking.panels.rememberPulse
import com.avek.chat.feature.chat.thinking.panels.rememberThinkingPalette
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * Where the thinking block gets its data and saves the person's choices (provided by the chat
 * screen from the TraceRepository and the settings). Absent = no telemetry (the block still works).
 */
@Stable
interface ThinkingEnvironment {
    val settings: StateFlow<ThinkingSettings>
    val runtime: StateFlow<TraceRuntimeDto?>

    /** True in Demo mode: there is no harness, so there is no telemetry and the block says so. */
    val demo: Boolean

    /** The telemetry of a turn; [fetch] = ask the PC (`trace.get`) when it is not known yet. */
    fun telemetry(chatId: String, promptId: String, fetch: Boolean): StateFlow<TurnTelemetry>

    /** `trace.get` again (a finished turn's block was opened). */
    fun load(chatId: String, promptId: String)

    /** A block or the inspector is on screen; call the result when it leaves. */
    fun viewing(): () -> Unit

    fun chooseStyle(id: String)

    /** `runtime.get` for the inspector when no turn runs. */
    fun refreshRuntime()
}

val LocalThinkingEnvironment = compositionLocalOf<ThinkingEnvironment?> { null }

/** What the person did with one block: expanded, chosen style (null = the default), sheets open. */
@Stable
class ThinkingBlockState(expanded: Boolean) {
    var expanded by mutableStateOf(expanded)
    var switcherOpen by mutableStateOf(false)
    var inspectorOpen by mutableStateOf(false)
    var showReasoning by mutableStateOf(false)
}

/**
 * The thinking block (v3 task E): a header pill that is always the same (model, phase, elapsed,
 * tok/s, chevron), and below it the chosen style. Tap expands; long-press or the overflow icon
 * opens the style switcher and the inspector.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ThinkingBlock(
    chatId: String,
    promptId: String?,
    /** Null = not loaded yet (old turns load it when the reasoning is opened). */
    thinkingText: String?,
    isThinking: Boolean,
    streaming: Boolean,
    modelName: String?,
    /** When the turn started on this device (keeps the timer right when the screen is left and re-opened). */
    startedAt: Long,
    durationMs: Long,
    loading: Boolean,
    onLoadThinking: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val env = LocalThinkingEnvironment.current
    val settings by (env?.settings ?: remember { MutableStateFlow(ThinkingSettings()) }).collectAsState()
    val key = remember(chatId, promptId) { promptId?.let { TurnKey(chatId, it) } }
    val flow = remember(env, key, streaming) {
        // A running turn is fetched at once; a finished one only when it is opened.
        if (env != null && key != null) env.telemetry(key.chatId, key.promptId, fetch = streaming) else null
    }
    val telemetry by (flow ?: remember(key) { MutableStateFlow(TraceReducer.empty(key ?: TurnKey(chatId, ""), env?.demo == true)) }).collectAsState()
    val state = remember(key) { ThinkingBlockState(settings.expandedByDefault) }
    var openedOnce by rememberSaveable(key) { mutableStateOf(false) }

    // The `trace` topic is wanted while this block is on screen.
    if (env != null && streaming) {
        DisposableEffect(env, key) {
            val release = env.viewing()
            onDispose(release)
        }
    }
    LaunchedEffect(state.expanded, state.inspectorOpen) {
        if ((state.expanded || state.inspectorOpen) && !openedOnce) {
            openedOnce = true
            if (env != null && key != null && !telemetry.live && !telemetry.hasTrace && !telemetry.demo) env.load(key.chatId, key.promptId)
        }
        if ((state.expanded && (settings.showFullReasoning || state.showReasoning)) && thinkingText == null && !isThinking) onLoadThinking()
    }

    val colors = AvekTheme.colors
    val style = ThinkingStyleCatalog.resolve(settings.style, telemetry)
    val text = thinkingText.orEmpty()

    Column(
        modifier
            .fillMaxWidth()
            .clip(avekShape(16.dp))
            .background(colors.thinkingSurface)
            .border(1.dp, colors.outline.copy(alpha = 0.45f), avekShape(16.dp)),
    ) {
        ThinkingHeader(
            t = telemetry,
            isThinking = isThinking,
            fallbackModel = modelName,
            startedAt = startedAt,
            durationMs = durationMs,
            expanded = state.expanded,
            demo = env?.demo == true || telemetry.demo,
            modifier = Modifier.combinedClickable(
                onClick = { state.expanded = !state.expanded },
                onLongClick = { state.switcherOpen = true },
                onLongClickLabel = "Choose a display style",
            ),
            onOverflow = { state.switcherOpen = true },
        )

        // Collapsed while the turn runs: the chosen style in its compact form (one or two lines).
        AnimatedVisibility(visible = !state.expanded && (isThinking || telemetry.live)) {
            style.content(telemetry, text, ThinkingMode.Compact, Modifier.padding(start = 14.dp, end = 14.dp, bottom = 12.dp))
        }

        AnimatedVisibility(visible = state.expanded, enter = expandVertically() + fadeIn(), exit = shrinkVertically() + fadeOut()) {
            Column(Modifier.padding(start = 14.dp, end = 14.dp, bottom = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (env?.demo == true || telemetry.demo) {
                    Text("Demo mode: there is no harness, so there is no live telemetry. The reasoning text below is the demo's.", style = AvekTheme.type.caption, color = colors.textTertiary)
                } else if (!telemetry.hasTrace && !telemetry.live) {
                    Text(if (env == null) "No telemetry for this turn" else "Loading telemetry…", style = AvekTheme.type.caption, color = colors.textTertiary)
                }
                style.content(telemetry, text, ThinkingMode.Expanded, Modifier)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = { state.showReasoning = !state.showReasoning }) {
                        Text(if (state.showReasoning || settings.showFullReasoning) "Hide reasoning" else "Show reasoning", color = colors.accent)
                    }
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick = { state.inspectorOpen = true }) { Text("Open inspector", color = colors.accent) }
                }
                if (state.showReasoning || settings.showFullReasoning) {
                    ReasoningText(thinkingText, loading || (thinkingText == null && !isThinking))
                }
            }
        }
    }

    if (state.switcherOpen) {
        ThinkingStyleSwitcher(
            t = telemetry,
            thinkingText = text,
            selectedId = settings.style,
            onSelect = { id -> env?.chooseStyle(id) },
            onOpenInspector = { state.switcherOpen = false; state.inspectorOpen = true },
            onDismiss = { state.switcherOpen = false },
        )
    }
    if (state.inspectorOpen) {
        if (env != null) {
            DisposableEffect(env) {
                val release = env.viewing()
                onDispose(release)
            }
        }
        ThinkingInspector(
            t = telemetry,
            thinkingText = thinkingText,
            runtime = env?.runtime,
            onRefreshRuntime = { env?.refreshRuntime() },
            onLoadThinking = onLoadThinking,
            onDismiss = { state.inspectorOpen = false },
        )
    }
}

@Composable
private fun ReasoningText(thinking: String?, loading: Boolean) {
    val colors = AvekTheme.colors
    when {
        thinking == null -> Text(if (loading) "Loading reasoning…" else "", style = AvekTheme.type.thinking, color = colors.textTertiary)
        thinking.isBlank() -> Text("No reasoning text was kept for this turn.", style = AvekTheme.type.thinking, color = colors.textTertiary)
        else -> MarkdownContent(markdown = thinking, textStyle = AvekTheme.type.thinking, color = colors.thinkingText)
    }
}

/** The header pill: independent of the style. */
@Composable
fun ThinkingHeader(
    t: TurnTelemetry,
    isThinking: Boolean,
    fallbackModel: String?,
    startedAt: Long,
    durationMs: Long,
    expanded: Boolean,
    demo: Boolean,
    modifier: Modifier = Modifier,
    onOverflow: (() -> Unit)? = null,
) {
    val colors = AvekTheme.colors
    val palette = rememberThinkingPalette()
    val live = isThinking || t.live
    val now by rememberNow(live)
    val pulse by rememberPulse(live)
    val chevron by animateFloatAsState(if (expanded) 180f else 0f, label = "chevron")
    val phase = ThinkingFormat.phaseLabel(t, isThinking)
    val elapsed = t.elapsedMs(now, startedAt) ?: if (!live && durationMs > 0) durationMs else if (live && startedAt > 0) now - startedAt else null
    val stale = t.isStale(now)
    val model = t.modelName.ifEmpty { fallbackModel.orEmpty() }
    val description = listOfNotNull(model.ifEmpty { null }, phase, elapsed?.let { ThinkingFormat.ms(it) }, t.tps?.let { ThinkingFormat.tps(it) }).joinToString(", ")
    Row(
        modifier
            .fillMaxWidth()
            .semantics { contentDescription = "Thinking: $description${if (expanded) ", expanded" else ", collapsed"}" }
            .padding(start = 14.dp, end = 4.dp, top = 8.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Dot(if (live) palette.accent else palette.muted, 9, alpha = if (live) pulse else 1f)
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(
                if (stale) "Waiting for the harness… ${ThinkingFormat.ms(t.silenceMs(now))}" else phase,
                style = AvekTheme.type.label.copy(fontWeight = FontWeight.Medium),
                color = if (stale) palette.warn else colors.textPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                listOfNotNull(model.ifEmpty { null }, elapsed?.let { ThinkingFormat.ms(it) }, t.tps?.let { ThinkingFormat.tps(it) }).joinToString(" · ").ifEmpty { ThinkingFormat.NONE },
                style = AvekTheme.type.caption,
                color = colors.textTertiary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        if (demo) {
            Text(
                "Demo",
                style = AvekTheme.type.caption.copy(fontWeight = FontWeight.Medium),
                color = colors.thinkingGlow,
                modifier = Modifier.clip(avekPill()).background(colors.accentContainer).padding(horizontal = 8.dp, vertical = 2.dp),
            )
        }
        if (onOverflow != null) {
            IconButton(onClick = onOverflow, modifier = Modifier.size(36.dp)) {
                Icon(Icons.Outlined.MoreVert, contentDescription = "Display style and inspector", tint = colors.textSecondary, modifier = Modifier.size(18.dp))
            }
        }
        Icon(
            Icons.Outlined.KeyboardArrowDown,
            contentDescription = null,
            tint = colors.textSecondary,
            modifier = Modifier.padding(end = 6.dp).size(20.dp).rotate(chevron),
        )
    }
}

/** Space between the header and other content when used in lists. */
@Composable
fun ThinkingGap() = Spacer(Modifier.height(12.dp))
