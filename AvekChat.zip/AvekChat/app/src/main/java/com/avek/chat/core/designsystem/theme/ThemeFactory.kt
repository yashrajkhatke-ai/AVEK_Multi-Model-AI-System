package com.avek.chat.core.designsystem.theme

import androidx.compose.ui.graphics.Color

/** How the user's message bubble relates to the rest of the palette. */
enum class BubbleTone(val label: String) {
    TONAL("Tonal"),
    VIVID("Vivid"),
    SUBTLE("Subtle"),
    INVERSE("Inverse"),
}

enum class ContrastLevel(val label: String) { SOFT("Soft"), STANDARD("Standard"), HIGH("High") }

/** Where the neutral (background) colours get their hue from. */
enum class NeutralFamily(val label: String, val short: String) {
    WARM("Warm paper", "Paper"),
    COOL("Cool slate", "Slate"),
    PURE("Pure gray", "Gray"),
    TINTED("Accent tint", "Tint"),
    DEEP("Deep ink", "Ink"),
    PASTEL("Pastel wash", "Pastel"),
}

/** Minimal description from which a complete light + dark [AvekColors] pair is derived. */
data class ThemeSeed(
    val accentHue: Float,
    val accentSaturation: Float = 0.62f,
    val neutralHue: Float,
    val neutralSaturation: Float,
    val tone: BubbleTone = BubbleTone.TONAL,
    val contrast: ContrastLevel = ContrastLevel.STANDARD,
    /** Extra lightness pushed into light backgrounds (pastel families). */
    val airiness: Float = 0f,
)

object ThemeFactory {

    fun seed(accentHue: Float, family: NeutralFamily, tone: BubbleTone, contrast: ContrastLevel): ThemeSeed {
        val (hue, sat, air) = when (family) {
            NeutralFamily.WARM -> Triple(40f, 0.24f, 0f)
            NeutralFamily.COOL -> Triple(215f, 0.18f, 0f)
            NeutralFamily.PURE -> Triple(0f, 0f, 0f)
            NeutralFamily.TINTED -> Triple(accentHue, 0.22f, 0f)
            NeutralFamily.DEEP -> Triple(accentHue, 0.38f, -0.01f)
            NeutralFamily.PASTEL -> Triple(accentHue + 25f, 0.55f, 0.01f)
        }
        return ThemeSeed(
            accentHue = accentHue,
            accentSaturation = if (family == NeutralFamily.PASTEL) 0.5f else 0.64f,
            neutralHue = hue,
            neutralSaturation = sat,
            tone = tone,
            contrast = contrast,
            airiness = air,
        )
    }

    fun build(seed: ThemeSeed, dark: Boolean): AvekColors = if (dark) buildDark(seed) else buildLight(seed)

    /** Yellows and greens look washed out at the same lightness as blues; compensate. */
    private fun accentLightness(hue: Float, dark: Boolean): Float {
        val h = ((hue % 360f) + 360f) % 360f
        val yellowGreen = h in 40f..170f
        return when {
            dark && yellowGreen -> 0.58f
            dark -> 0.66f
            yellowGreen -> 0.38f
            else -> 0.52f
        }
    }

    private fun buildLight(seed: ThemeSeed): AvekColors {
        val nh = seed.neutralHue
        val ns = seed.neutralSaturation
        val base = when (seed.contrast) {
            ContrastLevel.SOFT -> 0.945f
            ContrastLevel.STANDARD -> 0.965f
            ContrastLevel.HIGH -> 0.985f
        } + seed.airiness
        fun n(l: Float, satScale: Float = 1f) = ColorMath.hsl(nh, ns * satScale, l)

        val textPrimary = n(
            when (seed.contrast) {
                ContrastLevel.SOFT -> 0.2f
                ContrastLevel.STANDARD -> 0.12f
                ContrastLevel.HIGH -> 0.05f
            },
            satScale = 0.6f,
        )
        val textSecondary = n(if (seed.contrast == ContrastLevel.HIGH) 0.32f else 0.42f, 0.5f)
        val accent = ColorMath.hsl(seed.accentHue, seed.accentSaturation, accentLightness(seed.accentHue, false))
        val background = n(base)
        val surface = n((base + 0.03f).coerceAtMost(1f), 0.7f)

        val userBubble = when (seed.tone) {
            BubbleTone.TONAL -> n(base - 0.065f)
            BubbleTone.VIVID -> accent
            BubbleTone.SUBTLE -> ColorMath.hsl(seed.accentHue, 0.45f, 0.91f)
            BubbleTone.INVERSE -> n(0.17f, 0.7f)
        }
        val outline = n(base - if (seed.contrast == ContrastLevel.HIGH) 0.2f else 0.12f)
        return AvekColors(
            isDark = false,
            chatBackground = background,
            topBar = background,
            surface = surface,
            outline = outline,
            userBubble = userBubble,
            userText = ColorMath.readableOn(userBubble, textPrimary),
            assistantBubble = surface,
            assistantText = textPrimary,
            thinkingSurface = n(base - 0.028f),
            thinkingText = ColorMath.readableOn(n(base - 0.028f), n(0.36f, 0.5f), 4.5f),
            codeSurface = n(base - 0.045f),
            codeText = textPrimary,
            sidebar = n(base - 0.025f),
            sidebarSelected = n(base - 0.08f),
            sidebarText = textPrimary,
            composer = surface,
            composerBorder = outline,
            accent = accent,
            onAccent = ColorMath.readableOn(accent, Color.White, 3f),
            thinkingGlow = accent,
            textPrimary = textPrimary,
            textSecondary = ColorMath.readableOn(background, textSecondary, 4.5f),
        )
    }

    private fun buildDark(seed: ThemeSeed): AvekColors {
        val nh = seed.neutralHue
        val ns = (seed.neutralSaturation * 0.8f).coerceAtMost(0.4f)
        val base = when (seed.contrast) {
            ContrastLevel.SOFT -> 0.17f
            ContrastLevel.STANDARD -> 0.13f
            ContrastLevel.HIGH -> 0.06f
        } + if (seed.airiness < 0f) seed.airiness * 2 else 0f
        fun n(l: Float, satScale: Float = 1f) = ColorMath.hsl(nh, ns * satScale, l)

        val textPrimary = n(if (seed.contrast == ContrastLevel.SOFT) 0.88f else 0.94f, 0.35f)
        val textSecondary = n(if (seed.contrast == ContrastLevel.HIGH) 0.76f else 0.66f, 0.3f)
        val accent = ColorMath.hsl(seed.accentHue, seed.accentSaturation, accentLightness(seed.accentHue, true))
        val background = n(base)
        val surface = n(base + 0.045f)

        val userBubble = when (seed.tone) {
            BubbleTone.TONAL -> n((base - 0.045f).coerceAtLeast(0.03f))
            BubbleTone.VIVID -> ColorMath.hsl(seed.accentHue, seed.accentSaturation * 0.85f, 0.42f)
            BubbleTone.SUBTLE -> ColorMath.hsl(seed.accentHue, 0.32f, base + 0.11f)
            BubbleTone.INVERSE -> n(0.9f, 0.4f)
        }
        val outline = n(base + if (seed.contrast == ContrastLevel.HIGH) 0.2f else 0.12f)
        return AvekColors(
            isDark = true,
            chatBackground = background,
            topBar = background,
            surface = surface,
            outline = outline,
            userBubble = userBubble,
            userText = ColorMath.readableOn(userBubble, textPrimary),
            assistantBubble = surface,
            assistantText = textPrimary,
            thinkingSurface = n(base + 0.03f),
            thinkingText = ColorMath.readableOn(n(base + 0.03f), n(0.72f, 0.3f), 4.5f),
            codeSurface = n((base - 0.035f).coerceAtLeast(0.02f)),
            codeText = n(0.9f, 0.3f),
            sidebar = n((base - 0.025f).coerceAtLeast(0.02f)),
            sidebarSelected = n(base + 0.07f),
            sidebarText = textPrimary,
            composer = surface,
            composerBorder = outline,
            accent = accent,
            onAccent = ColorMath.readableOn(accent, Color(0xFF111111), 3f),
            thinkingGlow = accent,
            textPrimary = textPrimary,
            textSecondary = textSecondary,
        )
    }
}
