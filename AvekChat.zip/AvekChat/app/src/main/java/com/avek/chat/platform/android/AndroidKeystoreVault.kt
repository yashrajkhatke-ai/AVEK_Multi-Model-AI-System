package com.avek.chat.platform.android

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import com.avek.chat.core.link.store.SecretVault
import com.avek.chat.core.link.store.VaultException
import java.security.GeneralSecurityException
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Encrypts the device secret with a non-exportable AES-256-GCM key that lives in the Android
 * Keystore. The key never leaves the secure hardware (or the Keystore daemon); only the
 * ciphertext (`iv || ciphertext || tag`) is written to disk.
 */
@Singleton
class AndroidKeystoreVault @Inject constructor() : SecretVault {

    override fun encrypt(plain: ByteArray): ByteArray = try {
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, key())
        cipher.iv + cipher.doFinal(plain)
    } catch (e: GeneralSecurityException) {
        throw VaultException("Could not encrypt with the Keystore key", e)
    }

    override fun decrypt(cipher: ByteArray): ByteArray {
        if (cipher.size <= IV_BYTES) throw VaultException("Stored secret is too short")
        return try {
            val c = Cipher.getInstance(TRANSFORMATION)
            c.init(Cipher.DECRYPT_MODE, key(create = false), GCMParameterSpec(TAG_BITS, cipher, 0, IV_BYTES))
            c.doFinal(cipher, IV_BYTES, cipher.size - IV_BYTES)
        } catch (e: GeneralSecurityException) {
            // Key gone (app data restored on another device, lock screen reset…) or data tampered with.
            throw VaultException("Could not decrypt the stored secret", e)
        }
    }

    private fun key(create: Boolean = true): SecretKey {
        val store = KeyStore.getInstance(PROVIDER).apply { load(null) }
        (store.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        if (!create) throw VaultException("The Keystore key is missing")
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, PROVIDER)
        generator.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build(),
        )
        return generator.generateKey()
    }

    private companion object {
        const val PROVIDER = "AndroidKeyStore"
        const val ALIAS = "avek_link_secret_v1"
        const val TRANSFORMATION = "AES/GCM/NoPadding"
        const val IV_BYTES = 12
        const val TAG_BITS = 128
    }
}
