package com.avek.chat.feature.history

import androidx.compose.runtime.Immutable
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.avek.chat.core.data.downloads.DownloadManager
import com.avek.chat.core.data.remote.toDomain
import com.avek.chat.core.domain.lists.ChatListController
import com.avek.chat.core.domain.lists.ChatListState
import com.avek.chat.core.domain.lists.ListMemoryRegistry
import com.avek.chat.core.domain.repository.ChatListQuery
import com.avek.chat.core.domain.repository.ChatRepository
import com.avek.chat.core.domain.repository.SettingsRepository
import com.avek.chat.core.link.LinkRepository
import com.avek.chat.core.link.rpc.RpcException
import com.avek.chat.core.link.wire.LinkEvent
import com.avek.chat.core.model.Conversation
import com.avek.chat.core.model.settings.UserSettings
import com.avek.chat.feature.connection.ConnectionUi
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

enum class HistoryFilter(val label: String) { ALL("All"), STARRED("Starred"), ARCHIVED("Archived") }

@Immutable
data class HistoryUiState(
    val list: ChatListState = ChatListState(),
    val query: String = "",
    val filter: HistoryFilter = HistoryFilter.ALL,
    val downloadedIds: Set<String> = emptySet(),
    val profileName: String = "",
    val plan: String = "",
    /** Without the PC the list shows only the downloaded chats. */
    val offline: Boolean = false,
) {
    val conversations: List<Conversation> get() = list.items
}

sealed interface HistoryEvent {
    data class Message(val text: String) : HistoryEvent
}

/**
 * The sidebar. Chats come from the PC page by page (see [ChatListController] for the paging
 * rules); typing searches on the PC (`chats.list {query}`, debounced 300 ms); without the PC the
 * list is the downloaded chats.
 */
@HiltViewModel
class HistoryViewModel @Inject constructor(
    private val chats: ChatRepository,
    private val link: LinkRepository,
    private val downloads: DownloadManager,
    settingsRepository: SettingsRepository,
    registry: ListMemoryRegistry,
) : ViewModel() {

    private val query = MutableStateFlow("")
    private val filter = MutableStateFlow(HistoryFilter.ALL)
    private var appliedQuery = ""
    private var open = false

    private val _events = Channel<HistoryEvent>(Channel.BUFFERED)
    val events: Flow<HistoryEvent> = _events.receiveAsFlow()

    private val settings: StateFlow<UserSettings> =
        settingsRepository.settings.stateIn(viewModelScope, SharingStarted.Eagerly, UserSettings())

    private val controller = ChatListController(
        scope = viewModelScope,
        fetch = { limit, after ->
            chats.list(
                ChatListQuery(text = appliedQuery, archived = filter.value == HistoryFilter.ARCHIVED, starred = filter.value == HistoryFilter.STARRED),
                limit,
                after,
            )
        },
        keepSeconds = { settings.value.connection.keepListsSeconds },
        registry = registry,
    )

    private val connection = combine(link.state, settings.map { it.connection.demoMode }.distinctUntilChanged()) { state, demo ->
        ConnectionUi.from(state, demo)
    }

    val uiState: StateFlow<HistoryUiState> = combine(
        controller.state, query, filter, downloads.downloadedIds, combine(settings, connection) { s, c -> s to c },
    ) { list, q, f, downloaded, (s, c) ->
        HistoryUiState(
            list = list,
            query = q,
            filter = f,
            downloadedIds = downloaded,
            profileName = s.profile.displayName,
            plan = s.profile.plan,
            offline = !c.connected,
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), HistoryUiState())

    init {
        viewModelScope.launch {
            query.debounce(SEARCH_DEBOUNCE_MS).map { it.trim() }.distinctUntilChanged().collect { text ->
                if (text == appliedQuery) return@collect // the initial empty text, or typing that came back to what is shown
                appliedQuery = text
                if (open) controller.refresh()
            }
        }
        viewModelScope.launch { link.events.collect(::onLinkEvent) }
        // Plugged in or out: a list on screen switches between the PC's chats and the downloaded ones.
        viewModelScope.launch {
            connection.map { it.connected }.distinctUntilChanged().drop(1).collect { if (open) controller.refresh() }
        }
    }

    // ------------------------------------------------------------------ view lifecycle

    fun onSidebarOpened() {
        open = true
        controller.opened()
    }

    fun onSidebarClosed() {
        open = false
        controller.closed()
    }

    fun onVisibleIndex(index: Int) = controller.onVisibleIndex(index)

    fun seeAll() = controller.seeAll()

    fun reload() = controller.refresh()

    // ------------------------------------------------------------------ filters

    fun setQuery(value: String) {
        query.value = value
    }

    fun setFilter(value: HistoryFilter) {
        if (filter.value == value) return
        filter.value = value
        controller.refresh()
    }

    // ------------------------------------------------------------------ chat actions

    fun rename(conversation: Conversation, title: String) {
        if (title.isBlank()) return
        change(conversation) { chats.setChat(it.id, title = title.trim()) }
    }

    fun toggleStar(conversation: Conversation) = change(conversation) { chats.setChat(it.id, starred = !it.isStarred) }

    fun toggleArchive(conversation: Conversation) {
        viewModelScope.launch {
            try {
                chats.setChat(conversation.id, archived = !conversation.isArchived)
                // The chat leaves this list (Archived lists the archived ones, the others hide them).
                controller.remove(conversation.id)
                _events.trySend(HistoryEvent.Message(if (conversation.isArchived) "Restored “${conversation.title}”" else "Archived “${conversation.title}”"))
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                report(e)
            }
        }
    }

    fun delete(conversation: Conversation) {
        viewModelScope.launch {
            try {
                chats.delete(conversation.id)
                controller.remove(conversation.id)
                _events.trySend(HistoryEvent.Message("Deleted “${conversation.title}”"))
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                report(e)
            }
        }
    }

    fun toggleDownload(conversation: Conversation) {
        val downloaded = conversation.id in uiState.value.downloadedIds
        viewModelScope.launch {
            try {
                if (downloaded) {
                    downloads.remove(conversation.id)
                    _events.trySend(HistoryEvent.Message("Removed from this device"))
                } else {
                    _events.trySend(HistoryEvent.Message("Downloading…"))
                    downloads.download(conversation.id)
                    _events.trySend(HistoryEvent.Message("Downloaded: readable without the PC"))
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                report(e)
            }
        }
    }

    // ------------------------------------------------------------------ internals

    private fun change(conversation: Conversation, block: suspend (Conversation) -> Conversation) {
        viewModelScope.launch {
            try {
                controller.update(block(conversation))
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                report(e)
            }
        }
    }

    private fun onLinkEvent(event: LinkEvent) {
        when (event) {
            LinkEvent.Refresh -> if (open) controller.refresh()
            is LinkEvent.ChatCreated -> controller.upsert(event.chat.toDomain(), insertIfMissing = matches(event.chat.toDomain()))
            is LinkEvent.ChatUpdated -> {
                val chat = event.chat.toDomain()
                if (matches(chat)) controller.upsert(chat, insertIfMissing = true) else controller.remove(chat.id)
            }
            is LinkEvent.ChatDeleted -> controller.remove(event.chatId)
            else -> Unit
        }
    }

    /** Does a (new or changed) chat belong in the list as currently filtered? */
    private fun matches(chat: Conversation): Boolean {
        if (appliedQuery.isNotBlank()) return chat.title.contains(appliedQuery, ignoreCase = true)
        return when (filter.value) {
            HistoryFilter.ALL -> !chat.isArchived
            HistoryFilter.STARRED -> chat.isStarred && !chat.isArchived
            HistoryFilter.ARCHIVED -> chat.isArchived
        }
    }

    private fun report(e: Throwable) {
        val text = if (e is RpcException && e.code == RpcException.NOT_CONNECTED) "PC not reachable." else e.message ?: "Something went wrong."
        _events.trySend(HistoryEvent.Message(text))
    }

    private companion object {
        const val SEARCH_DEBOUNCE_MS = 300L
    }
}
