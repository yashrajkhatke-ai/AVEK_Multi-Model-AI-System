package com.avek.chat.feature.history

import androidx.compose.runtime.Immutable
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.avek.chat.core.domain.repository.ConversationRepository
import com.avek.chat.core.domain.repository.SettingsRepository
import com.avek.chat.core.model.Conversation
import com.avek.chat.core.model.Message
import com.avek.chat.core.model.TaskMode
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

enum class HistoryFilter(val label: String) { ALL("All"), STARRED("Starred"), ARCHIVED("Archived") }

@Immutable
data class HistoryUiState(
    /** One continuous list, most recently active first. */
    val conversations: List<Conversation> = emptyList(),
    val query: String = "",
    val filter: HistoryFilter = HistoryFilter.ALL,
    val taskFilter: TaskMode? = null,
    val resultCount: Int = 0,
    val profileName: String = "",
    val plan: String = "",
    val isLoading: Boolean = true,
)

sealed interface HistoryEvent {
    data class Deleted(val title: String) : HistoryEvent
    data class Archived(val title: String, val archived: Boolean) : HistoryEvent
}

@HiltViewModel
class HistoryViewModel @Inject constructor(
    private val repository: ConversationRepository,
    settings: SettingsRepository,
) : ViewModel() {

    private val query = MutableStateFlow("")
    private val filter = MutableStateFlow(HistoryFilter.ALL)
    private val taskFilter = MutableStateFlow<TaskMode?>(null)
    private var lastDeleted: Pair<Conversation, List<Message>>? = null

    private val _events = Channel<HistoryEvent>(Channel.BUFFERED)
    val events: Flow<HistoryEvent> = _events.receiveAsFlow()

    private val source: Flow<List<Conversation>> =
        combine(query.debounce(150).map { it.trim() }.distinctUntilChanged(), filter) { q, f -> q to f }
            .flatMapLatest { (q, f) ->
                when {
                    q.isNotEmpty() -> repository.search(q).map { list ->
                        list.filter { if (f == HistoryFilter.ARCHIVED) it.isArchived else !it.isArchived }
                    }
                    f == HistoryFilter.ARCHIVED -> repository.observeArchived()
                    else -> repository.observeConversations()
                }
            }

    val uiState: StateFlow<HistoryUiState> =
        combine(source, query, filter, taskFilter, settings.settings) { list, q, f, task, s ->
            val filtered = list
                .filter { f != HistoryFilter.STARRED || it.isStarred }
                .filter { task == null || it.taskMode == task }
            HistoryUiState(
                conversations = filtered.sortedByDescending { it.updatedAt },
                query = q,
                filter = f,
                taskFilter = task,
                resultCount = filtered.size,
                profileName = s.profile.displayName,
                plan = s.profile.plan,
                isLoading = false,
            )
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), HistoryUiState())

    fun setQuery(value: String) {
        query.value = value
    }

    fun setFilter(value: HistoryFilter) {
        filter.value = value
    }

    fun setTaskFilter(value: TaskMode?) {
        taskFilter.value = value
    }

    fun rename(conversation: Conversation, title: String) {
        if (title.isBlank()) return
        viewModelScope.launch { repository.rename(conversation.id, title) }
    }

    fun toggleStar(conversation: Conversation) {
        viewModelScope.launch { repository.setStarred(conversation.id, !conversation.isStarred) }
    }

    fun toggleArchive(conversation: Conversation) {
        viewModelScope.launch {
            repository.setArchived(conversation.id, !conversation.isArchived)
            _events.send(HistoryEvent.Archived(conversation.title, !conversation.isArchived))
        }
    }

    fun delete(conversation: Conversation) {
        viewModelScope.launch {
            lastDeleted = conversation to repository.getMessages(conversation.id)
            repository.delete(conversation.id)
            _events.send(HistoryEvent.Deleted(conversation.title))
        }
    }

    fun undoDelete() {
        val (conversation, messages) = lastDeleted ?: return
        lastDeleted = null
        viewModelScope.launch { repository.insertAll(listOf(conversation), messages) }
    }
}
