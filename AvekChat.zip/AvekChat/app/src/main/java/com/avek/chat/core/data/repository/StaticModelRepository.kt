package com.avek.chat.core.data.repository

import com.avek.chat.core.domain.repository.ModelRepository
import com.avek.chat.core.model.AiModel
import com.avek.chat.core.model.TaskMode
import com.avek.chat.core.model.ThinkingDepth
import javax.inject.Inject
import javax.inject.Singleton

/** The simulated model line-up. Swap for a remote catalogue when wiring a backend. */
@Singleton
class StaticModelRepository @Inject constructor() : ModelRepository {

    override val models: List<AiModel> = listOf(
        AiModel(
            id = "avek-atlas",
            name = "Atlas",
            version = "4",
            tagline = "Most capable, for complex work",
            description = "Frontier reasoning for hard, open-ended problems. Takes its time and gets it right.",
            contextWindowK = 500,
            maxDepth = ThinkingDepth.MAXIMUM,
            speed = 2,
            intelligence = 5,
            strengths = setOf(TaskMode.DEEP_RESEARCH, TaskMode.ANALYSIS, TaskMode.MATH, TaskMode.CODING),
            tokensPerSecond = 42,
            badge = "Most capable",
        ),
        AiModel(
            id = "avek-nova",
            name = "Nova",
            version = "4",
            tagline = "Smart and fast for everyday tasks",
            description = "The best balance of intelligence and speed. A great default for almost anything.",
            contextWindowK = 200,
            maxDepth = ThinkingDepth.EXTENDED,
            speed = 4,
            intelligence = 4,
            strengths = setOf(TaskMode.GENERAL, TaskMode.WRITING, TaskMode.CODING, TaskMode.LEARN),
            tokensPerSecond = 85,
            badge = "Recommended",
        ),
        AiModel(
            id = "avek-flash",
            name = "Flash",
            version = "3.5",
            tagline = "Fastest for quick answers",
            description = "Near-instant replies for lookups, rewrites and quick back-and-forth.",
            contextWindowK = 128,
            maxDepth = ThinkingDepth.LIGHT,
            speed = 5,
            intelligence = 3,
            strengths = setOf(TaskMode.GENERAL, TaskMode.BRAINSTORM),
            tokensPerSecond = 160,
            badge = "Fastest",
        ),
        AiModel(
            id = "avek-forge",
            name = "Forge",
            version = "2",
            tagline = "Specialist for code",
            description = "Tuned on software engineering: architecture, refactors, debugging and tests.",
            contextWindowK = 256,
            maxDepth = ThinkingDepth.EXTENDED,
            speed = 3,
            intelligence = 4,
            strengths = setOf(TaskMode.CODING, TaskMode.MATH, TaskMode.ANALYSIS),
            tokensPerSecond = 70,
            badge = "Code",
        ),
        AiModel(
            id = "avek-sage",
            name = "Sage",
            version = "2",
            tagline = "Deep research with a 1M window",
            description = "Reads widely, cross-checks sources and writes structured, cited briefs.",
            contextWindowK = 1000,
            maxDepth = ThinkingDepth.MAXIMUM,
            speed = 2,
            intelligence = 5,
            strengths = setOf(TaskMode.DEEP_RESEARCH, TaskMode.LEARN, TaskMode.ANALYSIS),
            tokensPerSecond = 38,
            badge = "1M context",
        ),
        AiModel(
            id = "avek-muse",
            name = "Muse",
            version = "3",
            tagline = "Creative writing partner",
            description = "Voice, rhythm and imagination — for stories, copy and brainstorming.",
            contextWindowK = 200,
            maxDepth = ThinkingDepth.DEEP,
            speed = 4,
            intelligence = 4,
            strengths = setOf(TaskMode.WRITING, TaskMode.BRAINSTORM),
            tokensPerSecond = 90,
            badge = "Creative",
        ),
        AiModel(
            id = "avek-lumen",
            name = "Lumen",
            version = "1",
            tagline = "A patient tutor",
            description = "Explains step by step, checks understanding and adapts to your level.",
            contextWindowK = 128,
            maxDepth = ThinkingDepth.DEEP,
            speed = 4,
            intelligence = 3,
            strengths = setOf(TaskMode.LEARN, TaskMode.MATH),
            tokensPerSecond = 75,
            badge = "Preview",
        ),
    )

    override val defaultModel: AiModel = models[1]
}
