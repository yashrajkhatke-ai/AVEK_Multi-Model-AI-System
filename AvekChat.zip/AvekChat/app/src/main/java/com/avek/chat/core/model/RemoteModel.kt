package com.avek.chat.core.model

enum class ModelKind { TEXT, VISION }

/** Load state of a model on the PC (UI-WIRE v3 section 8.2). [UNKNOWN] = not connected: shown as nothing. */
enum class ModelLoadState(val wire: String) {
    UNLOADED("unloaded"),
    LOADING("loading"),
    READY("ready"),
    ERROR("error"),
    UNKNOWN("");

    companion object {
        fun fromWire(value: String?): ModelLoadState = entries.firstOrNull { it.wire == value && it != UNKNOWN } ?: UNKNOWN
    }
}

/** One chip of a model card. The first one of every model is the context window (`key == "context"`). */
data class Capability(val key: String, val label: String)

/**
 * A model the PC can run (one model card; section 8.2). Every model has every field and the app only
 * draws them: there is no per-model logic anywhere in the UI.
 */
data class RemoteModel(
    val id: String,
    val name: String,
    val kind: ModelKind,
    val rank: Int,
    val tagline: String = "",
    val description: String = "",
    val badge: String? = null,
    /** 1..5 meters. */
    val intelligence: Int = 0,
    val speed: Int = 0,
    val thinking: Int = 0,
    val contextTokens: Int = 0,
    val capabilities: List<Capability> = emptyList(),
    val sizeBytes: Long = 0,
    val state: ModelLoadState = ModelLoadState.UNKNOWN,
    val measuredTps: Double? = null,
) {
    val isVision: Boolean get() = kind == ModelKind.VISION
}
