package com.avek.chat.core.model

enum class ModelKind { TEXT, VISION }

/** A model the PC can run right now. The PC lists only available chat models, best first. */
data class RemoteModel(
    val id: String,
    val name: String,
    val kind: ModelKind,
    val note: String,
    val contextTokens: Int,
    val rank: Int,
) {
    val isVision: Boolean get() = kind == ModelKind.VISION

    /** "80K context", "1M context" (binary thousands, so 81920 tokens read as 80K). */
    val contextLabel: String
        get() = when {
            contextTokens <= 0 -> ""
            contextTokens >= 1_000_000 -> "${(contextTokens / 1_000_000f).toString().removeSuffix(".0")}M context"
            else -> "${(contextTokens / 1024f).let { if (it % 1f == 0f) it.toInt().toString() else "%.1f".format(it) }}K context"
        }
}
