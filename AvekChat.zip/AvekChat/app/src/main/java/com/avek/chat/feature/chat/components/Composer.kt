package com.avek.chat.feature.chat.components

import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.expandHorizontally
import com.avek.chat.core.designsystem.theme.avekShape
import com.avek.chat.core.designsystem.theme.avekPill
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.foundation.Canvas
import androidx.compose.material.icons.outlined.Mic
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.AttachFile
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.ErrorOutline
import androidx.compose.material.icons.outlined.ExpandLess
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.KeyboardArrowDown
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import com.avek.chat.core.designsystem.component.ThinkingDepthBar
import com.avek.chat.core.designsystem.icon.icon
import com.avek.chat.core.designsystem.motion.DepthGlyph
import com.avek.chat.core.designsystem.motion.ThinkingIndicator
import com.avek.chat.core.designsystem.theme.AvekTheme
import com.avek.chat.feature.chat.AttachStatus
import com.avek.chat.feature.chat.PendingAttachment
import com.avek.chat.core.model.TaskMode
import com.avek.chat.core.model.ThinkingDepth

/**
 * The floating input card: text field, attachments, task mode, thinking depth
 * (with an expandable depth bar) and send / stop.
 */
@Composable
fun Composer(
    draft: String,
    onDraftChange: (String) -> Unit,
    onSend: () -> Unit,
    onStop: () -> Unit,
    isGenerating: Boolean,
    isNewChat: Boolean,
    modelName: String?,
    /** The PC is reachable: otherwise the field is disabled (a typed draft is kept). */
    enabled: Boolean,
    canSend: Boolean,
    task: TaskMode,
    depth: ThinkingDepth,
    onDepthChange: (ThinkingDepth) -> Unit,
    model: com.avek.chat.feature.chat.ModelChip = com.avek.chat.feature.chat.ModelChip(loading = false),
    onOpenModelPicker: () -> Unit = {},
    onOpenTaskPicker: () -> Unit,
    attachments: List<PendingAttachment>,
    onPickPhotos: () -> Unit,
    onPickFiles: () -> Unit,
    onRemoveAttachment: (String) -> Unit,
    onComingSoon: (String) -> Unit,
    modifier: Modifier = Modifier,
    /** The context circle of this chat (null = no data: an empty dashed ring). */
    context: com.avek.chat.core.link.wire.ContextDataDto? = null,
    onContextClick: () -> Unit = {},
) {
    val colors = AvekTheme.colors
    val type = AvekTheme.type
    var depthOpen by remember { mutableStateOf(false) }
    var attachOpen by remember { mutableStateOf(false) }

    Column(
        modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp)
            .padding(bottom = 8.dp)
            .shadow(10.dp, avekShape(26.dp), ambientColor = Color.Black.copy(alpha = 0.08f), spotColor = Color.Black.copy(alpha = 0.12f))
            .clip(avekShape(26.dp))
            .background(colors.composer)
            .border(1.dp, colors.composerBorder, avekShape(26.dp)),
    ) {
        AnimatedVisibility(
            visible = depthOpen,
            enter = expandVertically() + fadeIn(),
            exit = shrinkVertically() + fadeOut(),
        ) {
            Column {
                ThinkingDepthBar(
                    depth = depth,
                    onDepthChange = onDepthChange,
                    maxDepth = ThinkingDepth.MAXIMUM,
                    modelName = modelName ?: "The model",
                    modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 12.dp),
                )
                HorizontalDivider(color = colors.outline.copy(alpha = 0.5f))
            }
        }

        if (attachments.isNotEmpty()) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(start = 14.dp, end = 14.dp, top = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                attachments.forEach { AttachmentChip(it, onRemove = { onRemoveAttachment(it.key) }) }
            }
        }

        model.statusLine?.let { line ->
            Text(
                line,
                style = AvekTheme.type.caption,
                color = if (model.error != null) colors.danger else colors.textSecondary,
                modifier = Modifier.padding(start = 18.dp, end = 18.dp, top = 10.dp),
            )
        }

        Box(Modifier.padding(start = 18.dp, end = 18.dp, top = 14.dp, bottom = 4.dp)) {
            if (draft.isEmpty()) {
                Text(
                    when {
                        !enabled -> "PC not reachable"
                        isNewChat || modelName == null -> "How can I help you today?"
                        else -> "Reply to $modelName…"
                    },
                    style = AvekTheme.type.userMessage,
                    color = colors.textTertiary,
                )
            }
            BasicTextField(
                value = draft,
                onValueChange = onDraftChange,
                enabled = enabled,
                textStyle = AvekTheme.type.userMessage.copy(color = colors.textPrimary),
                cursorBrush = SolidColor(colors.accent),
                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
                maxLines = 8,
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 26.dp),
            )
        }

        Row(
            Modifier
                .fillMaxWidth()
                .padding(start = 8.dp, end = 8.dp, bottom = 8.dp, top = 2.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box {
                PlainIconButton(Icons.Outlined.Add, "Attach", active = attachOpen, onClick = { attachOpen = true })
                DropdownMenu(
                    expanded = attachOpen,
                    onDismissRequest = { attachOpen = false },
                    containerColor = colors.surface,
                ) {
                    listOf(
                        Triple("Photos", Icons.Outlined.Image, onPickPhotos),
                        Triple("Files", Icons.Outlined.AttachFile, onPickFiles),
                    ).forEach { (label, icon, pick) ->
                        DropdownMenuItem(
                            text = { Text(label, style = type.body, color = colors.textPrimary) },
                            leadingIcon = { Icon(icon, null, tint = colors.textSecondary) },
                            enabled = enabled,
                            onClick = {
                                attachOpen = false
                                pick()
                            },
                        )
                    }
                }
            }

            Row(
                Modifier
                    .weight(1f)
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                if (model.name != null) {
                    ComposerPill(onClick = onOpenModelPicker, highlighted = false) {
                        ModelStateDot(model.loadState, Modifier.size(9.dp))
                        if (model.loadState != com.avek.chat.core.model.ModelLoadState.UNKNOWN) Spacer(Modifier.width(6.dp))
                        Text(model.name, style = type.label, color = colors.textPrimary, maxLines = 1)
                    }
                }
                ComposerPill(onClick = onOpenTaskPicker, highlighted = !task.isAuto) {
                    Icon(task.icon, contentDescription = null, tint = if (task.isAuto) colors.textSecondary else colors.textPrimary, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    AnimatedContent(task.label, transitionSpec = { fadeIn() togetherWith fadeOut() }, label = "task-label") { text ->
                        Text(text, style = type.label, color = colors.textPrimary, maxLines = 1)
                    }
                }
                ComposerPill(onClick = { depthOpen = !depthOpen }, highlighted = depthOpen) {
                    if (depth.thinks) {
                        DepthGlyph(depth, colors.thinkingGlow, Modifier.size(16.dp), AvekTheme.motion.animationSpeed, animate = !AvekTheme.motion.reduceMotion)
                    } else {
                        DepthGlyph(depth, colors.textSecondary, Modifier.size(16.dp), animate = false)
                    }
                    Spacer(Modifier.width(6.dp))
                    Text(depth.label, style = type.label, color = colors.textPrimary, maxLines = 1)
                    Spacer(Modifier.width(2.dp))
                    Icon(
                        if (depthOpen) Icons.Outlined.ExpandLess else Icons.Outlined.KeyboardArrowDown,
                        contentDescription = null,
                        tint = colors.textSecondary,
                        modifier = Modifier.size(16.dp),
                    )
                }
            }

            // Empty composer: dictation mic + voice-mode button. Typing morphs the
            // voice button into send; while a reply streams it becomes stop.
            val mode = when {
                isGenerating -> PrimaryAction.STOP
                draft.isNotBlank() || attachments.isNotEmpty() -> PrimaryAction.SEND
                else -> PrimaryAction.VOICE
            }
            AnimatedVisibility(
                visible = mode == PrimaryAction.VOICE,
                enter = fadeIn() + scaleIn(initialScale = 0.6f) + expandHorizontally(expandFrom = Alignment.End),
                exit = fadeOut() + scaleOut(targetScale = 0.6f) + shrinkHorizontally(shrinkTowards = Alignment.End),
            ) {
                PlainIconButton(Icons.Outlined.Mic, "Dictate", active = false, onClick = { onComingSoon("Voice dictation") })
            }
            // The context circle: always visible between the microphone and the send arrow.
            ContextCircle(context, onClick = onContextClick)
            Spacer(Modifier.width(2.dp))
            PrimaryActionButton(
                mode = mode,
                enabled = mode == PrimaryAction.STOP || mode == PrimaryAction.VOICE || canSend,
                onSend = {
                    depthOpen = false
                    onSend()
                },
                onStop = onStop,
                onVoice = { onComingSoon("Voice conversations") },
            )
        }
    }
}

private enum class PrimaryAction { VOICE, SEND, STOP }

@Composable
private fun PrimaryActionButton(mode: PrimaryAction, enabled: Boolean, onSend: () -> Unit, onStop: () -> Unit, onVoice: () -> Unit) {
    val colors = AvekTheme.colors
    // At rest the button is a light hairline circle; once there's something to
    // act on (send / stop) the ring thickens and darkens.
    val active = mode != PrimaryAction.VOICE
    val ring by animateColorAsState(if (active) colors.textPrimary else colors.outline, label = "primary-ring")
    val ringWidth by animateDpAsState(if (active) 2.dp else 1.dp, label = "primary-ring-width")
    val tint by animateColorAsState(if (active) colors.textPrimary else colors.textSecondary, label = "primary-tint")
    Box(
        Modifier
            .size(40.dp)
            .clip(CircleShape)
            .border(ringWidth, ring, CircleShape)
            .graphicsLayer { alpha = if (enabled) 1f else 0.4f }
            .clickable(enabled = enabled) {
                when (mode) {
                    PrimaryAction.VOICE -> onVoice()
                    PrimaryAction.SEND -> onSend()
                    PrimaryAction.STOP -> onStop()
                }
            },
        contentAlignment = Alignment.Center,
    ) {
        AnimatedContent(
            targetState = mode,
            transitionSpec = { (scaleIn(initialScale = 0.5f) + fadeIn()) togetherWith (scaleOut(targetScale = 0.5f) + fadeOut()) },
            label = "primary-icon",
        ) { current ->
            when (current) {
                PrimaryAction.VOICE -> VoiceWaveIcon(tint, Modifier.size(width = 18.dp, height = 16.dp))
                PrimaryAction.SEND -> Icon(Icons.Filled.ArrowUpward, contentDescription = "Send", tint = tint, modifier = Modifier.size(20.dp))
                PrimaryAction.STOP -> Box(contentAlignment = Alignment.Center) {
                    ThinkingIndicator(
                        style = com.avek.chat.core.model.settings.ThinkingAnimation.PULSE,
                        color = colors.textPrimary.copy(alpha = 0.25f),
                        modifier = Modifier.size(34.dp),
                        intensity = 0.2f,
                        animate = !AvekTheme.motion.reduceMotion,
                    )
                    Icon(Icons.Filled.Stop, contentDescription = "Stop", tint = tint, modifier = Modifier.size(18.dp))
                }
            }
        }
    }
}

/** Voice-mode glyph: seven rounded bars of varying height, like an audio waveform. */
@Composable
private fun VoiceWaveIcon(color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier.semantics { contentDescription = "Voice mode" }) {
        val heights = floatArrayOf(0.28f, 0.6f, 0.4f, 1f, 0.4f, 0.6f, 0.28f)
        val gap = size.width / (heights.size * 2 - 1)
        heights.forEachIndexed { i, h ->
            val x = gap / 2 + i * gap * 2
            val half = size.height * h / 2
            drawLine(
                color = color,
                start = Offset(x, size.height / 2 - half),
                end = Offset(x, size.height / 2 + half),
                strokeWidth = gap,
                cap = StrokeCap.Round,
            )
        }
    }
}

/**
 * A bare icon with no container, like the reference design: light grey at rest,
 * dark while pressed or while whatever it opened is showing.
 */
@Composable
private fun PlainIconButton(icon: ImageVector, description: String, active: Boolean, onClick: () -> Unit) {
    val colors = AvekTheme.colors
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val tint by animateColorAsState(if (active || pressed) colors.textPrimary else colors.textTertiary, label = "icon-tint")
    Box(
        Modifier
            .size(40.dp)
            .clip(CircleShape)
            .clickable(interactionSource = interaction, indication = null, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, contentDescription = description, tint = tint, modifier = Modifier.size(24.dp))
    }
}

@Composable
private fun ComposerPill(onClick: () -> Unit, highlighted: Boolean, content: @Composable () -> Unit) {
    val colors = AvekTheme.colors
    val border by animateColorAsState(if (highlighted) colors.textPrimary else colors.outline, label = "pill")
    val width by animateDpAsState(if (highlighted) 2.dp else 1.dp, label = "pill-width")
    Row(
        Modifier
            .clip(avekPill())
            .border(width, border, avekPill())
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) { content() }
}

/** Tiny bold label used by several chat components. */
@Composable
internal fun MetaLabel(text: String, color: Color = AvekTheme.colors.textSecondary) {
    Text(text, style = AvekTheme.type.caption.copy(fontWeight = FontWeight.Medium), color = color, maxLines = 1)
}


/** A picked file: name, upload progress, and a button that removes it (cancelling a running upload). */
@Composable
private fun AttachmentChip(attachment: PendingAttachment, onRemove: () -> Unit) {
    val colors = AvekTheme.colors
    val failed = attachment.status == AttachStatus.FAILED
    Row(
        Modifier
            .clip(avekShape(14.dp))
            .border(1.dp, if (failed) colors.danger.copy(alpha = 0.6f) else colors.outline, avekShape(14.dp))
            .padding(start = 10.dp, end = 4.dp, top = 6.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            if (failed) Icons.Outlined.ErrorOutline else Icons.Outlined.Description,
            contentDescription = null,
            tint = if (failed) colors.danger else colors.textSecondary,
            modifier = Modifier.size(18.dp),
        )
        Spacer(Modifier.width(8.dp))
        Column(Modifier.widthIn(max = 150.dp)) {
            Text(attachment.name, style = AvekTheme.type.caption.copy(fontWeight = FontWeight.Medium), color = colors.textPrimary, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
            if (attachment.status == AttachStatus.UPLOADING) {
                LinearProgressIndicator(
                    progress = { attachment.progress },
                    modifier = Modifier.fillMaxWidth().padding(top = 3.dp).height(3.dp),
                    color = colors.accent,
                    trackColor = colors.outline.copy(alpha = 0.5f),
                )
            } else {
                Text(
                    if (failed) attachment.error ?: "Upload failed" else formatSize(attachment.size),
                    style = AvekTheme.type.caption,
                    color = if (failed) colors.danger else colors.textTertiary,
                    maxLines = 1,
                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                )
            }
        }
        Box(
            Modifier
                .size(28.dp)
                .clip(CircleShape)
                .clickable(onClick = onRemove),
            contentAlignment = Alignment.Center,
        ) {
            Icon(Icons.Outlined.Close, contentDescription = "Remove ${attachment.name}", tint = colors.textSecondary, modifier = Modifier.size(15.dp))
        }
    }
}

internal fun formatSize(bytes: Long): String = when {
    bytes >= 1_048_576 -> "%.1f MB".format(bytes / 1_048_576.0)
    bytes >= 1024 -> "${bytes / 1024} KB"
    else -> "$bytes B"
}
