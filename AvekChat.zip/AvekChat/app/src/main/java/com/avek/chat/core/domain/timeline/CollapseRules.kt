package com.avek.chat.core.domain.timeline

/** The open/closed state of one row (keyed by chat, prompt and block id). */
data class RowState(val expanded: Boolean = false, val pinned: Boolean = false)

/**
 * The rules of section 13, "The thinking section" (pure, JVM-tested):
 * a thinking block that streams can be opened; when it ends it closes by itself unless the person
 * tapped it after it ended (pinned). Tool, agent and note rows never close by themselves.
 */
object CollapseRules {

    fun onTap(state: RowState, ended: Boolean): RowState =
        if (ended) RowState(expanded = !state.expanded, pinned = true) else state.copy(expanded = !state.expanded)

    fun onEnd(kind: String, state: RowState, collapseWhenEnds: Boolean = true): RowState =
        if (kind == BlockKind.THINKING && collapseWhenEnds && !state.pinned) state.copy(expanded = false) else state

    /**
     * A group is open while it is the running one (the turn runs and no answer followed it yet),
     * unless the person chose otherwise ([userChoice]); every other group is closed by default.
     */
    fun groupExpanded(group: LayoutItem.Group, turnLive: Boolean, isLastGroup: Boolean, userChoice: Boolean?, keepRunningOpen: Boolean = true): Boolean =
        userChoice ?: (keepRunningOpen && turnLive && isLastGroup && !group.followedByAnswer)
}
