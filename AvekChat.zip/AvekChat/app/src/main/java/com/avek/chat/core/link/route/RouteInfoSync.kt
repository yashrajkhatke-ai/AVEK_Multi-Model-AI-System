package com.avek.chat.core.link.route

import com.avek.chat.core.link.store.PairedPcStore
import com.avek.chat.core.link.wire.RoutesData

/**
 * Keeps the stored routes fresh (UI-WIRE v4 section 8.9): the answer of `routes.get` after every
 * connection and every `routes.changed`. The store seals them with the other secrets. This is the
 * only way the app learns the Tailscale host and the ngrok address.
 */
class RouteInfoSync(private val store: PairedPcStore) {

    /** Calls `routes.get` through [fetch] and stores the answer. */
    suspend fun refresh(fetch: suspend () -> RoutesData): RoutesData {
        val routes = fetch()
        apply(routes)
        return routes
    }

    fun apply(routes: RoutesData) {
        store.update { if (it.routes == routes) it else it.copy(routes = routes) }
    }
}
