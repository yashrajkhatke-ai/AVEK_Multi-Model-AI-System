package com.avek.chat.di

import com.avek.chat.core.common.TimeProvider
import com.avek.chat.core.data.downloads.DownloadDatabase
import com.avek.chat.core.data.downloads.DownloadManager
import com.avek.chat.core.data.downloads.DownloadedChatStore
import com.avek.chat.core.data.downloads.LocalChatRepository
import com.avek.chat.core.data.downloads.RoomDownloadedChatStore
import com.avek.chat.core.data.remote.ChatSource
import com.avek.chat.core.data.remote.RemoteChatRepository
import com.avek.chat.core.domain.chat.AskCoordinator
import com.avek.chat.core.domain.chat.AttachmentUploader
import com.avek.chat.core.domain.chat.GenerateReplyUseCase
import com.avek.chat.core.domain.chat.OpenChatBus
import com.avek.chat.core.domain.chat.TurnFollower
import com.avek.chat.core.domain.lists.ListMemoryRegistry
import com.avek.chat.core.domain.repository.ChatRepository
import com.avek.chat.core.link.HarnessApi
import com.avek.chat.core.link.LinkRepository
import com.avek.chat.core.link.route.ConnectionState
import com.avek.chat.core.link.wire.LimitsDto
import com.avek.chat.core.model.settings.UserSettings
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import javax.inject.Singleton

/** Chats, downloads, asks and uploads: the use cases and repositories on top of the link. */
@Module
@InstallIn(SingletonComponent::class)
object DataModule {

    @Provides
    @Singleton
    fun provideDownloadedStore(database: DownloadDatabase, time: TimeProvider): DownloadedChatStore = RoomDownloadedChatStore(database, time)

    @Provides
    @Singleton
    fun provideRemoteChats(api: HarnessApi): RemoteChatRepository = RemoteChatRepository(api)

    @Provides
    @Singleton
    fun provideLocalChats(store: DownloadedChatStore): LocalChatRepository = LocalChatRepository(store)

    /** Connected: the PC. Not connected: the downloaded copy, read only. */
    @Provides
    @Singleton
    fun provideChats(
        remote: RemoteChatRepository,
        local: LocalChatRepository,
        link: LinkRepository,
        store: DownloadedChatStore,
    ): ChatRepository = ChatSource(
        remote = remote,
        local = local,
        isConnected = { link.state.value is ConnectionState.Connected },
        isDownloaded = { chatId -> chatId in store.ids() },
    )

    @Provides
    @Singleton
    fun provideTurnFollower(chats: ChatRepository): TurnFollower = TurnFollower(chats)

    @Provides
    @Singleton
    fun provideGenerateReply(api: HarnessApi, link: LinkRepository, follower: TurnFollower, time: TimeProvider): GenerateReplyUseCase =
        GenerateReplyUseCase(api, link, follower, time)

    @Provides
    @Singleton
    fun provideUploader(api: HarnessApi, link: LinkRepository): AttachmentUploader =
        AttachmentUploader(api) { link.ready.value?.limits ?: LimitsDto() }

    @Provides
    @Singleton
    fun provideAsks(api: HarnessApi, link: LinkRepository, @ApplicationScope scope: CoroutineScope): AskCoordinator =
        AskCoordinator(api, link, scope)

    @Provides
    @Singleton
    fun provideDownloadManager(
        api: HarnessApi,
        store: DownloadedChatStore,
        link: LinkRepository,
        settings: StateFlow<UserSettings>,
        @ApplicationScope scope: CoroutineScope,
    ): DownloadManager = DownloadManager(
        api = api,
        store = store,
        link = link,
        demoMode = settings.map { it.connection.demoMode }.distinctUntilChanged().stateIn(scope, SharingStarted.Eagerly, settings.value.connection.demoMode),
        scope = scope,
    )

    @Provides
    @Singleton
    fun provideModelStates(link: LinkRepository, api: HarnessApi, @ApplicationScope scope: CoroutineScope): com.avek.chat.core.domain.models.ModelStateTracker =
        com.avek.chat.core.domain.models.ModelStateTracker(link, api, scope)

    @Provides
    @Singleton
    fun provideModelPreloader(
        api: HarnessApi,
        link: LinkRepository,
        tracker: com.avek.chat.core.domain.models.ModelStateTracker,
        settings: StateFlow<UserSettings>,
        @ApplicationScope scope: CoroutineScope,
    ): com.avek.chat.core.domain.models.ModelPreloader =
        com.avek.chat.core.domain.models.ModelPreloader(api, link, tracker, { settings.value.connection.demoMode }, scope)

    @Provides
    @Singleton
    fun provideTraceRepository(
        link: LinkRepository,
        api: HarnessApi,
        settings: StateFlow<UserSettings>,
        @ApplicationScope scope: CoroutineScope,
    ): com.avek.chat.core.domain.trace.TraceRepository =
        com.avek.chat.core.domain.trace.TraceRepository(link, api, scope, { settings.value.connection.demoMode })

    @Provides
    @Singleton
    fun provideFrameClock(): com.avek.chat.core.domain.chat.FrameClock = com.avek.chat.platform.android.ChoreographerFrameClock()

    @Provides
    @Singleton
    fun provideListMemoryRegistry(): ListMemoryRegistry = ListMemoryRegistry()

    @Provides
    @Singleton
    fun provideOpenChatBus(): OpenChatBus = OpenChatBus()
}
