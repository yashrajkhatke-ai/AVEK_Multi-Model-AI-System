package com.avek.chat.feature.chat.thinking.panels

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.avek.chat.core.designsystem.theme.AvekTheme
import com.avek.chat.core.domain.trace.TokenKind
import com.avek.chat.core.domain.trace.TurnTelemetry
import com.avek.chat.core.link.wire.TraceRuntimeDto
import com.avek.chat.feature.chat.thinking.ThinkingFormat

// ------------------------------------------------------------------ 1. minimal line

/** "Ornith 1.5 9B · Thinking · 4.2 s · 38 tok/s" */
fun minimalLine(t: TurnTelemetry, phase: String, elapsedMs: Long?): String = listOfNotNull(
    t.modelName.ifEmpty { null },
    phase,
    elapsedMs?.let { ThinkingFormat.ms(it) },
    t.tps?.let { ThinkingFormat.tps(it) },
).joinToString(" · ")

// ------------------------------------------------------------------ 2. live token ticker

/** The last ~40 tokens of reasoning (real `thinking.delta` text) scrolling by, with the reasoning count. */
@Composable
fun TickerPanel(t: TurnTelemetry, thinkingText: String, compact: Boolean, modifier: Modifier = Modifier) {
    val palette = rememberThinkingPalette()
    // The last 40 reasoning deltas are the last 40 tokens: their sizes come from the token cells.
    val tail = remember(thinkingText, t.tokenCount) {
        val chars = t.tokens.filter { it.kind == TokenKind.REASONING }.takeLast(TICKER_TOKENS).sumOf { it.chars }
        val take = if (chars > 0) chars else 160
        thinkingText.takeLast(take).replace('\n', ' ')
    }
    Column(modifier.fillMaxWidth()) {
        if (tail.isBlank()) {
            NoData("No reasoning text yet")
        } else {
            Text(
                tail,
                style = AvekTheme.type.code.copy(fontSize = AvekTheme.type.caption.fontSize),
                color = palette.text,
                maxLines = if (compact) 1 else 3,
                overflow = TextOverflow.Clip,
                modifier = Modifier.fillMaxWidth(),
            )
        }
        val count = t.steps.takeIf { it.isNotEmpty() }?.let { t.reasoningTokens }
        Text(
            "${count?.toString() ?: t.tokens.count { it.kind == TokenKind.REASONING }.takeIf { it > 0 }?.let { "$it streamed" } ?: ThinkingFormat.NONE} reasoning tokens",
            style = AvekTheme.type.caption, color = palette.muted,
        )
    }
}

private const val TICKER_TOKENS = 40

// ------------------------------------------------------------------ 10. runtime panel

@Composable
fun RuntimePanel(runtime: TraceRuntimeDto?, compact: Boolean, modifier: Modifier = Modifier) {
    val palette = rememberThinkingPalette()
    val r = runtime ?: return NoData("The PC has not reported its runtime yet", modifier)
    Column(modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        if (!compact) PanelTitle("Models", trailing = "${r.engine}${if (r.handoff.isNotEmpty()) " · ${r.handoff}" else ""}")
        r.models.forEach { m ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Dot(
                    when (m.state) {
                        "ready" -> palette.success
                        "loading" -> palette.accent
                        "error" -> palette.danger
                        else -> palette.track
                    },
                )
                Spacer(Modifier.width(6.dp))
                Text(m.name.ifEmpty { m.id }, style = AvekTheme.type.caption, color = palette.text, modifier = Modifier.weight(1f))
                Text(listOfNotNull(m.state, if (m.onGpu) "GPU" else "CPU", m.loadMs?.let { "loaded in ${ThinkingFormat.ms(it)}" }).joinToString(" · "), style = AvekTheme.type.caption, color = palette.muted)
            }
        }
        r.resources.gpu?.let { gpu ->
            UsageBar("GPU ${gpu.name}", gpu.vramTotalMb - gpu.vramFreeMb, gpu.vramTotalMb, palette, compact)
        }
        if (r.resources.ramTotalMb > 0) UsageBar("RAM", r.resources.ramTotalMb - r.resources.ramFreeMb, r.resources.ramTotalMb, palette, compact)
        r.pool?.let { pool ->
            val used = pool.usedTokens.toLong()
            Column {
                UsageBar("Memory pool (${pool.modelId})", used, pool.totalTokens.toLong(), palette, compact, tokens = true)
                if (!compact) {
                    pool.sessions.forEach { s ->
                        Text("slot ${s.slot} · ${s.role} · ${s.label} · ${ThinkingFormat.tokens(s.window)} · ${s.state}", style = AvekTheme.type.caption, color = palette.muted, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    if (pool.waiting > 0) Text("${pool.waiting} waiting for memory", style = AvekTheme.type.caption, color = palette.warn)
                }
            }
        }
        if (!compact) {
            if (r.plugins.isNotEmpty()) Text("Plug-ins: " + r.plugins.joinToString(", ") { "${it.name} (${it.state})" }, style = AvekTheme.type.caption, color = palette.muted)
            Text("${r.running} turn${if (r.running == 1) "" else "s"} running", style = AvekTheme.type.caption, color = palette.muted)
        }
    }
}

@Composable
private fun UsageBar(label: String, used: Long, total: Long, palette: ThinkingPalette, compact: Boolean, tokens: Boolean = false) {
    val fraction by animateFloatAsState(if (total > 0) (used.toFloat() / total).coerceIn(0f, 1f) else 0f, label = "usage")
    val text = if (tokens) "${ThinkingFormat.tokens(used.toInt())} / ${ThinkingFormat.tokens(total.toInt())}" else "${ThinkingFormat.mb(used)} / ${ThinkingFormat.mb(total)}"
    Column(Modifier.semantics { contentDescription = "$label ${(fraction * 100).toInt()} percent used" }) {
        Row {
            Text(label, style = AvekTheme.type.caption, color = palette.muted, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(text, style = AvekTheme.type.caption, color = palette.text)
        }
        Canvas(Modifier.fillMaxWidth().height(if (compact) 4.dp else 6.dp)) {
            drawRoundRect(palette.track, size = size, cornerRadius = CornerRadius(size.height / 2))
            drawRoundRect(palette.accent, size = Size(size.width * fraction, size.height), cornerRadius = CornerRadius(size.height / 2))
        }
    }
}

// ------------------------------------------------------------------ 11. waterfall

private data class Bar(val label: String, val from: Long, val to: Long, val color: androidx.compose.ui.graphics.Color)

/** Time axis; one row per step and per tool call and a lane for phases; bars grow live; tap to scrub. */
@Composable
fun WaterfallPanel(t: TurnTelemetry, now: Long, compact: Boolean, modifier: Modifier = Modifier) {
    val palette = rememberThinkingPalette()
    val pcNow = t.pcNow(now)
    val origin = t.startedAt ?: t.phases.mapNotNull { it.startT }.minOrNull()
    if (origin == null || pcNow == null) return NoData("No timings yet", modifier)
    val end = maxOf(pcNow, t.endedAt ?: 0L, origin + 1)
    val rows = remember(t.phases, t.steps, t.tools, end) {
        buildList {
            t.phases.filter { it.startT != null }.forEach { p -> add(Bar("phase", p.startT!!, p.endT ?: end, palette.accent.copy(alpha = 0.55f))) }
            t.steps.forEach { s -> add(Bar("Step ${s.step}", s.t - s.stepElapsedMs, if (s.state == "step-done") s.t else end, palette.reasoning)) }
            t.tools.values.forEach { tool ->
                val start = tool.startedAt ?: tool.t
                add(Bar(tool.name, start, if (tool.state == "done" || tool.state == "error") start + (tool.ms ?: 0) else end, palette.toolCall))
            }
        }
    }
    var scrub by remember { mutableStateOf<Float?>(null) }
    val span = (end - origin).coerceAtLeast(1)
    val lanes = remember(rows) { listOf("phase") + rows.map { it.label }.filter { it != "phase" }.distinct() }
    val visibleLanes = if (compact) lanes.take(3) else lanes
    Column(modifier.fillMaxWidth()) {
        Canvas(
            Modifier.fillMaxWidth().height((visibleLanes.size * if (compact) 8 else 14).dp)
                .pointerInput(Unit) { detectTapGestures { scrub = it.x / size.width } },
        ) {
            val laneH = size.height / visibleLanes.size
            rows.forEach { bar ->
                val lane = visibleLanes.indexOf(bar.label)
                if (lane < 0) return@forEach
                val x0 = size.width * (bar.from - origin) / span
                val x1 = size.width * (bar.to - origin) / span
                drawRoundRect(bar.color, Offset(x0, lane * laneH + laneH * 0.15f), Size((x1 - x0).coerceAtLeast(2f), laneH * 0.7f), CornerRadius(3f))
            }
            scrub?.let { drawLine(palette.text, Offset(size.width * it, 0f), Offset(size.width * it, size.height), strokeWidth = 1.5f) }
        }
        if (!compact) {
            Row(Modifier.fillMaxWidth()) {
                Text("0", style = AvekTheme.type.caption, color = palette.faint, modifier = Modifier.weight(1f))
                Text(
                    scrub?.let { "at ${ThinkingFormat.ms((span * it).toLong())}" } ?: lanes.drop(1).joinToString(" · "),
                    style = AvekTheme.type.caption, color = palette.muted, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(3f), textAlign = TextAlign.Center,
                )
                Text(ThinkingFormat.ms(span), style = AvekTheme.type.caption, color = palette.faint, modifier = Modifier.weight(1f), textAlign = TextAlign.End)
            }
        }
    }
}

// ------------------------------------------------------------------ 12. token heat strip

/** Every streamed token as a cell colored by kind, in order; width shows the real time since the previous one. */
@Composable
fun HeatStripPanel(t: TurnTelemetry, compact: Boolean, modifier: Modifier = Modifier) {
    val palette = rememberThinkingPalette()
    val cells = t.tokens
    if (cells.isEmpty()) return NoData("No tokens streamed yet", modifier)
    var picked by remember { mutableStateOf<Int?>(null) }
    // Widths from real inter-token gaps (device receive times), computed once per update, not per draw.
    val widths = remember(cells) {
        FloatArray(cells.size) { i -> if (i == 0) 1f else ((cells[i].atMs - cells[i - 1].atMs).coerceIn(0, 400) / 40f).coerceAtLeast(1f) }
    }
    val total = remember(widths) { widths.sum() }
    Column(modifier.fillMaxWidth()) {
        Canvas(
            Modifier.fillMaxWidth().height(if (compact) 10.dp else 18.dp).pointerInput(cells) {
                detectTapGestures { pos ->
                    var x = 0f
                    val unit = size.width / total
                    for (i in widths.indices) {
                        x += widths[i] * unit
                        if (pos.x <= x) { picked = i; break }
                    }
                }
            },
        ) {
            val unit = size.width / total
            var x = 0f
            for (i in cells.indices) {
                val w = widths[i] * unit
                drawRect(palette.kind(cells[i].kind), Offset(x, 0f), Size((w - 0.5f).coerceAtLeast(0.5f), size.height))
                x += w
            }
        }
        if (!compact) {
            val p = picked?.let { cells.getOrNull(it) }
            Text(
                if (p != null) "Token #${p.index + 1} · ${p.kind.name.lowercase().replace('_', ' ')} · +${p.atMs - cells.first().atMs} ms" else "${t.tokenCount} tokens streamed · tap a cell",
                style = AvekTheme.type.caption, color = palette.muted,
            )
            Legend(listOf("reasoning" to palette.reasoning, "answer" to palette.answer, "tool call" to palette.toolCall))
        }
    }
}

// ------------------------------------------------------------------ 13. dashboard grid

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DashboardPanel(t: TurnTelemetry, phase: String, elapsedMs: Long?, compact: Boolean, modifier: Modifier = Modifier) {
    val palette = rememberThinkingPalette()
    val gpu = t.runtime?.resources?.gpu
    val tiles = listOf(
        "Model" to t.modelName.ifEmpty { ThinkingFormat.NONE },
        "Phase" to phase,
        "Speed" to ThinkingFormat.tps(t.tps),
        "First token" to ThinkingFormat.ms(t.ttftMs),
        "Context" to ThinkingFormat.percent(t.contextFill),
        "Tokens" to if (t.steps.isEmpty()) ThinkingFormat.NONE else "${t.reasoningTokens}/${t.answerTokens}/${t.toolCallTokens}",
        "Steps" to if (t.steps.isEmpty()) ThinkingFormat.NONE else "${t.stepCount}",
        "Tools" to if (t.tools.isEmpty()) ThinkingFormat.NONE else "${t.toolCount}",
        "GPU memory" to (gpu?.let { "${ThinkingFormat.mb(it.vramTotalMb - it.vramFreeMb)} / ${ThinkingFormat.mb(it.vramTotalMb)}" } ?: ThinkingFormat.NONE),
        "Elapsed" to ThinkingFormat.ms(elapsedMs),
    )
    FlowRow(modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        (if (compact) tiles.take(4) else tiles).forEach { (label, value) ->
            Stat(
                label, value,
                Modifier.widthIn(min = 92.dp).clip(RoundedCornerShape(8.dp)).background(palette.track.copy(alpha = 0.18f)).padding(8.dp),
            )
        }
    }
}

// ------------------------------------------------------------------ 14. thought stream

/** The reasoning in a reading layout, with a gutter marking the phases and tool calls that happened. */
@Composable
fun ThoughtStreamPanel(t: TurnTelemetry, thinkingText: String, compact: Boolean, modifier: Modifier = Modifier) {
    val palette = rememberThinkingPalette()
    if (thinkingText.isBlank()) return NoData("No reasoning text yet", modifier)
    val paragraphs = remember(thinkingText) { thinkingText.split("\n\n").filter { it.isNotBlank() } }
    // Markers: phases of the turn and tool calls, in their real order (from the phase history).
    val markers = remember(t.phaseHistory, t.tools) {
        t.phaseHistory.filter { it.state == "start" && it.phase in setOf("thinking", "writing-tool-call", "running-tool", "answering", "compacting") }
            .map { it.label.ifEmpty { ThinkingFormat.phaseName(it.phase) } }
    }
    Row(modifier.fillMaxWidth()) {
        Column(Modifier.width(if (compact) 0.dp else 76.dp)) {
            if (!compact) markers.takeLast(12).forEach {
                Text("● $it", style = AvekTheme.type.caption, color = palette.accent, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(bottom = 6.dp))
            }
        }
        Column(Modifier.weight(1f)) {
            val shown = if (compact) listOf(paragraphs.last()) else paragraphs
            shown.forEach { para ->
                Text(
                    para.trim(),
                    style = AvekTheme.type.thinking,
                    color = palette.text.copy(alpha = 0.9f),
                    maxLines = if (compact) 2 else Int.MAX_VALUE,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(bottom = 8.dp),
                )
            }
        }
    }
}

// ------------------------------------------------------------------ 15. agent-loop graph

@Composable
fun LoopGraphPanel(t: TurnTelemetry, compact: Boolean, modifier: Modifier = Modifier) {
    val palette = rememberThinkingPalette()
    if (t.steps.isEmpty()) return NoData("No model call yet", modifier)
    val pulse by rememberPulse(t.live)
    Column(modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        t.steps.forEachIndexed { i, s ->
            val current = t.live && i == t.steps.lastIndex && s.state != "step-done"
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(if (compact) 20.dp else 28.dp).clip(RoundedCornerShape(50))
                        .background(if (current) palette.accent.copy(alpha = 0.3f + 0.5f * pulse) else palette.accent.copy(alpha = 0.18f)),
                    contentAlignment = Alignment.Center,
                ) { Text("${s.step}", style = AvekTheme.type.caption.copy(fontWeight = FontWeight.Bold), color = palette.text) }
                Spacer(Modifier.width(8.dp))
                Text(
                    "${s.modelName.ifEmpty { s.modelId }} · ${s.tokens.total} tokens${s.ttftMs?.let { " · first token ${ThinkingFormat.ms(it)}" } ?: ""} · ${s.state}",
                    style = AvekTheme.type.caption, color = palette.text, maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
            }
            val tools = t.tools.values.filter { it.step == s.step }
            tools.forEach { tool ->
                Row(Modifier.padding(start = if (compact) 8.dp else 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("↳", color = palette.toolCall, style = AvekTheme.type.caption)
                    Spacer(Modifier.width(6.dp))
                    Chip("${tool.name}${tool.ms?.let { " · ${ThinkingFormat.ms(it)}" } ?: ""}", palette.toolCall)
                }
            }
        }
    }
}

// ------------------------------------------------------------------ 16. radial rings

@Composable
fun RadialRingsPanel(t: TurnTelemetry, compact: Boolean, modifier: Modifier = Modifier) {
    val palette = rememberThinkingPalette()
    val c = t.context
    val step = t.latestGen
    val phaseProgress = remember(t.phases) { if (t.phases.isEmpty()) 0f else t.phases.count { !it.open }.toFloat() / t.phases.size }
    val ringSize = if (compact) 44.dp else 140.dp
    Row(modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Box(contentAlignment = Alignment.Center, modifier = Modifier.size(ringSize).semantics {
            contentDescription = "Context ${ThinkingFormat.percent(t.contextFill)}, ${ThinkingFormat.tps(t.tps)}"
        }) {
            Canvas(Modifier.size(ringSize)) {
                val stroke = size.minDimension * 0.08f
                fun ring(index: Int): Pair<Offset, Size> {
                    val inset = stroke / 2 + index * stroke * 1.5f
                    return Offset(inset, inset) to Size(size.width - inset * 2, size.height - inset * 2)
                }
                // Outer: the context window, segmented by category.
                val (o0, s0) = ring(0)
                drawArc(palette.track, 0f, 360f, false, o0, s0, style = Stroke(stroke))
                if (c != null && c.window > 0) {
                    var start = -90f
                    c.categories.forEach { cat ->
                        val sweep = 360f * cat.tokens / c.window
                        drawArc(palette.category(cat.key), start, sweep, false, o0, s0, style = Stroke(stroke))
                        start += sweep
                    }
                }
                // Middle: tokens of the current step by kind.
                val (o1, s1) = ring(1)
                drawArc(palette.track, 0f, 360f, false, o1, s1, style = Stroke(stroke))
                if (step != null && step.tokens.total > 0) {
                    var start = -90f
                    listOf(step.tokens.reasoning to palette.reasoning, step.tokens.answer to palette.answer, step.tokens.toolCall to palette.toolCall).forEach { (n, color) ->
                        val sweep = 360f * n / step.tokens.total
                        drawArc(color, start, sweep, false, o1, s1, style = Stroke(stroke))
                        start += sweep
                    }
                }
                // Inner: phases done of phases seen.
                val (o2, s2) = ring(2)
                drawArc(palette.track, 0f, 360f, false, o2, s2, style = Stroke(stroke))
                drawArc(palette.accent, -90f, 360f * phaseProgress, false, o2, s2, style = Stroke(stroke))
            }
            if (!compact) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(ThinkingFormat.tps(t.tps), style = AvekTheme.type.caption.copy(fontWeight = FontWeight.Bold), color = palette.text)
                    Text(t.modelName.ifEmpty { ThinkingFormat.NONE }, style = AvekTheme.type.caption, color = palette.muted, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 70.dp))
                }
            }
        }
        if (!compact) {
            Spacer(Modifier.width(12.dp))
            Column {
                Text("Outer: context ${ThinkingFormat.percent(t.contextFill)}", style = AvekTheme.type.caption, color = palette.muted)
                Text("Middle: step ${step?.step ?: ThinkingFormat.NONE} tokens by kind", style = AvekTheme.type.caption, color = palette.muted)
                Text("Inner: ${t.phases.count { !it.open }} of ${t.phases.size} phases done", style = AvekTheme.type.caption, color = palette.muted)
            }
        } else {
            Spacer(Modifier.width(8.dp))
            Text(ThinkingFormat.tps(t.tps), style = AvekTheme.type.caption, color = palette.muted)
        }
    }
}

/** Empty lane spacer used by the inspector. */
@Composable
fun PanelGap() = Spacer(Modifier.height(12.dp).heightIn(min = 12.dp))
