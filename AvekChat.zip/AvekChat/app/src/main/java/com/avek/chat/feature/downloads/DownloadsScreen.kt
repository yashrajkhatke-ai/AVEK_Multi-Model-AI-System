package com.avek.chat.feature.downloads

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.DownloadDone
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.avek.chat.core.common.TimeFormat
import com.avek.chat.core.data.downloads.DownloadedChatInfo
import com.avek.chat.core.designsystem.theme.AvekTheme
import com.avek.chat.feature.chat.components.formatSize

@Composable
fun DownloadsRoute(onBack: () -> Unit, onOpenChat: () -> Unit, viewModel: DownloadsViewModel = hiltViewModel()) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    DownloadsScreen(
        state = state,
        onBack = onBack,
        onOpen = {
            viewModel.open(it)
            onOpenChat()
        },
        onRemove = viewModel::remove,
        onRemoveAll = viewModel::removeAll,
    )
}

@Composable
fun DownloadsScreen(
    state: DownloadsUiState,
    onBack: () -> Unit,
    onOpen: (String) -> Unit,
    onRemove: (String) -> Unit,
    onRemoveAll: () -> Unit,
) {
    val colors = AvekTheme.colors
    var confirmRemove by remember { mutableStateOf<DownloadedChatInfo?>(null) }
    var confirmAll by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = colors.chatBackground,
        topBar = {
            TopAppBar(
                title = { Text("Downloaded chats", style = AvekTheme.type.headline, color = colors.textPrimary) },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Outlined.ArrowBack, "Back", tint = colors.textPrimary) }
                },
                actions = {
                    if (state.chats.isNotEmpty()) TextButton(onClick = { confirmAll = true }) { Text("Remove all", color = colors.danger) }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = colors.chatBackground),
            )
        },
    ) { padding ->
        if (state.chats.isEmpty() && !state.loading) {
            Column(Modifier.fillMaxSize().padding(padding).padding(32.dp), verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Outlined.DownloadDone, null, tint = colors.textTertiary, modifier = Modifier.size(40.dp))
                Spacer(Modifier.padding(6.dp))
                Text("Nothing downloaded yet", style = AvekTheme.type.title, color = colors.textPrimary)
                Text(
                    "Use “Download” in a chat's menu to keep a copy on this device. Downloaded chats stay readable when your PC is not reachable.",
                    style = AvekTheme.type.bodySmall,
                    color = colors.textSecondary,
                    modifier = Modifier.padding(top = 6.dp),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                )
            }
        } else {
            LazyColumn(Modifier.fillMaxSize().padding(padding), contentPadding = PaddingValues(bottom = 32.dp)) {
                item {
                    Text(
                        "${state.chats.size} ${if (state.chats.size == 1) "chat" else "chats"} · ${formatSize(state.totalBytes)} on this device",
                        style = AvekTheme.type.bodySmall,
                        color = colors.textSecondary,
                        modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp),
                    )
                }
                items(state.chats, key = { it.chat.id }) { info ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable { onOpen(info.chat.id) }
                            .padding(start = 20.dp, end = 4.dp, top = 8.dp, bottom = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(info.chat.title, style = AvekTheme.type.body, color = colors.textPrimary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(
                                "${formatSize(info.sizeBytes)} · ${info.chat.turnCount} ${if (info.chat.turnCount == 1) "turn" else "turns"} · ${TimeFormat.relativeDay(info.chat.updatedAt, System.currentTimeMillis())}",
                                style = AvekTheme.type.caption,
                                color = colors.textTertiary,
                            )
                        }
                        Spacer(Modifier.width(8.dp))
                        IconButton(onClick = { confirmRemove = info }) {
                            Icon(Icons.Outlined.DeleteOutline, "Remove download", tint = colors.textSecondary)
                        }
                    }
                    HorizontalDivider(color = colors.outline.copy(alpha = 0.3f), modifier = Modifier.padding(horizontal = 20.dp))
                }
            }
        }
    }

    confirmRemove?.let { info ->
        AlertDialog(
            onDismissRequest = { confirmRemove = null },
            containerColor = colors.surface,
            title = { Text("Remove download?", color = colors.textPrimary) },
            text = { Text("“${info.chat.title}” stays on your PC. Only the copy on this device is removed.", color = colors.textSecondary) },
            confirmButton = {
                TextButton(onClick = {
                    onRemove(info.chat.id)
                    confirmRemove = null
                }) { Text("Remove", color = colors.danger) }
            },
            dismissButton = { TextButton(onClick = { confirmRemove = null }) { Text("Cancel", color = colors.textSecondary) } },
        )
    }
    if (confirmAll) {
        AlertDialog(
            onDismissRequest = { confirmAll = false },
            containerColor = colors.surface,
            title = { Text("Remove all downloads?", color = colors.textPrimary) },
            text = { Text("The chats stay on your PC. Only the copies on this device are removed.", color = colors.textSecondary) },
            confirmButton = {
                TextButton(onClick = {
                    onRemoveAll()
                    confirmAll = false
                }) { Text("Remove all", color = colors.danger) }
            },
            dismissButton = { TextButton(onClick = { confirmAll = false }) { Text("Cancel", color = colors.textSecondary) } },
        )
    }
}
