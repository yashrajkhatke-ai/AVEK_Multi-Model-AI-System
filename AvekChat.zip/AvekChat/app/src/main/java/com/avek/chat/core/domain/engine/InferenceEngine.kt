package com.avek.chat.core.domain.engine

import com.avek.chat.core.model.SourceRef
import com.avek.chat.core.model.TaskMode
import com.avek.chat.core.model.ThinkingDepth
import kotlinx.coroutines.flow.Flow

/**
 * Produces a streamed reply. Only the built-in Demo mode uses it: with a PC, the harness does this work
 * and the app just follows its events. It never receives chat history (the PC owns that).
 */
interface InferenceEngine {
    fun generate(request: GenerationRequest): Flow<GenerationEvent>
}

data class GenerationRequest(
    val task: TaskMode,
    val depth: ThinkingDepth,
    val prompt: String,
    /** Distinguishes regenerations of the same prompt. */
    val variant: Int = 0,
    val tokensPerSecond: Int = 80,
    /** Multiplier applied to simulated streaming speed. */
    val speed: Float = 1f,
)

sealed interface GenerationEvent {
    /** A new reasoning phase began, e.g. "Breaking the problem down". */
    data class ThinkingStep(val title: String) : GenerationEvent
    data class ThinkingDelta(val text: String) : GenerationEvent
    data class ThinkingFinished(val durationMs: Long) : GenerationEvent
    data class SourceFound(val source: SourceRef) : GenerationEvent
    data class AnswerDelta(val text: String) : GenerationEvent
    data object Finished : GenerationEvent
}
