package com.avek.chat.core.domain.engine

import com.avek.chat.core.model.AiModel
import com.avek.chat.core.model.Message
import com.avek.chat.core.model.SourceRef
import com.avek.chat.core.model.TaskMode
import com.avek.chat.core.model.ThinkingDepth
import kotlinx.coroutines.flow.Flow

/**
 * Contract for anything that can produce a streamed reply. The app ships with
 * a simulated engine; a real network-backed engine only needs to implement this.
 */
interface InferenceEngine {
    fun generate(request: GenerationRequest): Flow<GenerationEvent>
}

data class GenerationRequest(
    val model: AiModel,
    val task: TaskMode,
    val depth: ThinkingDepth,
    val prompt: String,
    val history: List<Message>,
    /** Multiplier applied to simulated streaming speed. */
    val speed: Float = 1f,
)

sealed interface GenerationEvent {
    /** A new reasoning phase began, e.g. "Breaking the problem down". */
    data class ThinkingStep(val title: String) : GenerationEvent
    data class ThinkingDelta(val text: String) : GenerationEvent
    data class ThinkingFinished(val durationMs: Long) : GenerationEvent
    data class SourceFound(val source: SourceRef) : GenerationEvent
    data class AnswerDelta(val text: String) : GenerationEvent
    data object Finished : GenerationEvent
}
