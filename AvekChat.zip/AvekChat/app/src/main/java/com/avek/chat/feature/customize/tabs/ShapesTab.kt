package com.avek.chat.feature.customize.tabs

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.avek.chat.core.designsystem.component.SectionHeader
import com.avek.chat.core.designsystem.component.SettingsCard
import com.avek.chat.core.designsystem.component.SliderRow
import com.avek.chat.core.designsystem.theme.AvekTheme
import com.avek.chat.core.designsystem.theme.avekPill
import com.avek.chat.core.designsystem.theme.avekShape
import com.avek.chat.core.designsystem.theme.cornerShape
import com.avek.chat.core.model.settings.CornerStyle
import com.avek.chat.core.model.settings.ShapeSettings
import kotlin.math.roundToInt

private data class RoundnessPreset(val label: String, val value: Float)

private val Presets = listOf(
    RoundnessPreset("Square", 0f),
    RoundnessPreset("Crisp", 0.25f),
    RoundnessPreset("Balanced", 0.55f),
    RoundnessPreset("Soft", 1f),
    RoundnessPreset("Pillowy", 1.5f),
)

/** Global corner roundness and corner style, applied to every surface in the app. */
@Composable
fun ShapesTab(shapes: ShapeSettings, onChange: ((ShapeSettings) -> ShapeSettings) -> Unit) {
    val colors = AvekTheme.colors
    LazyColumn(contentPadding = PaddingValues(bottom = 40.dp)) {
        item { SectionHeader("Preview", subtitle = "Composer, cards, chips and buttons update live") }
        item {
            Column(
                Modifier
                    .padding(horizontal = 16.dp)
                    .fillMaxWidth()
                    .clip(avekShape(20.dp))
                    .background(colors.chatBackground)
                    .border(1.dp, colors.outline, avekShape(20.dp))
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .clip(avekShape(14.dp))
                        .background(colors.surface)
                        .border(1.dp, colors.outline.copy(alpha = 0.7f), avekShape(14.dp))
                        .padding(14.dp),
                ) {
                    Text("A card, like code blocks and source tiles", style = AvekTheme.type.bodySmall, color = colors.textSecondary)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Chip", "Auto", "Deep").forEach { label ->
                        Text(
                            label,
                            style = AvekTheme.type.label,
                            color = colors.textPrimary,
                            modifier = Modifier
                                .clip(avekPill())
                                .border(1.dp, colors.outline, avekPill())
                                .padding(horizontal = 14.dp, vertical = 8.dp),
                        )
                    }
                }
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(avekShape(26.dp))
                        .background(colors.composer)
                        .border(1.dp, colors.composerBorder, avekShape(26.dp))
                        .padding(start = 16.dp, end = 8.dp, top = 8.dp, bottom = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text("Composer", style = AvekTheme.type.body, color = colors.textTertiary, modifier = Modifier.weight(1f))
                    Box(Modifier.size(32.dp).clip(avekPill()).background(colors.textPrimary))
                }
            }
        }

        item { SectionHeader("Roundness") }
        item {
            SettingsCard {
                SliderRow(
                    "Corner roundness",
                    shapes.roundness,
                    { v -> onChange { it.copy(roundness = (v * 20).roundToInt() / 20f) } },
                    0f..1.5f,
                    "${(shapes.roundness * 100).roundToInt()}%",
                )
                HorizontalDivider(color = colors.outline.copy(alpha = 0.4f))
                Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Presets.forEach { preset ->
                        val selected = (shapes.roundness - preset.value) in -0.01f..0.01f
                        Column(
                            Modifier
                                .weight(1f)
                                .clip(avekShape(12.dp))
                                .clickable { onChange { it.copy(roundness = preset.value) } }
                                .padding(vertical = 8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                        ) {
                            val r = 14.dp * preset.value
                            val shape = cornerShape(shapes.style, r, r, r, r)
                            Box(
                                Modifier
                                    .size(36.dp)
                                    .clip(shape)
                                    .background(if (selected) colors.textPrimary else colors.sidebarSelected)
                                    .border(if (selected) 2.dp else 1.dp, if (selected) colors.textPrimary else colors.outline, shape),
                            )
                            Spacer(Modifier.height(6.dp))
                            Text(
                                preset.label,
                                style = AvekTheme.type.caption.copy(fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal),
                                color = if (selected) colors.textPrimary else colors.textSecondary,
                                textAlign = TextAlign.Center,
                            )
                        }
                    }
                }
            }
        }

        item { SectionHeader("Corner style") }
        item {
            SettingsCard {
                CornerStyle.entries.forEachIndexed { index, style ->
                    if (index > 0) HorizontalDivider(color = colors.outline.copy(alpha = 0.4f))
                    val selected = style == shapes.style
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable { onChange { it.copy(style = style) } }
                            .padding(horizontal = 16.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        val shape = cornerShape(style, 12.dp, 12.dp, 12.dp, 12.dp)
                        Box(
                            Modifier
                                .size(40.dp)
                                .clip(shape)
                                .background(colors.sidebarSelected)
                                .border(if (selected) 2.dp else 1.dp, if (selected) colors.textPrimary else colors.outline, shape),
                        )
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(style.label, style = AvekTheme.type.body.copy(fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal), color = colors.textPrimary)
                            Text(style.description, style = AvekTheme.type.caption, color = colors.textSecondary)
                        }
                        if (selected) {
                            Box(Modifier.size(10.dp).clip(avekPill()).background(colors.textPrimary))
                        }
                    }
                }
            }
        }
        item {
            Text(
                "Message bubble corners have their own slider under Chat.",
                style = AvekTheme.type.caption,
                color = colors.textTertiary,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp),
            )
        }
    }
}
