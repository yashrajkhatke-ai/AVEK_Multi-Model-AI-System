package com.avek.chat

import android.app.Application
import android.content.ComponentCallbacks2
import com.avek.chat.core.domain.lists.ListMemoryRegistry
import com.avek.chat.di.AppStarter
import dagger.hilt.android.HiltAndroidApp
import javax.inject.Inject

@HiltAndroidApp
class AvekApplication : Application() {

    @Inject lateinit var starter: AppStarter
    @Inject lateinit var listMemory: ListMemoryRegistry

    override fun onCreate() {
        super.onCreate()
        starter.start()
    }

    /** Low on memory while we are in use: forget the loaded chat and model pages (UI-WIRE section 13). */
    @Deprecated("Deprecated in Java")
    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (level >= ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW) listMemory.trimAll()
    }
}
