package com.avek.chat.core.link.transport

import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.channels.ReceiveChannel
import kotlinx.coroutines.suspendCancellableCoroutine
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import okio.ByteString.Companion.toByteString
import java.io.IOException
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/** Opens raw message channels to a PC. */
fun interface ChannelFactory {
    suspend fun open(target: HostPort): RawChannel
}

/** Wi-Fi: a plain `ws://host:port/ui` WebSocket. Confidentiality comes from AVEK-SEC/1, not from TLS. */
class OkHttpChannelFactory(
    private val base: OkHttpClient = defaultClient(),
    private val binding: WifiBinding = NoWifiBinding,
) : ChannelFactory {

    override suspend fun open(target: HostPort): RawChannel {
        val factory = binding.socketFactory()
        val client = base.newBuilder().apply { if (factory != null) socketFactory(factory) }.build()
        val host = if (':' in target.host && !target.host.startsWith("[")) "[${target.host}]" else target.host
        val request = Request.Builder().url("ws://$host:${target.port}/ui").build()

        return suspendCancellableCoroutine { continuation ->
            val inbox = Channel<RawMessage>(Channel.UNLIMITED)
            val opened = AtomicBoolean(false)
            val finished = AtomicBoolean(false)
            lateinit var socket: WebSocket

            fun finish(code: Int, reason: String) {
                if (finished.compareAndSet(false, true)) {
                    inbox.trySend(RawMessage.Closed(code, reason))
                    inbox.close()
                }
            }

            val channel = object : RawChannel {
                override val remote = target
                override val incoming: ReceiveChannel<RawMessage> = inbox

                override suspend fun sendText(text: String) {
                    if (!socket.send(text)) throw IOException("WebSocket is closed")
                }

                override suspend fun sendBinary(bytes: ByteArray) {
                    if (!socket.send(bytes.toByteString())) throw IOException("WebSocket is closed")
                }

                override fun close(code: Int, reason: String) {
                    socket.close(code, reason.take(120))
                    finish(code, reason)
                }
            }

            socket = client.newWebSocket(
                request,
                object : WebSocketListener() {
                    override fun onOpen(webSocket: WebSocket, response: Response) {
                        opened.set(true)
                        if (continuation.isActive) continuation.resume(channel) else webSocket.cancel()
                    }

                    override fun onMessage(webSocket: WebSocket, text: String) {
                        inbox.trySend(RawMessage.Text(text))
                    }

                    override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
                        inbox.trySend(RawMessage.Binary(bytes.toByteArray()))
                    }

                    override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                        webSocket.close(1000, null)
                        finish(code, reason)
                    }

                    override fun onClosed(webSocket: WebSocket, code: Int, reason: String) = finish(code, reason)

                    override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                        if (!opened.get()) {
                            if (continuation.isActive) continuation.resumeWithException(IOException(t.message ?: "Could not connect", t))
                        } else {
                            finish(1006, t.message ?: "connection failed")
                        }
                    }
                },
            )
            continuation.invokeOnCancellation { socket.cancel() }
        }
    }

    companion object {
        fun defaultClient(): OkHttpClient = OkHttpClient.Builder()
            .connectTimeout(5, TimeUnit.SECONDS)
            .readTimeout(0, TimeUnit.MILLISECONDS)
            .writeTimeout(10, TimeUnit.SECONDS)
            .retryOnConnectionFailure(false)
            .build()
    }
}
