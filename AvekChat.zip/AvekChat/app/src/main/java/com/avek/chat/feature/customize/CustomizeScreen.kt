package com.avek.chat.feature.customize

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Casino
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material.icons.outlined.RestartAlt
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material.icons.outlined.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.PrimaryScrollableTabRow
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.avek.chat.core.designsystem.theme.AvekTheme
import com.avek.chat.core.designsystem.theme.isDark
import com.avek.chat.core.model.settings.FontRole
import com.avek.chat.feature.customize.tabs.ChatTab
import com.avek.chat.feature.customize.tabs.ColorsTab
import com.avek.chat.feature.customize.tabs.FontPickerSheet
import com.avek.chat.feature.customize.tabs.FontsTab
import com.avek.chat.feature.customize.tabs.MotionTab
import com.avek.chat.feature.customize.tabs.ShapesTab
import com.avek.chat.feature.customize.tabs.ThemesTab

private enum class CustomizeTab(val label: String) {
    THEMES("Themes"),
    COLORS("Colors"),
    FONTS("Fonts"),
    SHAPES("Shapes"),
    CHAT("Chat"),
    MOTION("Motion"),
    THINKING("Thinking"),
}

@Composable
fun CustomizeRoute(onBack: () -> Unit, viewModel: CustomizeViewModel = hiltViewModel()) {
    val appearance by viewModel.appearance.collectAsStateWithLifecycle()
    val fontQuery by viewModel.fontQuery.collectAsStateWithLifecycle()
    val fontFilter by viewModel.fontFilter.collectAsStateWithLifecycle()
    val fontResults by viewModel.fontResults.collectAsStateWithLifecycle()
    val thinking by viewModel.thinking.collectAsStateWithLifecycle()
    val thinkingPreview by viewModel.thinkingPreview.collectAsStateWithLifecycle()
    val colors = AvekTheme.colors
    val isDark = appearance.isDark(isSystemInDarkTheme())

    var tab by rememberSaveable { mutableStateOf(CustomizeTab.THEMES) }
    var showPreview by rememberSaveable { mutableStateOf(true) }
    var menu by remember { mutableStateOf(false) }
    var confirmReset by remember { mutableStateOf(false) }
    var pickingFor by remember { mutableStateOf<FontRole?>(null) }

    Scaffold(
        containerColor = colors.chatBackground,
        topBar = {
            TopAppBar(
                title = { Text("Customize", style = AvekTheme.type.headline, color = colors.textPrimary) },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Outlined.ArrowBack, "Back", tint = colors.textPrimary) }
                },
                actions = {
                    IconButton(onClick = { showPreview = !showPreview }) {
                        Icon(if (showPreview) Icons.Outlined.VisibilityOff else Icons.Outlined.Visibility, "Toggle preview", tint = colors.textPrimary)
                    }
                    IconButton(onClick = viewModel::surpriseMe) { Icon(Icons.Outlined.Casino, "Random theme", tint = colors.textPrimary) }
                    IconButton(onClick = { menu = true }) { Icon(Icons.Outlined.MoreVert, "More", tint = colors.textPrimary) }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }, containerColor = colors.surface) {
                        DropdownMenuItem(
                            text = { Text("Reset everything", color = colors.danger) },
                            leadingIcon = { Icon(Icons.Outlined.RestartAlt, null, tint = colors.danger) },
                            onClick = {
                                menu = false
                                confirmReset = true
                            },
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = colors.chatBackground),
            )
        },
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            AnimatedVisibility(showPreview, enter = expandVertically() + fadeIn(), exit = shrinkVertically() + fadeOut()) {
                LivePreview(
                    Modifier
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                        .fillMaxWidth()
                        .height(204.dp),
                )
            }
            PrimaryScrollableTabRow(
                selectedTabIndex = tab.ordinal,
                containerColor = colors.chatBackground,
                contentColor = colors.textPrimary,
                edgePadding = 12.dp,
                indicator = {
                    TabRowDefaults.PrimaryIndicator(
                        modifier = Modifier.tabIndicatorOffset(tab.ordinal, matchContentSize = true),
                        color = colors.accent,
                    )
                },
                divider = {},
            ) {
                CustomizeTab.entries.forEach { entry ->
                    Tab(
                        selected = entry == tab,
                        onClick = { tab = entry },
                        text = { Text(entry.label, style = AvekTheme.type.label) },
                        selectedContentColor = colors.textPrimary,
                        unselectedContentColor = colors.textSecondary,
                    )
                }
            }
            Box(Modifier.weight(1f)) {
                AnimatedContent(tab, transitionSpec = { fadeIn() togetherWith fadeOut() }, label = "customize-tab") { current ->
                    when (current) {
                        CustomizeTab.THEMES -> ThemesTab(
                            themeId = appearance.themeId,
                            themeMode = appearance.themeMode,
                            isDark = isDark,
                            onThemeMode = viewModel::setThemeMode,
                            onTheme = viewModel::setTheme,
                            onSurprise = viewModel::surpriseMe,
                        )
                        CustomizeTab.COLORS -> ColorsTab(
                            appearance = appearance,
                            isDark = isDark,
                            onSetColor = viewModel::setColor,
                            onClearColor = viewModel::clearColor,
                            onClearAll = viewModel::clearAllColors,
                        )
                        CustomizeTab.FONTS -> FontsTab(
                            fonts = appearance.fonts,
                            onStyle = viewModel::setTextStyle,
                            onPickFont = { pickingFor = it },
                            onPairing = viewModel::applyPairing,
                            onReset = viewModel::resetFonts,
                        )
                        CustomizeTab.SHAPES -> ShapesTab(appearance.shapes, viewModel::updateShapes)
                        CustomizeTab.CHAT -> ChatTab(appearance.chat, viewModel::updateChat)
                        CustomizeTab.MOTION -> MotionTab(appearance.motion, viewModel::updateMotion)
                        CustomizeTab.THINKING -> com.avek.chat.feature.customize.tabs.ThinkingTab(thinking, thinkingPreview, viewModel::updateThinking)
                    }
                }
            }
        }
    }

    pickingFor?.let { role ->
        FontPickerSheet(
            role = role,
            current = appearance.fonts[role].font,
            query = fontQuery,
            filter = fontFilter,
            results = fontResults,
            onQuery = viewModel::setFontQuery,
            onFilter = viewModel::setFontFilter,
            onPick = { viewModel.setFont(role, it) },
            onDismiss = { pickingFor = null },
        )
    }

    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            containerColor = colors.surface,
            title = { Text("Reset appearance?", color = colors.textPrimary) },
            text = { Text("Theme, colours, fonts, layout and motion return to their defaults.", color = colors.textSecondary) },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.resetAll()
                    confirmReset = false
                }) { Text("Reset", color = colors.danger) }
            },
            dismissButton = { TextButton(onClick = { confirmReset = false }) { Text("Cancel", color = colors.textSecondary) } },
        )
    }
}
