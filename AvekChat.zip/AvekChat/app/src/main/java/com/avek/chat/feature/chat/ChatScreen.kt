package com.avek.chat.feature.chat

import androidx.activity.compose.BackHandler
import com.avek.chat.core.designsystem.theme.avekShape
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.union
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.avek.chat.core.designsystem.component.LocalShareHandler
import com.avek.chat.core.designsystem.theme.AvekTheme
import com.avek.chat.core.model.TaskMode
import com.avek.chat.feature.chat.components.ChatTopBar
import com.avek.chat.feature.chat.components.TopBarHeight
import com.avek.chat.feature.chat.components.Composer
import com.avek.chat.feature.chat.components.MessageActions
import com.avek.chat.feature.chat.components.MessageList
import com.avek.chat.feature.chat.components.ModelPickerSheet
import com.avek.chat.feature.chat.components.TaskPickerSheet
import com.avek.chat.feature.chat.components.WelcomePane
import com.avek.chat.feature.history.HistoryActions
import com.avek.chat.feature.history.HistoryEvent
import com.avek.chat.feature.history.HistorySidebar
import com.avek.chat.feature.history.HistoryUiState
import com.avek.chat.feature.history.HistoryViewModel
import com.avek.chat.feature.history.RenameDialog
import kotlinx.coroutines.launch

/** Stateful entry point: wires ViewModels to the stateless [ChatScreen]. */
@Composable
fun ChatRoute(
    onOpenCustomize: () -> Unit,
    onOpenSettings: () -> Unit,
    chatViewModel: ChatViewModel = hiltViewModel(),
    historyViewModel: HistoryViewModel = hiltViewModel(),
) {
    val state by chatViewModel.uiState.collectAsStateWithLifecycle()
    val history by historyViewModel.uiState.collectAsStateWithLifecycle()
    val detectedTask by chatViewModel.detectedTask.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }

    LaunchedEffect(chatViewModel) {
        chatViewModel.events.collect { event ->
            when (event) {
                is ChatEvent.Error -> snackbar.showSnackbar(event.message)
                is ChatEvent.Info -> snackbar.showSnackbar(event.message)
            }
        }
    }
    LaunchedEffect(historyViewModel) {
        historyViewModel.events.collect { event ->
            when (event) {
                is HistoryEvent.Deleted -> {
                    val result = snackbar.showSnackbar("Deleted “${event.title}”", actionLabel = "Undo", duration = SnackbarDuration.Long)
                    if (result == SnackbarResult.ActionPerformed) historyViewModel.undoDelete()
                }
                is HistoryEvent.Archived ->
                    snackbar.showSnackbar(if (event.archived) "Archived “${event.title}”" else "Restored “${event.title}”")
            }
        }
    }

    ChatScreen(
        state = state,
        history = history,
        draft = chatViewModel.draft,
        detectedTask = detectedTask,
        snackbar = snackbar,
        onDraftChange = chatViewModel::updateDraft,
        onSend = chatViewModel::send,
        onStop = chatViewModel::stop,
        onSelectModel = chatViewModel::selectModel,
        onSelectTask = chatViewModel::selectTask,
        onSelectDepth = chatViewModel::selectDepth,
        onSuggestion = chatViewModel::useSuggestion,
        onNewChat = chatViewModel::newChat,
        onToggleStar = chatViewModel::toggleStar,
        onRename = chatViewModel::rename,
        onDelete = chatViewModel::deleteActive,
        messageActionsFactory = { copy, share ->
            MessageActions(
                onCopy = copy,
                onShare = share,
                onRegenerate = chatViewModel::regenerate,
                onFeedback = chatViewModel::setFeedback,
                onEdit = chatViewModel::editAndResend,
            )
        },
        historyActions = HistoryActions(
            onQuery = historyViewModel::setQuery,
            onFilter = historyViewModel::setFilter,
            onTaskFilter = historyViewModel::setTaskFilter,
            onOpen = { chatViewModel.openConversation(it.id) },
            onNewChat = chatViewModel::newChat,
            onRename = historyViewModel::rename,
            onToggleStar = historyViewModel::toggleStar,
            onToggleArchive = historyViewModel::toggleArchive,
            onDelete = historyViewModel::delete,
            onCustomize = onOpenCustomize,
            onSettings = onOpenSettings,
        ),
        onOpenCustomize = onOpenCustomize,
        onOpenSettings = onOpenSettings,
    )
}

@Composable
fun ChatScreen(
    state: ChatUiState,
    history: HistoryUiState,
    draft: String,
    detectedTask: TaskMode?,
    snackbar: SnackbarHostState,
    onDraftChange: (String) -> Unit,
    onSend: () -> Unit,
    onStop: () -> Unit,
    onSelectModel: (String) -> Unit,
    onSelectTask: (TaskMode) -> Unit,
    onSelectDepth: (com.avek.chat.core.model.ThinkingDepth) -> Unit,
    onSuggestion: (String, TaskMode) -> Unit,
    onNewChat: () -> Unit,
    onToggleStar: () -> Unit,
    onRename: (String) -> Unit,
    onDelete: () -> Unit,
    messageActionsFactory: (copy: (String) -> Unit, share: (String) -> Unit) -> MessageActions,
    historyActions: HistoryActions,
    onOpenCustomize: () -> Unit,
    onOpenSettings: () -> Unit,
) {
    val colors = AvekTheme.colors
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current
    val share = LocalShareHandler.current
    var showModelPicker by remember { mutableStateOf(false) }
    var showTaskPicker by remember { mutableStateOf(false) }
    var showRename by remember { mutableStateOf(false) }

    val actions = remember(messageActionsFactory) {
        messageActionsFactory(
            { text ->
                clipboard.setText(AnnotatedString(text))
                scope.launch { snackbar.showSnackbar("Copied to clipboard") }
            },
            { text -> share.share(text) },
        )
    }

    BackHandler(enabled = drawerState.isOpen) { scope.launch { drawerState.close() } }

    fun closeDrawerThen(action: () -> Unit) {
        action()
        scope.launch { drawerState.close() }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        scrimColor = colors.scrim,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = colors.sidebar,
                drawerShape = avekShape(topEnd = 24.dp, bottomEnd = 24.dp),
                windowInsets = WindowInsets(0, 0, 0, 0),
                modifier = Modifier.width(318.dp),
            ) {
                HistorySidebar(
                    state = history,
                    selectedId = state.conversationId,
                    actions = historyActions.copy(
                        onOpen = { c -> closeDrawerThen { historyActions.onOpen(c) } },
                        onNewChat = { closeDrawerThen(historyActions.onNewChat) },
                        onCustomize = { closeDrawerThen(historyActions.onCustomize) },
                        onSettings = { closeDrawerThen(historyActions.onSettings) },
                        onClose = { scope.launch { drawerState.close() } },
                    ),
                )
            }
        },
    ) {
        Scaffold(
            containerColor = colors.chatBackground,
            snackbarHost = { SnackbarHost(snackbar) },
            // Insets are handled manually so content can scroll under the top bar.
            contentWindowInsets = WindowInsets(0, 0, 0, 0),
        ) { _ ->
            val topInset = WindowInsets.statusBars.asPaddingValues().calculateTopPadding() + TopBarHeight
            Box(Modifier.fillMaxSize()) {
            Column(
                Modifier
                    .fillMaxSize()
                    .windowInsetsPadding(WindowInsets.navigationBars.union(WindowInsets.ime)),
            ) {
                Box(Modifier.weight(1f)) {
                    AnimatedContent(
                        targetState = state.isEmpty,
                        transitionSpec = { fadeIn() togetherWith fadeOut() },
                        label = "chat-body",
                    ) { empty ->
                        if (empty) {
                            WelcomePane(
                                profileName = state.profileName,
                                onSuggestion = onSuggestion,
                                modifier = Modifier.padding(top = topInset),
                            )
                        } else {
                            MessageList(
                                conversationId = state.conversationId,
                                messages = state.messages,
                                streaming = state.streaming,
                                models = state.models,
                                isGenerating = state.isGenerating,
                                sessionStartedAt = state.sessionStartedAt,
                                actions = actions,
                                modifier = Modifier.fillMaxSize(),
                                topInset = topInset,
                            )
                        }
                    }
                }
                Composer(
                    draft = draft,
                    onDraftChange = onDraftChange,
                    onSend = onSend,
                    onStop = onStop,
                    isGenerating = state.isGenerating,
                    isNewChat = state.conversationId == null,
                    model = state.model,
                    task = state.task,
                    detectedTask = detectedTask,
                    depth = state.depth,
                    onDepthChange = onSelectDepth,
                    onOpenTaskPicker = { showTaskPicker = true },
                    onAttach = { feature -> scope.launch { snackbar.showSnackbar("$feature will work once a real backend is connected") } },
                )
            }
            // Transparent top bar floating over the faded content.
            ChatTopBar(
                model = state.model,
                title = state.title,
                isStarred = state.isStarred,
                hasConversation = state.conversationId != null,
                onMenu = { scope.launch { drawerState.open() } },
                onModelClick = { showModelPicker = true },
                onNewChat = onNewChat,
                onToggleStar = onToggleStar,
                onRename = { showRename = true },
                onDelete = onDelete,
                onCustomize = onOpenCustomize,
                onSettings = onOpenSettings,
            )
            }
        }
    }

    if (showModelPicker) {
        ModelPickerSheet(
            models = state.models,
            selectedId = state.model.id,
            onSelect = {
                onSelectModel(it.id)
                showModelPicker = false
            },
            onDismiss = { showModelPicker = false },
        )
    }
    if (showTaskPicker) {
        TaskPickerSheet(
            selected = state.task,
            detected = detectedTask,
            onSelect = {
                onSelectTask(it)
                showTaskPicker = false
            },
            onDismiss = { showTaskPicker = false },
        )
    }
    if (showRename) {
        RenameDialog(
            initial = state.title.orEmpty(),
            onDismiss = { showRename = false },
            onConfirm = {
                onRename(it)
                showRename = false
            },
        )
    }
}
