package com.avek.chat.feature.chat

import androidx.activity.compose.BackHandler
import com.avek.chat.core.designsystem.theme.avekShape
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.union
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.TextButton
import androidx.compose.material3.Text
import androidx.compose.runtime.DisposableEffect
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.size
import androidx.compose.ui.Alignment
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.avek.chat.core.designsystem.component.LocalFilePicker
import com.avek.chat.core.designsystem.component.LocalShareHandler
import com.avek.chat.core.model.AskRequest
import com.avek.chat.core.model.AskKind
import com.avek.chat.core.domain.lists.ModelPickerState
import com.avek.chat.core.model.RemoteModel
import com.avek.chat.feature.chat.components.AskSheet
import com.avek.chat.feature.chat.components.ConnectionBanner
import com.avek.chat.core.designsystem.theme.AvekTheme
import com.avek.chat.core.model.TaskMode
import com.avek.chat.feature.chat.components.ChatTopBar
import com.avek.chat.feature.chat.components.TopBarHeight
import com.avek.chat.feature.chat.components.Composer
import com.avek.chat.feature.chat.components.MessageActions
import com.avek.chat.feature.chat.components.MessageList
import com.avek.chat.feature.chat.components.ModelPickerSheet
import com.avek.chat.feature.chat.components.TaskPickerSheet
import com.avek.chat.feature.chat.components.WelcomePane
import com.avek.chat.feature.history.HistoryActions
import com.avek.chat.feature.history.HistoryEvent
import com.avek.chat.feature.history.HistorySidebar
import com.avek.chat.feature.history.HistoryUiState
import com.avek.chat.feature.history.HistoryViewModel
import com.avek.chat.feature.history.RenameDialog
import androidx.compose.foundation.layout.Column
import kotlinx.coroutines.launch

/** Stateful entry point: wires ViewModels to the stateless [ChatScreen]. */
@Composable
fun ChatRoute(
    onOpenCustomize: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenConnection: () -> Unit,
    onOpenDownloads: () -> Unit,
    onOnboarding: () -> Unit = {},
    chatViewModel: ChatViewModel = hiltViewModel(),
    historyViewModel: HistoryViewModel = hiltViewModel(),
) {
    val state by chatViewModel.uiState.collectAsStateWithLifecycle()
    val history by historyViewModel.uiState.collectAsStateWithLifecycle()
    val models by chatViewModel.pickerModels.collectAsStateWithLifecycle()
    val ask by chatViewModel.pendingAsk.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }
    val filePicker = LocalFilePicker.current
    val needsOnboarding by chatViewModel.needsOnboarding.collectAsStateWithLifecycle()
    LaunchedEffect(needsOnboarding) { if (needsOnboarding) onOnboarding() }

    LaunchedEffect(chatViewModel) {
        chatViewModel.events.collect { event ->
            when (event) {
                is ChatEvent.Error -> snackbar.showSnackbar(event.message)
                is ChatEvent.Info -> snackbar.showSnackbar(event.message)
            }
        }
    }
    LaunchedEffect(historyViewModel) {
        historyViewModel.events.collect { event ->
            when (event) {
                is HistoryEvent.Message -> snackbar.showSnackbar(event.text)
            }
        }
    }

    ChatScreen(
        state = state,
        thinking = chatViewModel.thinking,
        history = history,
        models = models,
        pendingAsk = ask,
        draft = chatViewModel.draft,
        snackbar = snackbar,
        modelNameFor = chatViewModel::modelNameOf,
        onDraftChange = chatViewModel::updateDraft,
        onSend = chatViewModel::send,
        onStop = chatViewModel::stop,
        onSelectModel = chatViewModel::selectModel,
        onModelSheetOpened = chatViewModel::onModelSheetOpened,
        onModelSheetClosed = chatViewModel::onModelSheetClosed,
        onReloadModels = chatViewModel.modelPicker::reload,
        onSelectTask = chatViewModel::selectTask,
        onSelectDepth = chatViewModel::selectDepth,
        onSuggestion = chatViewModel::useSuggestion,
        onNewChat = chatViewModel::newChat,
        onToggleStar = chatViewModel::toggleStar,
        onRename = chatViewModel::rename,
        onDelete = chatViewModel::deleteActive,
        onToggleDownload = chatViewModel::toggleDownload,
        onRetryLoad = chatViewModel::retryLoad,
        onLoadOlder = chatViewModel::loadOlder,
        onPickPhotos = { filePicker.pick(listOf("image/*"), chatViewModel::attach) },
        onPickFiles = { filePicker.pick(listOf("*/*"), chatViewModel::attach) },
        onRemoveAttachment = chatViewModel::removeAttachment,
        onAskDecision = { a, decision -> chatViewModel.answerAsk(a, decision) },
        onAskText = { a, text -> chatViewModel.answerAskText(a, text) },
        messageActionsFactory = { copy, share ->
            MessageActions(
                onCopy = copy,
                onShare = share,
                onRegenerate = chatViewModel::regenerate,
                onFeedback = chatViewModel::setFeedback,
                onEdit = chatViewModel::editAndResend,
                onLoadThinking = chatViewModel::loadThinking,
                onLoadTool = chatViewModel::loadTool,
            )
        },
        historyActions = HistoryActions(
            onQuery = historyViewModel::setQuery,
            onFilter = historyViewModel::setFilter,
            onTaskFilter = {},
            onOpen = { chatViewModel.openConversation(it.id) },
            onNewChat = chatViewModel::newChat,
            onRename = historyViewModel::rename,
            onToggleStar = historyViewModel::toggleStar,
            onToggleArchive = historyViewModel::toggleArchive,
            onToggleDownload = historyViewModel::toggleDownload,
            onDelete = historyViewModel::delete,
            onSeeAll = historyViewModel::seeAll,
            onVisibleIndex = historyViewModel::onVisibleIndex,
            onRetry = historyViewModel::reload,
            onCustomize = onOpenCustomize,
            onSettings = onOpenSettings,
        ),
        onSidebarOpened = historyViewModel::onSidebarOpened,
        onSidebarClosed = historyViewModel::onSidebarClosed,
        onOpenCustomize = onOpenCustomize,
        onOpenSettings = onOpenSettings,
        onOpenConnection = onOpenConnection,
        onOpenDownloads = onOpenDownloads,
    )

}

@Composable
fun ChatScreen(
    state: ChatUiState,
    history: HistoryUiState,
    models: ModelPickerState,
    pendingAsk: AskRequest?,
    draft: String,
    snackbar: SnackbarHostState,
    modelNameFor: (String?) -> String?,
    onDraftChange: (String) -> Unit,
    onSend: () -> Unit,
    onStop: () -> Unit,
    onSelectModel: (RemoteModel) -> Unit,
    onModelSheetOpened: () -> Unit,
    onModelSheetClosed: () -> Unit,
    onReloadModels: () -> Unit,
    onSelectTask: (TaskMode) -> Unit,
    onSelectDepth: (com.avek.chat.core.model.ThinkingDepth) -> Unit,
    onSuggestion: (String, TaskMode) -> Unit,
    onNewChat: () -> Unit,
    onToggleStar: () -> Unit,
    onRename: (String) -> Unit,
    onDelete: () -> Unit,
    onToggleDownload: () -> Unit,
    onRetryLoad: () -> Unit,
    onLoadOlder: () -> Unit,
    onPickPhotos: () -> Unit,
    onPickFiles: () -> Unit,
    onRemoveAttachment: (String) -> Unit,
    onAskDecision: (AskRequest, String) -> Unit,
    onAskText: (AskRequest, String) -> Unit,
    messageActionsFactory: (copy: (String) -> Unit, share: (String) -> Unit) -> MessageActions,
    historyActions: HistoryActions,
    onSidebarOpened: () -> Unit,
    onSidebarClosed: () -> Unit,
    onOpenCustomize: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenConnection: () -> Unit,
    onOpenDownloads: () -> Unit,
    thinking: com.avek.chat.feature.chat.thinking.ThinkingEnvironment? = null,
) {
    val colors = AvekTheme.colors
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current
    val share = LocalShareHandler.current
    var showModelPicker by remember { mutableStateOf(false) }
    var showTaskPicker by remember { mutableStateOf(false) }
    var showRename by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }

    val actions = remember(messageActionsFactory, scope) {
        messageActionsFactory(
            { text ->
                clipboard.setText(AnnotatedString(text))
                scope.launch { snackbar.showSnackbar("Copied to clipboard") }
            },
            { text -> share.share(text) },
        )
    }

    BackHandler(enabled = drawerState.isOpen) { scope.launch { drawerState.close() } }

    // The chat list lives in memory while the sidebar is in use; closing it starts the countdown.
    LaunchedEffect(drawerState) {
        androidx.compose.runtime.snapshotFlow { drawerState.targetValue }.collect { target ->
            if (target == DrawerValue.Open) onSidebarOpened() else onSidebarClosed()
        }
    }

    fun closeDrawerThen(action: () -> Unit) {
        action()
        scope.launch { drawerState.close() }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        scrimColor = colors.scrim,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = colors.sidebar,
                drawerShape = avekShape(topEnd = 24.dp, bottomEnd = 24.dp),
                windowInsets = WindowInsets(0, 0, 0, 0),
                modifier = Modifier.width(318.dp),
            ) {
                HistorySidebar(
                    state = history,
                    selectedId = state.conversationId,
                    actions = historyActions.copy(
                        onOpen = { c -> closeDrawerThen { historyActions.onOpen(c) } },
                        onNewChat = { closeDrawerThen(historyActions.onNewChat) },
                        onCustomize = { closeDrawerThen(historyActions.onCustomize) },
                        onSettings = { closeDrawerThen(historyActions.onSettings) },
                        onClose = { scope.launch { drawerState.close() } },
                    ),
                )
            }
        },
    ) {
        Scaffold(
            containerColor = colors.chatBackground,
            snackbarHost = { SnackbarHost(snackbar) },
            // Insets are handled manually so content can scroll under the top bar.
            contentWindowInsets = WindowInsets(0, 0, 0, 0),
        ) { _ ->
            val topInset = WindowInsets.statusBars.asPaddingValues().calculateTopPadding() + TopBarHeight
            Box(Modifier.fillMaxSize()) {
            Column(
                Modifier
                    .fillMaxSize()
                    .windowInsetsPadding(WindowInsets.navigationBars.union(WindowInsets.ime)),
            ) {
                Box(Modifier.weight(1f)) {
                    AnimatedContent(
                        targetState = when {
                            state.loadingChat -> BodyKind.LOADING
                            state.loadError != null -> BodyKind.ERROR
                            state.isEmpty -> BodyKind.WELCOME
                            else -> BodyKind.MESSAGES
                        },
                        transitionSpec = { fadeIn() togetherWith fadeOut() },
                        label = "chat-body",
                    ) { kind ->
                        when (kind) {
                            BodyKind.WELCOME -> WelcomePane(
                                profileName = state.profileName,
                                onSuggestion = onSuggestion,
                                modifier = Modifier.padding(top = topInset),
                            )
                            BodyKind.LOADING -> Box(Modifier.fillMaxSize().padding(top = topInset), contentAlignment = Alignment.Center) {
                                CircularProgressIndicator(color = colors.textTertiary, strokeWidth = 2.dp, modifier = Modifier.size(28.dp))
                            }
                            BodyKind.ERROR -> Column(
                                Modifier.fillMaxSize().padding(top = topInset, start = 32.dp, end = 32.dp),
                                verticalArrangement = Arrangement.Center,
                                horizontalAlignment = Alignment.CenterHorizontally,
                            ) {
                                Text(state.loadError.orEmpty(), style = AvekTheme.type.body, color = colors.textSecondary, textAlign = TextAlign.Center)
                                TextButton(onClick = onRetryLoad) { Text("Try again", color = colors.accent) }
                            }
                            BodyKind.MESSAGES -> ThinkingScope(thinking) { MessageList(
                                conversationId = state.conversationId,
                                messages = state.messages,
                                streaming = state.streaming,
                                modelNameFor = modelNameFor,
                                isGenerating = state.isGenerating,
                                sessionStartedAt = state.sessionStartedAt,
                                actions = actions,
                                toolViews = state.toolViews,
                                thinkingLoading = state.thinkingLoading,
                                loadingOlder = state.loadingOlder,
                                onNearTop = onLoadOlder,
                                modifier = Modifier.fillMaxSize(),
                                topInset = topInset,
                            ) }
                        }
                    }
                }
                ConnectionBanner(state.connection, onClick = onOpenConnection)
                val lastTurn = state.messages.lastOrNull { !it.isUser && it.promptId != null }
                val composerTelemetry = remember(thinking, lastTurn?.conversationId, lastTurn?.promptId) {
                    lastTurn?.let { m -> thinking?.telemetry(m.conversationId, m.promptId!!, fetch = true) }
                }?.collectAsState()?.value
                Composer(
                    draft = draft,
                    onDraftChange = onDraftChange,
                    onSend = onSend,
                    onStop = onStop,
                    isGenerating = state.isGenerating,
                    isNewChat = state.conversationId == null,
                    modelName = state.model.name,
                    enabled = state.connection.connected,
                    canSend = state.canSend(draft),
                    task = state.task,
                    depth = state.depth,
                    model = state.model,
                    onOpenModelPicker = { showModelPicker = true },
                    onDepthChange = onSelectDepth,
                    onOpenTaskPicker = { showTaskPicker = true },
                    attachments = state.attachments,
                    onPickPhotos = onPickPhotos,
                    onPickFiles = onPickFiles,
                    onRemoveAttachment = onRemoveAttachment,
                    onComingSoon = { feature -> scope.launch { snackbar.showSnackbar("$feature is not available yet") } },
                    telemetry = composerTelemetry,
                )
            }
            // Transparent top bar floating over the faded content.
            ChatTopBar(
                model = state.model,
                title = state.title,
                isStarred = state.isStarred,
                isDownloaded = state.isDownloaded,
                hasConversation = state.conversationId != null,
                onMenu = { scope.launch { drawerState.open() } },
                onModelClick = { showModelPicker = true },
                onNewChat = onNewChat,
                onToggleStar = onToggleStar,
                onRename = { showRename = true },
                onDelete = { confirmDelete = true },
                onToggleDownload = onToggleDownload,
                onOpenDownloads = onOpenDownloads,
                onOpenConnection = onOpenConnection,
                onCustomize = onOpenCustomize,
                onSettings = onOpenSettings,
            )
            }
        }
    }

    if (showModelPicker) {
        DisposableEffect(Unit) {
            onModelSheetOpened()
            onDispose { onModelSheetClosed() }
        }
        ModelPickerSheet(
            state = models,
            selectedId = state.model.id,
            pcName = state.connection.serverName,
            onSelect = {
                onSelectModel(it)
                showModelPicker = false
            },
            onRetry = onReloadModels,
            onDismiss = { showModelPicker = false },
        )
    }
    if (showTaskPicker) {
        TaskPickerSheet(
            selected = state.task,
            onSelect = {
                onSelectTask(it)
                showTaskPicker = false
            },
            onDismiss = { showTaskPicker = false },
        )
    }
    if (pendingAsk != null) {
        AskSheet(
            ask = pendingAsk,
            onDecision = { onAskDecision(pendingAsk, it) },
            onText = { onAskText(pendingAsk, it) },
        )
    }
    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            containerColor = colors.surface,
            title = { Text("Delete chat?", color = colors.textPrimary) },
            text = { Text("This deletes the chat from the PC. It cannot be undone.", color = colors.textSecondary) },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    onDelete()
                }) { Text("Delete", color = colors.danger) }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel", color = colors.textSecondary) } },
        )
    }
    if (showRename) {
        RenameDialog(
            initial = state.title.orEmpty(),
            onDismiss = { showRename = false },
            onConfirm = {
                onRename(it)
                showRename = false
            },
        )
    }
}

private enum class BodyKind { WELCOME, LOADING, ERROR, MESSAGES }

/** Gives the thinking blocks below their data source (telemetry, chosen style). */
@Composable
private fun ThinkingScope(env: com.avek.chat.feature.chat.thinking.ThinkingEnvironment?, content: @Composable () -> Unit) {
    androidx.compose.runtime.CompositionLocalProvider(com.avek.chat.feature.chat.thinking.LocalThinkingEnvironment provides env, content = content)
}
