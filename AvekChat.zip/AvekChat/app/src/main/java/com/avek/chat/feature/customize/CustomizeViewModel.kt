package com.avek.chat.feature.customize

import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.avek.chat.core.designsystem.theme.ThemeCatalog
import com.avek.chat.core.domain.repository.FontCatalogRepository
import com.avek.chat.core.domain.repository.SettingsRepository
import com.avek.chat.core.model.FontCategory
import com.avek.chat.core.model.settings.AppearanceSettings
import com.avek.chat.core.model.settings.ChatLayout
import com.avek.chat.core.model.settings.ColorRole
import com.avek.chat.core.model.settings.FontChoice
import com.avek.chat.core.model.settings.FontRole
import com.avek.chat.core.model.settings.MotionSettings
import com.avek.chat.core.model.settings.ShapeSettings
import com.avek.chat.core.model.settings.TextStyleSettings
import com.avek.chat.core.model.settings.ThemeMode
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.mapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

enum class FontFilter(val label: String, val category: FontCategory?) {
    FEATURED("Featured", null),
    ALL("All", null),
    SANS("Sans", FontCategory.SANS),
    SERIF("Serif", FontCategory.SERIF),
    DISPLAY("Display", FontCategory.DISPLAY),
    HANDWRITING("Handwriting", FontCategory.HANDWRITING),
    MONO("Mono", FontCategory.MONO),
    SYSTEM("System", null),
}

@Immutable
data class FontOption(val choice: FontChoice, val subtitle: String)

@Immutable
data class FontResults(
    val options: List<FontOption> = emptyList(),
    val total: Int = 0,
    val loading: Boolean = true,
)

@HiltViewModel
class CustomizeViewModel @Inject constructor(
    private val settings: SettingsRepository,
    private val fonts: FontCatalogRepository,
    private val traces: com.avek.chat.core.domain.trace.TraceRepository,
    private val chats: com.avek.chat.core.domain.repository.ChatRepository,
) : ViewModel() {

    val thinking: StateFlow<com.avek.chat.core.model.settings.ThinkingSettings> = settings.settings
        .map { it.thinking }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), com.avek.chat.core.model.settings.ThinkingSettings())

    /**
     * The person's latest real turn for the Thinking previews (`trace.get` + its reasoning text);
     * null until they have sent a prompt: the tab then says "Send a prompt to see a preview".
     */
    val thinkingPreview: StateFlow<com.avek.chat.feature.customize.tabs.ThinkingPreview?> = traces.latest
        .flatMapLatest { key ->
            if (key == null) {
                kotlinx.coroutines.flow.flowOf(null)
            } else {
                val text = kotlinx.coroutines.flow.flow {
                    emit("")
                    val loaded = runCatching { chats.turn(key.chatId, key.promptId, withThinking = true).assistant.thinking }.getOrNull()
                    emit(loaded.orEmpty())
                }
                combine(traces.telemetry(key.chatId, key.promptId), text) { t, thinkingText ->
                    com.avek.chat.feature.customize.tabs.ThinkingPreview(t, thinkingText)
                }
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    fun updateThinking(transform: (com.avek.chat.core.model.settings.ThinkingSettings) -> com.avek.chat.core.model.settings.ThinkingSettings) {
        viewModelScope.launch { settings.update { it.copy(thinking = transform(it.thinking)) } }
    }

    val appearance: StateFlow<AppearanceSettings> = settings.settings
        .map { it.appearance }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), AppearanceSettings())

    val fontQuery = MutableStateFlow("")
    val fontFilter = MutableStateFlow(FontFilter.FEATURED)

    val fontResults: StateFlow<FontResults> = combine(fontQuery.debounce(120), fontFilter) { q, f -> q to f }
        .mapLatest { (query, filter) -> loadFonts(query, filter) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), FontResults())

    private suspend fun loadFonts(query: String, filter: FontFilter): FontResults {
        val total = fonts.all().size + FontChoice.systemFonts.size
        val options = when (filter) {
            FontFilter.SYSTEM -> FontChoice.systemFonts
                .filter { it.name.contains(query, ignoreCase = true) }
                .map { FontOption(it, "Built in · works offline") }
            FontFilter.FEATURED -> fonts.featured()
                .filter { it.name.contains(query, ignoreCase = true) }
                .map { FontOption(FontChoice.google(it.name), "${it.category.label} · ${it.weights.size} weights") }
            else -> fonts.search(query, filter.category)
                .map { FontOption(FontChoice.google(it.name), "${it.category.label} · ${it.weights.size} weights") }
        }
        return FontResults(options, total, loading = false)
    }

    fun setFontQuery(value: String) {
        fontQuery.value = value
    }

    fun setFontFilter(value: FontFilter) {
        fontFilter.value = value
    }

    // ------------------------------------------------------------------ themes

    fun setThemeMode(mode: ThemeMode) = update { it.copy(themeMode = mode) }

    fun setTheme(id: String) = update { it.copy(themeId = id) }

    fun surpriseMe() = setTheme(ThemeCatalog.random())

    // ------------------------------------------------------------------ colours

    fun setColor(dark: Boolean, role: ColorRole, color: Color) {
        val argb = color.toArgb().toLong() and 0xFFFFFFFFL
        update {
            if (dark) it.copy(darkOverrides = it.darkOverrides + (role to argb))
            else it.copy(lightOverrides = it.lightOverrides + (role to argb))
        }
    }

    fun clearColor(dark: Boolean, role: ColorRole) = update {
        if (dark) it.copy(darkOverrides = it.darkOverrides - role) else it.copy(lightOverrides = it.lightOverrides - role)
    }

    fun clearAllColors(dark: Boolean) = update {
        if (dark) it.copy(darkOverrides = emptyMap()) else it.copy(lightOverrides = emptyMap())
    }

    // ------------------------------------------------------------------ fonts

    fun setTextStyle(role: FontRole, style: TextStyleSettings) = update { it.copy(fonts = it.fonts.with(role, style)) }

    fun setFont(role: FontRole, font: FontChoice) = update { it.copy(fonts = it.fonts.with(role, it.fonts[role].copy(font = font))) }

    fun applyPairing(pairing: FontPairing) = update { it.copy(fonts = pairing.applyTo(it.fonts)) }

    fun resetFonts() = update { it.copy(fonts = AppearanceSettings().fonts) }

    // ------------------------------------------------------------- layout/motion

    fun updateChat(transform: (ChatLayout) -> ChatLayout) = update { it.copy(chat = transform(it.chat)) }

    fun updateMotion(transform: (MotionSettings) -> MotionSettings) = update { it.copy(motion = transform(it.motion)) }

    fun updateShapes(transform: (ShapeSettings) -> ShapeSettings) = update { it.copy(shapes = transform(it.shapes)) }

    fun resetAll() = update { AppearanceSettings() }

    private fun update(transform: (AppearanceSettings) -> AppearanceSettings) {
        viewModelScope.launch { settings.update { it.copy(appearance = transform(it.appearance)) } }
    }
}
