package com.avek.chat.core.link.transport

import kotlinx.coroutines.channels.ReceiveChannel

data class HostPort(val host: String, val port: Int) {
    override fun toString(): String = "$host:$port"

    companion object {
        const val DEFAULT_PORT = 7810

        /** Parses `host` or `host:port`; returns null for anything that is not a plausible address. */
        fun parse(text: String): HostPort? {
            val trimmed = text.trim()
            if (trimmed.isEmpty() || trimmed.any { it.isWhitespace() || it == '/' }) return null
            val colon = trimmed.lastIndexOf(':')
            if (colon < 0) return HostPort(trimmed, DEFAULT_PORT)
            val host = trimmed.substring(0, colon)
            val port = trimmed.substring(colon + 1).toIntOrNull() ?: return null
            if (host.isEmpty() || port !in 1..65535) return null
            return HostPort(host, port)
        }
    }
}

sealed interface RawMessage {
    data class Text(val text: String) : RawMessage
    class Binary(val bytes: ByteArray) : RawMessage
    data class Closed(val code: Int, val reason: String) : RawMessage
}

/**
 * A raw, message-oriented channel to the PC. Wi-Fi uses a WebSocket; a future
 * route (Bluetooth, Wi-Fi Direct…) only has to produce one of these.
 * [incoming] ends with exactly one [RawMessage.Closed] and is then closed.
 */
interface RawChannel {
    val remote: HostPort
    val incoming: ReceiveChannel<RawMessage>
    suspend fun sendText(text: String)
    suspend fun sendBinary(bytes: ByteArray)
    fun close(code: Int = 1000, reason: String = "")
}
