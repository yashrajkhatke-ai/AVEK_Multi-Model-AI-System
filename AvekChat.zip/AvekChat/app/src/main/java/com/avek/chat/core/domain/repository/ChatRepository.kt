package com.avek.chat.core.domain.repository

import com.avek.chat.core.model.Conversation
import com.avek.chat.core.model.Feedback
import com.avek.chat.core.model.Message
import com.avek.chat.core.model.TaskMode
import com.avek.chat.core.model.ToolView

/** One page of a lazy list (UI-WIRE section 7). [next] is an opaque cursor; null = no more. */
data class Page<T>(val items: List<T>, val total: Int, val next: String?)

data class ChatListQuery(
    val text: String = "",
    val archived: Boolean = false,
    val starred: Boolean = false,
)

/** A page of turns as messages, oldest first within the page. [next] goes further back in time. */
data class ChatTurns(
    val chat: Conversation?,
    val messages: List<Message>,
    val total: Int,
    val next: String?,
)

/** The two messages of one turn. */
data class TurnMessages(val user: Message, val assistant: Message)

/**
 * The chats of the PC (the source of truth), or the local copies when the PC is not reachable.
 * Every mutation needs the PC.
 */
interface ChatRepository {
    suspend fun list(query: ChatListQuery, limit: Int, after: String?): Page<Conversation>

    /** `chat.get`: turns newest first by page (`after` = older), returned oldest first within the page. */
    suspend fun open(chatId: String, limit: Int, after: String?): ChatTurns

    /** One turn; the (lazy) reasoning text is only fetched when [withThinking]. */
    suspend fun turn(chatId: String, promptId: String, withThinking: Boolean): TurnMessages

    suspend fun tool(chatId: String, promptId: String, callId: String): ToolView

    suspend fun setChat(
        chatId: String,
        title: String? = null,
        mode: TaskMode? = null,
        starred: Boolean? = null,
        archived: Boolean? = null,
        modelId: String? = null,
    ): Conversation

    suspend fun delete(chatId: String)

    /** Deletes [fromPromptId] and every later turn ("edit message" and "regenerate"). */
    suspend fun rewind(chatId: String, fromPromptId: String)

    suspend fun feedback(chatId: String, promptId: String, value: Feedback)
}
