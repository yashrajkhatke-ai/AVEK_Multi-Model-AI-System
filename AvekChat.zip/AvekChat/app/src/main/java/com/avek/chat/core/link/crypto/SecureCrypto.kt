package com.avek.chat.core.link.crypto

import java.math.BigInteger
import java.security.AlgorithmParameters
import java.security.KeyFactory
import java.security.KeyPairGenerator
import java.security.MessageDigest
import java.security.PrivateKey
import java.security.PublicKey
import java.security.SecureRandom
import java.security.interfaces.ECPrivateKey
import java.security.interfaces.ECPublicKey
import java.security.spec.ECGenParameterSpec
import java.security.spec.ECParameterSpec
import java.security.spec.ECPoint
import java.security.spec.ECPrivateKeySpec
import java.security.spec.ECPublicKeySpec
import java.util.Base64
import javax.crypto.Cipher
import javax.crypto.KeyAgreement
import javax.crypto.Mac
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/** An ephemeral ECDH P-256 key pair; [publicRaw] is the 65-byte uncompressed point `04 || X || Y`. */
class EphemeralKeyPair(val privateKey: PrivateKey, val publicRaw: ByteArray)

/** Source of ephemeral keys and random bytes. Tests inject fixed values. */
interface KeySource {
    fun newKeyPair(): EphemeralKeyPair
    fun randomBytes(size: Int): ByteArray
}

class SystemKeySource(private val random: SecureRandom = SecureRandom()) : KeySource {
    override fun newKeyPair(): EphemeralKeyPair = SecureCrypto.generateKeyPair()
    override fun randomBytes(size: Int): ByteArray = ByteArray(size).also(random::nextBytes)
}

/**
 * AVEK-SEC/2 primitives (UI-WIRE v3 sections 2 to 5), built only on `java.security`
 * and `javax.crypto` so they run unchanged on the JVM and on Android API 26+.
 */
object SecureCrypto {

    const val KEY_BYTES = 32
    const val TAG_BYTES = 16
    const val GCM_NONCE_BYTES = 12
    const val PUBLIC_KEY_BYTES = 65

    private val random = SecureRandom()

    private val curve: ECParameterSpec by lazy {
        AlgorithmParameters.getInstance("EC").run {
            init(ECGenParameterSpec("secp256r1"))
            getParameterSpec(ECParameterSpec::class.java)
        }
    }

    // ------------------------------------------------------------------ keys

    fun generateKeyPair(): EphemeralKeyPair {
        val generator = KeyPairGenerator.getInstance("EC")
        generator.initialize(ECGenParameterSpec("secp256r1"), random)
        val pair = generator.generateKeyPair()
        return EphemeralKeyPair(pair.private, encodePublicKey(pair.public as ECPublicKey))
    }

    /** Builds a private key from its 32-byte scalar (used by the test vectors). */
    fun privateKeyFromScalar(scalar: ByteArray): PrivateKey =
        KeyFactory.getInstance("EC").generatePrivate(ECPrivateKeySpec(BigInteger(1, scalar), curve))

    fun encodePublicKey(key: ECPublicKey): ByteArray {
        val out = ByteArray(PUBLIC_KEY_BYTES)
        out[0] = 0x04
        fixedWidth(key.w.affineX).copyInto(out, 1)
        fixedWidth(key.w.affineY).copyInto(out, 33)
        return out
    }

    /**
     * Decodes a peer's 65-byte uncompressed point after checking it really is a point of P-256:
     * length 65, first byte 4, both coordinates below p, and y² ≡ x³ + ax + b (mod p).
     */
    fun decodePublicKey(raw: ByteArray): PublicKey {
        require(isValidPublicKey(raw)) { "Not a valid P-256 public key" }
        val x = BigInteger(1, raw.copyOfRange(1, 33))
        val y = BigInteger(1, raw.copyOfRange(33, 65))
        return KeyFactory.getInstance("EC").generatePublic(ECPublicKeySpec(ECPoint(x, y), curve))
    }

    fun isValidPublicKey(raw: ByteArray): Boolean {
        if (raw.size != PUBLIC_KEY_BYTES || raw[0] != 0x04.toByte()) return false
        val field = curve.curve.field as? java.security.spec.ECFieldFp ?: return false
        val p = field.p
        val x = BigInteger(1, raw.copyOfRange(1, 33))
        val y = BigInteger(1, raw.copyOfRange(33, 65))
        if (x >= p || y >= p) return false
        val a = curve.curve.a
        val b = curve.curve.b
        val left = y.modPow(BigInteger.valueOf(2), p)
        val right = x.modPow(BigInteger.valueOf(3), p).add(a.multiply(x)).add(b).mod(p)
        return left == right
    }

    /** The raw point of a software public key (used by the fake vault and the test server). */
    fun publicKeyOf(privateKey: PrivateKey): ByteArray {
        val ec = privateKey as ECPrivateKey
        val g = curve.generator
        val point = multiply(g, ec.s)
        val out = ByteArray(PUBLIC_KEY_BYTES)
        out[0] = 0x04
        fixedWidth(point.affineX).copyInto(out, 1)
        fixedWidth(point.affineY).copyInto(out, 33)
        return out
    }

    // Double-and-add on P-256 (affine coordinates); only used to derive a public key from a known scalar.
    private fun multiply(point: ECPoint, k: BigInteger): ECPoint {
        var result: ECPoint = ECPoint.POINT_INFINITY
        var addend = point
        for (i in 0 until k.bitLength()) {
            if (k.testBit(i)) result = add(result, addend)
            addend = add(addend, addend)
        }
        return result
    }

    private fun add(p1: ECPoint, p2: ECPoint): ECPoint {
        if (p1 == ECPoint.POINT_INFINITY) return p2
        if (p2 == ECPoint.POINT_INFINITY) return p1
        val p = (curve.curve.field as java.security.spec.ECFieldFp).p
        val a = curve.curve.a
        val lambda = if (p1.affineX == p2.affineX) {
            if ((p1.affineY + p2.affineY).mod(p) == BigInteger.ZERO) return ECPoint.POINT_INFINITY
            (BigInteger.valueOf(3) * p1.affineX.pow(2) + a) * (BigInteger.valueOf(2) * p1.affineY).modInverse(p)
        } else {
            (p2.affineY - p1.affineY) * (p2.affineX - p1.affineX).modInverse(p)
        }.mod(p)
        val x3 = (lambda.pow(2) - p1.affineX - p2.affineX).mod(p)
        val y3 = (lambda * (p1.affineX - x3) - p1.affineY).mod(p)
        return ECPoint(x3, y3)
    }

    // ------------------------------------------------------------------ ECDSA P-256 / SHA-256 (DER)

    /** Verifies a DER signature of [message] (hashed by the algorithm) under a raw 65-byte public key. */
    fun verify(publicRaw: ByteArray, message: ByteArray, signature: ByteArray): Boolean = try {
        if (!isValidPublicKey(publicRaw)) false
        else java.security.Signature.getInstance("SHA256withECDSA").run {
            initVerify(decodePublicKey(publicRaw))
            update(message)
            verify(signature)
        }
    } catch (_: java.security.GeneralSecurityException) {
        false
    } catch (_: IllegalArgumentException) {
        false
    }

    fun sign(privateKey: PrivateKey, message: ByteArray): ByteArray =
        java.security.Signature.getInstance("SHA256withECDSA").run {
            initSign(privateKey)
            update(message)
            sign()
        }

    /** BigInteger bytes stripped or zero-padded to exactly 32 bytes. */
    private fun fixedWidth(value: BigInteger): ByteArray {
        val bytes = value.toByteArray()
        return when {
            bytes.size == 32 -> bytes
            bytes.size > 32 -> bytes.copyOfRange(bytes.size - 32, bytes.size)
            else -> ByteArray(32).also { bytes.copyInto(it, 32 - bytes.size) }
        }
    }

    /** ECDH shared secret: the 32-byte X coordinate. The peer key is validated first. */
    fun ecdh(privateKey: PrivateKey, otherPublicRaw: ByteArray): ByteArray {
        val agreement = KeyAgreement.getInstance("ECDH")
        agreement.init(privateKey)
        agreement.doPhase(decodePublicKey(otherPublicRaw), true)
        return agreement.generateSecret()
    }

    // ------------------------------------------------------------------ hashes

    fun sha256(vararg parts: ByteArray): ByteArray {
        val digest = MessageDigest.getInstance("SHA-256")
        parts.forEach(digest::update)
        return digest.digest()
    }

    fun hmacSha256(key: ByteArray, vararg parts: ByteArray): ByteArray {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(key, "HmacSHA256"))
        parts.forEach(mac::update)
        return mac.doFinal()
    }

    /** RFC 5869 HKDF with SHA-256 (extract-then-expand). */
    fun hkdf(ikm: ByteArray, salt: ByteArray, info: ByteArray, length: Int): ByteArray {
        require(length in 1..(255 * 32)) { "Invalid HKDF length" }
        val prk = hmacSha256(if (salt.isEmpty()) ByteArray(32) else salt, ikm)
        val out = ByteArray(length)
        var previous = ByteArray(0)
        var produced = 0
        var counter = 1
        while (produced < length) {
            previous = hmacSha256(prk, previous, info, byteArrayOf(counter.toByte()))
            val take = minOf(previous.size, length - produced)
            previous.copyInto(out, produced, 0, take)
            produced += take
            counter++
        }
        return out
    }

    fun hkdf(ikm: ByteArray, salt: ByteArray, info: String, length: Int = KEY_BYTES): ByteArray =
        hkdf(ikm, salt, info.toByteArray(Charsets.UTF_8), length)

    /** Constant-time comparison. */
    fun constantTimeEquals(a: ByteArray, b: ByteArray): Boolean = MessageDigest.isEqual(a, b)

    // ------------------------------------------------------------------ AES-256-GCM

    /** Returns `ciphertext || tag(16)`. */
    fun aesGcmSeal(key: ByteArray, nonce: ByteArray, aad: ByteArray, plaintext: ByteArray): ByteArray {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(TAG_BYTES * 8, nonce))
        if (aad.isNotEmpty()) cipher.updateAAD(aad)
        return cipher.doFinal(plaintext)
    }

    /** Expects `ciphertext || tag(16)`; throws [java.security.GeneralSecurityException] if the tag fails. */
    fun aesGcmOpen(key: ByteArray, nonce: ByteArray, aad: ByteArray, sealed: ByteArray): ByteArray {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(TAG_BYTES * 8, nonce))
        if (aad.isNotEmpty()) cipher.updateAAD(aad)
        return cipher.doFinal(sealed)
    }

    // ------------------------------------------------------------------ encodings

    fun b64(bytes: ByteArray): String = Base64.getEncoder().encodeToString(bytes)
    fun unb64(text: String): ByteArray = Base64.getDecoder().decode(text)

    fun hex(bytes: ByteArray): String = bytes.joinToString("") { "%02x".format(it) }
    fun unhex(text: String): ByteArray {
        require(text.length % 2 == 0) { "Odd-length hex" }
        return ByteArray(text.length / 2) { text.substring(it * 2, it * 2 + 2).toInt(16).toByte() }
    }

    fun utf8(text: String): ByteArray = text.toByteArray(Charsets.UTF_8)

    /** Byte concatenation helper. */
    fun concat(vararg parts: ByteArray): ByteArray {
        val out = ByteArray(parts.sumOf { it.size })
        var offset = 0
        for (part in parts) {
            part.copyInto(out, offset)
            offset += part.size
        }
        return out
    }
}
