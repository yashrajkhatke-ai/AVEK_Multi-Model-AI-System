package com.avek.chat.core.data.remote

import com.avek.chat.core.domain.repository.ModelRepository
import com.avek.chat.core.link.HarnessApi
import com.avek.chat.core.model.RemoteModel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flatMapConcat
import kotlinx.coroutines.flow.asFlow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class RemoteModelRepository @Inject constructor(private val api: HarnessApi) : ModelRepository {

    override suspend fun defaultModel(): RemoteModel? = api.defaultModel()?.toDomain()

    override fun allModels(): Flow<RemoteModel> =
        api.allModels().flatMapConcat { part -> part.items.map { it.toDomain() }.asFlow() }
}
