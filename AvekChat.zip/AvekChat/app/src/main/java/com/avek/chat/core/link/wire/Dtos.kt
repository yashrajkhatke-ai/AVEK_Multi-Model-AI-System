package com.avek.chat.core.link.wire

import kotlinx.serialization.Serializable

// ------------------------------------------------------------------ models

@Serializable
data class CapabilityDto(val key: String = "", val label: String = "")

/** One model card (UI-WIRE v3 section 8.2): every item has every field; the app only draws them. */
@Serializable
data class ModelDto(
    val id: String,
    val name: String = "",
    val kind: String = "text",
    val rank: Int = 0,
    val tagline: String = "",
    val description: String = "",
    val badge: String? = null,
    val intelligence: Int = 0,
    val speed: Int = 0,
    val thinking: Int = 0,
    val contextTokens: Int = 0,
    val capabilities: List<CapabilityDto> = emptyList(),
    val sizeBytes: Long = 0,
    val state: String = "unloaded",
    val measuredTps: Double? = null,
)

/** `model.state` event / `models.state` item / `ready.modelStates` item. */
@Serializable
data class ModelStateDto(
    val modelId: String,
    val state: String = "unloaded",
    val since: String = "",
    val loadMs: Long? = null,
    val error: String? = null,
    val reason: String? = null,
)

@Serializable
data class ModelsStateResultDto(val items: List<ModelStateDto> = emptyList())

/** `model.load` answer. */
@Serializable
data class ModelLoadResultDto(val modelId: String = "", val state: String = "loading", val waiting: Boolean = false)

// ------------------------------------------------------------------ chats

@Serializable
data class ChatSummaryDto(
    val chatId: String,
    val title: String = "",
    val createdAt: String = "",
    val updatedAt: String = "",
    val modelId: String? = null,
    val mode: String = "auto",
    val turnCount: Int = 0,
    val preview: String = "",
    val starred: Boolean = false,
    val archived: Boolean = false,
)

@Serializable
data class AttachmentInfoDto(val name: String = "", val mime: String = "", val size: Long = 0)

@Serializable
data class UserPartDto(val text: String = "", val attachments: List<AttachmentInfoDto> = emptyList())

@Serializable
data class AssistantPartDto(val text: String = "")

/** `text` is lazy: present only when requested with `include` (or in downloaded copies). */
@Serializable
data class ThinkingDto(val ms: Long = 0, val text: String? = null)

@Serializable
data class ToolDto(
    val callId: String,
    val name: String = "",
    val ok: Boolean? = null,
    val title: String = "",
    val body: String? = null,
)

@Serializable
data class SourceDto(val title: String = "", val domain: String = "", val url: String = "", val snippet: String = "")

@Serializable
data class TurnViewDto(
    val promptId: String,
    val createdAt: String = "",
    val status: String = "completed",
    val modelId: String? = null,
    val mode: String = "auto",
    val depth: Int = 0,
    val user: UserPartDto = UserPartDto(),
    val assistant: AssistantPartDto = AssistantPartDto(),
    val thinking: ThinkingDto? = null,
    val tools: List<ToolDto> = emptyList(),
    val sources: List<SourceDto> = emptyList(),
    val error: String? = null,
    val feedback: String = "none",
    /** Revision 2: the turn's blocks without texts (`include:["outline"]`); absent for old turns. */
    val outline: List<TimelineBlockDto>? = null,
)

@Serializable
data class ToolViewDto(
    val title: String = "",
    val detail: String = "",
    val body: String = "",
    val style: String = "text",
)

// ------------------------------------------------------------------ list / op results

@Serializable
data class ModelListPartDto(val items: List<ModelDto> = emptyList(), val total: Int = 0, val next: String? = null)

@Serializable
data class ChatListPartDto(val items: List<ChatSummaryDto> = emptyList(), val total: Int = 0, val next: String? = null)

/** `chat.get` part: the first part also carries the chat summary. */
@Serializable
data class ChatGetPartDto(
    val chat: ChatSummaryDto? = null,
    val items: List<TurnViewDto> = emptyList(),
    val total: Int = 0,
    val next: String? = null,
)

@Serializable
data class TurnGetDto(val turn: TurnViewDto)

@Serializable
data class ToolGetDto(
    val callId: String = "",
    val name: String = "",
    val ok: Boolean? = null,
    val view: ToolViewDto = ToolViewDto(),
)

@Serializable
data class ChatResultDto(val chat: ChatSummaryDto)

@Serializable
data class RewindResultDto(val chat: ChatSummaryDto? = null, val removed: Int = 0)

@Serializable
data class PromptAckDto(val chatId: String, val promptId: String, val chat: ChatSummaryDto? = null)

@Serializable
data class SubscribeResultDto(val topics: List<String> = emptyList())

@Serializable
data class ResumeResultDto(val replayed: Int? = null, val gap: Boolean = false)

@Serializable
data class DownloadsSetResultDto(val chatIds: List<String> = emptyList())

@Serializable
data class DownloadStatusItemDto(
    val chatId: String,
    val exists: Boolean = true,
    val updatedAt: String = "",
    val turnCount: Int = 0,
)

@Serializable
data class DownloadsStatusResultDto(val items: List<DownloadStatusItemDto> = emptyList())

@Serializable
data class AttachBeginResultDto(val uploadId: String, val chunkBytes: Int = 262_144)

@Serializable
data class AttachEndResultDto(val attachmentId: String, val name: String = "", val size: Long = 0)

// ------------------------------------------------------------------ events

@Serializable
data class ServerInfoDto(val id: String = "", val name: String = "", val version: String = "")

@Serializable
data class LimitsDto(
    val maxFrameBytes: Int = 1_048_576,
    val attachChunkBytes: Int = 262_144,
    val maxAttachmentBytes: Long = 52_428_800,
    val maxListPart: Int = 100,
)

@Serializable
data class DeviceDto(val id: String = "", val name: String = "")

@Serializable
data class RunningTurnDto(val chatId: String, val promptId: String, val modelId: String? = null)

@Serializable
data class AskRequestDto(
    val chatId: String? = null,
    val promptId: String? = null,
    val askId: String,
    val kind: String = "approval",
    val tool: String? = null,
    val summary: String = "",
    val detail: String? = null,
    val choices: List<String> = listOf("allow", "deny", "allow-session"),
)

@Serializable
data class ReadyDto(
    val server: ServerInfoDto = ServerInfoDto(),
    val protocol: Int = 4,
    /** The route this connection came by: `wifi` | `tailscale` | `tunnel`. */
    val route: String? = null,
    val now: String = "",
    val epoch: String = "",
    val limits: LimitsDto = LimitsDto(),
    val resumeHoldSec: Int = 150,
    val device: DeviceDto = DeviceDto(),
    val runningTurns: List<RunningTurnDto> = emptyList(),
    val pendingAsks: List<AskRequestDto> = emptyList(),
    val modelStates: List<ModelStateDto> = emptyList(),
    /** 2 = harness 0.0.8 (timeline, context circle); absent on older harnesses. */
    val revision: Int = 1,
)

@Serializable
data class TurnStartedDto(
    val chatId: String,
    val promptId: String,
    val modelId: String? = null,
    val mode: String = "auto",
    val depth: Int = 0,
)

@Serializable
data class DeltaDto(val chatId: String, val promptId: String, val text: String = "", val offset: Int = 0)

@Serializable
data class ToolCallEventDto(
    val chatId: String,
    val promptId: String,
    val callId: String,
    val name: String = "",
    val title: String = "",
    val detail: String? = null,
)

@Serializable
data class ToolResultEventDto(
    val chatId: String,
    val promptId: String,
    val callId: String,
    val ok: Boolean = true,
    val title: String = "",
)

@Serializable
data class StatusDto(
    val chatId: String? = null,
    val promptId: String? = null,
    val phase: String = "",
    val state: String = "update",
    val text: String = "",
)

@Serializable
data class SourcesEventDto(val chatId: String, val promptId: String, val sources: List<SourceDto> = emptyList())

@Serializable
data class AskResolvedDto(val askId: String, val decision: String? = null, val by: String = "")

@Serializable
data class UsageDto(val promptTokens: Int = 0, val completionTokens: Int = 0)

@Serializable
data class TurnCompletedDto(
    val chatId: String,
    val promptId: String,
    val stopReason: String = "",
    val usage: UsageDto? = null,
    val durationMs: Long = 0,
    val thinkingMs: Long = 0,
    val title: String = "",
    val preview: String = "",
)

@Serializable
data class TurnEndedDto(val chatId: String, val promptId: String)

@Serializable
data class TurnFailedDto(val chatId: String, val promptId: String, val message: String = "")

@Serializable
data class ChatEventDto(val chat: ChatSummaryDto)

@Serializable
data class ChatDeletedDto(val chatId: String)

@Serializable
data class DownloadTurnDto(val chatId: String, val turn: TurnViewDto)

@Serializable
data class ByeDto(val reason: String = "")

// ------------------------------------------------------------------ v3: tool-call arguments and telemetry

/** `toolcall.delta`: the arguments of a tool call while the model writes them. `(step, index)` names the call. */
@Serializable
data class ToolCallDeltaDto(
    val chatId: String,
    val promptId: String,
    val step: Int = 1,
    val index: Int = 0,
    val callId: String? = null,
    val name: String? = null,
    val text: String = "",
    val offset: Int = 0,
)

@Serializable
data class TracePhaseDto(
    val chatId: String = "",
    val promptId: String = "",
    val t: Long = 0,
    val id: String = "",
    val phase: String = "",
    val state: String = "start",
    val label: String = "",
    val detail: String? = null,
    val step: Int? = null,
    val ms: Long? = null,
)

@Serializable
data class ContextCategoryDto(val key: String = "", val label: String = "", val tokens: Int = 0)

@Serializable
data class WindowGrowthDto(val from: Int = 0, val to: Int = 0)

@Serializable
data class TraceContextDto(
    val chatId: String = "",
    val promptId: String = "",
    val t: Long = 0,
    val step: Int = 1,
    val window: Int = 0,
    val windowMax: Int = 0,
    val compactAt: Int = 0,
    val outputReserve: Int = 0,
    val promptTokens: Int = 0,
    val exact: Boolean = false,
    val free: Int = 0,
    val categories: List<ContextCategoryDto> = emptyList(),
    val grew: WindowGrowthDto? = null,
    val compacted: kotlinx.serialization.json.JsonElement? = null,
    val trimmed: kotlinx.serialization.json.JsonElement? = null,
)

@Serializable
data class GenTokensDto(val reasoning: Int = 0, val answer: Int = 0, val toolCall: Int = 0, val total: Int = 0, val exact: Boolean = false)

@Serializable
data class TurnTotalsDto(val promptTokens: Int = 0, val completionTokens: Int = 0, val steps: Int = 0, val elapsedMs: Long = 0)

@Serializable
data class TraceGenDto(
    val chatId: String = "",
    val promptId: String = "",
    val t: Long = 0,
    val step: Int = 1,
    val modelId: String = "",
    val modelName: String = "",
    val state: String = "",
    val tokens: GenTokensDto = GenTokensDto(),
    val stepElapsedMs: Long = 0,
    val ttftMs: Long? = null,
    val tps: Double = 0.0,
    val avgTps: Double = 0.0,
    val turn: TurnTotalsDto = TurnTotalsDto(),
    val finish: String? = null,
)

@Serializable
data class TraceToolDto(
    val chatId: String = "",
    val promptId: String = "",
    val t: Long = 0,
    val step: Int = 1,
    val index: Int = 0,
    val callId: String = "",
    val name: String = "",
    val state: String = "writing",
    val owner: String = "core",
    val argTokens: Int? = null,
    val startedAt: Long? = null,
    val ms: Long? = null,
    val resultChars: Int? = null,
    val resultTokens: Int? = null,
)

@Serializable
data class RuntimeModelDto(val id: String = "", val name: String = "", val kind: String = "", val state: String = "", val onGpu: Boolean = false, val loadMs: Long? = null)

@Serializable
data class PoolSessionDto(val slot: Int = 0, val role: String = "", val label: String = "", val window: Int = 0, val state: String = "")

@Serializable
data class PoolDto(val modelId: String = "", val totalTokens: Int = 0, val usedTokens: Int = 0, val waiting: Int = 0, val sessions: List<PoolSessionDto> = emptyList())

@Serializable
data class GpuDto(val name: String = "", val vramTotalMb: Long = 0, val vramFreeMb: Long = 0)

@Serializable
data class ResourcesDto(val gpu: GpuDto? = null, val ramTotalMb: Long = 0, val ramFreeMb: Long = 0)

@Serializable
data class PluginStateDto(val name: String = "", val state: String = "")

@Serializable
data class TraceRuntimeDto(
    val chatId: String? = null,
    val promptId: String? = null,
    val t: Long = 0,
    val engine: String = "",
    val handoff: String = "",
    val models: List<RuntimeModelDto> = emptyList(),
    val pool: PoolDto? = null,
    val resources: ResourcesDto = ResourcesDto(),
    val plugins: List<PluginStateDto> = emptyList(),
    val running: Int = 0,
)

@Serializable
data class TraceLogDto(
    val chatId: String = "",
    val promptId: String = "",
    val t: Long = 0,
    val level: String = "info",
    val source: String = "",
    val text: String = "",
)

/** `trace.get`: everything the thinking block shows for one turn. */
@Serializable
data class TraceSnapshotDto(
    val chatId: String = "",
    val promptId: String = "",
    val live: Boolean = false,
    val modelId: String = "",
    val modelName: String = "",
    val startedAt: Long = 0,
    val endedAt: Long? = null,
    val phases: List<TracePhaseDto> = emptyList(),
    val context: TraceContextDto? = null,
    val steps: List<TraceGenDto> = emptyList(),
    val tools: List<TraceToolDto> = emptyList(),
    val logs: List<TraceLogDto> = emptyList(),
    val runtime: TraceRuntimeDto? = null,
)

// ------------------------------------------------------------------ revision 2: the timeline of a turn (section 9a)

@Serializable
data class BlockToolDto(val name: String = "", val label: String = "", val callId: String? = null, val owner: String = "core")

@Serializable
data class BlockAgentDto(val role: String = "", val label: String = "", val modelId: String? = null, val modelName: String? = null)

@Serializable
data class BlockSummaryDto(val title: String = "", val detail: String? = null)

@Serializable
data class BlockStartDto(
    val chatId: String,
    val promptId: String,
    val t: Long = 0,
    val id: String,
    val parent: String? = null,
    val kind: String = "thinking",
    val step: Int? = null,
    val title: String = "",
    val tool: BlockToolDto? = null,
    val agent: BlockAgentDto? = null,
    val from: Int? = null,
    val state: String = "running",
)

@Serializable
data class BlockTitleDto(val chatId: String, val promptId: String, val t: Long = 0, val id: String, val title: String = "", val tool: BlockToolDto? = null)

@Serializable
data class BlockDeltaDto(
    val chatId: String,
    val promptId: String,
    val t: Long = 0,
    val id: String,
    val channel: String = "text",
    val text: String = "",
    val offset: Int = 0,
)

@Serializable
data class BlockStateDto(val chatId: String, val promptId: String, val t: Long = 0, val id: String, val state: String, val detail: String? = null, val title: String? = null)

@Serializable
data class BlockEndDto(
    val chatId: String,
    val promptId: String,
    val t: Long = 0,
    val id: String,
    val state: String = "done",
    val title: String? = null,
    val ms: Long? = null,
    val summary: BlockSummaryDto? = null,
    val ok: Boolean? = null,
    val tokens: Int? = null,
    val to: Int? = null,
)

/** One block as `timeline.get` / the outline return it (`text` / `args` absent in an outline). */
@Serializable
data class TimelineBlockDto(
    val id: String,
    val parent: String? = null,
    val kind: String = "thinking",
    val state: String = "done",
    val title: String = "",
    val t0: Long? = null,
    val t1: Long? = null,
    val step: Int? = null,
    val from: Int? = null,
    val to: Int? = null,
    val textChars: Int? = null,
    val argsChars: Int? = null,
    val ms: Long? = null,
    val tool: BlockToolDto? = null,
    val agent: BlockAgentDto? = null,
    val summary: BlockSummaryDto? = null,
    val tokens: Int? = null,
    val ok: Boolean? = null,
    val detail: String? = null,
    val text: String? = null,
    val args: String? = null,
    val truncated: Boolean = false,
)

@Serializable
data class TimelineDto(
    val items: List<TimelineBlockDto> = emptyList(),
    val total: Int? = null,
    val chatId: String? = null,
    val promptId: String? = null,
    val live: Boolean? = null,
    val dropped: Int? = null,
    val next: String? = null,
)

@Serializable
data class ContextStepDto(
    val tokens: Int = 0,
    val tps: Double = 0.0,
    val avgTps: Double = 0.0,
    val ttftMs: Long? = null,
    val promptTokens: Int = 0,
    val completionTokens: Int = 0,
    val at: String = "",
)

@Serializable
data class ContextTurnDto(val promptId: String = "", val promptTokens: Int = 0, val completionTokens: Int = 0, val durationMs: Long = 0, val steps: Int = 0)

/** The context circle of a chat (`context.get` / `chat.context`). */
@Serializable
data class ContextDataDto(
    val chatId: String = "",
    val modelId: String? = null,
    val modelName: String? = null,
    val circleTokens: Int = 0,
    val usedTokens: Int = 0,
    val windowTokens: Int = 0,
    val compactAtTokens: Int = 0,
    val promptTokens: Int = 0,
    val exact: Boolean = false,
    val freeTokens: Int = 0,
    val categories: List<ContextCategoryDto> = emptyList(),
    val lastStep: ContextStepDto? = null,
    val lastTurn: ContextTurnDto? = null,
    val asOfPromptId: String? = null,
    val live: Boolean = false,
)
