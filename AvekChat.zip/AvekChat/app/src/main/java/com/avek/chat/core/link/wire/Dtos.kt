package com.avek.chat.core.link.wire

import kotlinx.serialization.Serializable

// ------------------------------------------------------------------ models

@Serializable
data class ModelDto(
    val id: String,
    val name: String = "",
    val kind: String = "text",
    val note: String = "",
    val contextTokens: Int = 0,
    val rank: Int = 0,
)

// ------------------------------------------------------------------ chats

@Serializable
data class ChatSummaryDto(
    val chatId: String,
    val title: String = "",
    val createdAt: String = "",
    val updatedAt: String = "",
    val modelId: String? = null,
    val mode: String = "auto",
    val turnCount: Int = 0,
    val preview: String = "",
    val starred: Boolean = false,
    val archived: Boolean = false,
)

@Serializable
data class AttachmentInfoDto(val name: String = "", val mime: String = "", val size: Long = 0)

@Serializable
data class UserPartDto(val text: String = "", val attachments: List<AttachmentInfoDto> = emptyList())

@Serializable
data class AssistantPartDto(val text: String = "")

/** `text` is lazy: present only when requested with `include` (or in downloaded copies). */
@Serializable
data class ThinkingDto(val ms: Long = 0, val text: String? = null)

@Serializable
data class ToolDto(
    val callId: String,
    val name: String = "",
    val ok: Boolean? = null,
    val title: String = "",
    val body: String? = null,
)

@Serializable
data class SourceDto(val title: String = "", val domain: String = "", val url: String = "", val snippet: String = "")

@Serializable
data class TurnViewDto(
    val promptId: String,
    val createdAt: String = "",
    val status: String = "completed",
    val modelId: String? = null,
    val mode: String = "auto",
    val depth: Int = 0,
    val user: UserPartDto = UserPartDto(),
    val assistant: AssistantPartDto = AssistantPartDto(),
    val thinking: ThinkingDto? = null,
    val tools: List<ToolDto> = emptyList(),
    val sources: List<SourceDto> = emptyList(),
    val error: String? = null,
    val feedback: String = "none",
)

@Serializable
data class ToolViewDto(
    val title: String = "",
    val detail: String = "",
    val body: String = "",
    val style: String = "text",
)

// ------------------------------------------------------------------ list / op results

@Serializable
data class ModelListPartDto(val items: List<ModelDto> = emptyList(), val total: Int = 0, val next: String? = null)

@Serializable
data class ChatListPartDto(val items: List<ChatSummaryDto> = emptyList(), val total: Int = 0, val next: String? = null)

/** `chat.get` part: the first part also carries the chat summary. */
@Serializable
data class ChatGetPartDto(
    val chat: ChatSummaryDto? = null,
    val items: List<TurnViewDto> = emptyList(),
    val total: Int = 0,
    val next: String? = null,
)

@Serializable
data class TurnGetDto(val turn: TurnViewDto)

@Serializable
data class ToolGetDto(
    val callId: String = "",
    val name: String = "",
    val ok: Boolean? = null,
    val view: ToolViewDto = ToolViewDto(),
)

@Serializable
data class ChatResultDto(val chat: ChatSummaryDto)

@Serializable
data class RewindResultDto(val chat: ChatSummaryDto? = null, val removed: Int = 0)

@Serializable
data class PromptAckDto(val chatId: String, val promptId: String, val chat: ChatSummaryDto? = null)

@Serializable
data class SubscribeResultDto(val topics: List<String> = emptyList())

@Serializable
data class ResumeResultDto(val replayed: Int? = null, val gap: Boolean = false)

@Serializable
data class DownloadsSetResultDto(val chatIds: List<String> = emptyList())

@Serializable
data class DownloadStatusItemDto(
    val chatId: String,
    val exists: Boolean = true,
    val updatedAt: String = "",
    val turnCount: Int = 0,
)

@Serializable
data class DownloadsStatusResultDto(val items: List<DownloadStatusItemDto> = emptyList())

@Serializable
data class AttachBeginResultDto(val uploadId: String, val chunkBytes: Int = 262_144)

@Serializable
data class AttachEndResultDto(val attachmentId: String, val name: String = "", val size: Long = 0)

// ------------------------------------------------------------------ events

@Serializable
data class ServerInfoDto(val id: String = "", val name: String = "", val version: String = "")

@Serializable
data class LimitsDto(
    val maxFrameBytes: Int = 1_048_576,
    val attachChunkBytes: Int = 262_144,
    val maxAttachmentBytes: Long = 52_428_800,
    val maxListPart: Int = 100,
)

@Serializable
data class DeviceDto(val id: String = "", val name: String = "")

@Serializable
data class RunningTurnDto(val chatId: String, val promptId: String, val modelId: String? = null)

@Serializable
data class AskRequestDto(
    val chatId: String? = null,
    val promptId: String? = null,
    val askId: String,
    val kind: String = "approval",
    val tool: String? = null,
    val summary: String = "",
    val detail: String? = null,
    val choices: List<String> = listOf("allow", "deny", "allow-session"),
)

@Serializable
data class ReadyDto(
    val server: ServerInfoDto = ServerInfoDto(),
    val protocol: Int = 2,
    val now: String = "",
    val epoch: String = "",
    val limits: LimitsDto = LimitsDto(),
    val resumeHoldSec: Int = 150,
    val device: DeviceDto = DeviceDto(),
    val runningTurns: List<RunningTurnDto> = emptyList(),
    val pendingAsks: List<AskRequestDto> = emptyList(),
)

@Serializable
data class TurnStartedDto(
    val chatId: String,
    val promptId: String,
    val modelId: String? = null,
    val mode: String = "auto",
    val depth: Int = 0,
)

@Serializable
data class DeltaDto(val chatId: String, val promptId: String, val text: String = "", val offset: Int = 0)

@Serializable
data class ToolCallEventDto(
    val chatId: String,
    val promptId: String,
    val callId: String,
    val name: String = "",
    val title: String = "",
    val detail: String? = null,
)

@Serializable
data class ToolResultEventDto(
    val chatId: String,
    val promptId: String,
    val callId: String,
    val ok: Boolean = true,
    val title: String = "",
)

@Serializable
data class StatusDto(
    val chatId: String? = null,
    val promptId: String? = null,
    val phase: String = "",
    val state: String = "update",
    val text: String = "",
)

@Serializable
data class SourcesEventDto(val chatId: String, val promptId: String, val sources: List<SourceDto> = emptyList())

@Serializable
data class AskResolvedDto(val askId: String, val decision: String? = null, val by: String = "")

@Serializable
data class UsageDto(val promptTokens: Int = 0, val completionTokens: Int = 0)

@Serializable
data class TurnCompletedDto(
    val chatId: String,
    val promptId: String,
    val stopReason: String = "",
    val usage: UsageDto? = null,
    val durationMs: Long = 0,
    val thinkingMs: Long = 0,
    val title: String = "",
    val preview: String = "",
)

@Serializable
data class TurnEndedDto(val chatId: String, val promptId: String)

@Serializable
data class TurnFailedDto(val chatId: String, val promptId: String, val message: String = "")

@Serializable
data class ChatEventDto(val chat: ChatSummaryDto)

@Serializable
data class ChatDeletedDto(val chatId: String)

@Serializable
data class DownloadTurnDto(val chatId: String, val turn: TurnViewDto)

@Serializable
data class ByeDto(val reason: String = "")
