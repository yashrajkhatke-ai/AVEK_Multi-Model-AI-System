package com.avek.chat.feature.customize.tabs

import androidx.compose.foundation.background
import com.avek.chat.core.designsystem.theme.avekShape
import com.avek.chat.core.designsystem.theme.avekPill
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyGridScope
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Casino
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.avek.chat.core.designsystem.component.ChipRow
import com.avek.chat.core.designsystem.component.SegmentedPicker
import com.avek.chat.core.designsystem.theme.AvekTheme
import com.avek.chat.core.designsystem.theme.BubbleTone
import com.avek.chat.core.designsystem.theme.ColorMath
import com.avek.chat.core.designsystem.theme.ContrastLevel
import com.avek.chat.core.designsystem.theme.NeutralFamily
import com.avek.chat.core.designsystem.theme.ThemeCatalog
import com.avek.chat.core.designsystem.theme.ThemeFilter
import com.avek.chat.core.model.settings.ThemeMode
import com.avek.chat.feature.customize.ThemeSwatch
import java.text.NumberFormat

@Composable
fun ThemesTab(
    themeId: String,
    themeMode: ThemeMode,
    isDark: Boolean,
    onThemeMode: (ThemeMode) -> Unit,
    onTheme: (String) -> Unit,
    onSurprise: () -> Unit,
) {
    val colors = AvekTheme.colors
    var hue by rememberSaveable { mutableStateOf<Int?>(null) }
    var family by rememberSaveable { mutableStateOf<NeutralFamily?>(null) }
    var tone by rememberSaveable { mutableStateOf<BubbleTone?>(null) }
    var contrast by rememberSaveable { mutableStateOf<ContrastLevel?>(ContrastLevel.STANDARD) }
    val generated = remember(hue, family, tone, contrast) {
        ThemeCatalog.generatedIds(ThemeFilter(hue, family, tone, contrast))
    }
    val number = remember { NumberFormat.getIntegerInstance() }

    LazyVerticalGrid(
        columns = GridCells.Adaptive(minSize = 150.dp),
        contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 8.dp, bottom = 32.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        fullWidth("mode") {
            Column(Modifier.padding(horizontal = 4.dp, vertical = 8.dp)) {
                SegmentedPicker(ThemeMode.entries, themeMode, onThemeMode, { it.label })
                Spacer(Modifier.height(12.dp))
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(avekShape(16.dp))
                        .background(colors.accentContainer)
                        .clickable(onClick = onSurprise)
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.Outlined.Casino, null, tint = colors.accent)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Surprise me", style = AvekTheme.type.body.copy(fontWeight = FontWeight.SemiBold), color = colors.textPrimary)
                        Text(
                            "Roll from ${number.format(ThemeCatalog.presets.size + ThemeCatalog.generatedCount)} themes · ${number.format((ThemeCatalog.presets.size + ThemeCatalog.generatedCount) * 2)} light & dark schemes",
                            style = AvekTheme.type.caption,
                            color = colors.textSecondary,
                        )
                    }
                }
            }
        }

        fullWidth("curated-header") { GridHeader("Curated", "${ThemeCatalog.presets.size} hand-tuned themes") }
        items(ThemeCatalog.presets, key = { it.id }) { theme ->
            ThemeSwatch(theme, isDark, selected = theme.id == themeId, onClick = { onTheme(theme.id) })
        }

        fullWidth("generated-header") {
            GridHeader("Generated", "${number.format(ThemeCatalog.generatedCount)} combinations of accent × neutral × bubble × contrast")
        }
        fullWidth("filters") {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                HueRow(selected = hue, onSelect = { hue = it })
                ChipRow(listOf<NeutralFamily?>(null) + NeutralFamily.entries, family, { family = it }, { it?.label ?: "Any neutral" }, contentPadding = PaddingValues(horizontal = 4.dp))
                ChipRow(listOf<BubbleTone?>(null) + BubbleTone.entries, tone, { tone = it }, { it?.let { t -> "${t.label} bubbles" } ?: "Any bubble" }, contentPadding = PaddingValues(horizontal = 4.dp))
                ChipRow(listOf<ContrastLevel?>(null) + ContrastLevel.entries, contrast, { contrast = it }, { it?.let { c -> "${c.label} contrast" } ?: "Any contrast" }, contentPadding = PaddingValues(horizontal = 4.dp))
                Text(
                    "Showing ${number.format(generated.size)} themes",
                    style = AvekTheme.type.caption,
                    color = colors.textTertiary,
                    modifier = Modifier.padding(horizontal = 4.dp),
                )
            }
        }
        items(generated, key = { it }) { id ->
            val theme = remember(id) { ThemeCatalog.resolve(id) }
            ThemeSwatch(theme, isDark, selected = id == themeId, onClick = { onTheme(id) })
        }
    }
}

private fun LazyGridScope.fullWidth(key: String, content: @Composable () -> Unit) {
    item(key = key, span = { GridItemSpan(maxLineSpan) }) { content() }
}

@Composable
private fun GridHeader(title: String, subtitle: String) {
    Column(Modifier.padding(start = 4.dp, end = 4.dp, top = 16.dp, bottom = 2.dp)) {
        Text(title, style = AvekTheme.type.title, color = AvekTheme.colors.textPrimary)
        Text(subtitle, style = AvekTheme.type.bodySmall, color = AvekTheme.colors.textSecondary)
    }
}

@Composable
private fun HueRow(selected: Int?, onSelect: (Int?) -> Unit) {
    val colors = AvekTheme.colors
    Row(
        Modifier
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .clip(avekPill())
                .border(1.dp, if (selected == null) colors.accent else colors.outline, avekPill())
                .clickable { onSelect(null) }
                .padding(horizontal = 12.dp, vertical = 6.dp),
        ) {
            Text("Any hue", style = AvekTheme.type.label, color = colors.textPrimary)
        }
        ThemeCatalog.accentHues.forEachIndexed { index, accent ->
            val isSelected = selected == index
            Box(
                Modifier
                    .size(if (isSelected) 32.dp else 26.dp)
                    .clip(CircleShape)
                    .background(ColorMath.hsl(accent.hue, 0.65f, if (colors.isDark) 0.62f else 0.5f))
                    .border(if (isSelected) 3.dp else 0.dp, colors.textPrimary, CircleShape)
                    .clickable { onSelect(if (isSelected) null else index) },
            )
        }
    }
}
