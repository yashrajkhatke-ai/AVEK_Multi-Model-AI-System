package com.avek.chat.core.data.downloads

import com.avek.chat.core.link.wire.ChatSummaryDto
import com.avek.chat.core.link.wire.TurnViewDto
import com.avek.chat.core.model.Conversation
import kotlinx.coroutines.flow.Flow

/** A downloaded chat as listed on the Downloaded chats screen. */
data class DownloadedChatInfo(val chat: Conversation, val sizeBytes: Long, val downloadedAt: Long)

/**
 * Complete copies of the chats the person chose to keep on this device (Room).
 * Turns are stored exactly as the PC sent them, with reasoning text and tool bodies.
 */
interface DownloadedChatStore {
    fun observeInfo(): Flow<List<DownloadedChatInfo>>
    fun observeIds(): Flow<Set<String>>

    suspend fun ids(): Set<String>
    suspend fun chat(chatId: String): Conversation?
    suspend fun turns(chatId: String): List<TurnViewDto>

    /** Replaces the whole copy (summary + every turn) atomically. */
    suspend fun replace(chat: ChatSummaryDto, turns: List<TurnViewDto>)

    suspend fun upsertTurn(chatId: String, turn: TurnViewDto)

    /** Updates the summary of a chat that is already stored; ignored for chats not downloaded. */
    suspend fun upsertChat(chat: ChatSummaryDto)

    suspend fun delete(chatId: String)
}
