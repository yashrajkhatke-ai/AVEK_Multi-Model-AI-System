package com.avek.chat.core.domain.repository

import com.avek.chat.core.model.RemoteModel
import kotlinx.coroutines.flow.Flow

/**
 * Models live on the PC and are requested lazily: the app never sends a list or a name
 * (UI-WIRE section 8.2). Nothing is cached beyond what the screen that asked is showing.
 */
interface ModelRepository {
    /** The best-scored available model: one `models.list {limit:1}`. Null = no model is ready on the PC. */
    suspend fun defaultModel(): RemoteModel?

    /** Every available chat model, best first, emitted one by one as the parts arrive (`limit:"all"`). */
    fun allModels(): Flow<RemoteModel>
}
