package com.avek.chat.core.domain.repository

import com.avek.chat.core.model.AiModel

interface ModelRepository {
    val models: List<AiModel>
    val defaultModel: AiModel

    fun find(id: String?): AiModel = models.firstOrNull { it.id == id } ?: defaultModel
}
