package com.avek.chat.di

import javax.inject.Qualifier

/** A coroutine scope that lives as long as the process (link, downloads, notifications). */
@Qualifier
@Retention(AnnotationRetention.BINARY)
annotation class ApplicationScope
