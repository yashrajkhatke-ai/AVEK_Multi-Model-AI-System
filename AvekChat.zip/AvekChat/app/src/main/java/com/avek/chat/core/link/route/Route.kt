package com.avek.chat.core.link.route

import com.avek.chat.core.link.crypto.AvekProtocol
import com.avek.chat.core.link.crypto.HandshakeException
import com.avek.chat.core.link.discovery.KnockClient
import com.avek.chat.core.link.rpc.LinkClosedException
import com.avek.chat.core.link.store.DeviceKey
import com.avek.chat.core.link.store.PairedPc
import com.avek.chat.core.link.transport.ChannelFactory
import com.avek.chat.core.link.transport.ChannelOpenException
import com.avek.chat.core.link.transport.ChannelTarget
import com.avek.chat.core.link.transport.RawChannel
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.emptyFlow
import java.net.ConnectException
import java.net.NoRouteToHostException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.security.SecureRandom

/** What the phone knows about its own network (Android: ConnectivityManager and PackageManager). */
interface NetworkEnvironment {
    /** Emits when the default network or the Wi-Fi changes (retry at once, section 13). */
    val changes: Flow<Unit>

    /** The Tailscale app (`com.tailscale.ipn`) is installed on this phone. */
    fun tailscaleInstalled(): Boolean

    /** A VPN is active on the phone (Android allows one at a time). */
    fun vpnActive(): Boolean
}

object NoNetworkEnvironment : NetworkEnvironment {
    override val changes: Flow<Unit> = emptyFlow()
    override fun tailscaleInstalled() = false
    override fun vpnActive() = false
}

/** The credentials of one connection attempt: the stored device id, the key to use and its `dk`/`rk`. */
class RouteCredentials(
    val deviceId: String,
    val key: DeviceKey,
    val dk: ByteArray,
    val rk: ByteArray,
    /** First connection with a new key after a replacement. */
    val slotNext: Boolean,
) {
    /** Overwrites `dk` and `rk` in memory (after the race: the session keys are derived by then). */
    fun wipe() {
        dk.fill(0)
        rk.fill(0)
    }

    override fun toString(): String = "RouteCredentials($deviceId, ${key.alias}, slotNext=$slotNext)"
}

/** Completes the session handshake and waits for `ready` on an opened channel (the repository does it). */
typealias Establish<T> = suspend (channel: RawChannel, route: RouteKind, credentials: RouteCredentials) -> T

/** A short sentence per failure reason (section 2.3 and B.3 of the task). */
object RouteMessages {
    const val NOT_FOUND = "Your PC did not answer. Is it on and on this network?"
    const val REFUSED = "Your PC refused the connection."
    const val DENIED = "Your PC does not accept this device on this route."
    const val TIMEOUT = "Your PC did not answer in time."
    const val NOT_SET_UP = "Not set up"
    const val TAILSCALE_MISSING = "Tailscale is not installed on this phone"
    const val OTHER_VPN = "Not available: another VPN is on"
    const val OTHER_VPN_SENTENCE = "Tailscale is not available while another VPN is on"
    const val NOT_OUR_PC = "This is not the PC you paired with."
    const val FORGOTTEN = "This PC forgot this device. Pair again."
    const val GRANT_UNREADABLE = "This phone can no longer read its pairing secrets. Forget this PC and pair again."
}

/** Shared mapping of "the PC was reached; now the handshake" failures to route failures. */
internal suspend fun <T : Any> handshakeOn(
    channel: RawChannel,
    route: RouteKind,
    credentials: RouteCredentials,
    establish: Establish<T>,
): T = try {
    establish(channel, route, credentials)
} catch (e: CancellationException) {
    channel.close()
    throw e
} catch (e: HandshakeException.Forgotten) {
    channel.close()
    throw RouteFailedException(FailureReason.Denied, RouteMessages.FORGOTTEN, Fatal.Forgotten, e)
} catch (e: HandshakeException.NotOurPc) {
    channel.close()
    throw RouteFailedException(FailureReason.Denied, RouteMessages.NOT_OUR_PC, Fatal.NotOurPc, e)
} catch (e: HandshakeException.Timeout) {
    channel.close()
    throw RouteFailedException(FailureReason.Timeout, RouteMessages.TIMEOUT, cause = e)
} catch (e: LinkClosedException) {
    channel.close()
    if (e.info.isAuthFailure) throw RouteFailedException(FailureReason.Denied, RouteMessages.FORGOTTEN, Fatal.Forgotten, e)
    throw RouteFailedException(FailureReason.Error, "The connection closed (${e.info.code})", cause = e)
} catch (e: kotlinx.coroutines.TimeoutCancellationException) {
    channel.close()
    throw RouteFailedException(FailureReason.Timeout, RouteMessages.TIMEOUT, cause = e)
} catch (e: HandshakeException) {
    channel.close()
    throw RouteFailedException(FailureReason.Error, e.message ?: "Handshake failed", cause = e)
} catch (e: Exception) {
    channel.close()
    throw RouteFailedException(FailureReason.Error, e.message ?: "Handshake failed", cause = e)
}

/** Opening the WebSocket: refused / not found / denied (an empty 404 from the tunnel door) / timeout. */
internal suspend fun openOrFail(channels: ChannelFactory, target: ChannelTarget): RawChannel = try {
    channels.open(target)
} catch (e: CancellationException) {
    throw e
} catch (e: ChannelOpenException) {
    throw when {
        e.httpCode == 404 || e.httpCode == 403 || e.httpCode == 401 -> RouteFailedException(FailureReason.Denied, RouteMessages.DENIED, cause = e)
        e.cause is UnknownHostException -> RouteFailedException(FailureReason.NotFound, RouteMessages.NOT_FOUND, cause = e)
        e.cause is SocketTimeoutException -> RouteFailedException(FailureReason.Timeout, RouteMessages.TIMEOUT, cause = e)
        e.cause is ConnectException || e.cause is NoRouteToHostException -> RouteFailedException(FailureReason.Refused, RouteMessages.REFUSED, cause = e)
        e.httpCode != null -> RouteFailedException(FailureReason.Refused, RouteMessages.REFUSED, cause = e)
        else -> RouteFailedException(FailureReason.Error, e.message ?: "Could not connect", cause = e)
    }
} catch (e: Exception) {
    throw RouteFailedException(FailureReason.Refused, RouteMessages.REFUSED, cause = e)
}

/** Wi-Fi: a signed knock on the local network (section 2.1), then `ws://<answer>:<port>/ui` through the Wi-Fi network. */
class WifiRouteAttempt<T : Any>(
    private val pc: PairedPc,
    private val credentials: RouteCredentials,
    private val knock: KnockClient,
    private val channels: ChannelFactory,
    private val establish: Establish<T>,
) : RouteAttempt<T> {
    override val kind = RouteKind.WIFI

    /** Where the knock was answered ("192.168.1.5:7810"), once known. */
    @Volatile
    var reachedAddress: String? = null
        private set

    override fun skipReason(): String? = null

    override suspend fun connect(): T {
        val answer = knock.knockWifi(pc, credentials.key)
            ?: throw RouteFailedException(FailureReason.NotFound, RouteMessages.NOT_FOUND)
        reachedAddress = "${answer.host}:${answer.port}"
        val channel = openOrFail(channels, ChannelTarget.ws(answer.host, answer.port, viaWifi = true))
        return handshakeOn(channel, kind, credentials, establish)
    }
}

/** Tailscale: one unicast knock to `<host>:<knockPort>` and `ws://<host>:<port>/ui`, over the default network (the VPN). */
class TailscaleRouteAttempt<T : Any>(
    private val pc: PairedPc,
    private val credentials: RouteCredentials,
    private val knock: KnockClient,
    private val channels: ChannelFactory,
    private val environment: NetworkEnvironment,
    private val establish: Establish<T>,
) : RouteAttempt<T> {
    override val kind = RouteKind.TAILSCALE

    override fun skipReason(): String? {
        val ts = pc.routes?.tailscale
        return when {
            ts == null || (ts.host.isBlank() && ts.dns.isNullOrBlank()) -> RouteMessages.NOT_SET_UP
            !environment.tailscaleInstalled() -> RouteMessages.TAILSCALE_MISSING
            else -> null
        }
    }

    override suspend fun connect(): T {
        val ts = pc.routes?.tailscale ?: throw RouteFailedException(FailureReason.Skipped, RouteMessages.NOT_SET_UP)
        val host = ts.host.ifBlank { ts.dns.orEmpty() }
        val answer = knock.knockTailscale(pc, credentials.key, host, ts.knockPort)
            ?: throw RouteFailedException(FailureReason.NotFound, RouteMessages.NOT_FOUND)
        val channel = openOrFail(channels, ChannelTarget.ws(host, answer.port, viaWifi = false))
        return handshakeOn(channel, kind, credentials, establish)
    }
}

/**
 * ngrok: `wss://<host>/ui` with a fresh route proof (`Authorization: AVEK <deviceId>.<ts>.<nonce>.<mac>`)
 * and `ngrok-skip-browser-warning: 1`, then the ordinary session handshake on that socket (no knock).
 */
class NgrokRouteAttempt<T : Any>(
    private val pc: PairedPc,
    private val credentials: RouteCredentials,
    private val channels: ChannelFactory,
    private val establish: Establish<T>,
    private val nowMs: () -> Long = System::currentTimeMillis,
    private val randomBytes: (Int) -> ByteArray = { n -> ByteArray(n).also(SecureRandom()::nextBytes) },
) : RouteAttempt<T> {
    override val kind = RouteKind.NGROK

    override fun skipReason(): String? = if (pc.routes?.ngrokHost == null) RouteMessages.NOT_SET_UP else null

    /** The headers of one attempt (a fresh nonce every time). */
    fun headers(): Map<String, String> = mapOf(
        "Authorization" to AvekProtocol.routeHeader(credentials.rk, credentials.deviceId, nowMs(), randomBytes(16)),
        "ngrok-skip-browser-warning" to "1",
    )

    override suspend fun connect(): T {
        val host = pc.routes?.ngrokHost ?: throw RouteFailedException(FailureReason.Skipped, RouteMessages.NOT_SET_UP)
        val channel = openOrFail(channels, ChannelTarget.wss(host, headers()))
        return handshakeOn(channel, kind, credentials, establish)
    }
}
