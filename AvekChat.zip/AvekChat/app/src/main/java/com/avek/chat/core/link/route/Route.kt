package com.avek.chat.core.link.route

import com.avek.chat.core.link.discovery.BeaconSource
import com.avek.chat.core.link.store.PairedPc
import com.avek.chat.core.link.transport.ChannelFactory
import com.avek.chat.core.link.transport.HostPort
import com.avek.chat.core.link.transport.RawChannel
import com.avek.chat.core.model.settings.RouteSpec
import kotlinx.coroutines.flow.first
import java.io.IOException

/**
 * One way to reach the PC: "try to open a raw message channel". Wi-Fi routes are
 * below; Bluetooth or Wi-Fi Direct later only need to implement this interface.
 */
interface Route {
    /** `last`, `discover` or `host`: what the Connection screen lists while trying. */
    val kind: String

    /** Human-readable, e.g. `host 192.168.43.5:7810`. */
    val label: String

    suspend fun open(): RawChannel
}

class HostRoute(private val target: HostPort, private val channels: ChannelFactory) : Route {
    override val kind = "host"
    override val label = "host $target"
    override suspend fun open(): RawChannel = channels.open(target)
}

/** The address of the last successful connection (read when the attempt starts). */
class LastRoute(private val lastTarget: () -> HostPort?, private val channels: ChannelFactory) : Route {
    override val kind = "last"
    override val label get() = lastTarget()?.let { "last $it" } ?: "last"
    override suspend fun open(): RawChannel =
        channels.open(lastTarget() ?: throw IOException("No previous connection"))
}

/** Waits for the paired PC's UDP beacon (a paired app only accepts its own `serverId`). */
class DiscoverRoute(
    private val serverId: String,
    private val beacons: BeaconSource,
    private val channels: ChannelFactory,
) : Route {
    override val kind = "discover"
    override val label = "discover"
    override suspend fun open(): RawChannel {
        val beacon = beacons.beacons().first { it.serverId == serverId }
        return channels.open(HostPort(beacon.host, beacon.port))
    }
}

/** Turns the persisted ordered [RouteSpec] list into runnable routes. */
class RouteFactory(
    private val channels: ChannelFactory,
    private val beacons: BeaconSource,
    private val lastTarget: (PairedPc) -> HostPort? = { pc -> pc.lastHost?.let { HostPort(it, pc.lastPort) } },
) {
    fun build(specs: List<RouteSpec>, pc: PairedPc, currentPc: () -> PairedPc? = { pc }): List<Route> =
        specs.map { spec ->
            when (spec) {
                RouteSpec.Last -> LastRoute({ currentPc()?.let(lastTarget) }, channels)
                RouteSpec.Discover -> DiscoverRoute(pc.serverId, beacons, channels)
                is RouteSpec.Host -> HostRoute(HostPort(spec.host, spec.port), channels)
            }
        }
}
