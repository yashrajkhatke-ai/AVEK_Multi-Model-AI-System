package com.avek.chat.core.link.route

import com.avek.chat.core.link.discovery.KnockClient
import com.avek.chat.core.link.store.PairedPc
import com.avek.chat.core.link.transport.ChannelFactory
import com.avek.chat.core.link.transport.RawChannel

/** A raw channel that reached the PC, and where it went ("192.168.43.5:7810"). */
class Reached(val channel: RawChannel, val address: String)

/**
 * One way to reach the paired PC. Wi-Fi (knock, then WebSocket) is the only one in this version;
 * a Bluetooth route would implement the same interface and nothing else would change.
 */
interface Route {
    val kind: String

    /** Finds the PC and opens a raw channel to it, or returns null when it did not answer. */
    suspend fun reach(pc: PairedPc): Reached?
}

/** Wi-Fi: a signed knock on UDP 7811 (section 2), then `ws://<answer address>:<port>/ui`. */
class WifiRoute(private val knock: KnockClient, private val channels: ChannelFactory) : Route {
    override val kind = "wifi"

    override suspend fun reach(pc: PairedPc): Reached? {
        val answer = knock.knock(pc) ?: return null
        return Reached(channels.open(answer.target), "${answer.host}:${answer.port}")
    }
}
