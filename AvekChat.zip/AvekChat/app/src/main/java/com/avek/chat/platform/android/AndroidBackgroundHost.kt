package com.avek.chat.platform.android

import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import com.avek.chat.core.link.BackgroundHost
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

/** Starts and stops [LinkService]. Android 12+ only lets an app start a foreground service from the foreground. */
@Singleton
class AndroidBackgroundHost @Inject constructor(
    @ApplicationContext private val context: Context,
) : BackgroundHost {

    private var running = false

    @Synchronized
    override fun setActive(active: Boolean) {
        if (active == running) return
        val intent = Intent(context, LinkService::class.java)
        if (active) {
            try {
                ContextCompat.startForegroundService(context, intent)
                running = true
            } catch (_: Exception) {
                // Started from the background (for example by a notification button): the link still
                // works while the process lives; the service starts the next time the app is opened.
                running = false
            }
        } else {
            context.stopService(intent)
            running = false
        }
    }
}
