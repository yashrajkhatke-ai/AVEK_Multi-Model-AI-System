package com.avek.chat.core.domain.models

import com.avek.chat.core.link.HarnessApi
import com.avek.chat.core.link.LinkRepository
import com.avek.chat.core.link.route.ConnectionState
import com.avek.chat.core.link.rpc.RpcException
import com.avek.chat.core.model.ModelLoadState
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

/** What the last `model.load` said, for the chip ("Will load when the current answer finishes"). */
data class PreloadStatus(val modelId: String, val waiting: Boolean = false, val error: String? = null)

/**
 * Asks the PC to load a model while the person types (UI-WIRE v3 section 8.2, "Model preload").
 * [want] is idempotent and debounced (150 ms); the latest request wins (a newer one replaces a
 * pending one that was not sent yet). Nothing is sent when not connected, in Demo mode, or when
 * the PC already says the model is ready or loading. It never blocks sending a prompt.
 */
class ModelPreloader(
    private val api: HarnessApi,
    private val link: LinkRepository,
    private val tracker: ModelStateTracker,
    private val demoMode: () -> Boolean,
    private val scope: CoroutineScope,
    private val debounceMs: Long = DEBOUNCE_MS,
) {
    private var pending: Job? = null
    private var pendingId: String? = null

    private val _status = MutableStateFlow<PreloadStatus?>(null)
    val status: StateFlow<PreloadStatus?> = _status

    /** Number of `model.load` requests actually sent (for tests and diagnostics). */
    @Volatile
    var sent: Int = 0
        private set

    @Synchronized
    fun want(modelId: String?, immediate: Boolean = false) {
        if (modelId.isNullOrBlank()) return
        if (pendingId == modelId && pending?.isActive == true && !immediate) return
        pending?.cancel()
        pendingId = modelId
        pending = scope.launch {
            if (!immediate) delay(debounceMs)
            send(modelId)
        }
    }

    private suspend fun send(modelId: String) {
        if (demoMode() || link.state.value !is ConnectionState.Connected) return
        val known = tracker.stateOf(modelId)
        if (known == ModelLoadState.READY || known == ModelLoadState.LOADING) return
        try {
            sent++
            val result = api.modelLoad(modelId)
            _status.value = PreloadStatus(modelId, waiting = result.waiting)
        } catch (e: CancellationException) {
            throw e
        } catch (e: RpcException) {
            _status.value = PreloadStatus(modelId, error = if (e.code == "no-model") "This model is not available on the PC" else e.message)
        } catch (e: Exception) {
            _status.value = PreloadStatus(modelId, error = e.message)
        }
    }

    companion object {
        const val DEBOUNCE_MS = 150L
    }
}
