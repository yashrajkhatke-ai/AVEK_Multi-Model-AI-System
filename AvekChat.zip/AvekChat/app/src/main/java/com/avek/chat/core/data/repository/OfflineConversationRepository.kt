package com.avek.chat.core.data.repository

import com.avek.chat.core.common.IdGenerator
import com.avek.chat.core.common.TimeProvider
import com.avek.chat.core.data.local.AvekDatabase
import com.avek.chat.core.data.local.ConversationDao
import com.avek.chat.core.data.local.MessageDao
import com.avek.chat.core.data.local.asDomain
import com.avek.chat.core.data.local.asEntity
import com.avek.chat.core.domain.repository.ConversationRepository
import com.avek.chat.core.model.Conversation
import com.avek.chat.core.model.Feedback
import com.avek.chat.core.model.Message
import com.avek.chat.core.model.TaskMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

/** Room-backed repository. Everything lives on device; there is no remote. */
@Singleton
class OfflineConversationRepository @Inject constructor(
    database: AvekDatabase,
    private val ids: IdGenerator,
    private val time: TimeProvider,
) : ConversationRepository {

    private val conversations: ConversationDao = database.conversationDao()
    private val messages: MessageDao = database.messageDao()

    override fun observeConversations(): Flow<List<Conversation>> =
        conversations.observeActive().map { list -> list.map { it.asDomain() } }.distinctUntilChanged()

    override fun observeArchived(): Flow<List<Conversation>> =
        conversations.observeArchived().map { list -> list.map { it.asDomain() } }.distinctUntilChanged()

    override fun search(query: String): Flow<List<Conversation>> =
        conversations.search(query.trim()).map { list -> list.map { it.asDomain() } }

    override fun observeConversation(id: String): Flow<Conversation?> =
        conversations.observe(id).map { it?.asDomain() }.distinctUntilChanged()

    override fun observeMessages(conversationId: String): Flow<List<Message>> =
        messages.observe(conversationId).map { list -> list.map { it.asDomain() } }.distinctUntilChanged()

    override suspend fun getConversation(id: String): Conversation? = conversations.get(id)?.asDomain()

    override suspend fun getMessages(conversationId: String): List<Message> =
        messages.get(conversationId).map { it.asDomain() }

    override suspend fun createConversation(title: String, modelId: String, taskMode: TaskMode): Conversation {
        val now = time.now()
        val conversation = Conversation(
            id = ids.newId(),
            title = title,
            createdAt = now,
            updatedAt = now,
            isStarred = false,
            isArchived = false,
            modelId = modelId,
            taskMode = taskMode,
            preview = "",
            messageCount = 0,
        )
        conversations.upsert(conversation.asEntity())
        return conversation
    }

    override suspend fun upsertMessage(message: Message) = messages.upsert(message.asEntity())

    override suspend fun deleteMessagesFrom(conversationId: String, fromCreatedAt: Long) =
        messages.deleteFrom(conversationId, fromCreatedAt)

    override suspend fun setFeedback(messageId: String, feedback: Feedback) =
        messages.setFeedback(messageId, feedback.name)

    override suspend fun refreshSummary(conversationId: String, modelId: String, taskMode: TaskMode) {
        val latest = messages.latest(conversationId)
        val preview = latest?.content.orEmpty()
            .replace(Regex("[#*`>|_]"), "")
            .replace(Regex("\\s+"), " ")
            .trim()
            .take(PREVIEW_LENGTH)
        conversations.updateSummary(
            id = conversationId,
            updatedAt = maxOf(time.now(), latest?.createdAt ?: 0L),
            preview = preview,
            modelId = modelId,
            taskMode = taskMode.name,
        )
    }

    override suspend fun rename(id: String, title: String) = conversations.rename(id, title.trim())
    override suspend fun setStarred(id: String, starred: Boolean) = conversations.setStarred(id, starred)
    override suspend fun setArchived(id: String, archived: Boolean) = conversations.setArchived(id, archived)
    override suspend fun delete(id: String) = conversations.delete(id)
    override suspend fun deleteAll() = conversations.deleteAll()
    override suspend fun recoverInterruptedReplies() = messages.stopInterrupted()

    override suspend fun insertAll(conversations: List<Conversation>, messages: List<Message>) {
        this.conversations.upsertAll(conversations.map { it.asEntity() })
        this.messages.upsertAll(messages.map { it.asEntity() })
    }

    private companion object {
        const val PREVIEW_LENGTH = 140
    }
}
