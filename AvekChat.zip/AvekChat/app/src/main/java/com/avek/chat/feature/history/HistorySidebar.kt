package com.avek.chat.feature.history

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Archive
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.CloudDownload
import androidx.compose.material.icons.outlined.DownloadDone
import androidx.compose.material.icons.outlined.CloudOff
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.DriveFileRenameOutline
import androidx.compose.material.icons.outlined.Palette
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.StarOutline
import androidx.compose.material.icons.outlined.Unarchive
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.snapshotFlow
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.avek.chat.core.designsystem.component.AvekMenuIcon
import com.avek.chat.core.designsystem.component.fadingEdges
import com.avek.chat.core.designsystem.theme.AvekTheme
import com.avek.chat.core.designsystem.theme.avekShape
import com.avek.chat.core.model.Conversation
import com.avek.chat.core.model.TaskMode

data class HistoryActions(
    val onQuery: (String) -> Unit,
    val onFilter: (HistoryFilter) -> Unit,
    val onTaskFilter: (TaskMode?) -> Unit,
    val onOpen: (Conversation) -> Unit,
    val onNewChat: () -> Unit,
    val onRename: (Conversation, String) -> Unit,
    val onToggleStar: (Conversation) -> Unit,
    val onToggleArchive: (Conversation) -> Unit,
    val onToggleDownload: (Conversation) -> Unit,
    val onDelete: (Conversation) -> Unit,
    val onSeeAll: () -> Unit,
    val onVisibleIndex: (Int) -> Unit,
    val onRetry: () -> Unit,
    val onCustomize: () -> Unit,
    val onSettings: () -> Unit,
    val onClose: () -> Unit = {},
)

private const val UPPER_FRACTION = 0.4f

/**
 * The drawer, split vertically 40 / 60:
 *  - upper 40%: menu glyph, compact search, navigation and profile
 *  - lower 60%: one continuous, minimal list of chats (most recent first)
 */
@Composable
fun HistorySidebar(
    state: HistoryUiState,
    selectedId: String?,
    actions: HistoryActions,
    modifier: Modifier = Modifier,
) {
    val colors = AvekTheme.colors
    var renaming by remember { mutableStateOf<Conversation?>(null) }
    var confirmDelete by remember { mutableStateOf<Conversation?>(null) }

    Column(
        modifier
            .fillMaxSize()
            .background(colors.sidebar)
            .statusBarsPadding()
            .navigationBarsPadding(),
    ) {
        // ------------------------------------------------------------ upper 40%
        Column(
            Modifier
                .weight(UPPER_FRACTION)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState()),
        ) {
            IconButton(onClick = actions.onClose, modifier = Modifier.padding(start = 6.dp, top = 6.dp)) {
                AvekMenuIcon(colors.sidebarText, contentDescription = "Close menu")
            }

            SearchField(
                query = state.query,
                onQuery = actions.onQuery,
                modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 10.dp),
            )

            NavRow("New chat", Icons.Outlined.Add, onClick = actions.onNewChat)
            NavRow(
                "Starred",
                Icons.Outlined.StarOutline,
                selected = state.filter == HistoryFilter.STARRED,
                onClick = { actions.onFilter(if (state.filter == HistoryFilter.STARRED) HistoryFilter.ALL else HistoryFilter.STARRED) },
            )
            NavRow(
                "Archived",
                Icons.Outlined.Archive,
                selected = state.filter == HistoryFilter.ARCHIVED,
                onClick = { actions.onFilter(if (state.filter == HistoryFilter.ARCHIVED) HistoryFilter.ALL else HistoryFilter.ARCHIVED) },
            )
            NavRow("Customize", Icons.Outlined.Palette, onClick = actions.onCustomize)

            ProfileRow(state.profileName, state.plan, actions.onSettings)
        }

        HorizontalDivider(color = colors.outline.copy(alpha = 0.5f), modifier = Modifier.padding(horizontal = 16.dp))

        // ------------------------------------------------------------ lower 60%
        Column(
            Modifier
                .weight(1f - UPPER_FRACTION)
                .fillMaxWidth(),
        ) {
            Text(
                when {
                    state.query.isNotBlank() -> "Results"
                    state.filter == HistoryFilter.STARRED -> "Starred"
                    state.filter == HistoryFilter.ARCHIVED -> "Archived"
                    else -> "Recents"
                },
                style = AvekTheme.type.caption.copy(fontWeight = FontWeight.Medium),
                color = colors.textTertiary,
                modifier = Modifier.padding(start = 24.dp, top = 14.dp, bottom = 4.dp),
            )

            val list = state.list
            val listState = rememberLazyListState()
            // Tell the paging rules which loaded item is the last one on screen.
            LaunchedEffect(listState, list.items.size) {
                snapshotFlow { listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: -1 }
                    .collect { last -> if (last >= 0 && list.items.isNotEmpty()) actions.onVisibleIndex(minOf(last, list.items.size - 1)) }
            }

            if (state.offline) {
                Row(
                    Modifier.padding(start = 24.dp, end = 16.dp, bottom = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.Outlined.CloudOff, null, tint = colors.textTertiary, modifier = Modifier.size(14.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("PC not reachable: showing downloaded chats", style = AvekTheme.type.caption, color = colors.textTertiary)
                }
            }

            when {
                list.loading && list.items.isEmpty() -> SkeletonRows()
                list.error != null && list.items.isEmpty() -> Column(Modifier.padding(horizontal = 24.dp, vertical = 12.dp)) {
                    Text(list.error ?: "", style = AvekTheme.type.bodySmall, color = colors.textSecondary)
                    TextButton(onClick = actions.onRetry) { Text("Try again", color = colors.accent) }
                }
                !list.loading && list.items.isEmpty() -> Text(
                    when {
                        state.query.isNotBlank() -> "No chats match “${state.query}”"
                        state.filter == HistoryFilter.STARRED -> "Star a chat to keep it here"
                        state.filter == HistoryFilter.ARCHIVED -> "Archived chats will appear here"
                        state.offline -> "Download a chat to read it without the PC"
                        else -> "Your conversations will appear here"
                    },
                    style = AvekTheme.type.bodySmall,
                    color = colors.textSecondary,
                    modifier = Modifier.padding(horizontal = 24.dp, vertical = 16.dp),
                )
            }

            LazyColumn(
                Modifier
                    .weight(1f)
                    .fadingEdges(topFade = 10.dp, bottomFade = 24.dp),
                state = listState,
                contentPadding = PaddingValues(top = 4.dp, bottom = 24.dp),
            ) {
                items(list.items, key = { it.id }) { conversation ->
                    ConversationRow(
                        conversation = conversation,
                        selected = conversation.id == selectedId,
                        showPreview = state.query.isNotBlank(),
                        downloaded = conversation.id in state.downloadedIds,
                        canDownload = !state.offline,
                        onOpen = { actions.onOpen(conversation) },
                        onRename = { renaming = conversation },
                        onToggleStar = { actions.onToggleStar(conversation) },
                        onToggleArchive = { actions.onToggleArchive(conversation) },
                        onToggleDownload = { actions.onToggleDownload(conversation) },
                        onDelete = { confirmDelete = conversation },
                        modifier = Modifier.animateItem(),
                    )
                }
                // The 21st row: how many more there are.
                if (list.showSeeAll) {
                    item(key = "see-all") {
                        Text(
                            "See all (${list.total})",
                            style = AvekTheme.type.body.copy(fontWeight = FontWeight.Medium),
                            color = colors.accent,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 10.dp, vertical = 1.dp)
                                .clip(avekShape(10.dp))
                                .clickable(onClick = actions.onSeeAll)
                                .padding(horizontal = 14.dp, vertical = 12.dp),
                        )
                    }
                }
                if (list.loadingMore) {
                    item(key = "loading-more") {
                        Box(Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator(Modifier.size(20.dp), color = colors.textTertiary, strokeWidth = 2.dp)
                        }
                    }
                }
            }
        }
    }

    renaming?.let { conversation ->
        RenameDialog(
            initial = conversation.title,
            onDismiss = { renaming = null },
            onConfirm = {
                actions.onRename(conversation, it)
                renaming = null
            },
        )
    }

    confirmDelete?.let { conversation ->
        AlertDialog(
            onDismissRequest = { confirmDelete = null },
            containerColor = colors.surface,
            title = { Text("Delete chat?", color = colors.textPrimary) },
            text = { Text("“${conversation.title}” will be deleted from the PC. This cannot be undone.", color = colors.textSecondary) },
            confirmButton = {
                TextButton(onClick = {
                    actions.onDelete(conversation)
                    confirmDelete = null
                }) { Text("Delete", color = colors.danger) }
            },
            dismissButton = {
                TextButton(onClick = { confirmDelete = null }) { Text("Cancel", color = colors.textSecondary) }
            },
        )
    }
}

/** A compact rectangular search bar with the magnifier on the left. */
@Composable
private fun SearchField(query: String, onQuery: (String) -> Unit, modifier: Modifier = Modifier) {
    val colors = AvekTheme.colors
    Row(
        modifier
            .fillMaxWidth()
            .height(40.dp)
            .clip(avekShape(10.dp))
            .background(colors.sidebarSelected.copy(alpha = 0.7f))
            .padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Outlined.Search, null, tint = colors.textTertiary, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(8.dp))
        Box(Modifier.weight(1f)) {
            if (query.isEmpty()) {
                Text("Search", style = AvekTheme.type.body, color = colors.textTertiary)
            }
            BasicTextField(
                value = query,
                onValueChange = onQuery,
                singleLine = true,
                textStyle = AvekTheme.type.body.copy(color = colors.sidebarText),
                cursorBrush = SolidColor(colors.accent),
                modifier = Modifier.fillMaxWidth(),
            )
        }
        AnimatedVisibility(query.isNotEmpty(), enter = fadeIn(), exit = fadeOut()) {
            Icon(
                Icons.Outlined.Close,
                contentDescription = "Clear search",
                tint = colors.textSecondary,
                modifier = Modifier
                    .size(18.dp)
                    .clip(CircleShape)
                    .clickable { onQuery("") },
            )
        }
    }
}

@Composable
private fun NavRow(label: String, icon: ImageVector, selected: Boolean = false, onClick: () -> Unit) {
    val colors = AvekTheme.colors
    val bg by animateColorAsState(if (selected) colors.sidebarSelected else Color.Transparent, label = "nav-bg")
    Row(
        Modifier
            .padding(horizontal = 10.dp, vertical = 1.dp)
            .fillMaxWidth()
            .clip(avekShape(10.dp))
            .background(bg)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, null, tint = if (selected) colors.sidebarText else colors.textSecondary, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(14.dp))
        Text(
            label,
            style = AvekTheme.type.body.copy(fontWeight = if (selected) FontWeight.Medium else FontWeight.Normal),
            color = colors.sidebarText,
        )
    }
}

/** Minimal row: a small circle, then the title. Starred chats get a filled dot. */
@Composable
private fun ConversationRow(
    conversation: Conversation,
    selected: Boolean,
    showPreview: Boolean,
    downloaded: Boolean,
    canDownload: Boolean,
    onOpen: () -> Unit,
    onRename: () -> Unit,
    onToggleStar: () -> Unit,
    onToggleArchive: () -> Unit,
    onToggleDownload: () -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val colors = AvekTheme.colors
    var menu by remember { mutableStateOf(false) }
    val bg by animateColorAsState(if (selected) colors.sidebarSelected else Color.Transparent, label = "row-bg")

    Box(modifier.padding(horizontal = 10.dp, vertical = 1.dp)) {
        Row(
            Modifier
                .fillMaxWidth()
                .clip(avekShape(10.dp))
                .background(bg)
                .combinedClickable(onClick = onOpen, onLongClick = { menu = true })
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = if (showPreview) Alignment.Top else Alignment.CenterVertically,
        ) {
            Box(
                Modifier
                    .padding(top = if (showPreview) 7.dp else 0.dp)
                    .size(7.dp)
                    .clip(CircleShape)
                    .then(
                        if (conversation.isStarred) {
                            Modifier.background(colors.accent)
                        } else {
                            Modifier.border(1.2.dp, if (selected) colors.sidebarText else colors.textTertiary, CircleShape)
                        },
                    ),
            )
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    conversation.title,
                    style = AvekTheme.type.body.copy(fontWeight = if (selected) FontWeight.Medium else FontWeight.Normal),
                    color = colors.sidebarText,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                if (showPreview && conversation.preview.isNotBlank()) {
                    Text(
                        conversation.preview,
                        style = AvekTheme.type.caption,
                        color = colors.textSecondary,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
            if (downloaded) {
                Spacer(Modifier.width(8.dp))
                Icon(
                    Icons.Outlined.DownloadDone,
                    contentDescription = "Downloaded",
                    tint = colors.textTertiary,
                    modifier = Modifier.size(15.dp),
                )
            }
        }
        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }, containerColor = colors.surface) {
            RowMenuItem(if (conversation.isStarred) "Unstar" else "Star", if (conversation.isStarred) Icons.Filled.Star else Icons.Outlined.StarOutline) {
                menu = false
                onToggleStar()
            }
            RowMenuItem("Rename", Icons.Outlined.DriveFileRenameOutline) {
                menu = false
                onRename()
            }
            RowMenuItem(if (conversation.isArchived) "Unarchive" else "Archive", if (conversation.isArchived) Icons.Outlined.Unarchive else Icons.Outlined.Archive) {
                menu = false
                onToggleArchive()
            }
            if (canDownload || downloaded) {
                RowMenuItem(if (downloaded) "Remove download" else "Download", Icons.Outlined.CloudDownload) {
                    menu = false
                    onToggleDownload()
                }
            }
            HorizontalDivider(color = colors.outline.copy(alpha = 0.6f))
            RowMenuItem("Delete", Icons.Outlined.DeleteOutline, danger = true) {
                menu = false
                onDelete()
            }
        }
    }
}

@Composable
private fun RowMenuItem(label: String, icon: ImageVector, danger: Boolean = false, onClick: () -> Unit) {
    val colors = AvekTheme.colors
    DropdownMenuItem(
        text = { Text(label, style = AvekTheme.type.body, color = if (danger) colors.danger else colors.textPrimary) },
        leadingIcon = { Icon(icon, null, tint = if (danger) colors.danger else colors.textSecondary) },
        onClick = onClick,
    )
}

@Composable
private fun ProfileRow(name: String, plan: String, onSettings: () -> Unit) {
    val colors = AvekTheme.colors
    Row(
        Modifier
            .fillMaxWidth()
            .padding(start = 16.dp, end = 8.dp, top = 8.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(34.dp)
                .clip(CircleShape)
                .background(colors.textPrimary),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                name.trim().split(' ').filter { it.isNotEmpty() }.take(2).joinToString("") { it.first().uppercase() }.ifEmpty { "A" },
                style = AvekTheme.type.label.copy(fontWeight = FontWeight.SemiBold),
                color = colors.chatBackground,
            )
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(name.ifBlank { "Guest" }, style = AvekTheme.type.body.copy(fontWeight = FontWeight.Medium), color = colors.sidebarText, maxLines = 1)
            Text(plan, style = AvekTheme.type.caption, color = colors.textSecondary)
        }
        IconButton(onClick = onSettings) { Icon(Icons.Outlined.Settings, contentDescription = "Settings", tint = colors.textSecondary) }
    }
}

@Composable
fun RenameDialog(initial: String, onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    val colors = AvekTheme.colors
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = colors.surface,
        title = { Text("Rename chat", color = colors.textPrimary) },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                singleLine = true,
                textStyle = AvekTheme.type.body.copy(color = colors.textPrimary),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = colors.accent,
                    unfocusedBorderColor = colors.outline,
                    cursorColor = colors.accent,
                ),
            )
        },
        confirmButton = {
            TextButton(onClick = { onConfirm(text) }, enabled = text.isNotBlank()) { Text("Save", color = colors.accent) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel", color = colors.textSecondary) }
        },
    )
}

/** Placeholder rows while the first page loads. */
@Composable
private fun SkeletonRows() {
    val colors = AvekTheme.colors
    Column(Modifier.padding(horizontal = 24.dp, vertical = 8.dp), verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(18.dp)) {
        listOf(0.8f, 0.6f, 0.7f, 0.5f, 0.75f).forEach { fraction ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(7.dp).clip(CircleShape).background(colors.outline.copy(alpha = 0.6f)))
                Spacer(Modifier.width(14.dp))
                Box(
                    Modifier
                        .fillMaxWidth(fraction)
                        .height(12.dp)
                        .clip(avekShape(6.dp))
                        .background(colors.outline.copy(alpha = 0.35f)),
                )
            }
        }
    }
}
