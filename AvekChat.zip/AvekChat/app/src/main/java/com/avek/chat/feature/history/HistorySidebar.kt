package com.avek.chat.feature.history

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.DriveFileRenameOutline
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Archive
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.FilterList
import androidx.compose.material.icons.outlined.Palette
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.StarOutline
import androidx.compose.material.icons.outlined.Unarchive
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.avek.chat.core.designsystem.component.AvekChip
import com.avek.chat.core.designsystem.component.AvekSpark
import com.avek.chat.core.designsystem.icon.icon
import com.avek.chat.core.designsystem.theme.AvekTheme
import com.avek.chat.core.domain.usecase.HistoryGrouper
import com.avek.chat.core.model.Conversation
import com.avek.chat.core.model.TaskMode

data class HistoryActions(
    val onQuery: (String) -> Unit,
    val onFilter: (HistoryFilter) -> Unit,
    val onTaskFilter: (TaskMode?) -> Unit,
    val onOpen: (Conversation) -> Unit,
    val onNewChat: () -> Unit,
    val onRename: (Conversation, String) -> Unit,
    val onToggleStar: (Conversation) -> Unit,
    val onToggleArchive: (Conversation) -> Unit,
    val onDelete: (Conversation) -> Unit,
    val onCustomize: () -> Unit,
    val onSettings: () -> Unit,
)

/** The drawer: new chat, search, filters, date-grouped history and the profile footer. */
@Composable
fun HistorySidebar(
    state: HistoryUiState,
    selectedId: String?,
    actions: HistoryActions,
    modifier: Modifier = Modifier,
) {
    val colors = AvekTheme.colors
    var renaming by remember { mutableStateOf<Conversation?>(null) }
    var confirmDelete by remember { mutableStateOf<Conversation?>(null) }
    var taskMenu by remember { mutableStateOf(false) }

    Column(
        modifier
            .fillMaxSize()
            .background(colors.sidebar)
            .statusBarsPadding()
            .navigationBarsPadding(),
    ) {
        Row(
            Modifier.padding(start = 20.dp, end = 12.dp, top = 14.dp, bottom = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            AvekSpark(colors.thinkingGlow, Modifier.size(24.dp))
            Spacer(Modifier.width(10.dp))
            Text("Avek", style = AvekTheme.type.headline, color = colors.sidebarText)
        }

        // New chat
        Row(
            Modifier
                .padding(horizontal = 12.dp)
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .clickable(onClick = actions.onNewChat)
                .padding(horizontal = 10.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                Modifier
                    .size(28.dp)
                    .clip(CircleShape)
                    .background(colors.accent),
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Outlined.Add, null, tint = colors.onAccent, modifier = Modifier.size(18.dp))
            }
            Spacer(Modifier.width(12.dp))
            Text("New chat", style = AvekTheme.type.body.copy(fontWeight = FontWeight.Medium), color = colors.accent)
        }

        // Search
        Row(
            Modifier
                .padding(horizontal = 12.dp, vertical = 6.dp)
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(colors.sidebarSelected.copy(alpha = 0.7f))
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Outlined.Search, null, tint = colors.textSecondary, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Box(Modifier.weight(1f)) {
                if (state.query.isEmpty()) {
                    Text("Search chats", style = AvekTheme.type.body, color = colors.textTertiary)
                }
                BasicTextField(
                    value = state.query,
                    onValueChange = actions.onQuery,
                    singleLine = true,
                    textStyle = AvekTheme.type.body.copy(color = colors.sidebarText),
                    cursorBrush = SolidColor(colors.accent),
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            AnimatedVisibility(state.query.isNotEmpty(), enter = fadeIn(), exit = fadeOut()) {
                Icon(
                    Icons.Outlined.Close,
                    contentDescription = "Clear search",
                    tint = colors.textSecondary,
                    modifier = Modifier
                        .size(18.dp)
                        .clip(CircleShape)
                        .clickable { actions.onQuery("") },
                )
            }
        }

        // Filters
        Row(
            Modifier.padding(start = 12.dp, end = 4.dp, top = 4.dp, bottom = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            HistoryFilter.entries.forEach { filter ->
                AvekChip(filter.label, selected = state.filter == filter, onClick = { actions.onFilter(filter) })
            }
            Spacer(Modifier.weight(1f))
            Box {
                IconButton(onClick = { taskMenu = true }) {
                    Icon(
                        state.taskFilter?.icon ?: Icons.Outlined.FilterList,
                        contentDescription = "Filter by task",
                        tint = if (state.taskFilter != null) colors.accent else colors.textSecondary,
                    )
                }
                DropdownMenu(expanded = taskMenu, onDismissRequest = { taskMenu = false }, containerColor = colors.surface) {
                    DropdownMenuItem(
                        text = { Text("Any task", color = colors.textPrimary) },
                        leadingIcon = { Icon(Icons.Outlined.FilterList, null, tint = colors.textSecondary) },
                        onClick = {
                            taskMenu = false
                            actions.onTaskFilter(null)
                        },
                    )
                    TaskMode.concrete.forEach { task ->
                        DropdownMenuItem(
                            text = { Text(task.label, color = if (task == state.taskFilter) colors.accent else colors.textPrimary) },
                            leadingIcon = { Icon(task.icon, null, tint = colors.textSecondary) },
                            onClick = {
                                taskMenu = false
                                actions.onTaskFilter(task)
                            },
                        )
                    }
                }
            }
        }

        LazyColumn(
            Modifier.weight(1f),
            contentPadding = PaddingValues(bottom = 16.dp),
        ) {
            if (!state.isLoading && state.sections.isEmpty()) {
                item {
                    EmptyHistory(
                        when {
                            state.query.isNotBlank() -> "No chats match “${state.query}”"
                            state.filter == HistoryFilter.STARRED -> "Star a chat to keep it here"
                            state.filter == HistoryFilter.ARCHIVED -> "Archived chats will appear here"
                            else -> "Your conversations will appear here"
                        },
                    )
                }
            }
            state.sections.forEach { section ->
                stickyHeader(key = "header-${section.key}") {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .background(colors.sidebar)
                            .padding(start = 24.dp, end = 16.dp, top = 14.dp, bottom = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        if (section.key == HistoryGrouper.KEY_STARRED) {
                            Icon(Icons.Filled.Star, null, tint = colors.accent, modifier = Modifier.size(13.dp))
                            Spacer(Modifier.width(6.dp))
                        }
                        Text(
                            section.label,
                            style = AvekTheme.type.caption.copy(fontWeight = FontWeight.SemiBold),
                            color = colors.textSecondary,
                        )
                    }
                }
                items(section.conversations, key = { "${section.key}-${it.id}" }) { conversation ->
                    ConversationRow(
                        conversation = conversation,
                        selected = conversation.id == selectedId,
                        showPreview = state.query.isNotBlank(),
                        onOpen = { actions.onOpen(conversation) },
                        onRename = { renaming = conversation },
                        onToggleStar = { actions.onToggleStar(conversation) },
                        onToggleArchive = { actions.onToggleArchive(conversation) },
                        onDelete = { confirmDelete = conversation },
                        modifier = Modifier.animateItem(),
                    )
                }
            }
        }

        HorizontalDivider(color = colors.outline.copy(alpha = 0.5f))
        ProfileFooter(state.profileName, state.plan, actions.onCustomize, actions.onSettings)
    }

    renaming?.let { conversation ->
        RenameDialog(
            initial = conversation.title,
            onDismiss = { renaming = null },
            onConfirm = {
                actions.onRename(conversation, it)
                renaming = null
            },
        )
    }

    confirmDelete?.let { conversation ->
        AlertDialog(
            onDismissRequest = { confirmDelete = null },
            containerColor = colors.surface,
            title = { Text("Delete chat?", color = colors.textPrimary) },
            text = { Text("“${conversation.title}” will be removed. You can undo right after.", color = colors.textSecondary) },
            confirmButton = {
                TextButton(onClick = {
                    actions.onDelete(conversation)
                    confirmDelete = null
                }) { Text("Delete", color = colors.danger) }
            },
            dismissButton = {
                TextButton(onClick = { confirmDelete = null }) { Text("Cancel", color = colors.textSecondary) }
            },
        )
    }
}

@Composable
private fun ConversationRow(
    conversation: Conversation,
    selected: Boolean,
    showPreview: Boolean,
    onOpen: () -> Unit,
    onRename: () -> Unit,
    onToggleStar: () -> Unit,
    onToggleArchive: () -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val colors = AvekTheme.colors
    var menu by remember { mutableStateOf(false) }
    val bg by animateColorAsState(if (selected) colors.sidebarSelected else colors.sidebar, label = "row-bg")

    Box(modifier.padding(horizontal = 10.dp, vertical = 1.dp)) {
        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(bg)
                .combinedClickable(onClick = onOpen, onLongClick = { menu = true })
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(conversation.taskMode.icon, null, tint = colors.textTertiary, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    conversation.title,
                    style = AvekTheme.type.body.copy(fontWeight = if (selected) FontWeight.Medium else FontWeight.Normal),
                    color = colors.sidebarText,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                if (showPreview && conversation.preview.isNotBlank()) {
                    Text(
                        conversation.preview,
                        style = AvekTheme.type.caption,
                        color = colors.textSecondary,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
            if (conversation.isStarred) {
                Spacer(Modifier.width(6.dp))
                Icon(Icons.Filled.Star, null, tint = colors.accent.copy(alpha = 0.8f), modifier = Modifier.size(13.dp))
            }
        }
        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }, containerColor = colors.surface) {
            RowMenuItem(if (conversation.isStarred) "Unstar" else "Star", if (conversation.isStarred) Icons.Filled.Star else Icons.Outlined.StarOutline) {
                menu = false
                onToggleStar()
            }
            RowMenuItem("Rename", Icons.Outlined.DriveFileRenameOutline) {
                menu = false
                onRename()
            }
            RowMenuItem(if (conversation.isArchived) "Unarchive" else "Archive", if (conversation.isArchived) Icons.Outlined.Unarchive else Icons.Outlined.Archive) {
                menu = false
                onToggleArchive()
            }
            HorizontalDivider(color = colors.outline.copy(alpha = 0.6f))
            RowMenuItem("Delete", Icons.Outlined.DeleteOutline, danger = true) {
                menu = false
                onDelete()
            }
        }
    }
}

@Composable
private fun RowMenuItem(label: String, icon: ImageVector, danger: Boolean = false, onClick: () -> Unit) {
    val colors = AvekTheme.colors
    DropdownMenuItem(
        text = { Text(label, style = AvekTheme.type.body, color = if (danger) colors.danger else colors.textPrimary) },
        leadingIcon = { Icon(icon, null, tint = if (danger) colors.danger else colors.textSecondary) },
        onClick = onClick,
    )
}

@Composable
private fun EmptyHistory(message: String) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 24.dp, vertical = 48.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        AvekSpark(AvekTheme.colors.textTertiary.copy(alpha = 0.5f), Modifier.size(32.dp))
        Spacer(Modifier.height(12.dp))
        Text(message, style = AvekTheme.type.bodySmall, color = AvekTheme.colors.textSecondary)
    }
}

@Composable
private fun ProfileFooter(name: String, plan: String, onCustomize: () -> Unit, onSettings: () -> Unit) {
    val colors = AvekTheme.colors
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(colors.textPrimary)
                .border(2.dp, colors.accent.copy(alpha = 0.5f), CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                name.trim().split(' ').filter { it.isNotEmpty() }.take(2).joinToString("") { it.first().uppercase() }.ifEmpty { "A" },
                style = AvekTheme.type.label.copy(fontWeight = FontWeight.SemiBold),
                color = colors.chatBackground,
            )
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(name.ifBlank { "Guest" }, style = AvekTheme.type.body.copy(fontWeight = FontWeight.Medium), color = colors.sidebarText, maxLines = 1)
            Text(plan, style = AvekTheme.type.caption, color = colors.textSecondary)
        }
        IconButton(onClick = onCustomize) { Icon(Icons.Outlined.Palette, contentDescription = "Customize", tint = colors.textSecondary) }
        IconButton(onClick = onSettings) { Icon(Icons.Outlined.Settings, contentDescription = "Settings", tint = colors.textSecondary) }
    }
}

@Composable
fun RenameDialog(initial: String, onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    val colors = AvekTheme.colors
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = colors.surface,
        title = { Text("Rename chat", color = colors.textPrimary) },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                singleLine = true,
                textStyle = AvekTheme.type.body.copy(color = colors.textPrimary),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = colors.accent,
                    unfocusedBorderColor = colors.outline,
                    cursorColor = colors.accent,
                ),
            )
        },
        confirmButton = {
            TextButton(onClick = { onConfirm(text) }, enabled = text.isNotBlank()) { Text("Save", color = colors.accent) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel", color = colors.textSecondary) }
        },
    )
}
