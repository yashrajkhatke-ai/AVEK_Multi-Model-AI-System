package com.avek.chat.core.domain.timeline

import com.avek.chat.core.domain.trace.TurnKey
import com.avek.chat.core.link.wire.BlockAgentDto
import com.avek.chat.core.link.wire.BlockSummaryDto
import com.avek.chat.core.link.wire.BlockToolDto

/** Kinds of blocks (UI-WIRE section 9a). */
object BlockKind {
    const val THINKING = "thinking"
    const val TOOL = "tool"
    const val ANSWER = "answer"
    const val AGENT = "agent"
    const val NOTE = "note"
}

/** One block of a turn's timeline: everything one model wrote for one purpose. */
data class TimelineBlock(
    val id: String,
    val parentId: String?,
    val kind: String,
    val state: String,
    val title: String,
    val t0: Long? = null,
    val t1: Long? = null,
    val ms: Long? = null,
    val step: Int? = null,
    val tool: BlockToolDto? = null,
    val agent: BlockAgentDto? = null,
    val from: Int? = null,
    val to: Int? = null,
    val summary: BlockSummaryDto? = null,
    val tokens: Int? = null,
    val ok: Boolean? = null,
    val detail: String? = null,
    val text: String = "",
    val args: String = "",
    val textChars: Int? = null,
    val argsChars: Int? = null,
    val truncated: Boolean = false,
    /** `block.end` arrived: the block is final (only its heading may still change). */
    val ended: Boolean = false,
    /** A delta was missed for this block: fetch it with `timeline.get {ids}`. */
    val needsReload: Boolean = false,
    /** The texts are complete for what the harness has (live stream, or fetched). */
    val textLoaded: Boolean = true,
) {
    val running: Boolean get() = !ended

    /** There is text on the PC that this device has not fetched yet (outline of a saved turn). */
    val textMissing: Boolean
        get() = !textLoaded && ((textChars ?: 0) > text.length || (argsChars ?: 0) > args.length)
}

/** What the assistant side of a turn shows, in order: thinking groups and answers. */
sealed interface LayoutItem {
    val key: String

    /** Everything between two answers (top-level thinking and tool blocks). */
    data class Group(val index: Int, val blocks: List<TimelineBlock>, val followedByAnswer: Boolean) : LayoutItem {
        override val key: String get() = "group-${blocks.first().id}"
        val running: Boolean get() = blocks.any { it.running }
        val toolCount: Int get() = blocks.count { it.kind == BlockKind.TOOL }
        val totalMs: Long get() = blocks.sumOf { it.ms ?: 0L }
    }

    data class Answer(val block: TimelineBlock) : LayoutItem {
        override val key: String get() = "answer-${block.id}"
    }
}

/** The timeline of one turn, immutable; [TimelineReducer] produces the next one. */
data class TurnTimeline(
    val key: TurnKey,
    val blocks: Map<String, TimelineBlock> = emptyMap(),
    /** Block ids in the order they started. */
    val order: List<String> = emptyList(),
    val live: Boolean = false,
    /** Ids seen in events before their `block.start` (missed): fetch them. */
    val unknown: Set<String> = emptySet(),
    val dropped: Int = 0,
) {
    val isEmpty: Boolean get() = blocks.isEmpty()

    fun children(parentId: String?): List<TimelineBlock> = order.mapNotNull { blocks[it] }.filter { it.parentId == parentId }

    val topLevel: List<TimelineBlock> get() = children(null)

    /** Block ids to fetch again (a missed delta, or events for an unknown id). */
    val toReload: Set<String> get() = unknown + blocks.values.filter { it.needsReload }.map { it.id }

    /** The main model's answer: its answer blocks joined by a blank line (= `assistant.text`). */
    val answerText: String
        get() = topLevel.filter { it.kind == BlockKind.ANSWER }.map { it.text }.filter { it.isNotEmpty() }.joinToString("\n\n")

    /** The last top-level block that is still open (drives the reply phase). */
    val openTopLevel: TimelineBlock? get() = topLevel.lastOrNull { it.running }

    /** Groups and answers in order. */
    val layout: List<LayoutItem>
        get() {
            val items = mutableListOf<LayoutItem>()
            var current = mutableListOf<TimelineBlock>()
            var groupIndex = 0
            for (block in topLevel) {
                if (block.kind == BlockKind.ANSWER) {
                    if (current.isNotEmpty()) {
                        items += LayoutItem.Group(groupIndex++, current, followedByAnswer = true)
                        current = mutableListOf()
                    }
                    items += LayoutItem.Answer(block)
                } else {
                    current += block
                }
            }
            if (current.isNotEmpty()) items += LayoutItem.Group(groupIndex, current, followedByAnswer = false)
            return items
        }
}

/** "Thought for 12 s · 2 tool calls", "Thought for a moment". */
object GroupSummary {
    fun of(group: LayoutItem.Group): String {
        val seconds = (group.totalMs + 500) / 1000
        val time = if (seconds < 1) "Thought for a moment" else "Thought for $seconds s"
        val tools = group.toolCount
        return when (tools) {
            0 -> time
            1 -> "$time · 1 tool call"
            else -> "$time · $tools tool calls"
        }
    }
}
