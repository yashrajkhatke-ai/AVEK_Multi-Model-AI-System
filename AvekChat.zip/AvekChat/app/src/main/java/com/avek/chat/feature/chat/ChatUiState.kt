package com.avek.chat.feature.chat

import androidx.compose.runtime.Immutable
import com.avek.chat.core.domain.usecase.StreamingReply
import com.avek.chat.core.model.AiModel
import com.avek.chat.core.model.Message
import com.avek.chat.core.model.TaskMode
import com.avek.chat.core.model.ThinkingDepth

@Immutable
data class ChatUiState(
    val conversationId: String?,
    val title: String?,
    val isStarred: Boolean,
    val messages: List<Message>,
    /** The live reply for this conversation, if one is streaming. */
    val streaming: StreamingReply?,
    val isGenerating: Boolean,
    val model: AiModel,
    val models: List<AiModel>,
    val task: TaskMode,
    /** The requested depth, before clamping to the model. */
    val requestedDepth: ThinkingDepth,
    val profileName: String,
    /** Messages created after this instant animate in; older ones don't. */
    val sessionStartedAt: Long,
) {
    val depth: ThinkingDepth get() = model.clampDepth(requestedDepth)
    val isEmpty: Boolean get() = messages.isEmpty()
    val lastAssistantId: String? get() = messages.lastOrNull { !it.isUser }?.id
}

sealed interface ChatEvent {
    data class Error(val message: String) : ChatEvent
    data class Info(val message: String) : ChatEvent
}
