package com.avek.chat.feature.chat

import androidx.compose.runtime.Immutable
import com.avek.chat.core.domain.chat.StreamingReply
import com.avek.chat.core.model.Message
import com.avek.chat.core.model.TaskMode
import com.avek.chat.core.model.ThinkingDepth
import com.avek.chat.core.model.ToolView
import com.avek.chat.feature.connection.ConnectionUi

/** The model shown in the top bar and the composer. Never a made-up name. */
@Immutable
data class ModelChip(
    val id: String? = null,
    val name: String? = null,
    /** The default model is being fetched (or the PC is not reachable yet): show a neutral placeholder. */
    val loading: Boolean = true,
    /** The PC answered that no model is ready. */
    val noneAvailable: Boolean = false,
    /** Load state on the PC (from `model.state`); UNKNOWN shows nothing. */
    val loadState: com.avek.chat.core.model.ModelLoadState = com.avek.chat.core.model.ModelLoadState.UNKNOWN,
    /** `model.load` said another chat is answering: it loads when that finishes. */
    val waiting: Boolean = false,
    val error: String? = null,
) {
    /** "Loading Nova 4...", "Will load when the current answer finishes", or null. */
    val statusLine: String?
        get() = when {
            error != null -> error
            loadState == com.avek.chat.core.model.ModelLoadState.LOADING -> "Loading ${name ?: "the model"}..."
            waiting && loadState != com.avek.chat.core.model.ModelLoadState.READY -> "Will load when the current answer finishes"
            else -> null
        }

    val label: String
        get() = name ?: if (noneAvailable) "No model is ready" else "Model"
}

enum class AttachStatus { UPLOADING, READY, FAILED }

@Immutable
data class PendingAttachment(
    val key: String,
    val name: String,
    val size: Long,
    val progress: Float,
    val status: AttachStatus,
    val attachmentId: String? = null,
    val error: String? = null,
)

/** The expanded body of a tool call, loaded with `tool.get` when the person opens it. */
sealed interface ToolViewState {
    data object Loading : ToolViewState
    data class Loaded(val view: ToolView) : ToolViewState
    data class Failed(val message: String) : ToolViewState
}

@Immutable
data class ChatUiState(
    val conversationId: String?,
    val title: String?,
    val isStarred: Boolean,
    val isDownloaded: Boolean,
    val messages: List<Message>,
    /** The live reply for this conversation, if one is streaming. */
    val streaming: StreamingReply?,
    val isGenerating: Boolean,
    val loadingChat: Boolean,
    val loadError: String?,
    val hasOlder: Boolean,
    val loadingOlder: Boolean,
    val model: ModelChip,
    val task: TaskMode,
    val depth: ThinkingDepth,
    val profileName: String,
    val connection: ConnectionUi,
    val attachments: List<PendingAttachment>,
    val toolViews: Map<String, ToolViewState>,
    val thinkingLoading: Set<String>,
    /** Messages created after this instant animate in; older ones don't. */
    val sessionStartedAt: Long,
) {
    val isEmpty: Boolean get() = messages.isEmpty() && !loadingChat && loadError == null
    /** Sending needs the PC, no running upload, and no running reply in this chat. */
    fun canSend(draft: String): Boolean =
        connection.connected && !isGenerating && attachments.none { it.status == AttachStatus.UPLOADING } &&
            (draft.isNotBlank() || attachments.any { it.status == AttachStatus.READY })
}

sealed interface ChatEvent {
    data class Error(val message: String) : ChatEvent
    data class Info(val message: String) : ChatEvent
}
