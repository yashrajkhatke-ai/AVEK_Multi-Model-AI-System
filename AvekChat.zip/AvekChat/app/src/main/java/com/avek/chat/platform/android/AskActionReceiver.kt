package com.avek.chat.platform.android

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.avek.chat.core.domain.repository.SettingsRepository
import com.avek.chat.core.link.AppVisibility
import com.avek.chat.core.link.HarnessApi
import com.avek.chat.core.link.LinkRepository
import com.avek.chat.core.link.rpc.RpcException
import com.avek.chat.core.link.route.ConnectionState
import com.avek.chat.core.link.wire.ErrorCodes
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import javax.inject.Inject

/** The Allow / Deny buttons of a question notification: sends `ask.answer` and clears the notification. */
@AndroidEntryPoint
class AskActionReceiver : BroadcastReceiver() {

    @Inject lateinit var api: HarnessApi
    @Inject lateinit var link: LinkRepository
    @Inject lateinit var notifications: AvekNotifications
    @Inject lateinit var visibility: AppVisibility
    @Inject lateinit var settings: SettingsRepository

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != AvekNotifications.ACTION_ANSWER) return
        val askId = intent.getStringExtra(AvekNotifications.EXTRA_ASK_ID) ?: return
        val decision = intent.getStringExtra(AvekNotifications.EXTRA_DECISION) ?: return
        val pending = goAsync()
        CoroutineScope(SupervisorJob() + Dispatchers.Default).launch {
            try {
                // The process may have just been started by this tap: make sure there is a link.
                link.connect()
                val connected = withTimeoutOrNull(CONNECT_WAIT_MS) { link.state.first { it is ConnectionState.Connected } }
                if (connected == null) {
                    notifications.showMessage("Could not answer: your PC is not reachable.")
                    return@launch
                }
                try {
                    api.askAnswerDecision(askId, decision)
                } catch (e: RpcException) {
                    // Already answered elsewhere, or expired: nothing left to do either way.
                    if (e.code != ErrorCodes.EXPIRED && e.code != ErrorCodes.NOT_FOUND) {
                        notifications.showMessage("Could not answer: ${e.message}")
                        return@launch
                    }
                }
                notifications.cancelAsk(askId)
            } finally {
                // If this tap is what woke the link up, put it back to sleep like the lifecycle rules say.
                if (!visibility.visible.value && !settings.settings.first().connection.workInBackground) link.disconnect()
                pending.finish()
            }
        }
    }

    private companion object {
        const val CONNECT_WAIT_MS = 8_000L
    }
}
