package com.avek.chat.core.domain.chat

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update

/** "Open this chat": raised by the Downloaded chats screen and by notifications, consumed by the chat screen. */
class OpenChatBus {
    private val _pending = MutableStateFlow<String?>(null)
    val pending: StateFlow<String?> = _pending

    fun open(chatId: String) {
        _pending.value = chatId
    }

    /** The chat screen took it. */
    fun consume(chatId: String) {
        _pending.update { if (it == chatId) null else it }
    }
}
