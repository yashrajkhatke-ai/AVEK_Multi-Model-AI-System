package com.avek.chat.core.data.downloads

import com.avek.chat.core.data.remote.feedbackOf
import com.avek.chat.core.data.remote.toMessages
import com.avek.chat.core.domain.repository.ChatListQuery
import com.avek.chat.core.domain.repository.ChatRepository
import com.avek.chat.core.domain.repository.ChatTurns
import com.avek.chat.core.domain.repository.Page
import com.avek.chat.core.domain.repository.TurnMessages
import com.avek.chat.core.link.rpc.RpcException
import com.avek.chat.core.model.Conversation
import com.avek.chat.core.model.Feedback
import com.avek.chat.core.model.TaskMode
import com.avek.chat.core.model.ToolView
import kotlinx.coroutines.flow.first

/**
 * Read-only access to the downloaded copies, used while the PC is not reachable.
 * Cursors are plain offsets here (they never leave the app).
 */
class LocalChatRepository(private val store: DownloadedChatStore) : ChatRepository {

    override suspend fun list(query: ChatListQuery, limit: Int, after: String?): Page<Conversation> {
        val all = store.observeInfo().first().map { it.chat }
            .filter { it.isArchived == query.archived }
            .filter { !query.starred || it.isStarred }
            .filter { query.text.isBlank() || it.title.contains(query.text.trim(), ignoreCase = true) }
            .sortedByDescending { it.updatedAt }
        val start = after?.toIntOrNull() ?: 0
        val items = all.drop(start).take(limit)
        val next = (start + items.size).takeIf { it < all.size }?.toString()
        return Page(items, all.size, next)
    }

    override suspend fun open(chatId: String, limit: Int, after: String?): ChatTurns {
        val chat = store.chat(chatId) ?: throw RpcException(RpcException.NOT_FOUND_LOCAL, "Chat is not downloaded")
        val newestFirst = store.turns(chatId).sortedByDescending { it.createdAt }
        val start = after?.toIntOrNull() ?: 0
        val page = newestFirst.drop(start).take(limit)
        val next = (start + page.size).takeIf { it < newestFirst.size }?.toString()
        val messages = page.reversed().flatMap { turn -> turn.toMessages(chatId).let { listOf(it.user, it.assistant) } }
        return ChatTurns(if (start == 0) chat else null, messages, newestFirst.size, next)
    }

    override suspend fun turn(chatId: String, promptId: String, withThinking: Boolean): TurnMessages {
        val turn = store.turns(chatId).firstOrNull { it.promptId == promptId }
            ?: throw RpcException(RpcException.NOT_FOUND_LOCAL, "Turn not found")
        return turn.toMessages(chatId)
    }

    override suspend fun tool(chatId: String, promptId: String, callId: String): ToolView {
        val tool = store.turns(chatId).firstOrNull { it.promptId == promptId }?.tools?.firstOrNull { it.callId == callId }
            ?: throw RpcException(RpcException.NOT_FOUND_LOCAL, "Tool call not found")
        return ToolView(callId, tool.title, "", tool.body.orEmpty(), "text")
    }

    override suspend fun setChat(chatId: String, title: String?, mode: TaskMode?, starred: Boolean?, archived: Boolean?, modelId: String?): Conversation =
        throw RpcException.notConnected()

    override suspend fun delete(chatId: String) = throw RpcException.notConnected()

    override suspend fun rewind(chatId: String, fromPromptId: String) = throw RpcException.notConnected()

    override suspend fun feedback(chatId: String, promptId: String, value: Feedback) = throw RpcException.notConnected()
}
