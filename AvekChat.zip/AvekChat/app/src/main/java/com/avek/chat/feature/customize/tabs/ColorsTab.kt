package com.avek.chat.feature.customize.tabs

import androidx.compose.foundation.clickable
import com.avek.chat.core.designsystem.theme.avekShape
import com.avek.chat.core.designsystem.theme.avekPill
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.background
import com.avek.chat.core.designsystem.component.ColorDot
import com.avek.chat.core.designsystem.component.ColorPickerDialog
import com.avek.chat.core.designsystem.component.SectionHeader
import com.avek.chat.core.designsystem.component.SegmentedPicker
import com.avek.chat.core.designsystem.component.SettingsCard
import com.avek.chat.core.designsystem.theme.AvekTheme
import com.avek.chat.core.designsystem.theme.ColorMath
import com.avek.chat.core.designsystem.theme.ThemeCatalog
import com.avek.chat.core.model.settings.AppearanceSettings
import com.avek.chat.core.model.settings.ColorGroup
import com.avek.chat.core.model.settings.ColorRole

@Composable
fun ColorsTab(
    appearance: AppearanceSettings,
    isDark: Boolean,
    onSetColor: (dark: Boolean, ColorRole, Color) -> Unit,
    onClearColor: (dark: Boolean, ColorRole) -> Unit,
    onClearAll: (dark: Boolean) -> Unit,
) {
    val colors = AvekTheme.colors
    var editDark by remember(isDark) { mutableStateOf(isDark) }
    var editing by remember { mutableStateOf<ColorRole?>(null) }
    val theme = ThemeCatalog.resolve(appearance.themeId)
    val base = theme.colors(editDark)
    val overrides = if (editDark) appearance.darkOverrides else appearance.lightOverrides
    val effective = base.withOverrides(overrides)

    LazyColumn(contentPadding = PaddingValues(bottom = 40.dp)) {
        item {
            Column(Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
                Text(
                    "Fine-tune any colour on top of “${theme.name}”. Light and dark keep separate overrides.",
                    style = AvekTheme.type.bodySmall,
                    color = colors.textSecondary,
                )
                Spacer(Modifier.height(12.dp))
                SegmentedPicker(listOf(false, true), editDark, { editDark = it }, { if (it) "Dark scheme" else "Light scheme" })
            }
        }
        ColorGroup.entries.forEach { group ->
            item(key = "group-${group.name}") { SectionHeader(group.label) }
            item(key = "card-${group.name}") {
                SettingsCard {
                    val roles = ColorRole.entries.filter { it.group == group }
                    roles.forEachIndexed { index, role ->
                        if (index > 0) HorizontalDivider(color = colors.outline.copy(alpha = 0.4f), modifier = Modifier.padding(start = 56.dp))
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clickable { editing = role }
                                .padding(horizontal = 16.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            ColorDot(effective[role], size = 26)
                            Spacer(Modifier.width(14.dp))
                            Column(Modifier.weight(1f)) {
                                Text(role.label, style = AvekTheme.type.body, color = colors.textPrimary)
                                Text(ColorMath.toHex(effective[role]), style = AvekTheme.type.caption, color = colors.textTertiary)
                            }
                            if (role in overrides) {
                                Text(
                                    "Custom",
                                    style = AvekTheme.type.caption.copy(fontWeight = FontWeight.SemiBold),
                                    color = colors.accent,
                                    modifier = Modifier
                                        .clip(avekPill())
                                        .background(colors.accentContainer)
                                        .padding(horizontal = 8.dp, vertical = 2.dp),
                                )
                            }
                        }
                    }
                }
            }
        }
        item {
            Spacer(Modifier.height(20.dp))
            Text(
                "Reset ${if (editDark) "dark" else "light"} overrides (${overrides.size})",
                style = AvekTheme.type.body.copy(fontWeight = FontWeight.Medium),
                color = if (overrides.isEmpty()) colors.textTertiary else colors.danger,
                modifier = Modifier
                    .padding(horizontal = 16.dp)
                    .clip(avekShape(12.dp))
                    .clickable(enabled = overrides.isNotEmpty()) { onClearAll(editDark) }
                    .padding(horizontal = 12.dp, vertical = 10.dp),
            )
        }
    }

    editing?.let { role ->
        ColorPickerDialog(
            title = role.label,
            initial = effective[role],
            onDismiss = { editing = null },
            onConfirm = {
                onSetColor(editDark, role, it)
                editing = null
            },
            onReset = if (role in overrides) {
                {
                    onClearColor(editDark, role)
                    editing = null
                }
            } else {
                null
            },
        )
    }
}
