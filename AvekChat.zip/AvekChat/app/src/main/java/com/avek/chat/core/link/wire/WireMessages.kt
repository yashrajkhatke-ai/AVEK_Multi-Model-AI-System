package com.avek.chat.core.link.wire

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.longOrNull
import kotlinx.serialization.json.put

/** The one JSON configuration for the wire: unknown fields are ignored (forward compatibility). */
val WireJson: Json = Json {
    ignoreUnknownKeys = true
    explicitNulls = false
    encodeDefaults = false
    coerceInputValues = true
}

@Serializable
data class ErrorBody(val code: String = "internal", val message: String = "")

/** Server -> app reply to one request. Lists answer in several parts: `more = true` on all but the last. */
data class WireResponse(
    val re: String,
    val ok: Boolean,
    val data: JsonElement?,
    val error: ErrorBody?,
    val more: Boolean,
)

/** Server -> app event. `ready` and `bye` have no [seq]. */
data class WireEvent(val ev: String, val seq: Long?, val data: JsonObject)

/** Error codes of the protocol (UI-WIRE section 6). */
object ErrorCodes {
    const val BAD_REQUEST = "bad-request"
    const val UNKNOWN_OP = "unknown-op"
    const val NOT_FOUND = "not-found"
    const val BUSY = "busy"
    const val NO_MODEL = "no-model"
    const val DENIED = "denied"
    const val TOO_LARGE = "too-large"
    const val EXPIRED = "expired"
    const val UNSUPPORTED = "unsupported"
    const val RATE_LIMITED = "rate-limited"
    const val INTERNAL = "internal"
}

object WireCodec {

    fun encodeRequest(id: String, op: String, args: JsonObject): String =
        WireJson.encodeToString(
            JsonObject.serializer(),
            buildJsonObject {
                put("id", id)
                put("op", op)
                put("args", args)
            },
        )

    /** Returns a [WireResponse] or [WireEvent]; anything else (unknown kinds) is ignored with null. */
    fun parse(text: String): Any? {
        val obj = WireJson.parseToJsonElement(text) as? JsonObject ?: return null
        obj["re"]?.let { re ->
            val id = (re as? JsonPrimitive)?.contentOrNull ?: return null
            val ok = (obj["ok"] as? JsonPrimitive)?.booleanOrNull ?: false
            val error = (obj["error"] as? JsonObject)?.let { WireJson.decodeFromJsonElement(ErrorBody.serializer(), it) }
            val more = (obj["more"] as? JsonPrimitive)?.booleanOrNull ?: false
            val data = obj["data"]?.takeIf { it !is JsonNull }
            return WireResponse(id, ok, data, error, more)
        }
        obj["ev"]?.let { ev ->
            val name = (ev as? JsonPrimitive)?.contentOrNull ?: return null
            val seq = (obj["seq"] as? JsonPrimitive)?.longOrNull
            val data = (obj["data"] as? JsonObject) ?: JsonObject(emptyMap())
            return WireEvent(name, seq, data)
        }
        return null
    }
}

val EmptyArgs: JsonObject = JsonObject(emptyMap())

/** Wire name of the thinking-delta event text channel etc. live in [LinkEvent]. */
fun JsonObject.str(key: String): String? = (this[key] as? JsonPrimitive)?.contentOrNull
