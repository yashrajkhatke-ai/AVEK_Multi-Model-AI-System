package com.avek.chat.core.model.settings

import kotlinx.serialization.Serializable

/**
 * Link settings. Routes are not a setting any more (UI-WIRE v3): the knock finds the PC.
 * Older files that still contain `routes` decode fine (unknown keys are ignored).
 */
@Serializable
data class ConnectionSettings(
    /** Keep the link alive from a foreground service while the app is off screen. */
    val workInBackground: Boolean = false,
    /** Use the built-in simulator instead of a PC. */
    val demoMode: Boolean = false,
    /** How long loaded chat/model pages stay in memory after their view closes (30..600). */
    val keepListsSeconds: Int = DEFAULT_KEEP_LISTS_SECONDS,
    /** The first-launch pairing screen was shown (or skipped) once. */
    val onboardingDone: Boolean = false,
) {
    companion object {
        const val DEFAULT_KEEP_LISTS_SECONDS = 120
        const val MIN_KEEP_LISTS_SECONDS = 30
        const val MAX_KEEP_LISTS_SECONDS = 600
    }
}
