package com.avek.chat.core.model.settings

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/** One entry of the ordered list of ways to reach the PC (UI-WIRE section 13, "Routes"). */
@Serializable
sealed interface RouteSpec {
    /** The host:port of the last successful connection, kept automatically. */
    @Serializable
    @SerialName("last")
    data object Last : RouteSpec

    /** The UDP beacon the PC broadcasts on the local network. */
    @Serializable
    @SerialName("discover")
    data object Discover : RouteSpec

    /** A typed address; any number of these. */
    @Serializable
    @SerialName("host")
    data class Host(val host: String, val port: Int = 7810) : RouteSpec
}

@Serializable
data class ConnectionSettings(
    val routes: List<RouteSpec> = listOf(RouteSpec.Last, RouteSpec.Discover),
    /** Keep the link alive from a foreground service while the app is off screen. */
    val workInBackground: Boolean = false,
    /** Use the built-in simulator instead of a PC. */
    val demoMode: Boolean = false,
    /** How long loaded chat/model pages stay in memory after their view closes (30..600). */
    val keepListsSeconds: Int = DEFAULT_KEEP_LISTS_SECONDS,
) {
    companion object {
        const val DEFAULT_KEEP_LISTS_SECONDS = 120
        const val MIN_KEEP_LISTS_SECONDS = 30
        const val MAX_KEEP_LISTS_SECONDS = 600
    }
}
