package com.avek.chat.feature.settings

import androidx.compose.runtime.Immutable
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.avek.chat.core.data.fake.DemoContentSeeder
import com.avek.chat.core.domain.repository.ConversationRepository
import com.avek.chat.core.domain.repository.ModelRepository
import com.avek.chat.core.domain.repository.SettingsRepository
import com.avek.chat.core.model.AiModel
import com.avek.chat.core.model.TaskMode
import com.avek.chat.core.model.ThinkingDepth
import com.avek.chat.core.model.settings.UserSettings
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@Immutable
data class SettingsUiState(
    val settings: UserSettings = UserSettings(),
    val models: List<AiModel> = emptyList(),
) {
    val defaultModel: AiModel? get() = models.firstOrNull { it.id == settings.defaults.modelId } ?: models.firstOrNull()
}

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val settingsRepository: SettingsRepository,
    private val conversations: ConversationRepository,
    private val seeder: DemoContentSeeder,
    models: ModelRepository,
) : ViewModel() {

    val uiState: StateFlow<SettingsUiState> = settingsRepository.settings
        .map { SettingsUiState(it, models.models) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), SettingsUiState(models = models.models))

    private val _messages = Channel<String>(Channel.BUFFERED)
    val messages: Flow<String> = _messages.receiveAsFlow()

    fun setName(name: String) = update { it.copy(profile = it.profile.copy(displayName = name.take(40))) }
    fun setDefaultModel(id: String) = update { it.copy(defaults = it.defaults.copy(modelId = id)) }
    fun setDefaultTask(task: TaskMode) = update { it.copy(defaults = it.defaults.copy(taskMode = task)) }
    fun setDefaultDepth(depth: ThinkingDepth) = update { it.copy(defaults = it.defaults.copy(depth = depth)) }
    fun setAutoTitle(enabled: Boolean) = update { it.copy(defaults = it.defaults.copy(autoTitle = enabled)) }

    fun deleteAllConversations() {
        viewModelScope.launch {
            conversations.deleteAll()
            _messages.send("All conversations deleted")
        }
    }

    fun restoreDemoConversations() {
        viewModelScope.launch {
            seeder.seed()
            _messages.send("Sample conversations added")
        }
    }

    private fun update(transform: (UserSettings) -> UserSettings) {
        viewModelScope.launch { settingsRepository.update(transform) }
    }
}
