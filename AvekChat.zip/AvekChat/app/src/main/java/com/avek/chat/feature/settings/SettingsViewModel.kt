package com.avek.chat.feature.settings

import androidx.compose.runtime.Immutable
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.avek.chat.core.domain.repository.SettingsRepository
import com.avek.chat.core.link.LinkRepository
import com.avek.chat.core.model.TaskMode
import com.avek.chat.core.model.ThinkingDepth
import com.avek.chat.core.model.settings.UserSettings
import com.avek.chat.core.model.settings.SecuritySettings
import com.avek.chat.core.domain.lock.AppLockManager
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.receiveAsFlow
import com.avek.chat.feature.connection.describe
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@Immutable
data class SettingsUiState(
    val settings: UserSettings = UserSettings(),
    /** One line about the link to the PC, for the Connection row. */
    val connectionStatus: String = "",
)

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val settingsRepository: SettingsRepository,
    link: LinkRepository,
    private val lock: AppLockManager,
) : ViewModel() {

    private val _messages = Channel<String>(Channel.BUFFERED)
    val messages: Flow<String> = _messages.receiveAsFlow()

    val uiState: StateFlow<SettingsUiState> = combine(settingsRepository.settings, link.state) { settings, state ->
        SettingsUiState(settings, describe(state, settings.connection.demoMode))
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), SettingsUiState())

    fun setName(name: String) = update { it.copy(profile = it.profile.copy(displayName = name.take(40))) }
    fun setDefaultTask(task: TaskMode) = update { it.copy(defaults = it.defaults.copy(taskMode = task)) }
    fun setDefaultDepth(depth: ThinkingDepth) = update { it.copy(defaults = it.defaults.copy(depth = depth)) }

    // ------------------------------------------------------------------ Security (section 13, "App lock")

    fun setGraceMinutes(minutes: Int) = update {
        it.copy(security = it.security.copy(graceMinutes = minutes.takeIf { m -> m in SecuritySettings.GRACE_OPTIONS } ?: 0))
    }

    fun setAllowScreenshots(allow: Boolean) = update { it.copy(security = it.security.copy(allowScreenshots = allow)) }

    /** Asks the old password first; all three arrays are wiped by the lock manager. Calls [onDone] with null on success. */
    fun changePassword(old: CharArray, first: CharArray, second: CharArray, onDone: (String?) -> Unit) {
        viewModelScope.launch {
            val error = lock.changePassword(old, first, second)
            onDone(error)
            if (error == null) _messages.trySend("App password changed")
        }
    }

    private fun update(transform: (UserSettings) -> UserSettings) {
        viewModelScope.launch { settingsRepository.update(transform) }
    }
}
