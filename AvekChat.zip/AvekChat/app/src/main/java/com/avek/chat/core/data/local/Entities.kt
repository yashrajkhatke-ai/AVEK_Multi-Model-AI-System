package com.avek.chat.core.data.local

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "conversations",
    indices = [Index(value = ["updated_at"]), Index(value = ["is_archived"])],
)
data class ConversationEntity(
    @PrimaryKey val id: String,
    val title: String,
    @ColumnInfo(name = "created_at") val createdAt: Long,
    @ColumnInfo(name = "updated_at") val updatedAt: Long,
    @ColumnInfo(name = "is_starred") val isStarred: Boolean,
    @ColumnInfo(name = "is_archived") val isArchived: Boolean,
    @ColumnInfo(name = "model_id") val modelId: String,
    @ColumnInfo(name = "task_mode") val taskMode: String,
    val preview: String,
    @ColumnInfo(name = "message_count") val messageCount: Int,
)

@Entity(
    tableName = "messages",
    foreignKeys = [
        ForeignKey(
            entity = ConversationEntity::class,
            parentColumns = ["id"],
            childColumns = ["conversation_id"],
            onDelete = ForeignKey.CASCADE,
        ),
    ],
    indices = [Index(value = ["conversation_id", "created_at"])],
)
data class MessageEntity(
    @PrimaryKey val id: String,
    @ColumnInfo(name = "conversation_id") val conversationId: String,
    val role: String,
    val content: String,
    val thinking: String?,
    @ColumnInfo(name = "thinking_duration_ms") val thinkingDurationMs: Long,
    @ColumnInfo(name = "model_id") val modelId: String?,
    @ColumnInfo(name = "requested_task") val requestedTask: String,
    @ColumnInfo(name = "resolved_task") val resolvedTask: String?,
    val depth: Int,
    val status: String,
    val feedback: String,
    @ColumnInfo(name = "sources_json") val sourcesJson: String,
    @ColumnInfo(name = "created_at") val createdAt: Long,
)
