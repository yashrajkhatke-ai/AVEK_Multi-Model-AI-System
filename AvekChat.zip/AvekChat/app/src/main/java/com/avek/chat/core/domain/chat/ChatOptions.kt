package com.avek.chat.core.domain.chat

import com.avek.chat.core.model.Conversation
import com.avek.chat.core.model.Message
import com.avek.chat.core.model.TaskMode
import com.avek.chat.core.model.ThinkingDepth

/** The knobs the person picked in the composer for one turn. A null model keeps the chat's (or the default) model. */
data class ChatOptions(
    val modelId: String?,
    val task: TaskMode,
    val depth: ThinkingDepth,
)

enum class ReplyPhase { THINKING, ANSWERING, DONE }

/** A live snapshot of one turn while it streams (or its final state). */
data class StreamingReply(
    val user: Message,
    /** The assistant message being built. */
    val message: Message,
    val phase: ReplyPhase,
    /** What the PC is doing right now ("Loading Ornith…", a running tool's title), if anything. */
    val activity: String?,
    /** The chat summary, known once the PC accepted the prompt. */
    val chat: Conversation? = null,
)
