package com.avek.chat.core.link.wire

import kotlinx.serialization.SerializationException
import kotlinx.serialization.json.JsonObject

/** Decoded server events plus a few synthetic ones raised by the app's own link layer. */
sealed interface LinkEvent {
    val seq: Long?

    data class TurnStarted(override val seq: Long?, val data: TurnStartedDto) : LinkEvent
    data class ThinkingDelta(override val seq: Long?, val data: DeltaDto) : LinkEvent
    data class AnswerDelta(override val seq: Long?, val data: DeltaDto) : LinkEvent
    data class ToolCall(override val seq: Long?, val data: ToolCallEventDto) : LinkEvent
    data class ToolResult(override val seq: Long?, val data: ToolResultEventDto) : LinkEvent
    data class Status(override val seq: Long?, val data: StatusDto) : LinkEvent
    data class Sources(override val seq: Long?, val data: SourcesEventDto) : LinkEvent
    data class AskRequest(override val seq: Long?, val data: AskRequestDto) : LinkEvent
    data class AskResolved(override val seq: Long?, val data: AskResolvedDto) : LinkEvent
    data class TurnCompleted(override val seq: Long?, val data: TurnCompletedDto) : LinkEvent
    data class TurnCancelled(override val seq: Long?, val data: TurnEndedDto) : LinkEvent
    data class TurnFailed(override val seq: Long?, val data: TurnFailedDto) : LinkEvent
    data class ChatCreated(override val seq: Long?, val chat: ChatSummaryDto) : LinkEvent
    data class ChatUpdated(override val seq: Long?, val chat: ChatSummaryDto) : LinkEvent
    data class ChatDeleted(override val seq: Long?, val chatId: String) : LinkEvent
    data class ModelsChanged(override val seq: Long?) : LinkEvent
    data class DownloadTurn(override val seq: Long?, val data: DownloadTurnDto) : LinkEvent
    data class DownloadChat(override val seq: Long?, val chat: ChatSummaryDto) : LinkEvent
    data class DownloadDeleted(override val seq: Long?, val chatId: String) : LinkEvent
    data class Bye(override val seq: Long?, val reason: String) : LinkEvent

    // v3
    data class ToolCallDelta(override val seq: Long?, val data: ToolCallDeltaDto) : LinkEvent
    data class ModelState(override val seq: Long?, val data: ModelStateDto) : LinkEvent
    data class TracePhase(override val seq: Long?, val data: TracePhaseDto) : LinkEvent
    data class TraceContext(override val seq: Long?, val data: TraceContextDto) : LinkEvent
    data class TraceGen(override val seq: Long?, val data: TraceGenDto) : LinkEvent
    data class TraceTool(override val seq: Long?, val data: TraceToolDto) : LinkEvent
    data class TraceRuntime(override val seq: Long?, val data: TraceRuntimeDto) : LinkEvent
    data class TraceLog(override val seq: Long?, val data: TraceLogDto) : LinkEvent

    /**
     * Synthetic: raised after every (re)connection and when the app returns to the
     * foreground. Screens refresh what they show; offsets make that always safe.
     */
    data object Refresh : LinkEvent {
        override val seq: Long? = null
    }
}

object EventDecoder {
    const val READY = "ready"

    /** Decodes one wire event. Unknown events and malformed payloads return null and are ignored. */
    fun decode(event: WireEvent): LinkEvent? = try {
        decodeOrThrow(event)
    } catch (_: SerializationException) {
        null
    } catch (_: IllegalArgumentException) {
        null
    }

    private fun decodeOrThrow(event: WireEvent): LinkEvent? {
        val seq = event.seq
        val data = event.data
        return when (event.ev) {
            "turn.started" -> LinkEvent.TurnStarted(seq, data.decode(TurnStartedDto.serializer()))
            "thinking.delta" -> LinkEvent.ThinkingDelta(seq, data.decode(DeltaDto.serializer()))
            "answer.delta" -> LinkEvent.AnswerDelta(seq, data.decode(DeltaDto.serializer()))
            "tool.call" -> LinkEvent.ToolCall(seq, data.decode(ToolCallEventDto.serializer()))
            "tool.result" -> LinkEvent.ToolResult(seq, data.decode(ToolResultEventDto.serializer()))
            "status" -> LinkEvent.Status(seq, data.decode(StatusDto.serializer()))
            "sources" -> LinkEvent.Sources(seq, data.decode(SourcesEventDto.serializer()))
            "ask.request" -> LinkEvent.AskRequest(seq, data.decode(AskRequestDto.serializer()))
            "ask.resolved" -> LinkEvent.AskResolved(seq, data.decode(AskResolvedDto.serializer()))
            "turn.completed" -> LinkEvent.TurnCompleted(seq, data.decode(TurnCompletedDto.serializer()))
            "turn.cancelled" -> LinkEvent.TurnCancelled(seq, data.decode(TurnEndedDto.serializer()))
            "turn.failed" -> LinkEvent.TurnFailed(seq, data.decode(TurnFailedDto.serializer()))
            "chat.created" -> LinkEvent.ChatCreated(seq, data.decode(ChatEventDto.serializer()).chat)
            "chat.updated" -> LinkEvent.ChatUpdated(seq, data.decode(ChatEventDto.serializer()).chat)
            "chat.deleted" -> LinkEvent.ChatDeleted(seq, data.decode(ChatDeletedDto.serializer()).chatId)
            "models.changed" -> LinkEvent.ModelsChanged(seq)
            "download.turn" -> LinkEvent.DownloadTurn(seq, data.decode(DownloadTurnDto.serializer()))
            "download.chat" -> LinkEvent.DownloadChat(seq, data.decode(ChatEventDto.serializer()).chat)
            "download.deleted" -> LinkEvent.DownloadDeleted(seq, data.decode(ChatDeletedDto.serializer()).chatId)
            "bye" -> LinkEvent.Bye(seq, data.decode(ByeDto.serializer()).reason)
            "toolcall.delta" -> LinkEvent.ToolCallDelta(seq, data.decode(ToolCallDeltaDto.serializer()))
            "model.state" -> LinkEvent.ModelState(seq, data.decode(ModelStateDto.serializer()))
            "trace.phase" -> LinkEvent.TracePhase(seq, data.decode(TracePhaseDto.serializer()))
            "trace.context" -> LinkEvent.TraceContext(seq, data.decode(TraceContextDto.serializer()))
            "trace.gen" -> LinkEvent.TraceGen(seq, data.decode(TraceGenDto.serializer()))
            "trace.tool" -> LinkEvent.TraceTool(seq, data.decode(TraceToolDto.serializer()))
            "trace.runtime" -> LinkEvent.TraceRuntime(seq, data.decode(TraceRuntimeDto.serializer()))
            "trace.log" -> LinkEvent.TraceLog(seq, data.decode(TraceLogDto.serializer()))
            else -> null
        }
    }

    fun decodeReady(data: JsonObject): ReadyDto = WireJson.decodeFromJsonElement(ReadyDto.serializer(), data)

    private fun <T> JsonObject.decode(serializer: kotlinx.serialization.KSerializer<T>): T =
        WireJson.decodeFromJsonElement(serializer, this)
}
