package com.avek.chat.core.link.store

import com.avek.chat.core.link.crypto.SecureCrypto
import java.security.PrivateKey

/**
 * The device's long-term ECDSA P-256 identity keys (UI-WIRE v4 section 3), by alias. A key
 * replacement (section 4.1) keeps the old key alive until the new one has connected, so there can
 * be two at once. On Android the private keys live in the Keystore and never leave it.
 */
interface IdentityVault {
    fun exists(alias: String): Boolean

    /** Creates the key pair under [alias] if it does not exist yet. */
    fun create(alias: String)

    /** The 65-byte uncompressed public point `04 ‖ X ‖ Y`. */
    fun publicKey(alias: String): ByteArray

    /** ECDSA P-256 / SHA-256 signature (DER) of [message]. */
    fun sign(alias: String, message: ByteArray): ByteArray

    fun delete(alias: String)

    /** Every alias this vault holds (`avek.identity.<n>`). */
    fun aliases(): List<String>

    /** The next free alias: `avek.identity.<n>` with `n` counting up. */
    fun nextAlias(): String {
        val used = aliases().mapNotNull { it.removePrefix(ALIAS_PREFIX).toIntOrNull() }
        return ALIAS_PREFIX + ((used.maxOrNull() ?: 0) + 1)
    }

    companion object {
        const val ALIAS_PREFIX = "avek.identity."
    }
}

/** One key of the vault, as the handshakes use it. */
class DeviceKey(private val vault: IdentityVault, val alias: String) {
    fun publicKey(): ByteArray = vault.publicKey(alias)
    fun sign(message: ByteArray): ByteArray = vault.sign(alias, message)
}

class VaultException(message: String, cause: Throwable? = null) : Exception(message, cause)

/** Software keys (tests, the fake PC). [fixed] gives an alias a known scalar (test vectors). */
class SoftwareIdentityVault(fixed: Map<String, ByteArray> = emptyMap()) : IdentityVault {
    private val keys = LinkedHashMap<String, Pair<PrivateKey, ByteArray>>().apply {
        fixed.forEach { (alias, scalar) ->
            val key = SecureCrypto.privateKeyFromScalar(scalar)
            put(alias, key to SecureCrypto.publicKeyOf(key))
        }
    }

    @Synchronized override fun exists(alias: String) = alias in keys

    @Synchronized override fun create(alias: String) {
        if (alias in keys) return
        val pair = SecureCrypto.generateKeyPair()
        keys[alias] = pair.privateKey to pair.publicRaw
    }

    @Synchronized override fun publicKey(alias: String): ByteArray = keys[alias]?.second ?: throw VaultException("No identity key")

    @Synchronized override fun sign(alias: String, message: ByteArray): ByteArray =
        SecureCrypto.sign(keys[alias]?.first ?: throw VaultException("No identity key"), message)

    @Synchronized override fun delete(alias: String) {
        keys.remove(alias)
    }

    @Synchronized override fun aliases(): List<String> = keys.keys.toList()
}
