package com.avek.chat.core.link.store

import com.avek.chat.core.link.crypto.SecureCrypto
import java.security.PrivateKey

/**
 * The device's long-term ECDSA P-256 identity (UI-WIRE v3 section 3). On Android the private key
 * lives in the Keystore and never leaves it; only signatures and the public point come out.
 */
interface IdentityVault {
    fun exists(): Boolean

    /** Creates the key pair if it does not exist yet. */
    fun create()

    /** The 65-byte uncompressed public point `04 ‖ X ‖ Y`. */
    fun publicKey(): ByteArray

    /** ECDSA P-256 / SHA-256 signature (DER) of [message], which is hashed by the algorithm. */
    fun sign(message: ByteArray): ByteArray

    fun delete()
}

class VaultException(message: String, cause: Throwable? = null) : Exception(message, cause)

/** A software identity from a fixed 32-byte scalar (tests, the fake PC) or a fresh random one. */
class SoftwareIdentityVault(scalar: ByteArray? = null) : IdentityVault {
    private var key: PrivateKey? = scalar?.let(SecureCrypto::privateKeyFromScalar)
    private var pub: ByteArray? = key?.let(SecureCrypto::publicKeyOf)

    override fun exists() = key != null

    override fun create() {
        if (key != null) return
        val pair = SecureCrypto.generateKeyPair()
        key = pair.privateKey
        pub = pair.publicRaw
    }

    override fun publicKey(): ByteArray = pub ?: throw VaultException("No identity key")

    override fun sign(message: ByteArray): ByteArray = SecureCrypto.sign(key ?: throw VaultException("No identity key"), message)

    override fun delete() {
        key = null
        pub = null
    }
}
