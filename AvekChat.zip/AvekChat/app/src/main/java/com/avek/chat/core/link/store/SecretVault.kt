package com.avek.chat.core.link.store

/**
 * Encrypts small secrets at rest. The Android implementation uses a
 * non-exportable Android Keystore AES-GCM key; tests use an in-memory fake.
 */
interface SecretVault {
    fun encrypt(plain: ByteArray): ByteArray

    /** Throws [VaultException] when the key is gone or the data was tampered with. */
    fun decrypt(cipher: ByteArray): ByteArray
}

class VaultException(message: String, cause: Throwable? = null) : Exception(message, cause)
