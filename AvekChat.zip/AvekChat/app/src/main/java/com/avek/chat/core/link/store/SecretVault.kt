package com.avek.chat.core.link.store

import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * Seals small secrets (`dk`, `rk`, the stored routes) with an AES-256-GCM key. On Android the key
 * (`avek.seal`) is hardware-backed and never leaves the Keystore. Layout: 12-byte IV ‖ ciphertext ‖ tag.
 */
interface SecretVault {
    fun seal(plain: ByteArray): ByteArray
    fun open(sealed: ByteArray): ByteArray

    /** Deletes the sealing key (Forget this PC): everything sealed with it becomes unreadable. */
    fun destroy()
}

/** A JVM vault with an in-memory key (tests). */
class SoftwareSecretVault(private var key: SecretKey = SecretKeySpec(ByteArray(32).also(SecureRandom()::nextBytes), "AES")) : SecretVault {
    private val random = SecureRandom()

    override fun seal(plain: ByteArray): ByteArray = Seal.seal(key, plain, random)

    override fun open(sealed: ByteArray): ByteArray = Seal.open(key, sealed)

    override fun destroy() {
        key = SecretKeySpec(ByteArray(32).also(random::nextBytes), "AES")
    }
}

/** The AES-GCM layout shared by the Android and the JVM vault. */
object Seal {
    const val IV_BYTES = 12

    fun seal(key: SecretKey, plain: ByteArray, random: SecureRandom? = null): ByteArray {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        if (random != null) {
            val iv = ByteArray(IV_BYTES).also(random::nextBytes)
            cipher.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(128, iv))
            return iv + cipher.doFinal(plain)
        }
        // Keystore keys choose their own IV (randomized encryption is required by the Keystore).
        cipher.init(Cipher.ENCRYPT_MODE, key)
        return cipher.iv + cipher.doFinal(plain)
    }

    fun open(key: SecretKey, sealed: ByteArray): ByteArray {
        require(sealed.size > IV_BYTES + 16) { "Sealed data too short" }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, sealed.copyOfRange(0, IV_BYTES)))
        return cipher.doFinal(sealed, IV_BYTES, sealed.size - IV_BYTES)
    }
}

/** The device's two secrets made by the PC (section 3): `dk` mixed into every session, `rk` for the tunnel door. */
class DeviceSecrets(val dk: ByteArray, val rk: ByteArray) {
    init {
        require(dk.size == 32 && rk.size == 32) { "Secrets are 32 bytes" }
    }

    fun encode(): ByteArray = dk + rk

    /** Overwrites both secrets in memory. */
    fun wipe() {
        dk.fill(0)
        rk.fill(0)
    }

    override fun toString(): String = "DeviceSecrets(***)"

    companion object {
        fun decode(bytes: ByteArray): DeviceSecrets {
            require(bytes.size == 64) { "Bad secrets" }
            return DeviceSecrets(bytes.copyOfRange(0, 32), bytes.copyOfRange(32, 64))
        }
    }
}
