package com.avek.chat.feature.chat.thinking

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.avek.chat.core.designsystem.theme.AvekTheme
import com.avek.chat.core.designsystem.theme.avekShape
import com.avek.chat.core.domain.trace.TurnTelemetry
import com.avek.chat.feature.chat.thinking.panels.ContextBarPanel

/** Blue below 70 %, yellow from 70 %, red from 85 %. */
fun contextColor(fill: Float): Color = when {
    fill >= 0.85f -> Color(0xFFE53935)
    fill >= 0.70f -> Color(0xFFF2B705)
    else -> Color(0xFF2F7CF6)
}

/** How full the model's whole context window is (the full circle = the most it can hold). */
fun contextFillOf(t: TurnTelemetry?): Float? {
    val c = t?.context ?: return null
    val max = maxOf(c.windowMax, c.window)
    return if (max > 0) (c.promptTokens.toFloat() / max).coerceIn(0f, 1f) else null
}

/** The small ring between the mic and the send arrow. */
@Composable
fun ContextRing(fill: Float?, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val colors = AvekTheme.colors
    val animated by animateFloatAsState(fill ?: 0f, label = "context")
    val percent = ((fill ?: 0f) * 100).toInt()
    Box(
        modifier
            .size(36.dp)
            .clip(CircleShape)
            .clickable(onClick = onClick)
            .semantics { contentDescription = if (fill == null) "Context window: no data yet" else "Context window $percent percent full" },
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.size(20.dp)) {
            val stroke = 2.6.dp.toPx()
            drawCircle(colors.outline, radius = size.minDimension / 2 - stroke / 2, style = Stroke(stroke))
            if (fill != null && animated > 0f) {
                drawArc(contextColor(animated), -90f, 360f * animated, false, style = Stroke(stroke, cap = StrokeCap.Round))
            }
        }
    }
}

/** What opens when the ring is tapped: the context, tokens and speed of the latest turn. */
@Composable
fun ContextDetailsCard(t: TurnTelemetry?, modelName: String?, modifier: Modifier = Modifier) {
    val colors = AvekTheme.colors
    val fill = contextFillOf(t)
    Column(
        modifier
            .width(300.dp)
            .clip(avekShape(18.dp))
            .background(colors.surface)
            .border(1.dp, colors.outline.copy(alpha = 0.6f), avekShape(18.dp))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Context window", style = AvekTheme.type.title, color = colors.textPrimary, modifier = Modifier.weight(1f))
            if (fill != null) Text("${(fill * 100).toInt()}%", style = AvekTheme.type.title.copy(fontWeight = FontWeight.SemiBold), color = contextColor(fill))
        }
        val c = t?.context
        if (t == null || c == null) {
            Text("Send a prompt to see how full the context is.", style = AvekTheme.type.bodySmall, color = colors.textSecondary)
            return@Column
        }
        Text(
            "${ThinkingFormat.tokens(c.promptTokens)} of ${ThinkingFormat.tokens(maxOf(c.windowMax, c.window))} tokens · ${modelName ?: t.modelName}",
            style = AvekTheme.type.bodySmall, color = colors.textSecondary,
        )
        // The bar measures against the same total as the ring: the most the model can hold.
        ContextBarPanel(t.copy(context = c.copy(window = maxOf(c.windowMax, c.window))), compact = false)
        HorizontalDivider(color = colors.outline.copy(alpha = 0.4f))
        DetailRow("Speed", ThinkingFormat.tps(t.tps ?: t.latestGen?.tps))
        DetailRow("Average speed", ThinkingFormat.tps(t.avgTps))
        DetailRow("Time to first token", ThinkingFormat.ms(t.ttftMs))
        DetailRow("Reasoning tokens", if (t.steps.isEmpty()) ThinkingFormat.NONE else "${t.reasoningTokens}")
        DetailRow("Answer tokens", if (t.steps.isEmpty()) ThinkingFormat.NONE else "${t.answerTokens}")
        DetailRow("Tool-call tokens", if (t.steps.isEmpty()) ThinkingFormat.NONE else "${t.toolCallTokens}")
        DetailRow("Prompt / completion (turn)", "${ThinkingFormat.tokens(t.promptTokens)} / ${ThinkingFormat.tokens(t.completionTokens)}")
        DetailRow("Steps · tools", "${t.stepCount} · ${t.toolCount}")
        DetailRow("Counts", ThinkingFormat.exact(t.tokensExact))
    }
}

@Composable
private fun DetailRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth()) {
        Text(label, style = AvekTheme.type.bodySmall, color = AvekTheme.colors.textSecondary, modifier = Modifier.weight(1f))
        Spacer(Modifier.width(8.dp))
        Text(value, style = AvekTheme.type.bodySmall.copy(fontWeight = FontWeight.Medium), color = AvekTheme.colors.textPrimary)
    }
}

/** Space helper. */
@Composable
internal fun RingGap() = Spacer(Modifier.height(4.dp))
