package com.avek.chat.core.data.lock

import com.avek.chat.core.domain.lock.LockCounter
import com.avek.chat.core.domain.lock.LockStore
import com.avek.chat.core.domain.lock.PasswordRecord
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import java.io.File
import java.util.Base64

/**
 * The app lock on disk: `password.json` (salt, PBKDF2 hash, iterations: never the password) and
 * `counter.json` (wrong tries and the lockout). The directory is excluded from backups. A file that
 * exists but cannot be parsed throws, so the lock treats it as unreadable (locked), never as reset.
 */
class FileLockStore(private val dir: File) : LockStore {

    @Serializable
    private class StoredPassword(val salt: String, val hash: String, val iterations: Int)

    @Serializable
    private class StoredCounter(
        val failures: Int,
        val lockouts: Int,
        val lockStartElapsed: Long? = null,
        val lockDurationMs: Long = 0,
        val bootCount: Int = 0,
    )

    private val json = Json { ignoreUnknownKeys = true }
    private val passwordFile get() = File(dir, "password.json")
    private val counterFile get() = File(dir, "counter.json")

    @Synchronized
    override fun readPassword(): PasswordRecord? {
        if (!passwordFile.exists()) return null
        val stored = json.decodeFromString(StoredPassword.serializer(), passwordFile.readText())
        val salt = Base64.getDecoder().decode(stored.salt)
        val hash = Base64.getDecoder().decode(stored.hash)
        require(salt.size == 16 && hash.size == 32 && stored.iterations > 0) { "Bad password record" }
        return PasswordRecord(salt, hash, stored.iterations)
    }

    @Synchronized
    override fun writePassword(record: PasswordRecord) {
        val enc = Base64.getEncoder()
        write(passwordFile, json.encodeToString(StoredPassword.serializer(), StoredPassword(enc.encodeToString(record.salt), enc.encodeToString(record.hash), record.iterations)))
    }

    @Synchronized
    override fun readCounter(): LockCounter? {
        if (!counterFile.exists()) return null
        val s = json.decodeFromString(StoredCounter.serializer(), counterFile.readText())
        return LockCounter(s.failures, s.lockouts, s.lockStartElapsed, s.lockDurationMs, s.bootCount)
    }

    @Synchronized
    override fun writeCounter(counter: LockCounter) {
        write(
            counterFile,
            json.encodeToString(
                StoredCounter.serializer(),
                StoredCounter(counter.failures, counter.lockouts, counter.lockStartElapsed, counter.lockDurationMs, counter.bootCount),
            ),
        )
    }

    @Synchronized
    override fun clear() {
        passwordFile.delete()
        counterFile.delete()
    }

    private fun write(file: File, text: String) {
        dir.mkdirs()
        val temp = File(dir, file.name + ".tmp")
        temp.writeText(text)
        if (!temp.renameTo(file)) {
            file.delete()
            check(temp.renameTo(file)) { "Could not write ${file.name}" }
        }
    }
}
