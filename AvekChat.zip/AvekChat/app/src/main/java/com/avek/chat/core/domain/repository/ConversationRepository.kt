package com.avek.chat.core.domain.repository

import com.avek.chat.core.model.Conversation
import com.avek.chat.core.model.Feedback
import com.avek.chat.core.model.Message
import com.avek.chat.core.model.TaskMode
import kotlinx.coroutines.flow.Flow

/** Single source of truth for conversations and their messages. */
interface ConversationRepository {
    fun observeConversations(): Flow<List<Conversation>>
    fun observeArchived(): Flow<List<Conversation>>
    fun search(query: String): Flow<List<Conversation>>
    fun observeConversation(id: String): Flow<Conversation?>
    fun observeMessages(conversationId: String): Flow<List<Message>>

    suspend fun getConversation(id: String): Conversation?
    suspend fun getMessages(conversationId: String): List<Message>

    suspend fun createConversation(title: String, modelId: String, taskMode: TaskMode): Conversation
    suspend fun upsertMessage(message: Message)
    suspend fun deleteMessagesFrom(conversationId: String, fromCreatedAt: Long)
    suspend fun setFeedback(messageId: String, feedback: Feedback)

    /** Refreshes denormalised fields (preview, counts, timestamps) after a change. */
    suspend fun refreshSummary(conversationId: String, modelId: String, taskMode: TaskMode)

    suspend fun rename(id: String, title: String)
    suspend fun setStarred(id: String, starred: Boolean)
    suspend fun setArchived(id: String, archived: Boolean)
    suspend fun delete(id: String)
    suspend fun deleteAll()

    /** Marks replies that were mid-stream when the process died as stopped. */
    suspend fun recoverInterruptedReplies()

    /** Bulk import used by the demo seeder. */
    suspend fun insertAll(conversations: List<Conversation>, messages: List<Message>)
}
