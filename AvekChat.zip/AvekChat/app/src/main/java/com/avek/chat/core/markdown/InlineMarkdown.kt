package com.avek.chat.core.markdown

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.LinkAnnotation
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLinkStyles
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.withLink
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.em

/** Colours and fonts used for inline spans. */
data class InlineStyles(
    val codeFamily: FontFamily?,
    val codeBackground: Color,
    val codeColor: Color,
    val link: Color,
    val citation: Color,
)

/**
 * Converts inline Markdown (`**bold**`, `*italic*`, `` `code` ``, `~~strike~~`,
 * `[link](url)` and `[1]` citations) into an [AnnotatedString].
 */
object InlineMarkdown {

    fun render(text: String, styles: InlineStyles): AnnotatedString = buildAnnotatedString {
        var i = 0
        val n = text.length
        while (i < n) {
            val c = text[i]
            when {
                text.startsWith("**", i) || text.startsWith("__", i) -> {
                    val marker = text.substring(i, i + 2)
                    val end = text.indexOf(marker, i + 2)
                    if (end > i + 2) {
                        withStyle(SpanStyle(fontWeight = FontWeight.SemiBold)) {
                            append(render(text.substring(i + 2, end), styles))
                        }
                        i = end + 2
                    } else {
                        // Unclosed while streaming: render the rest bold without markers.
                        withStyle(SpanStyle(fontWeight = FontWeight.SemiBold)) { append(text.substring(i + 2)) }
                        i = n
                    }
                }
                text.startsWith("~~", i) -> {
                    val end = text.indexOf("~~", i + 2)
                    if (end > i + 2) {
                        withStyle(SpanStyle(textDecoration = TextDecoration.LineThrough)) { append(render(text.substring(i + 2, end), styles)) }
                        i = end + 2
                    } else {
                        append(c)
                        i++
                    }
                }
                c == '`' -> {
                    val end = text.indexOf('`', i + 1)
                    val code = if (end > i) text.substring(i + 1, end) else text.substring(i + 1)
                    withStyle(
                        SpanStyle(
                            fontFamily = styles.codeFamily,
                            background = styles.codeBackground,
                            color = styles.codeColor,
                            fontSize = 0.9.em,
                        ),
                    ) { append(" $code ") }
                    i = if (end > i) end + 1 else n
                }
                (c == '*' || c == '_') && i + 1 < n && !text[i + 1].isWhitespace() && (i == 0 || !text[i - 1].isLetterOrDigit()) -> {
                    val end = text.indexOf(c, i + 1)
                    if (end > i + 1 && !text[end - 1].isWhitespace()) {
                        withStyle(SpanStyle(fontStyle = FontStyle.Italic)) { append(render(text.substring(i + 1, end), styles)) }
                        i = end + 1
                    } else {
                        append(c)
                        i++
                    }
                }
                c == '[' -> {
                    val close = text.indexOf(']', i + 1)
                    val label = if (close > i) text.substring(i + 1, close) else null
                    when {
                        label != null && close + 1 < n && text[close + 1] == '(' && text.indexOf(')', close + 2) > 0 -> {
                            val urlEnd = text.indexOf(')', close + 2)
                            val url = text.substring(close + 2, urlEnd)
                            withLink(LinkAnnotation.Url(url, TextLinkStyles(SpanStyle(color = styles.link, textDecoration = TextDecoration.Underline)))) {
                                append(label)
                            }
                            i = urlEnd + 1
                        }
                        label != null && label.isNotEmpty() && label.all { it.isDigit() } -> {
                            withStyle(
                                SpanStyle(
                                    color = styles.citation,
                                    fontSize = 0.75.em,
                                    fontWeight = FontWeight.SemiBold,
                                ),
                            ) { append(" [$label]") }
                            i = close + 1
                        }
                        else -> {
                            append(c)
                            i++
                        }
                    }
                }
                else -> {
                    append(c)
                    i++
                }
            }
        }
    }

    /** Plain text with all inline markers removed (for copy / share). */
    fun strip(text: String): String = text
        .replace(Regex("\\*\\*|__|~~|`"), "")
        .replace(Regex("\\[([^\\]]+)]\\(([^)]+)\\)"), "$1")
}
