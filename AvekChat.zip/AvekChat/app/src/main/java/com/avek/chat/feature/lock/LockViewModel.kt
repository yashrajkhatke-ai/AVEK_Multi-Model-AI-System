package com.avek.chat.feature.lock

import androidx.compose.runtime.Immutable
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.avek.chat.core.domain.lock.AppLockManager
import com.avek.chat.core.domain.lock.LockState
import com.avek.chat.core.domain.lock.PasswordCheck
import com.avek.chat.core.domain.repository.SettingsRepository
import com.avek.chat.core.link.PcControl
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import javax.inject.Inject

@Immutable
data class LockUi(
    val lock: LockState = LockState.Locked(biometricPassed = false),
    /** The first-launch pairing (or "Later") is done: the password can be set. */
    val onboardingDone: Boolean = false,
    /** Hashing in progress (PBKDF2 takes a moment). */
    val busy: Boolean = false,
    val error: String? = null,
    /** Remaining lockout after too many wrong passwords (0 = none). */
    val lockoutMs: Long = 0,
)

/**
 * The app lock screens (UI-WIRE v4 section 13, "App lock"): create the password, the phone's
 * fingerprint/PIN, then the app password; "Forget this PC and start over" is the only way out.
 * Passwords arrive as CharArrays and are wiped by [AppLockManager].
 */
@HiltViewModel
class LockViewModel @Inject constructor(
    private val lock: AppLockManager,
    private val settings: SettingsRepository,
    private val control: PcControl,
) : ViewModel() {

    private val local = MutableStateFlow(LockUi())

    val state: StateFlow<LockUi> = combine(lock.state, settings.settings.map { it.connection.onboardingDone }, local) { lockState, onboarding, l ->
        l.copy(lock = lockState, onboardingDone = onboarding)
    }.stateIn(viewModelScope, SharingStarted.Eagerly, LockUi(lock = lock.state.value))

    init {
        // A lockout counts down on screen.
        viewModelScope.launch {
            while (isActive) {
                val s = lock.state.value
                val remaining = if (s is LockState.Locked && s.biometricPassed) lock.lockoutRemainingMs() else 0L
                if (remaining != local.value.lockoutMs) local.update { it.copy(lockoutMs = remaining) }
                delay(if (remaining > 0) 1_000 else 2_000)
            }
        }
    }

    fun onBiometricPassed() = lock.onBiometricPassed()

    fun createPassword(first: CharArray, second: CharArray) {
        local.update { it.copy(busy = true, error = null) }
        viewModelScope.launch {
            val error = lock.createPassword(first, second)
            local.update { it.copy(busy = false, error = error) }
        }
    }

    fun unlock(password: CharArray) {
        local.update { it.copy(busy = true, error = null) }
        viewModelScope.launch {
            val error = when (val result = lock.checkPassword(password)) {
                PasswordCheck.Correct -> null
                is PasswordCheck.Wrong -> if (result.triesLeft <= 3) "Wrong password. ${result.triesLeft} tries before a pause." else "Wrong password."
                is PasswordCheck.LockedOut -> null
            }
            local.update { it.copy(busy = false, error = error, lockoutMs = lock.lockoutRemainingMs().takeIf { lock.state.value != LockState.Unlocked } ?: 0) }
        }
    }

    fun clearError() = local.update { it.copy(error = null) }

    /** No password recovery by design: forget the PC, the password, and start again with pairing. */
    fun forgetAndStartOver() {
        local.update { it.copy(busy = true, error = null) }
        viewModelScope.launch {
            runCatching { control.forget() }
            lock.reset()
            settings.update { it.copy(connection = it.connection.copy(onboardingDone = false, demoMode = false)) }
            local.update { LockUi() }
        }
    }
}
