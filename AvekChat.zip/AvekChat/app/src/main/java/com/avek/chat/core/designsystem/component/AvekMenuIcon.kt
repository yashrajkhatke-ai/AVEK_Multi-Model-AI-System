package com.avek.chat.core.designsystem.component

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp

/** The Avek menu glyph: two full-width lines and a shorter third line, left-aligned. */
@Composable
fun AvekMenuIcon(color: Color, modifier: Modifier = Modifier, contentDescription: String? = null) {
    Canvas(
        modifier
            .size(24.dp)
            .then(if (contentDescription != null) Modifier.semantics { this.contentDescription = contentDescription } else Modifier),
    ) {
        val stroke = 2.dp.toPx()
        val left = size.width * 0.12f
        val right = size.width * 0.88f
        val ys = listOf(0.3f, 0.5f, 0.7f).map { it * size.height }
        ys.forEachIndexed { i, y ->
            val end = if (i == 2) left + (right - left) * 0.5f else right
            drawLine(color, Offset(left, y), Offset(end, y), strokeWidth = stroke, cap = StrokeCap.Round)
        }
    }
}
