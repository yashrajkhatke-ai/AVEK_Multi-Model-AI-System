package com.avek.chat.feature.chat.components

import androidx.compose.animation.AnimatedContent
import com.avek.chat.core.designsystem.theme.avekShape
import com.avek.chat.core.designsystem.theme.avekPill
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.ErrorOutline
import androidx.compose.material.icons.outlined.HelpOutline
import androidx.compose.material.icons.outlined.KeyboardArrowDown
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material.icons.outlined.StopCircle
import androidx.compose.material.icons.outlined.ThumbDown
import androidx.compose.material.icons.outlined.ThumbUp
import androidx.compose.material.icons.filled.ThumbDown
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.avek.chat.core.common.TimeFormat
import com.avek.chat.core.designsystem.component.AvekSpark
import com.avek.chat.core.designsystem.icon.icon
import com.avek.chat.core.designsystem.motion.StreamingCursor
import com.avek.chat.core.designsystem.motion.rememberPhase
import com.avek.chat.core.designsystem.theme.AvekTheme
import com.avek.chat.core.domain.chat.ReplyPhase
import com.avek.chat.core.domain.chat.StreamingReply
import com.avek.chat.core.model.ToolCall
import com.avek.chat.feature.chat.ToolViewState
import com.avek.chat.core.markdown.MarkdownContent
import com.avek.chat.core.model.Feedback
import com.avek.chat.core.model.Message
import com.avek.chat.core.model.MessageStatus
import com.avek.chat.core.model.SourceRef
import com.avek.chat.core.model.ThinkingDepth
import com.avek.chat.core.model.settings.AssistantStyle
import kotlinx.coroutines.delay

/** Callbacks for message-level actions, grouped to keep signatures readable. */
data class MessageActions(
    val onCopy: (String) -> Unit,
    val onShare: (String) -> Unit,
    val onRegenerate: (Message) -> Unit,
    val onFeedback: (Message, Feedback) -> Unit,
    val onEdit: (Message, String) -> Unit,
    val onLoadThinking: (Message) -> Unit = {},
    val onLoadTool: (Message, ToolCall) -> Unit = { _, _ -> },
)

@Composable
fun AssistantMessage(
    message: Message,
    modelName: String?,
    live: StreamingReply?,
    isLast: Boolean,
    actions: MessageActions,
    toolViews: Map<String, ToolViewState> = emptyMap(),
    thinkingLoading: Boolean = false,
    modifier: Modifier = Modifier,
) {
    val colors = AvekTheme.colors
    val layout = AvekTheme.layout
    val motion = AvekTheme.motion
    val density = layout.density.scale
    val phase = live?.phase ?: ReplyPhase.DONE
    val streaming = message.status == MessageStatus.STREAMING || message.status == MessageStatus.WAITING

    val container: Modifier = when (layout.assistantStyle) {
        AssistantStyle.PLAIN -> Modifier
        AssistantStyle.CARD -> Modifier
            .clip(avekShape(layout.bubbleCornerDp.dp, layout.bubbleCornerDp.dp, layout.bubbleCornerDp.dp, layout.bubbleCornerDp.dp, scaled = false))
            .background(colors.assistantBubble)
            .border(1.dp, colors.outline.copy(alpha = 0.7f), avekShape(layout.bubbleCornerDp.dp, layout.bubbleCornerDp.dp, layout.bubbleCornerDp.dp, layout.bubbleCornerDp.dp, scaled = false))
            .padding(16.dp)
        AssistantStyle.BUBBLE -> Modifier
            .clip(avekShape(topStart = 6.dp, topEnd = layout.bubbleCornerDp.dp, bottomEnd = layout.bubbleCornerDp.dp, bottomStart = layout.bubbleCornerDp.dp, scaled = false))
            .background(colors.assistantBubble)
            .padding(horizontal = 16.dp, vertical = 12.dp)
    }

    Column(modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = (6 * density).dp)) {
        if (layout.showAvatars || layout.showModelBadge) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 8.dp)) {
                if (layout.showAvatars) {
                    AvekSpark(colors.thinkingGlow, Modifier.size(20.dp), animated = streaming && !motion.reduceMotion)
                    Spacer(Modifier.width(8.dp))
                }
                if (layout.showModelBadge) {
                    MetaLabel(modelName ?: "Avek", colors.textPrimary)
                    val resolved = message.resolvedTask
                    if (resolved != null) {
                        Spacer(Modifier.width(6.dp))
                        MetaLabel("·", colors.textTertiary)
                        Spacer(Modifier.width(6.dp))
                        Icon(resolved.icon, null, tint = colors.textSecondary, modifier = Modifier.size(13.dp))
                        Spacer(Modifier.width(4.dp))
                        MetaLabel(if (message.requestedTask.isAuto) "Auto → ${resolved.label}" else resolved.label)
                    }
                }
                if (layout.showTimestamps) {
                    Spacer(Modifier.weight(1f))
                    MetaLabel(TimeFormat.clock(message.createdAt), colors.textTertiary)
                }
            }
        }

        Column(if (streaming) container else container.animateContentSize()) {
            // Plain timeline: thinking stretches and tool calls, each opening into a card.
            val env = com.avek.chat.feature.chat.thinking.LocalThinkingEnvironment.current
            val telemetryFlow = androidx.compose.runtime.remember(env, message.conversationId, message.promptId, streaming) {
                message.promptId?.let { env?.telemetry(message.conversationId, it, fetch = streaming) }
            }
            val telemetry = telemetryFlow?.collectAsState()?.value
            if (env != null && streaming) {
                androidx.compose.runtime.DisposableEffect(env, message.promptId) {
                    val release = env.viewing()
                    onDispose(release)
                }
            }
            val timeline = com.avek.chat.feature.chat.thinking.TimelineBuilder.build(
                thinking = message.thinking,
                tools = message.tools,
                t = telemetry,
                thinkingActive = streaming && phase == ReplyPhase.THINKING,
                streaming = streaming,
            )
            if (timeline.isNotEmpty()) {
                if (message.hasThinking && message.thinking == null && !streaming) {
                    androidx.compose.runtime.LaunchedEffect(message.id) { actions.onLoadThinking(message) }
                }
                com.avek.chat.feature.chat.thinking.TurnTimeline(timeline)
                Spacer(Modifier.height(10.dp))
            } else if (streaming && live?.activity != null) {
                ActivityLine(live.activity)
                Spacer(Modifier.height(12.dp))
            }

            if (message.sources.isNotEmpty()) {
                SourcesRow(message.sources)
                Spacer(Modifier.height(12.dp))
            }

            if (message.content.isNotEmpty() || (streaming && phase == ReplyPhase.ANSWERING)) {
                MarkdownContent(
                    markdown = message.content,
                    textStyle = AvekTheme.type.answer,
                    color = colors.assistantText,
                    onCopyCode = actions.onCopy,
                    showLineNumbers = layout.codeLineNumbers,
                    trailing = if (streaming && phase == ReplyPhase.ANSWERING) {
                        { StreamingCursor(motion.cursor, colors.thinkingGlow) }
                    } else {
                        null
                    },
                )
            }

            when (message.status) {
                MessageStatus.STOPPED -> StatusNote(Icons.Outlined.StopCircle, "Stopped", colors.textSecondary)
                MessageStatus.ERROR -> StatusNote(Icons.Outlined.ErrorOutline, message.error ?: "Something went wrong. Try regenerating.", colors.danger)
                MessageStatus.WAITING -> StatusNote(Icons.Outlined.HelpOutline, "Waiting for your answer", colors.textSecondary)
                else -> Unit
            }
        }

        AnimatedVisibility(visible = !streaming, enter = fadeIn(), exit = fadeOut()) {
            ActionRow(message, isLast, actions)
        }
    }
}

/** What the PC is doing right now when there is no reasoning panel ("Loading Ornith…", a tool title). */
@Composable
private fun ActivityLine(text: String) {
    ShimmerText("$text…", AvekTheme.colors.textSecondary, AvekTheme.colors.thinkingGlow)
}

@Composable
private fun StatusNote(icon: ImageVector, text: String, color: Color) {
    Row(Modifier.padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = color, modifier = Modifier.size(15.dp))
        Spacer(Modifier.width(6.dp))
        Text(text, style = AvekTheme.type.caption, color = color)
    }
}

/** Text with a highlight sweeping across it. */
@Composable
fun ShimmerText(text: String, base: Color, highlight: Color) {
    val phase = rememberPhase(1800, animate = !AvekTheme.motion.reduceMotion, label = "shimmer")
    Text(
        text,
        style = AvekTheme.type.label,
        color = base,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        modifier = Modifier
            .graphicsLayer(compositingStrategy = CompositingStrategy.Offscreen)
            .drawWithContent {
                drawContent()
                val x = (-0.5f + 2f * phase.value) * size.width
                drawRect(
                    Brush.linearGradient(
                        listOf(Color.Transparent, highlight, Color.Transparent),
                        start = androidx.compose.ui.geometry.Offset(x - size.width * 0.3f, 0f),
                        end = androidx.compose.ui.geometry.Offset(x + size.width * 0.3f, 0f),
                    ),
                    blendMode = BlendMode.SrcAtop,
                )
            },
    )
}

@Composable
private fun SourcesRow(sources: List<SourceRef>) {
    val colors = AvekTheme.colors
    Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
            MetaLabel("${sources.size} sources")
        }
        Spacer(Modifier.height(8.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            itemsIndexed(sources, key = { i, s -> "$i-${s.title}" }) { index, source ->
                Surface(
                    shape = avekShape(14.dp),
                    color = colors.surface,
                    border = BorderStroke(1.dp, colors.outline.copy(alpha = 0.7f)),
                    modifier = Modifier.width(210.dp),
                ) {
                    Column(Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                Modifier
                                    .size(18.dp)
                                    .clip(CircleShape)
                                    .background(colors.accentContainer),
                                contentAlignment = Alignment.Center,
                            ) {
                                Text("${index + 1}", style = AvekTheme.type.caption, color = colors.accent)
                            }
                            Spacer(Modifier.width(6.dp))
                            Text(source.domain, style = AvekTheme.type.caption, color = colors.textTertiary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        Spacer(Modifier.height(6.dp))
                        Text(source.title, style = AvekTheme.type.bodySmall.copy(fontWeight = FontWeight.Medium), color = colors.textPrimary, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        }
    }
}

@Composable
private fun ActionRow(message: Message, isLast: Boolean, actions: MessageActions) {
    val colors = AvekTheme.colors
    Row(
        Modifier.padding(top = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(2.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        ActionIcon(Icons.Outlined.ContentCopy, "Copy") { actions.onCopy(message.content) }
        if (isLast) ActionIcon(Icons.Outlined.Refresh, "Regenerate") { actions.onRegenerate(message) }
        ActionIcon(
            if (message.feedback == Feedback.POSITIVE) Icons.Filled.ThumbUp else Icons.Outlined.ThumbUp,
            "Good response",
            tint = if (message.feedback == Feedback.POSITIVE) colors.accent else colors.textTertiary,
        ) { actions.onFeedback(message, Feedback.POSITIVE) }
        ActionIcon(
            if (message.feedback == Feedback.NEGATIVE) Icons.Filled.ThumbDown else Icons.Outlined.ThumbDown,
            "Bad response",
            tint = if (message.feedback == Feedback.NEGATIVE) colors.accent else colors.textTertiary,
        ) { actions.onFeedback(message, Feedback.NEGATIVE) }
        ActionIcon(Icons.Outlined.Share, "Share") { actions.onShare(message.content) }
    }
}

@Composable
internal fun ActionIcon(
    icon: ImageVector,
    description: String,
    tint: Color = AvekTheme.colors.textTertiary,
    onClick: () -> Unit,
) {
    Box(
        Modifier
            .size(34.dp)
            .clip(CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, contentDescription = description, tint = tint, modifier = Modifier.size(17.dp))
    }
}
