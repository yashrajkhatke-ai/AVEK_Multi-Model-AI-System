package com.avek.chat.feature.chat.profiles

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.avek.chat.core.designsystem.theme.AvekTheme
import com.avek.chat.core.designsystem.theme.avekShape
import com.avek.chat.core.link.wire.HardwareData
import com.avek.chat.core.link.wire.LoadProfileDto
import java.util.Locale

/** The colours of the three processors (the words are always written too: colour is never the only signal). */
object ProcessorColors {
    val rtx = Color(0xFF76B900)
    val igpu = Color(0xFFE5732D)
    val cpu = Color(0xFF5B8DEF)
}

/** Opens the sheet for [modelId] (the model in the chip) with its own view model. */
@Composable
fun LoadProfilesRoute(modelId: String, modelName: String, onDismiss: () -> Unit, viewModel: LoadProfilesViewModel = hiltViewModel()) {
    LaunchedEffect(modelId) { viewModel.open(modelId, modelName) }
    val state by viewModel.state.collectAsStateWithLifecycle()
    LoadProfilesSheet(
        state = state,
        actions = ProfilesActions(
            onRefresh = viewModel::refresh,
            onUse = { viewModel.use(it) },
            onConfirmTooBig = { viewModel.use(it, force = true) },
            onDismissTooBig = viewModel::dismissTooBig,
            onCopy = viewModel::copy,
            onEdit = viewModel::edit,
            onDelete = viewModel::delete,
            onNew = viewModel::newProfile,
            editor = EditorActions(
                onName = viewModel::setName,
                onRtx = viewModel::setRtx,
                onIgpu = viewModel::setIgpu,
                onPreset = viewModel::applyPreset,
                onContext = viewModel::setContext,
                onSlots = viewModel::setSlots,
                onCacheType = viewModel::setCacheType,
                onNote = viewModel::setNote,
                onSave = viewModel::save,
                onCancel = viewModel::cancelEditing,
            ),
        ),
        onDismiss = onDismiss,
    )
}

class ProfilesActions(
    val onRefresh: () -> Unit,
    val onUse: (LoadProfileDto) -> Unit,
    val onConfirmTooBig: (LoadProfileDto) -> Unit,
    val onDismissTooBig: () -> Unit,
    val onCopy: (LoadProfileDto) -> Unit,
    val onEdit: (LoadProfileDto) -> Unit,
    val onDelete: (LoadProfileDto) -> Unit,
    val onNew: () -> Unit,
    val editor: EditorActions,
)

@Composable
fun LoadProfilesSheet(state: ProfilesUi, actions: ProfilesActions, onDismiss: () -> Unit) {
    val colors = AvekTheme.colors
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = colors.chatBackground,
        scrimColor = colors.scrim,
    ) {
        val phase = state.phase
        if (phase is ProfilesPhase.Editing) {
            ProfileEditorScreen(phase.draft, state.connected, actions.editor)
        } else {
            LoadProfilesContent(state, actions)
        }
    }
}

/** The body of the sheet (also rendered on its own in previews). */
@Composable
fun LoadProfilesContent(state: ProfilesUi, actions: ProfilesActions) {
    val colors = AvekTheme.colors
    var confirmDelete by remember { mutableStateOf<LoadProfileDto?>(null) }
    Column(
        Modifier
            .fillMaxWidth()
            .heightIn(max = 720.dp)
            .verticalScroll(rememberScrollState())
            .padding(start = 20.dp, end = 20.dp, bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Where it runs", style = AvekTheme.type.headline, color = colors.textPrimary)
                Text(state.modelName, style = AvekTheme.type.bodySmall, color = colors.textSecondary)
            }
            IconButton(onClick = actions.onRefresh, enabled = state.connected) { Icon(Icons.Outlined.Refresh, "Refresh", tint = colors.textSecondary) }
        }
        if (!state.connected) Text("Not connected", style = AvekTheme.type.bodySmall, color = colors.danger)
        HardwareLine(state.hardware ?: state.data?.hardware)
        Text(
            "The integrated GPU shares your PC's memory with the CPU, so using it can make the desktop stutter.",
            style = AvekTheme.type.caption,
            color = colors.textTertiary,
        )
        when (val phase = state.phase) {
            is ProfilesPhase.Applying -> Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(phase.text, style = AvekTheme.type.bodySmall, color = colors.textPrimary)
                LinearProgressIndicator(Modifier.fillMaxWidth(), color = colors.accent, trackColor = colors.outline.copy(alpha = 0.4f))
            }
            is ProfilesPhase.Error -> Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(phase.message, style = AvekTheme.type.bodySmall, color = colors.danger)
                TextButton(onClick = actions.onRefresh, enabled = state.connected) { Text("Try again", color = colors.accent) }
            }
            else -> Unit
        }
        state.message?.let { Text(it, style = AvekTheme.type.bodySmall, color = colors.danger) }

        val data = state.data
        if (data == null && state.phase == ProfilesPhase.Loading) {
            repeat(2) { SkeletonCard() }
        }
        if (data != null) {
            val ordered = data.profiles.filter { it.builtin } + data.profiles.filterNot { it.builtin }
            val busy = state.phase is ProfilesPhase.Applying
            Column(Modifier.alpha(if (state.connected) 1f else 0.5f), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                ordered.forEach { profile ->
                    ProfileCard(
                        profile = profile,
                        total = data.layersTotal,
                        active = profile.id == data.activeId || profile.active,
                        enabled = state.connected && !busy,
                        onUse = { actions.onUse(profile) },
                        onCopy = { actions.onCopy(profile) },
                        onEdit = { actions.onEdit(profile) },
                        onDelete = { confirmDelete = profile },
                    )
                }
                OutlinedButton(onClick = actions.onNew, enabled = state.connected && !busy, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Outlined.Add, null, tint = colors.textPrimary, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("New profile", color = colors.textPrimary)
                }
            }
        }
    }

    state.confirmTooBig?.let { id ->
        val profile = state.data?.profiles?.firstOrNull { it.id == id }
        if (profile != null) {
            AlertDialog(
                onDismissRequest = actions.onDismissTooBig,
                containerColor = colors.surface,
                title = { Text("Use ${profile.name}?", color = colors.textPrimary) },
                text = { Text("This probably does not fit in memory. Use it anyway?", color = colors.textSecondary) },
                confirmButton = { TextButton(onClick = { actions.onConfirmTooBig(profile) }) { Text("Use anyway", color = colors.danger) } },
                dismissButton = { TextButton(onClick = actions.onDismissTooBig) { Text("Cancel", color = colors.textSecondary) } },
            )
        }
    }
    confirmDelete?.let { profile ->
        AlertDialog(
            onDismissRequest = { confirmDelete = null },
            containerColor = colors.surface,
            title = { Text("Delete ${profile.name}?", color = colors.textPrimary) },
            text = { Text("The profile is removed from your PC. If it is the active one, the model's default becomes active again.", color = colors.textSecondary) },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = null
                    actions.onDelete(profile)
                }) { Text("Delete", color = colors.danger) }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = null }) { Text("Cancel", color = colors.textSecondary) } },
        )
    }
}

/** "RTX 5060 · 6.9 GB free  |  Radeon 780M (uses system memory)  |  RAM 7.0 GB free"; absent processors are hidden. */
@Composable
private fun HardwareLine(hardware: HardwareData?) {
    val colors = AvekTheme.colors
    val text = hardwareSummary(hardware) ?: "-"
    Text(text, style = AvekTheme.type.bodySmall, color = colors.textSecondary)
}

fun hardwareSummary(hardware: HardwareData?): String? {
    if (hardware == null) return null
    return buildList {
        hardware.rtx?.let { add("${it.name.ifBlank { "RTX" }} · ${gb(it.freeMb)} free") }
        hardware.igpu?.let { add("${it.name.ifBlank { "iGPU" }} (uses system memory)") }
        add("RAM ${gb(hardware.cpu.ramFreeMb)} free")
    }.joinToString("  |  ")
}

private fun gb(mb: Long): String = String.format(Locale.US, "%.1f GB", mb / 1024.0)

@Composable
private fun SkeletonCard() {
    val colors = AvekTheme.colors
    Column(
        Modifier
            .fillMaxWidth()
            .clip(avekShape(16.dp))
            .background(colors.surface)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Box(Modifier.width(120.dp).height(14.dp).clip(avekShape(6.dp)).background(colors.outline.copy(alpha = 0.4f)))
        Box(Modifier.fillMaxWidth().height(10.dp).clip(avekShape(5.dp)).background(colors.outline.copy(alpha = 0.3f)))
        Box(Modifier.width(180.dp).height(10.dp).clip(avekShape(5.dp)).background(colors.outline.copy(alpha = 0.3f)))
    }
}

/** One profile: name, the three-colour bar, numbers, context, the PC's estimate verdict, speed, Active, actions. */
@Composable
fun ProfileCard(
    profile: LoadProfileDto,
    total: Int,
    active: Boolean,
    enabled: Boolean,
    onUse: () -> Unit,
    onCopy: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
) {
    val colors = AvekTheme.colors
    val layers = profile.toLayers()
    Column(
        Modifier
            .fillMaxWidth()
            .clip(avekShape(16.dp))
            .background(colors.surface)
            .border(if (active) 1.5.dp else 1.dp, if (active) colors.accent else colors.outline.copy(alpha = 0.6f), avekShape(16.dp))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(profile.name, style = AvekTheme.type.title, color = colors.textPrimary, modifier = Modifier.weight(1f))
            if (profile.builtin) Badge("Built-in", colors.textSecondary, colors.outline.copy(alpha = 0.3f))
            if (active) {
                Spacer(Modifier.width(6.dp))
                Badge("Active", colors.accent, colors.accentContainer)
            }
        }
        LayerBar(layers, total)
        Text(LayerPlan.numbers(layers), style = AvekTheme.type.bodySmall, color = colors.textPrimary)
        Text(
            buildString {
                append(LayerPlan.contextK(profile.contextTokens)).append(" context · ")
                append(profile.slots).append(if (profile.slots == 1) " slot" else " slots")
                profile.cacheType?.let { append(" · ").append(it).append(" cache") }
            },
            style = AvekTheme.type.caption,
            color = colors.textSecondary,
        )
        EstimateChip(profile.estimate?.verdict ?: "unknown")
        profile.estimate?.notes?.firstOrNull()?.let { Text(it, style = AvekTheme.type.caption, color = colors.textSecondary) }
        profile.measured?.decodeTps?.let { Text(String.format(Locale.US, "%.1f tok/s measured", it), style = AvekTheme.type.caption, color = colors.textSecondary) }
        profile.note?.takeIf { it.isNotBlank() }?.let { Text(it, style = AvekTheme.type.caption, color = colors.textTertiary) }
        profile.problems.firstOrNull()?.let { Text(it, style = AvekTheme.type.caption, color = colors.danger) }
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
            Button(
                onClick = onUse,
                enabled = enabled && !active && profile.problems.isEmpty(),
                colors = ButtonDefaults.buttonColors(containerColor = colors.accent, contentColor = colors.onAccent),
            ) { Text(if (active) "In use" else "Use") }
            TextButton(onClick = onCopy, enabled = enabled) { Text("Copy", color = colors.textPrimary) }
            if (!profile.builtin) {
                TextButton(onClick = onEdit, enabled = enabled) { Text("Edit", color = colors.textPrimary) }
                TextButton(onClick = onDelete, enabled = enabled) { Text("Delete", color = colors.danger) }
            }
        }
    }
}

@Composable
private fun Badge(text: String, fg: Color, bg: Color) {
    Text(
        text,
        style = AvekTheme.type.caption.copy(fontWeight = FontWeight.SemiBold),
        color = fg,
        modifier = Modifier.clip(CircleShape).background(bg).padding(horizontal = 8.dp, vertical = 3.dp),
    )
}

/** Green "Fits", amber "Tight", red "Too big", grey "Unknown": the PC's verdict, in words. */
@Composable
fun EstimateChip(verdict: String) {
    val colors = AvekTheme.colors
    val (label, color) = when (verdict) {
        "fits" -> "Fits" to colors.success
        "tight" -> "Tight" to Color(0xFFE0A100)
        "too-big" -> "Too big" to colors.danger
        else -> "Unknown" to colors.textSecondary
    }
    Row(
        Modifier.clip(CircleShape).background(color.copy(alpha = 0.14f)).padding(horizontal = 10.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(color))
        Spacer(Modifier.width(6.dp))
        Text(label, style = AvekTheme.type.caption.copy(fontWeight = FontWeight.SemiBold), color = color)
    }
}

/** RTX / iGPU / CPU as one bar whose widths follow the three numbers (total = `layersTotal`). */
@Composable
fun LayerBar(layers: Layers, total: Int, modifier: Modifier = Modifier) {
    val colors = AvekTheme.colors
    val sum = (if (total > 0) total else layers.total).coerceAtLeast(1)
    Row(
        modifier
            .fillMaxWidth()
            .height(10.dp)
            .clip(CircleShape)
            .background(colors.outline.copy(alpha = 0.3f))
            .semantics { contentDescription = LayerPlan.description(layers) },
    ) {
        listOf(layers.rtx to ProcessorColors.rtx, layers.igpu to ProcessorColors.igpu, layers.cpu to ProcessorColors.cpu).forEach { (n, color) ->
            if (n > 0) Box(Modifier.weight(n.toFloat() / sum).fillMaxHeight().background(color))
        }
        val rest = sum - layers.total
        if (rest > 0) Spacer(Modifier.weight(rest.toFloat() / sum))
    }
}
