package com.avek.chat.core.model.settings

import kotlinx.serialization.Serializable

@Serializable
enum class BubbleStyle(val label: String) {
    FILLED("Filled"),
    TINTED("Tinted"),
    OUTLINED("Outlined"),
    GRADIENT("Gradient"),
    MINIMAL("Minimal"),
}

@Serializable
enum class AssistantStyle(val label: String) {
    PLAIN("Plain"),
    CARD("Card"),
    BUBBLE("Bubble"),
}

@Serializable
enum class Density(val label: String, val scale: Float) {
    COMPACT("Compact", 0.7f),
    COMFORTABLE("Comfortable", 1f),
    SPACIOUS("Spacious", 1.35f),
}

@Serializable
enum class UserAlignment(val label: String) { END("Right"), START("Left") }

@Serializable
data class ChatLayout(
    val bubbleStyle: BubbleStyle = BubbleStyle.FILLED,
    val assistantStyle: AssistantStyle = AssistantStyle.PLAIN,
    val bubbleCornerDp: Int = 20,
    val userAlignment: UserAlignment = UserAlignment.END,
    val density: Density = Density.COMFORTABLE,
    /** Max width of the user bubble as a fraction of the screen width. */
    val bubbleWidthFraction: Float = 0.82f,
    val showAvatars: Boolean = true,
    val showTimestamps: Boolean = false,
    val showModelBadge: Boolean = true,
    val thinkingExpandedByDefault: Boolean = false,
    val codeLineNumbers: Boolean = true,
)
