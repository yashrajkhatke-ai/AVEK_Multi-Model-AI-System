package com.avek.chat.feature.connection

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.outlined.AddLink
import androidx.compose.material.icons.outlined.ArrowDownward
import androidx.compose.material.icons.outlined.ArrowUpward
import androidx.compose.material.icons.outlined.BatteryChargingFull
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Computer
import androidx.compose.material.icons.outlined.LinkOff
import androidx.compose.material.icons.outlined.Memory
import androidx.compose.material.icons.outlined.NotificationsActive
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.Science
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.avek.chat.core.designsystem.component.LocalPlatformActions
import com.avek.chat.core.designsystem.component.SectionHeader
import com.avek.chat.core.designsystem.component.SettingRow
import com.avek.chat.core.designsystem.component.SettingsCard
import com.avek.chat.core.designsystem.component.SwitchRow
import com.avek.chat.core.designsystem.theme.AvekTheme
import com.avek.chat.core.designsystem.theme.avekShape
import com.avek.chat.core.model.settings.ConnectionSettings
import com.avek.chat.core.model.settings.RouteSpec

@Composable
fun ConnectionRoute(onBack: () -> Unit, viewModel: ConnectionViewModel = hiltViewModel()) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }
    LaunchedEffect(viewModel) { viewModel.messages.collect { snackbar.showSnackbar(it) } }
    val platform = LocalPlatformActions.current

    ConnectionScreen(
        state = state,
        snackbar = snackbar,
        onBack = onBack,
        onPair = viewModel::openPairing,
        onReconnect = viewModel::reconnect,
        onUnpair = viewModel::unpair,
        onWorkInBackground = { enabled ->
            // The notification permission is asked for when the person turns background work on.
            if (enabled) platform.requestNotificationPermission { }
            viewModel.setWorkInBackground(enabled)
        },
        onDemoMode = viewModel::setDemoMode,
        onKeepListsSeconds = viewModel::setKeepListsSeconds,
        onMoveRoute = viewModel::moveRoute,
        onAddHost = viewModel::addHost,
        onRemoveRoute = viewModel::removeRoute,
        batteryExempt = platform.isIgnoringBatteryOptimizations(),
        onBatteryExemption = platform::requestIgnoreBatteryOptimizations,
        pairingActions = PairingActions(
            onClose = viewModel::closePairing,
            onSelectServer = viewModel::selectServer,
            onManualAddress = viewModel::onManualAddress,
            onCode = viewModel::onCode,
            onDeviceName = viewModel::onDeviceName,
            onPair = viewModel::pair,
        ),
    )
}

data class PairingActions(
    val onClose: () -> Unit,
    val onSelectServer: (String) -> Unit,
    val onManualAddress: (String) -> Unit,
    val onCode: (String) -> Unit,
    val onDeviceName: (String) -> Unit,
    val onPair: () -> Unit,
)

@Composable
fun ConnectionScreen(
    state: ConnectionScreenState,
    snackbar: SnackbarHostState,
    onBack: () -> Unit,
    onPair: () -> Unit,
    onReconnect: () -> Unit,
    onUnpair: () -> Unit,
    onWorkInBackground: (Boolean) -> Unit,
    onDemoMode: (Boolean) -> Unit,
    onKeepListsSeconds: (Int) -> Unit,
    onMoveRoute: (Int, Int) -> Unit,
    onAddHost: (String) -> Boolean,
    onRemoveRoute: (Int) -> Unit,
    batteryExempt: Boolean,
    onBatteryExemption: () -> Unit,
    pairingActions: PairingActions,
) {
    val colors = AvekTheme.colors
    var confirmUnpair by remember { mutableStateOf(false) }
    var addingHost by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = colors.chatBackground,
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                title = { Text("Connection", style = AvekTheme.type.headline, color = colors.textPrimary) },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Outlined.ArrowBack, "Back", tint = colors.textPrimary) }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = colors.chatBackground),
            )
        },
    ) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding), contentPadding = PaddingValues(bottom = 40.dp)) {
            // ---------------------------------------------------------------- the PC
            item { SectionHeader("Your PC") }
            item {
                SettingsCard {
                    val paired = state.paired
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(if (state.connected) colors.accentContainer else colors.sidebarSelected),
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(
                                if (paired != null || state.demo) Icons.Outlined.Computer else Icons.Outlined.LinkOff,
                                contentDescription = null,
                                tint = if (state.connected) colors.accent else colors.textSecondary,
                            )
                        }
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                when {
                                    state.demo -> "Demo PC"
                                    paired != null -> paired.serverName
                                    else -> "No PC paired"
                                },
                                style = AvekTheme.type.title,
                                color = colors.textPrimary,
                            )
                            Text(state.status, style = AvekTheme.type.bodySmall, color = if (state.connected) colors.accent else colors.textSecondary)
                            if (paired != null && !state.demo) {
                                Text(
                                    buildString {
                                        append("This device: ").append(paired.deviceName)
                                        paired.address?.let { append(" · last ").append(it) }
                                    },
                                    style = AvekTheme.type.caption,
                                    color = colors.textTertiary,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis,
                                )
                            }
                        }
                    }
                    HorizontalDivider(color = colors.outline.copy(alpha = 0.4f))
                    Row(Modifier.padding(horizontal = 8.dp, vertical = 4.dp)) {
                        TextButton(onClick = onPair) {
                            Icon(Icons.Outlined.AddLink, null, modifier = Modifier.size(18.dp), tint = colors.accent)
                            Spacer(Modifier.width(6.dp))
                            Text(if (state.paired == null) "Pair a PC" else "Pair a new PC", color = colors.accent)
                        }
                        if (state.paired != null && !state.demo) {
                            TextButton(onClick = onReconnect) {
                                Icon(Icons.Outlined.Refresh, null, modifier = Modifier.size(18.dp), tint = colors.textPrimary)
                                Spacer(Modifier.width(6.dp))
                                Text("Reconnect", color = colors.textPrimary)
                            }
                            TextButton(onClick = { confirmUnpair = true }) {
                                Text("Unpair", color = colors.danger)
                            }
                        }
                    }
                }
            }

            // ---------------------------------------------------------------- routes
            item {
                SectionHeader(
                    "Routes",
                    subtitle = "All of these are tried at the same time, in this order; the first that connects wins.",
                )
            }
            item {
                SettingsCard {
                    state.settings.routes.forEachIndexed { index, route ->
                        if (index > 0) HorizontalDivider(color = colors.outline.copy(alpha = 0.4f))
                        RouteRow(
                            route = route,
                            canMoveUp = index > 0,
                            canMoveDown = index < state.settings.routes.lastIndex,
                            onUp = { onMoveRoute(index, -1) },
                            onDown = { onMoveRoute(index, 1) },
                            onRemove = { onRemoveRoute(index) },
                        )
                    }
                    HorizontalDivider(color = colors.outline.copy(alpha = 0.4f))
                    TextButton(onClick = { addingHost = true }, modifier = Modifier.padding(horizontal = 8.dp)) {
                        Text("Add an address", color = colors.accent)
                    }
                }
            }

            // ---------------------------------------------------------------- behaviour
            item { SectionHeader("Behaviour") }
            item {
                SettingsCard {
                    SwitchRow(
                        "Work in background",
                        state.settings.workInBackground,
                        onWorkInBackground,
                        subtitle = "Keep the link to your PC while the app is closed, so questions and answers reach you",
                        icon = Icons.Outlined.NotificationsActive,
                    )
                    if (state.settings.workInBackground) {
                        HorizontalDivider(color = colors.outline.copy(alpha = 0.4f))
                        SettingRow(
                            "Battery optimisation",
                            subtitle = if (batteryExempt) "This app is not restricted" else "Android may pause the link to save power. Tap to allow it to run freely.",
                            icon = Icons.Outlined.BatteryChargingFull,
                            onClick = if (batteryExempt) null else onBatteryExemption,
                        )
                    }
                    HorizontalDivider(color = colors.outline.copy(alpha = 0.4f))
                    SwitchRow(
                        "Demo mode",
                        state.settings.demoMode,
                        onDemoMode,
                        subtitle = "Try the app without a PC, with simulated chats and replies",
                        icon = Icons.Outlined.Science,
                    )
                }
            }
            item { SectionHeader("Memory") }
            item {
                SettingsCard {
                    KeepListsRow(state.settings.keepListsSeconds, onKeepListsSeconds)
                }
            }
        }
    }

    if (state.form != null) {
        PairingDialog(state.form, pairingActions)
    }
    if (addingHost) {
        AddressDialog(
            onDismiss = { addingHost = false },
            onAdd = { text -> if (onAddHost(text)) addingHost = false },
        )
    }
    if (confirmUnpair) {
        AlertDialog(
            onDismissRequest = { confirmUnpair = false },
            containerColor = colors.surface,
            title = { Text("Unpair this PC?", color = colors.textPrimary) },
            text = {
                Text(
                    "This device will forget the PC and tell it to forget this device. You will need a new code to pair again.",
                    color = colors.textSecondary,
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    confirmUnpair = false
                    onUnpair()
                }) { Text("Unpair", color = colors.danger) }
            },
            dismissButton = { TextButton(onClick = { confirmUnpair = false }) { Text("Cancel", color = colors.textSecondary) } },
        )
    }
}

@Composable
private fun RouteRow(
    route: RouteSpec,
    canMoveUp: Boolean,
    canMoveDown: Boolean,
    onUp: () -> Unit,
    onDown: () -> Unit,
    onRemove: () -> Unit,
) {
    val colors = AvekTheme.colors
    val (title, subtitle) = when (route) {
        RouteSpec.Last -> "Last used address" to "Kept automatically after every successful connection"
        RouteSpec.Discover -> "Find on Wi-Fi" to "Listens for your PC announcing itself on the network"
        is RouteSpec.Host -> "${route.host}:${route.port}" to "Typed address"
    }
    Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 4.dp, top = 6.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, style = AvekTheme.type.body.copy(fontWeight = FontWeight.Medium), color = colors.textPrimary)
            Text(subtitle, style = AvekTheme.type.caption, color = colors.textTertiary)
        }
        IconButton(onClick = onUp, enabled = canMoveUp) {
            Icon(Icons.Outlined.ArrowUpward, "Move up", tint = if (canMoveUp) colors.textSecondary else colors.textTertiary.copy(alpha = 0.4f), modifier = Modifier.size(20.dp))
        }
        IconButton(onClick = onDown, enabled = canMoveDown) {
            Icon(Icons.Outlined.ArrowDownward, "Move down", tint = if (canMoveDown) colors.textSecondary else colors.textTertiary.copy(alpha = 0.4f), modifier = Modifier.size(20.dp))
        }
        if (route is RouteSpec.Host) {
            IconButton(onClick = onRemove) { Icon(Icons.Outlined.Close, "Remove", tint = colors.danger, modifier = Modifier.size(20.dp)) }
        } else {
            Spacer(Modifier.width(48.dp))
        }
    }
}

@Composable
private fun KeepListsRow(seconds: Int, onChange: (Int) -> Unit) {
    val colors = AvekTheme.colors
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Outlined.Memory, null, tint = colors.textSecondary, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text("Keep lists in memory", style = AvekTheme.type.body, color = colors.textPrimary)
            Text(
                "Chat and model lists are forgotten this long after you close them (${ConnectionSettings.MIN_KEEP_LISTS_SECONDS}–${ConnectionSettings.MAX_KEEP_LISTS_SECONDS} s)",
                style = AvekTheme.type.bodySmall,
                color = colors.textSecondary,
            )
        }
        Spacer(Modifier.width(12.dp))
        var text by remember(seconds) { mutableStateOf(seconds.toString()) }
        OutlinedTextField(
            value = text,
            onValueChange = { raw ->
                val digits = raw.filter { it.isDigit() }.take(3)
                text = digits
                digits.toIntOrNull()?.takeIf { it in ConnectionSettings.MIN_KEEP_LISTS_SECONDS..ConnectionSettings.MAX_KEEP_LISTS_SECONDS }?.let(onChange)
            },
            singleLine = true,
            suffix = { Text("s", color = colors.textSecondary) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            textStyle = AvekTheme.type.body.copy(color = colors.textPrimary),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = colors.accent,
                unfocusedBorderColor = colors.outline,
                cursorColor = colors.accent,
            ),
            isError = text.toIntOrNull()?.let { it !in ConnectionSettings.MIN_KEEP_LISTS_SECONDS..ConnectionSettings.MAX_KEEP_LISTS_SECONDS } ?: true,
            modifier = Modifier.width(104.dp),
        )
    }
}

@Composable
private fun AddressDialog(onDismiss: () -> Unit, onAdd: (String) -> Unit) {
    val colors = AvekTheme.colors
    var text by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = colors.surface,
        title = { Text("Add an address", color = colors.textPrimary) },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                singleLine = true,
                placeholder = { Text("192.168.43.5:7810", color = colors.textTertiary) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                textStyle = AvekTheme.type.body.copy(color = colors.textPrimary),
                colors = fieldColors(),
            )
        },
        confirmButton = { TextButton(onClick = { onAdd(text) }, enabled = text.isNotBlank()) { Text("Add", color = colors.accent) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = colors.textSecondary) } },
    )
}

@Composable
private fun PairingDialog(form: PairingForm, actions: PairingActions) {
    val colors = AvekTheme.colors
    AlertDialog(
        onDismissRequest = { if (!form.busy) actions.onClose() },
        containerColor = colors.surface,
        title = { Text(if (form.pairedWith != null) "Paired" else "Pair a new PC", color = colors.textPrimary) },
        text = {
            if (form.pairedWith != null) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.CheckCircle, null, tint = colors.accent, modifier = Modifier.size(28.dp))
                    Spacer(Modifier.width(12.dp))
                    Text("This device is now paired with ${form.pairedWith}.", style = AvekTheme.type.body, color = colors.textPrimary)
                }
            } else {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        "On the laptop run  bun run Avek_Harness/pair.ts  and type the 12-character code it prints.",
                        style = AvekTheme.type.bodySmall,
                        color = colors.textSecondary,
                    )
                    Text("PCs found on this Wi-Fi", style = AvekTheme.type.label, color = colors.textSecondary)
                    if (form.discovered.isEmpty()) {
                        Text("Looking…", style = AvekTheme.type.bodySmall, color = colors.textTertiary)
                    }
                    form.discovered.forEach { server ->
                        val selected = form.selectedServerId == server.serverId
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clip(avekShape(12.dp))
                                .border(if (selected) 1.5.dp else 1.dp, if (selected) colors.accent else colors.outline, avekShape(12.dp))
                                .clickable { actions.onSelectServer(server.serverId) }
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Icon(Icons.Outlined.Computer, null, tint = if (selected) colors.accent else colors.textSecondary, modifier = Modifier.size(20.dp))
                            Spacer(Modifier.width(10.dp))
                            Column {
                                Text(server.name, style = AvekTheme.type.body.copy(fontWeight = FontWeight.Medium), color = colors.textPrimary)
                                Text(server.target.toString(), style = AvekTheme.type.caption, color = colors.textTertiary)
                            }
                        }
                    }
                    OutlinedTextField(
                        value = form.manualAddress,
                        onValueChange = actions.onManualAddress,
                        label = { Text("Or type the address (ip:port)") },
                        placeholder = { Text("192.168.43.5:7810", color = colors.textTertiary) },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                        textStyle = AvekTheme.type.body.copy(color = colors.textPrimary),
                        colors = fieldColors(),
                        modifier = Modifier.fillMaxWidth(),
                    )
                    OutlinedTextField(
                        value = form.code,
                        onValueChange = actions.onCode,
                        label = { Text("Pairing code") },
                        placeholder = { Text("XXXX-XXXX-XXXX", color = colors.textTertiary) },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Characters),
                        textStyle = AvekTheme.type.body.copy(color = colors.textPrimary, fontWeight = FontWeight.Medium),
                        colors = fieldColors(),
                        modifier = Modifier.fillMaxWidth(),
                    )
                    OutlinedTextField(
                        value = form.deviceName,
                        onValueChange = actions.onDeviceName,
                        label = { Text("Name of this device") },
                        singleLine = true,
                        textStyle = AvekTheme.type.body.copy(color = colors.textPrimary),
                        colors = fieldColors(),
                        modifier = Modifier.fillMaxWidth(),
                    )
                    if (form.error != null) {
                        Text(form.error, style = AvekTheme.type.bodySmall, color = colors.danger)
                    }
                }
            }
        },
        confirmButton = {
            if (form.pairedWith != null) {
                TextButton(onClick = actions.onClose) { Text("Done", color = colors.accent) }
            } else {
                Button(
                    onClick = actions.onPair,
                    enabled = form.canPair,
                    colors = ButtonDefaults.buttonColors(containerColor = colors.accent, contentColor = colors.onAccent),
                ) { Text(if (form.busy) "Pairing…" else "Pair") }
            }
        },
        dismissButton = {
            if (form.pairedWith == null) {
                TextButton(onClick = actions.onClose, enabled = !form.busy) { Text("Cancel", color = colors.textSecondary) }
            }
        },
    )
}

@Composable
private fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = AvekTheme.colors.accent,
    unfocusedBorderColor = AvekTheme.colors.outline,
    focusedLabelColor = AvekTheme.colors.accent,
    cursorColor = AvekTheme.colors.accent,
)
