package com.avek.chat.feature.connection

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.AddLink
import androidx.compose.material.icons.outlined.BatteryChargingFull
import androidx.compose.material.icons.outlined.Computer
import androidx.compose.material.icons.outlined.LinkOff
import androidx.compose.material.icons.outlined.Memory
import androidx.compose.material.icons.outlined.NotificationsActive
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.Science
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.avek.chat.core.designsystem.component.LocalPlatformActions
import com.avek.chat.core.designsystem.component.SectionHeader
import com.avek.chat.core.designsystem.component.SettingRow
import com.avek.chat.core.designsystem.component.SettingsCard
import com.avek.chat.core.designsystem.component.SwitchRow
import com.avek.chat.core.designsystem.theme.AvekTheme
import com.avek.chat.core.model.settings.ConnectionSettings

@Composable
fun ConnectionRoute(onBack: () -> Unit, onPair: () -> Unit, viewModel: ConnectionViewModel = hiltViewModel()) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }
    LaunchedEffect(viewModel) { viewModel.messages.collect { snackbar.showSnackbar(it) } }
    val platform = LocalPlatformActions.current

    ConnectionScreen(
        state = state,
        snackbar = snackbar,
        onBack = onBack,
        onPair = onPair,
        onReconnect = viewModel::reconnect,
        onForget = viewModel::forget,
        onWorkInBackground = { enabled ->
            // The notification permission is asked for when the person turns background work on.
            if (enabled) platform.requestNotificationPermission { }
            viewModel.setWorkInBackground(enabled)
        },
        onDemoMode = viewModel::setDemoMode,
        onKeepListsSeconds = viewModel::setKeepListsSeconds,
        batteryExempt = platform.isIgnoringBatteryOptimizations(),
        onBatteryExemption = platform::requestIgnoreBatteryOptimizations,
    )
}

/** Settings → Connection: no addresses, no codes, no routes. The app finds the paired PC by itself. */
@Composable
fun ConnectionScreen(
    state: ConnectionScreenState,
    snackbar: SnackbarHostState,
    onBack: () -> Unit,
    onPair: () -> Unit,
    onReconnect: () -> Unit,
    onForget: () -> Unit,
    onWorkInBackground: (Boolean) -> Unit,
    onDemoMode: (Boolean) -> Unit,
    onKeepListsSeconds: (Int) -> Unit,
    batteryExempt: Boolean,
    onBatteryExemption: () -> Unit,
) {
    val colors = AvekTheme.colors
    var confirmForget by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = colors.chatBackground,
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                title = { Text("Connection", style = AvekTheme.type.headline, color = colors.textPrimary) },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Outlined.ArrowBack, "Back", tint = colors.textPrimary) }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = colors.chatBackground),
            )
        },
    ) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding), contentPadding = PaddingValues(bottom = 40.dp)) {
            item { SectionHeader("Your PC") }
            item {
                SettingsCard {
                    val paired = state.paired
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(if (state.connected) colors.accentContainer else colors.sidebarSelected),
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(
                                if (paired != null || state.demo) Icons.Outlined.Computer else Icons.Outlined.LinkOff,
                                contentDescription = null,
                                tint = if (state.connected) colors.accent else colors.textSecondary,
                            )
                        }
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                when {
                                    state.demo -> "Demo PC"
                                    paired != null -> paired.serverName
                                    else -> "No PC paired"
                                },
                                style = AvekTheme.type.title,
                                color = colors.textPrimary,
                            )
                            Text(state.status, style = AvekTheme.type.bodySmall, color = if (state.connected) colors.accent else colors.textSecondary)
                            if (state.address != null && !state.demo) {
                                Text(state.address, style = AvekTheme.type.caption, color = colors.textTertiary)
                            }
                            if (paired != null && !state.demo) {
                                Text(
                                    buildString {
                                        append("This device: ").append(paired.deviceName)
                                        paired.fingerprint?.let { append(" · PC key ").append(it) }
                                    },
                                    style = AvekTheme.type.caption,
                                    color = colors.textTertiary,
                                )
                            }
                        }
                    }
                    if (state.notice != null) {
                        Text(state.notice, style = AvekTheme.type.bodySmall, color = colors.danger, modifier = Modifier.padding(start = 16.dp, end = 16.dp, bottom = 12.dp))
                    }
                    HorizontalDivider(color = colors.outline.copy(alpha = 0.4f))
                    Row(Modifier.padding(horizontal = 8.dp, vertical = 4.dp)) {
                        when {
                            state.paired == null || state.forgotten -> TextButton(onClick = onPair) {
                                Icon(Icons.Outlined.AddLink, null, modifier = Modifier.size(18.dp), tint = colors.accent)
                                Spacer(Modifier.width(6.dp))
                                Text(if (state.forgotten) "Pair again" else "Pair with a PC", color = colors.accent)
                            }
                            !state.demo -> TextButton(onClick = onReconnect) {
                                Icon(Icons.Outlined.Refresh, null, modifier = Modifier.size(18.dp), tint = colors.textPrimary)
                                Spacer(Modifier.width(6.dp))
                                Text("Reconnect", color = colors.textPrimary)
                            }
                        }
                        if (state.paired != null) {
                            TextButton(onClick = { confirmForget = true }) { Text("Forget this PC", color = colors.danger) }
                        }
                    }
                }
            }

            item { SectionHeader("Behaviour") }
            item {
                SettingsCard {
                    SwitchRow(
                        "Work in background",
                        state.settings.workInBackground,
                        onWorkInBackground,
                        subtitle = "Keep the link to your PC while the app is closed, so questions and answers reach you",
                        icon = Icons.Outlined.NotificationsActive,
                    )
                    if (state.settings.workInBackground) {
                        HorizontalDivider(color = colors.outline.copy(alpha = 0.4f))
                        SettingRow(
                            "Battery optimisation",
                            subtitle = if (batteryExempt) "This app is not restricted" else "Android may pause the link to save power. Tap to allow it to run freely.",
                            icon = Icons.Outlined.BatteryChargingFull,
                            onClick = if (batteryExempt) null else onBatteryExemption,
                        )
                    }
                    HorizontalDivider(color = colors.outline.copy(alpha = 0.4f))
                    SwitchRow(
                        "Demo mode",
                        state.settings.demoMode,
                        onDemoMode,
                        subtitle = "Try the app without a PC, with simulated chats and replies",
                        icon = Icons.Outlined.Science,
                    )
                }
            }
            item { SectionHeader("Memory") }
            item {
                SettingsCard {
                    KeepListsRow(state.settings.keepListsSeconds, onKeepListsSeconds)
                }
            }
        }
    }

    if (confirmForget) {
        AlertDialog(
            onDismissRequest = { confirmForget = false },
            containerColor = colors.surface,
            title = { Text("Forget this PC?", color = colors.textPrimary) },
            text = {
                Text(
                    "This device deletes its key and forgets the PC (and tells the PC when it is connected). You will pair again with the six digits.",
                    color = colors.textSecondary,
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    confirmForget = false
                    onForget()
                }) { Text("Forget", color = colors.danger) }
            },
            dismissButton = { TextButton(onClick = { confirmForget = false }) { Text("Cancel", color = colors.textSecondary) } },
        )
    }
}

@Composable
private fun KeepListsRow(seconds: Int, onChange: (Int) -> Unit) {
    val colors = AvekTheme.colors
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Outlined.Memory, null, tint = colors.textSecondary, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text("Keep lists in memory", style = AvekTheme.type.body, color = colors.textPrimary)
            Text(
                "Chat and model lists are forgotten this long after you close them (${ConnectionSettings.MIN_KEEP_LISTS_SECONDS}–${ConnectionSettings.MAX_KEEP_LISTS_SECONDS} s)",
                style = AvekTheme.type.bodySmall,
                color = colors.textSecondary,
            )
        }
        Spacer(Modifier.width(12.dp))
        var text by remember(seconds) { mutableStateOf(seconds.toString()) }
        OutlinedTextField(
            value = text,
            onValueChange = { raw ->
                val digits = raw.filter { it.isDigit() }.take(3)
                text = digits
                digits.toIntOrNull()?.takeIf { it in ConnectionSettings.MIN_KEEP_LISTS_SECONDS..ConnectionSettings.MAX_KEEP_LISTS_SECONDS }?.let(onChange)
            },
            singleLine = true,
            suffix = { Text("s", color = colors.textSecondary) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            textStyle = AvekTheme.type.body.copy(color = colors.textPrimary),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = colors.accent,
                unfocusedBorderColor = colors.outline,
                cursorColor = colors.accent,
            ),
            isError = text.toIntOrNull()?.let { it !in ConnectionSettings.MIN_KEEP_LISTS_SECONDS..ConnectionSettings.MAX_KEEP_LISTS_SECONDS } ?: true,
            modifier = Modifier.width(104.dp),
        )
    }
}


@Composable
private fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = AvekTheme.colors.accent,
    unfocusedBorderColor = AvekTheme.colors.outline,
    focusedLabelColor = AvekTheme.colors.accent,
    cursorColor = AvekTheme.colors.accent,
)
