package com.avek.chat.feature.connection

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.AddLink
import androidx.compose.material.icons.outlined.BatteryChargingFull
import androidx.compose.material.icons.outlined.Computer
import androidx.compose.material.icons.outlined.LinkOff
import androidx.compose.material.icons.outlined.Memory
import androidx.compose.material.icons.outlined.NotificationsActive
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.Science
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.avek.chat.core.designsystem.component.LocalPlatformActions
import com.avek.chat.core.designsystem.component.SectionHeader
import com.avek.chat.core.designsystem.component.SettingRow
import com.avek.chat.core.designsystem.component.SettingsCard
import com.avek.chat.core.designsystem.component.SwitchRow
import com.avek.chat.core.designsystem.theme.AvekTheme
import com.avek.chat.core.model.settings.ConnectionSettings
import com.avek.chat.core.link.route.RouteKind
import com.avek.chat.core.link.route.RouteMode
import androidx.compose.material.icons.outlined.Key
import androidx.compose.material.icons.outlined.Public
import androidx.compose.material.icons.outlined.VpnLock
import androidx.compose.material.icons.outlined.Wifi
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults

@Composable
fun ConnectionRoute(onBack: () -> Unit, onPair: () -> Unit, viewModel: ConnectionViewModel = hiltViewModel()) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }
    LaunchedEffect(viewModel) { viewModel.messages.collect { snackbar.showSnackbar(it) } }
    val platform = LocalPlatformActions.current

    ConnectionScreen(
        state = state,
        snackbar = snackbar,
        onBack = onBack,
        onPair = onPair,
        onReconnect = viewModel::reconnect,
        onForget = viewModel::forget,
        onRouteMode = viewModel::setRouteMode,
        onReplaceKeys = viewModel::replaceKeys,
        onDismissRekey = viewModel::dismissRekey,
        onWorkInBackground = { enabled ->
            // The notification permission is asked for when the person turns background work on.
            if (enabled) platform.requestNotificationPermission { }
            viewModel.setWorkInBackground(enabled)
        },
        onDemoMode = viewModel::setDemoMode,
        onKeepListsSeconds = viewModel::setKeepListsSeconds,
        batteryExempt = platform.isIgnoringBatteryOptimizations(),
        onBatteryExemption = platform::requestIgnoreBatteryOptimizations,
    )
}

/** Settings → Connection: the status line, the three routes, the route setting, key replacement, forget. Nothing is typed. */
@Composable
fun ConnectionScreen(
    state: ConnectionScreenState,
    snackbar: SnackbarHostState,
    onBack: () -> Unit,
    onPair: () -> Unit,
    onReconnect: () -> Unit,
    onForget: () -> Unit,
    onRouteMode: (RouteMode) -> Unit,
    onReplaceKeys: () -> Unit,
    onDismissRekey: () -> Unit,
    onWorkInBackground: (Boolean) -> Unit,
    onDemoMode: (Boolean) -> Unit,
    onKeepListsSeconds: (Int) -> Unit,
    batteryExempt: Boolean,
    onBatteryExemption: () -> Unit,
) {
    val colors = AvekTheme.colors
    var confirmForget by remember { mutableStateOf(false) }
    var confirmRekey by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = colors.chatBackground,
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                title = { Text("Connection", style = AvekTheme.type.headline, color = colors.textPrimary) },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Outlined.ArrowBack, "Back", tint = colors.textPrimary) }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = colors.chatBackground),
            )
        },
    ) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding), contentPadding = PaddingValues(bottom = 40.dp)) {
            item { SectionHeader("Your PC") }
            item {
                SettingsCard {
                    val paired = state.paired
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(if (state.connected) colors.accentContainer else colors.sidebarSelected),
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(
                                if (paired != null || state.demo) Icons.Outlined.Computer else Icons.Outlined.LinkOff,
                                contentDescription = null,
                                tint = if (state.connected) colors.accent else colors.textSecondary,
                            )
                        }
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                when {
                                    state.demo -> "Demo PC"
                                    paired != null -> paired.serverName
                                    else -> "No PC paired"
                                },
                                style = AvekTheme.type.title,
                                color = colors.textPrimary,
                            )
                            Text(state.status, style = AvekTheme.type.bodySmall, color = if (state.connected) colors.accent else colors.textSecondary)
                            if (paired != null && !state.demo) {
                                Text(
                                    buildString {
                                        append("This device: ").append(paired.deviceName).append(" (").append(paired.deviceId).append(")")
                                        paired.fingerprint?.let { append(" · Your PC's fingerprint ").append(it) }
                                    },
                                    style = AvekTheme.type.caption,
                                    color = colors.textTertiary,
                                )
                            }
                        }
                    }
                    if (state.notice != null) {
                        Text(state.notice, style = AvekTheme.type.bodySmall, color = colors.danger, modifier = Modifier.padding(start = 16.dp, end = 16.dp, bottom = 12.dp))
                    }
                    HorizontalDivider(color = colors.outline.copy(alpha = 0.4f))
                    Row(Modifier.padding(horizontal = 8.dp, vertical = 4.dp)) {
                        when {
                            state.paired == null || state.forgotten -> TextButton(onClick = onPair) {
                                Icon(Icons.Outlined.AddLink, null, modifier = Modifier.size(18.dp), tint = colors.accent)
                                Spacer(Modifier.width(6.dp))
                                Text(if (state.forgotten) "Pair again" else "Pair with a PC", color = colors.accent)
                            }
                            !state.demo -> TextButton(onClick = onReconnect) {
                                Icon(Icons.Outlined.Refresh, null, modifier = Modifier.size(18.dp), tint = colors.textPrimary)
                                Spacer(Modifier.width(6.dp))
                                Text("Reconnect", color = colors.textPrimary)
                            }
                        }
                        if (state.paired != null) {
                            TextButton(onClick = { confirmForget = true }) { Text("Forget this PC", color = colors.danger) }
                        }
                    }
                }
            }

            if (state.paired != null && !state.demo) {
                item { SectionHeader("Routes") }
                item { RoutesCard(state) }
                item { SectionHeader("Route") }
                item {
                    SettingsCard {
                        RouteMode.entries.forEachIndexed { index, mode ->
                            if (index > 0) HorizontalDivider(color = colors.outline.copy(alpha = 0.4f))
                            SettingRow(
                                mode.label,
                                subtitle = when (mode) {
                                    RouteMode.Auto -> "Wi-Fi and Tailscale at once, ngrok after 3 s if needed"
                                    RouteMode.WifiOnly -> "Only on the same Wi-Fi or hotspot"
                                    RouteMode.TailscaleOnly -> "Only through Tailscale"
                                    RouteMode.NgrokOnly -> "Only through the ngrok address"
                                },
                                onClick = { onRouteMode(mode) },
                            ) {
                                RadioButton(
                                    selected = state.routeMode == mode,
                                    onClick = { onRouteMode(mode) },
                                    colors = RadioButtonDefaults.colors(selectedColor = colors.accent),
                                )
                            }
                        }
                    }
                }
                item { SectionHeader("Keys") }
                item {
                    SettingsCard {
                        SettingRow(
                            "Replace this device's keys",
                            subtitle = when (val r = state.rekey) {
                                RekeyUi.Idle -> "A new key and new secrets for this device, without pairing again"
                                RekeyUi.Running -> "Replacing the keys..."
                                RekeyUi.Done -> "Done: this device now uses new keys"
                                RekeyUi.Pending -> "The new keys are stored; the PC confirms them on the next connection (within 10 minutes)"
                                is RekeyUi.Failed -> "Not replaced: ${r.message}"
                            },
                            icon = Icons.Outlined.Key,
                            onClick = if (state.connected && state.rekey != RekeyUi.Running) ({ confirmRekey = true }) else null,
                        ) {
                            if (state.rekey == RekeyUi.Running) CircularProgressIndicator(Modifier.size(20.dp), color = colors.accent, strokeWidth = 2.dp)
                        }
                    }
                }
            }

            item { SectionHeader("Behaviour") }
            item {
                SettingsCard {
                    SwitchRow(
                        "Work in background",
                        state.settings.workInBackground,
                        onWorkInBackground,
                        subtitle = "Keep the link to your PC while the app is closed, so questions and answers reach you",
                        icon = Icons.Outlined.NotificationsActive,
                    )
                    if (state.settings.workInBackground) {
                        HorizontalDivider(color = colors.outline.copy(alpha = 0.4f))
                        SettingRow(
                            "Battery optimisation",
                            subtitle = if (batteryExempt) "This app is not restricted" else "Android may pause the link to save power. Tap to allow it to run freely.",
                            icon = Icons.Outlined.BatteryChargingFull,
                            onClick = if (batteryExempt) null else onBatteryExemption,
                        )
                    }
                    HorizontalDivider(color = colors.outline.copy(alpha = 0.4f))
                    SwitchRow(
                        "Demo mode",
                        state.settings.demoMode,
                        onDemoMode,
                        subtitle = "Try the app without a PC, with simulated chats and replies",
                        icon = Icons.Outlined.Science,
                    )
                }
            }
            item { SectionHeader("Memory") }
            item {
                SettingsCard {
                    KeepListsRow(state.settings.keepListsSeconds, onKeepListsSeconds)
                }
            }
        }
    }

    if (confirmRekey) {
        AlertDialog(
            onDismissRequest = { confirmRekey = false },
            containerColor = colors.surface,
            title = { Text("Replace this device's keys?", color = colors.textPrimary) },
            text = { Text("This replaces the keys of this device on your PC. It takes a few seconds.", color = colors.textSecondary) },
            confirmButton = {
                TextButton(onClick = {
                    confirmRekey = false
                    onDismissRekey()
                    onReplaceKeys()
                }) { Text("Replace", color = colors.accent) }
            },
            dismissButton = { TextButton(onClick = { confirmRekey = false }) { Text("Cancel", color = colors.textSecondary) } },
        )
    }

    if (confirmForget) {
        AlertDialog(
            onDismissRequest = { confirmForget = false },
            containerColor = colors.surface,
            title = { Text("Forget this PC?", color = colors.textPrimary) },
            text = {
                Text(
                    "This device deletes its keys and secrets and forgets the PC (and tells the PC when it is connected). To use it again you pair with a new 12-digit code.",
                    color = colors.textSecondary,
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    confirmForget = false
                    onForget()
                }) { Text("Forget", color = colors.danger) }
            },
            dismissButton = { TextButton(onClick = { confirmForget = false }) { Text("Cancel", color = colors.textSecondary) } },
        )
    }
}

/** The three routes with their live state (section 8.9): only what the PC reported. */
@Composable
private fun RoutesCard(state: ConnectionScreenState) {
    val colors = AvekTheme.colors
    val r = state.routes
    SettingsCard {
        RouteRow(
            "Wi-Fi",
            Icons.Outlined.Wifi,
            if (r.wifiAddresses.isEmpty()) "-" else r.wifiAddresses.joinToString(", "),
            inUse = state.routeInUse == RouteKind.WIFI,
        )
        HorizontalDivider(color = colors.outline.copy(alpha = 0.4f))
        RouteRow(
            "Tailscale",
            Icons.Outlined.VpnLock,
            buildString {
                append(r.tailscaleName ?: "Not set up on your PC")
                append(" · ")
                append(if (r.tailscaleInstalled) "installed on this phone" else "not installed on this phone")
            },
            inUse = state.routeInUse == RouteKind.TAILSCALE,
        )
        HorizontalDivider(color = colors.outline.copy(alpha = 0.4f))
        RouteRow(
            "ngrok",
            Icons.Outlined.Public,
            if (r.ngrokUrl == null) {
                "Not set up on your PC"
            } else {
                buildString {
                    append(r.ngrokUrl)
                    r.ngrokState?.let { append(" · ").append(it) }
                    r.ngrokError?.let { append(" · ").append(it) }
                }
            },
            inUse = state.routeInUse == RouteKind.NGROK,
        )
    }
}

@Composable
private fun RouteRow(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, detail: String, inUse: Boolean) {
    val colors = AvekTheme.colors
    SettingRow(title, subtitle = detail, icon = icon) {
        if (inUse) {
            Text(
                "In use",
                style = AvekTheme.type.label,
                color = colors.accent,
                modifier = Modifier
                    .clip(CircleShape)
                    .background(colors.accentContainer)
                    .padding(horizontal = 10.dp, vertical = 4.dp),
            )
        }
    }
}

@Composable
private fun KeepListsRow(seconds: Int, onChange: (Int) -> Unit) {
    val colors = AvekTheme.colors
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Outlined.Memory, null, tint = colors.textSecondary, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text("Keep lists in memory", style = AvekTheme.type.body, color = colors.textPrimary)
            Text(
                "Chat and model lists are forgotten this long after you close them (${ConnectionSettings.MIN_KEEP_LISTS_SECONDS}–${ConnectionSettings.MAX_KEEP_LISTS_SECONDS} s)",
                style = AvekTheme.type.bodySmall,
                color = colors.textSecondary,
            )
        }
        Spacer(Modifier.width(12.dp))
        var text by remember(seconds) { mutableStateOf(seconds.toString()) }
        OutlinedTextField(
            value = text,
            onValueChange = { raw ->
                val digits = raw.filter { it.isDigit() }.take(3)
                text = digits
                digits.toIntOrNull()?.takeIf { it in ConnectionSettings.MIN_KEEP_LISTS_SECONDS..ConnectionSettings.MAX_KEEP_LISTS_SECONDS }?.let(onChange)
            },
            singleLine = true,
            suffix = { Text("s", color = colors.textSecondary) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            textStyle = AvekTheme.type.body.copy(color = colors.textPrimary),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = colors.accent,
                unfocusedBorderColor = colors.outline,
                cursorColor = colors.accent,
            ),
            isError = text.toIntOrNull()?.let { it !in ConnectionSettings.MIN_KEEP_LISTS_SECONDS..ConnectionSettings.MAX_KEEP_LISTS_SECONDS } ?: true,
            modifier = Modifier.width(104.dp),
        )
    }
}


@Composable
private fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = AvekTheme.colors.accent,
    unfocusedBorderColor = AvekTheme.colors.outline,
    focusedLabelColor = AvekTheme.colors.accent,
    cursorColor = AvekTheme.colors.accent,
)
