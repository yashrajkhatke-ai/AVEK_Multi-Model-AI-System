package com.avek.chat.platform.android

import com.avek.chat.core.link.transport.Datagram
import com.avek.chat.core.link.transport.LocalAddress
import com.avek.chat.core.link.transport.MulticastGuard
import com.avek.chat.core.link.transport.UdpSocket
import com.avek.chat.core.link.transport.UdpTransport
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.SocketTimeoutException
import javax.inject.Inject
import javax.inject.Singleton

/**
 * UDP for the knock (UI-WIRE v3 section 2): one socket per round, bound to the Wi-Fi network,
 * broadcast enabled, with the multicast lock held so broadcast answers are delivered.
 */
@Singleton
class AndroidUdpTransport @Inject constructor(
    private val wifi: WifiNetworkBinder,
    private val multicast: MulticastGuard,
) : UdpTransport {

    override suspend fun open(): UdpSocket = withContext(Dispatchers.IO) {
        multicast.acquire()
        wifi.acquire()
        val socket = DatagramSocket(null)
        try {
            socket.reuseAddress = true
            wifi.socketFactory() // waits briefly for the Wi-Fi network to be known
            wifi.bind(socket)
            socket.bind(InetSocketAddress(0))
            socket.broadcast = true
        } catch (e: Exception) {
            socket.close()
            wifi.release()
            multicast.release()
            throw e
        }
        object : UdpSocket {
            override suspend fun send(host: String, port: Int, data: ByteArray) = withContext(Dispatchers.IO) {
                socket.send(DatagramPacket(data, data.size, InetAddress.getByName(host), port))
            }

            override suspend fun receive(timeoutMs: Long): Datagram? = withContext(Dispatchers.IO) {
                val buffer = ByteArray(MAX_DATAGRAM)
                val packet = DatagramPacket(buffer, buffer.size)
                socket.soTimeout = timeoutMs.toInt().coerceAtLeast(1)
                try {
                    socket.receive(packet)
                    Datagram(packet.address.hostAddress.orEmpty(), packet.port, packet.data.copyOf(packet.length))
                } catch (_: SocketTimeoutException) {
                    null
                }
            }

            override fun close() {
                socket.close()
                wifi.release()
                multicast.release()
            }
        }
    }

    override fun localAddress(): LocalAddress? = wifi.localAddress()

    private companion object {
        const val MAX_DATAGRAM = 4096
    }
}
