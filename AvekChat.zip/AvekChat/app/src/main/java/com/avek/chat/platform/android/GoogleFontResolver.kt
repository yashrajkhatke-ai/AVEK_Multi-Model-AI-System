package com.avek.chat.platform.android

import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.googlefonts.Font
import androidx.compose.ui.text.googlefonts.GoogleFont
import com.avek.chat.R
import com.avek.chat.core.designsystem.theme.FontResolver
import com.avek.chat.core.designsystem.theme.SystemFontResolver
import com.avek.chat.core.model.settings.FontChoice
import java.util.concurrent.ConcurrentHashMap
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Resolves Google Fonts through the Play Services downloadable-fonts provider.
 * Fonts download lazily the first time a weight/style is rendered and are
 * cached system-wide; until then text renders in the platform fallback.
 */
@Singleton
class GoogleFontResolver @Inject constructor() : FontResolver {

    private val provider = GoogleFont.Provider(
        providerAuthority = "com.google.android.gms.fonts",
        providerPackage = "com.google.android.gms",
        certificates = R.array.com_google_android_gms_fonts_certs,
    )

    private val cache = ConcurrentHashMap<FontChoice, FontFamily>()

    override fun resolve(choice: FontChoice): FontFamily {
        SystemFontResolver.systemFamily(choice)?.let { return it }
        return cache.getOrPut(choice) {
            val googleFont = GoogleFont(choice.name, bestEffort = true)
            FontFamily(
                WEIGHTS.flatMap { weight ->
                    listOf(
                        Font(googleFont = googleFont, fontProvider = provider, weight = FontWeight(weight), style = FontStyle.Normal),
                        Font(googleFont = googleFont, fontProvider = provider, weight = FontWeight(weight), style = FontStyle.Italic),
                    )
                },
            )
        }
    }

    private companion object {
        val WEIGHTS = listOf(100, 200, 300, 400, 500, 600, 700, 800, 900)
    }
}
