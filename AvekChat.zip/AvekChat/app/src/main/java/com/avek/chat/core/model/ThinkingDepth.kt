package com.avek.chat.core.model

/**
 * How much deliberate reasoning a model performs before answering.
 * Each level maps to a reasoning budget, a visible number of thinking
 * steps, and its own animation in the UI.
 */
enum class ThinkingDepth(
    val level: Int,
    val label: String,
    val description: String,
    val budgetLabel: String,
    val thinkingSteps: Int,
) {
    INSTANT(0, "Instant", "Answers immediately with no visible reasoning", "No thinking", 0),
    LIGHT(1, "Light", "A quick sanity check before answering", "≈1K tokens", 2),
    BALANCED(2, "Balanced", "Weighs a few angles before committing", "≈4K tokens", 3),
    DEEP(3, "Deep", "Works through the problem carefully, step by step", "≈16K tokens", 5),
    EXTENDED(4, "Extended", "Explores alternatives and double-checks its work", "≈32K tokens", 7),
    MAXIMUM(5, "Maximum", "Exhaustive reasoning — leaves no stone unturned", "≈64K tokens", 9);

    val thinks: Boolean get() = this != INSTANT

    companion object {
        val MAX_LEVEL = entries.size - 1

        fun fromLevel(level: Int): ThinkingDepth =
            entries[level.coerceIn(0, MAX_LEVEL)]
    }
}
