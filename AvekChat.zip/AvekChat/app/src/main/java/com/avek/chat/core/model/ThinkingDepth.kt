package com.avek.chat.core.model

/**
 * How much deliberate reasoning a model performs before answering.
 * Each level maps to a reasoning budget, a visible number of thinking
 * steps, and its own animation in the UI.
 */
enum class ThinkingDepth(
    val level: Int,
    val label: String,
    val description: String,
    /** Position on the 0..5 scale, shown as a small badge. */
    val budgetLabel: String,
    /** Only the demo engine uses this: how many reasoning steps it narrates. */
    val thinkingSteps: Int,
) {
    INSTANT(0, "Instant", "Answers immediately with no visible reasoning", "Level 0 of 5", 0),
    LIGHT(1, "Light", "A quick sanity check before answering", "Level 1 of 5", 2),
    BALANCED(2, "Balanced", "Weighs a few angles before committing", "Level 2 of 5", 3),
    DEEP(3, "Deep", "Works through the problem carefully, step by step", "Level 3 of 5", 5),
    EXTENDED(4, "Extended", "Explores alternatives and double-checks its work", "Level 4 of 5", 7),
    MAXIMUM(5, "Maximum", "Exhaustive reasoning — leaves no stone unturned", "Level 5 of 5", 9);

    val thinks: Boolean get() = this != INSTANT

    companion object {
        val MAX_LEVEL = entries.size - 1

        fun fromLevel(level: Int): ThinkingDepth =
            entries[level.coerceIn(0, MAX_LEVEL)]
    }
}
