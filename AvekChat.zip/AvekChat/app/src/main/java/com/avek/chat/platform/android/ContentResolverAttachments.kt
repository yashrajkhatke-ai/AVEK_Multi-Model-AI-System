package com.avek.chat.platform.android

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.avek.chat.core.domain.chat.AttachmentSource
import com.avek.chat.core.domain.chat.AttachmentSourceFactory
import dagger.hilt.android.qualifiers.ApplicationContext
import java.io.InputStream
import javax.inject.Inject
import javax.inject.Singleton

/** A file chosen with the system picker, read through its content URI. */
class ContentResolverAttachment(
    private val context: Context,
    private val uri: Uri,
    override val name: String,
    override val mime: String,
    override val size: Long,
) : AttachmentSource {
    override fun open(): InputStream =
        context.contentResolver.openInputStream(uri) ?: throw java.io.IOException("Cannot open $name")
}

@Singleton
class AndroidAttachmentSourceFactory @Inject constructor(
    @ApplicationContext private val context: Context,
) : AttachmentSourceFactory {

    override fun create(uri: String): AttachmentSource? {
        val parsed = runCatching { Uri.parse(uri) }.getOrNull() ?: return null
        val resolver = context.contentResolver
        var name = parsed.lastPathSegment ?: "file"
        var size = -1L
        runCatching {
            resolver.query(parsed, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME).takeIf { it >= 0 }?.let { name = cursor.getString(it) ?: name }
                    cursor.getColumnIndex(OpenableColumns.SIZE).takeIf { it >= 0 && !cursor.isNull(it) }?.let { size = cursor.getLong(it) }
                }
            }
        }
        if (size < 0) {
            // Some providers do not report a size, which attach.begin needs: count the bytes.
            size = runCatching { resolver.openInputStream(parsed)?.use(::countBytes) }.getOrNull() ?: return null
        }
        val mime = resolver.getType(parsed) ?: "application/octet-stream"
        return ContentResolverAttachment(context, parsed, name, mime, size)
    }

    private fun countBytes(input: InputStream): Long {
        var total = 0L
        val buffer = ByteArray(64 * 1024)
        while (true) {
            val n = input.read(buffer)
            if (n < 0) return total
            total += n
        }
    }
}
