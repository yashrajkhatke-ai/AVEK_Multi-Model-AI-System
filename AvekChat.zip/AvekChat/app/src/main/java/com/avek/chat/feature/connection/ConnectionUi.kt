package com.avek.chat.feature.connection

import androidx.compose.runtime.Immutable
import com.avek.chat.core.link.route.ConnectionState

/** What the rest of the app shows about the link (banner text, enabled composer…). */
@Immutable
data class ConnectionUi(
    val connected: Boolean = false,
    /** Short status line; null when everything is fine. */
    val banner: String? = null,
    /** No PC is paired (or the PC forgot this device): the banner offers "Pair". */
    val needsPairing: Boolean = false,
    /** True while the built-in demo is the source. */
    val demo: Boolean = false,
    val serverName: String? = null,
    val address: String? = null,
) {
    companion object {
        const val NOT_REACHABLE = "PC not reachable. Looking for it on Wi-Fi..."

        fun from(state: ConnectionState, demo: Boolean): ConnectionUi = when {
            demo -> ConnectionUi(connected = true, demo = true, serverName = "Demo PC", address = "built-in demo")
            else -> when (state) {
                is ConnectionState.Connected -> ConnectionUi(connected = true, serverName = state.pcName, address = state.address)
                is ConnectionState.NeedsPairing -> ConnectionUi(banner = state.notice ?: "No PC paired yet.", needsPairing = true)
                ConnectionState.Disconnected -> ConnectionUi(banner = NOT_REACHABLE)
                is ConnectionState.Looking -> ConnectionUi(banner = NOT_REACHABLE, serverName = state.pcName)
                is ConnectionState.Connecting -> ConnectionUi(banner = "Connecting to ${state.pcName}...", serverName = state.pcName, address = state.address)
                is ConnectionState.Unreachable -> ConnectionUi(banner = NOT_REACHABLE, serverName = state.pcName)
                ConnectionState.Forgotten -> ConnectionUi(banner = FORGOTTEN, needsPairing = true)
                is ConnectionState.Failed -> ConnectionUi(banner = state.reason)
            }
        }

        const val FORGOTTEN = "This PC forgot this device. Pair again."
    }
}

/** The status line of the Connection screen (section 13): "Looking for <PC>...", "Connected to <PC>", "PC not reachable - trying again in 8 s". */
fun describe(state: ConnectionState, demo: Boolean, nowMs: Long = System.currentTimeMillis()): String = when {
    demo -> "Demo mode: no PC needed"
    else -> when (state) {
        is ConnectionState.Connected -> "Connected to ${state.pcName}"
        is ConnectionState.NeedsPairing -> state.notice ?: "Not paired"
        ConnectionState.Disconnected -> "Not connected"
        is ConnectionState.Looking -> "Looking for ${state.pcName}..."
        is ConnectionState.Connecting -> "Connecting to ${state.pcName}..."
        is ConnectionState.Unreachable -> {
            val retryIn = state.retryAtMs?.let { ((it - nowMs) + 999) / 1000 }
            if (retryIn != null && retryIn > 0) "PC not reachable - trying again in $retryIn s" else "PC not reachable - trying again"
        }
        ConnectionState.Forgotten -> ConnectionUi.FORGOTTEN
        is ConnectionState.Failed -> state.reason
    }
}
