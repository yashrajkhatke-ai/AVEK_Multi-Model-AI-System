package com.avek.chat.feature.connection

import androidx.compose.runtime.Immutable
import com.avek.chat.core.link.route.ConnectionState

/** What the rest of the app shows about the link (banner text, enabled composer…). */
@Immutable
data class ConnectionUi(
    val connected: Boolean = false,
    /** Short status line; null when everything is fine. */
    val banner: String? = null,
    /** The PC was never paired (or was revoked): the banner offers "Pair". */
    val needsPairing: Boolean = false,
    /** True while the built-in demo is the source. */
    val demo: Boolean = false,
    val serverName: String? = null,
    val routeName: String? = null,
) {
    companion object {
        fun from(state: ConnectionState, demo: Boolean): ConnectionUi = when {
            demo -> ConnectionUi(connected = true, demo = true, serverName = "Demo PC", routeName = "built-in demo")
            else -> when (state) {
                is ConnectionState.Connected -> ConnectionUi(connected = true, serverName = state.serverName, routeName = state.routeName)
                ConnectionState.NotPaired -> ConnectionUi(banner = "No PC paired yet.", needsPairing = true)
                ConnectionState.Disconnected -> ConnectionUi(banner = "Connecting…")
                is ConnectionState.Connecting -> ConnectionUi(
                    banner = if (state.retryInMs != null) "PC not reachable. Trying again in ${(state.retryInMs + 999) / 1000}s…" else "PC not reachable. Trying Wi-Fi…",
                )
                is ConnectionState.Failed -> ConnectionUi(banner = state.reason, needsPairing = true)
            }
        }
    }
}

/** "Connected · Wi-Fi 192.168.43.5:7810" / "Trying: last, discover, 2 hosts" for the Connection screen. */
fun describe(state: ConnectionState, demo: Boolean): String = when {
    demo -> "Demo mode: no PC needed"
    else -> when (state) {
        is ConnectionState.Connected -> "Connected to ${state.serverName} · ${state.routeName}"
        ConnectionState.NotPaired -> "Not paired"
        ConnectionState.Disconnected -> "Not connected"
        is ConnectionState.Connecting -> buildString {
            append("Trying: ").append(state.summary.ifBlank { "…" })
            if (state.retryInMs != null) append(" · next try in ${(state.retryInMs + 999) / 1000}s")
        }
        is ConnectionState.Failed -> state.reason
    }
}
