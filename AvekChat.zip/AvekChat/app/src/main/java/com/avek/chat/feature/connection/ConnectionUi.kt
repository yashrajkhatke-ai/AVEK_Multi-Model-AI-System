package com.avek.chat.feature.connection

import androidx.compose.runtime.Immutable
import com.avek.chat.core.link.route.ConnectionState
import com.avek.chat.core.link.route.FailureReason
import com.avek.chat.core.link.route.RouteFailure
import com.avek.chat.core.link.route.RouteKind
import com.avek.chat.core.link.route.RouteMessages

/** One line of "Can't reach your PC": the route, the reason in plain words. */
@Immutable
data class RouteLine(val route: RouteKind, val reason: FailureReason, val text: String)

/** The data of the full-screen "Can't reach your PC" state (UI-WIRE v4 section 2.3, item 5). */
@Immutable
data class UnreachableUi(
    val pcName: String,
    val lines: List<RouteLine>,
    val lastConnectedAt: Long?,
    val retryAtMs: Long?,
)

/** What the rest of the app shows about the link (banner text, enabled composer…). */
@Immutable
data class ConnectionUi(
    val connected: Boolean = false,
    /** Short status line; null when everything is fine. */
    val banner: String? = null,
    /** No PC is paired (or the PC forgot this device): the banner offers "Pair". */
    val needsPairing: Boolean = false,
    /** True while the built-in demo is the source. */
    val demo: Boolean = false,
    val serverName: String? = null,
    val address: String? = null,
    /** "Waking up your PC...": typing works, answers come later. */
    val waking: Boolean = false,
    /** Every route failed: the "Can't reach your PC" screen (or the slim banner after a drop). */
    val unreachable: UnreachableUi? = null,
    /** The link was up earlier in this app session: a drop shows the slim banner, not the full screen. */
    val droppedAfterConnect: Boolean = false,
) {
    companion object {
        const val WAKING = "Waking up your PC..."
        const val NOT_REACHABLE = "PC not reachable"

        fun from(state: ConnectionState, demo: Boolean, vpnActive: Boolean = false): ConnectionUi = when {
            demo -> ConnectionUi(connected = true, demo = true, serverName = "Demo PC", address = "built-in demo")
            else -> when (state) {
                is ConnectionState.Connected -> ConnectionUi(
                    connected = true,
                    serverName = state.pcName,
                    address = state.address,
                    waking = state.waking,
                    banner = if (state.waking) WAKING else null,
                )
                is ConnectionState.NeedsPairing -> ConnectionUi(banner = state.notice ?: "No PC paired yet.", needsPairing = true)
                ConnectionState.Disconnected -> ConnectionUi(banner = "Not connected")
                is ConnectionState.Looking -> ConnectionUi(banner = "Looking for ${state.pcName}...", serverName = state.pcName)
                is ConnectionState.WakingPc -> ConnectionUi(banner = WAKING, serverName = state.pcName, waking = true)
                is ConnectionState.Unreachable -> ConnectionUi(
                    banner = NOT_REACHABLE,
                    serverName = state.pcName,
                    unreachable = UnreachableUi(state.pcName, routeLines(state.failures, vpnActive), state.lastConnectedAt, state.retryAtMs),
                )
                ConnectionState.Forgotten -> ConnectionUi(banner = FORGOTTEN, needsPairing = true)
                is ConnectionState.Failed -> ConnectionUi(banner = state.reason)
            }
        }

        /** One line per route (Wi-Fi, Tailscale, ngrok) with the reason in plain words. */
        fun routeLines(failures: List<RouteFailure>, vpnActive: Boolean): List<RouteLine> = RouteKind.entries.map { route ->
            val failure = failures.firstOrNull { it.route == route }
            if (failure == null) {
                RouteLine(route, FailureReason.Skipped, "Not tried")
            } else {
                RouteLine(route, failure.reason, reasonText(failure, vpnActive))
            }
        }

        fun reasonText(failure: RouteFailure, vpnActive: Boolean): String = when (failure.reason) {
            FailureReason.NotFound ->
                if (failure.route == RouteKind.TAILSCALE && vpnActive) RouteMessages.OTHER_VPN_SENTENCE else RouteMessages.NOT_FOUND
            FailureReason.Refused -> RouteMessages.REFUSED
            FailureReason.Denied -> failure.message.ifBlank { RouteMessages.DENIED }
            FailureReason.Timeout ->
                if (failure.route == RouteKind.TAILSCALE && vpnActive) RouteMessages.OTHER_VPN_SENTENCE else RouteMessages.TIMEOUT
            FailureReason.Skipped -> failure.message.ifBlank { RouteMessages.NOT_SET_UP }
            FailureReason.Error -> failure.message.ifBlank { "Something went wrong" }
        }

        const val FORGOTTEN = RouteMessages.FORGOTTEN
        const val OLDER_HARNESS = "This PC runs an older AVEK. Update it to 0.0.8 for the thinking section."
    }
}

/** The status line of the Connection screen (section 13). */
fun describe(state: ConnectionState, demo: Boolean, nowMs: Long = System.currentTimeMillis()): String = when {
    demo -> "Demo mode: no PC needed"
    else -> when (state) {
        is ConnectionState.Connected ->
            if (state.waking) ConnectionUi.WAKING else "Connected to ${state.pcName} by ${state.route.label}"
        is ConnectionState.NeedsPairing -> state.notice ?: "Not paired"
        ConnectionState.Disconnected -> "Not connected"
        is ConnectionState.Looking -> "Looking for ${state.pcName}..."
        is ConnectionState.WakingPc -> ConnectionUi.WAKING
        is ConnectionState.Unreachable -> {
            val retryIn = state.retryAtMs?.let { ((it - nowMs) + 999) / 1000 }
            if (retryIn != null && retryIn > 0) "PC not reachable - trying again in $retryIn s" else "PC not reachable"
        }
        ConnectionState.Forgotten -> ConnectionUi.FORGOTTEN
        is ConnectionState.Failed -> state.reason
    }
}

/** "Last connected 3 hours ago" / "Never connected". */
fun lastConnectedText(at: Long?, nowMs: Long = System.currentTimeMillis()): String {
    if (at == null) return "Never connected"
    val minutes = ((nowMs - at).coerceAtLeast(0)) / 60_000
    return when {
        minutes < 1 -> "Last connected just now"
        minutes < 60 -> "Last connected $minutes ${if (minutes == 1L) "minute" else "minutes"} ago"
        minutes < 60 * 24 -> (minutes / 60).let { "Last connected $it ${if (it == 1L) "hour" else "hours"} ago" }
        else -> (minutes / (60 * 24)).let { "Last connected $it ${if (it == 1L) "day" else "days"} ago" }
    }
}
