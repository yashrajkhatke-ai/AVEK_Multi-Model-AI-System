package com.avek.chat.core.domain.usecase

import com.avek.chat.core.model.TaskMode
import javax.inject.Inject

/**
 * Lightweight, deterministic router used by [TaskMode.AUTO]. It scores a prompt
 * against weighted signals for every concrete task and returns the winner,
 * falling back to [TaskMode.GENERAL] when nothing stands out.
 */
class TaskClassifier @Inject constructor() {

    private data class Signal(val pattern: Regex, val weight: Int)

    private fun signals(weight: Int, vararg words: String): List<Signal> =
        words.map { Signal(Regex("\\b${Regex.escape(it)}\\b", RegexOption.IGNORE_CASE), weight) }

    private val table: Map<TaskMode, List<Signal>> = mapOf(
        TaskMode.CODING to signals(
            3, "code", "function", "bug", "debug", "compile", "compiler", "stack trace", "exception",
            "refactor", "regex", "kotlin", "python", "java", "javascript", "typescript", "rust", "golang",
            "swift", "sql", "api", "endpoint", "unit test", "jetpack compose", "android", "react", "algorithm",
        ) + signals(2, "class", "method", "variable", "null", "crash", "error", "script", "implement", "git") +
            listOf(Signal(Regex("```"), 6), Signal(Regex("[{};]\\s*$", RegexOption.MULTILINE), 2)),
        TaskMode.DEEP_RESEARCH to signals(
            3, "research", "sources", "cite", "citations", "literature", "studies", "evidence", "deep dive",
            "comprehensive", "report on", "state of", "landscape", "market", "trends", "history of",
        ) + signals(2, "compare", "latest", "investigate", "survey", "overview of"),
        TaskMode.WRITING to signals(
            3, "write", "draft", "rewrite", "essay", "email", "letter", "cover letter", "blog", "poem",
            "story", "proofread", "tone", "paragraph", "headline", "copy", "speech", "caption",
        ) + signals(2, "edit", "polish", "shorten", "summarize"),
        TaskMode.ANALYSIS to signals(
            3, "analyze", "analyse", "analysis", "pros and cons", "trade-off", "tradeoff", "evaluate",
            "should i", "decide", "decision", "metrics", "strategy", "swot", "risk",
        ) + signals(2, "data", "compare", "which is better", "versus", "vs"),
        TaskMode.MATH to signals(
            3, "solve", "equation", "integral", "derivative", "probability", "prove", "proof", "calculate",
            "math", "algebra", "geometry", "matrix", "theorem", "statistics",
        ) + listOf(Signal(Regex("\\d+\\s*[-+*/^=]\\s*\\d+"), 4)),
        TaskMode.BRAINSTORM to signals(
            3, "ideas", "brainstorm", "names for", "name ideas", "suggest", "come up with", "ways to",
            "creative", "inspiration", "options for",
        ),
        TaskMode.LEARN to signals(
            3, "explain", "teach me", "how does", "what is", "what are", "why does", "eli5", "understand",
            "intuition", "learn", "difference between",
        ),
    )

    fun scores(prompt: String): Map<TaskMode, Int> =
        table.mapValues { (_, signals) -> signals.sumOf { s -> if (s.pattern.containsMatchIn(prompt)) s.weight else 0 } }

    fun classify(prompt: String): TaskMode {
        if (prompt.isBlank()) return TaskMode.GENERAL
        val best = scores(prompt).maxByOrNull { it.value } ?: return TaskMode.GENERAL
        return if (best.value >= MIN_CONFIDENCE) best.key else TaskMode.GENERAL
    }

    private companion object {
        const val MIN_CONFIDENCE = 3
    }
}
