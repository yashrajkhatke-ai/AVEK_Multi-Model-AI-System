package com.avek.chat.di

import android.content.Context
import com.avek.chat.core.data.lock.FileLockStore
import com.avek.chat.core.domain.lock.AppLockManager
import com.avek.chat.core.domain.lock.LockClock
import com.avek.chat.core.link.DefaultLinkRepository
import com.avek.chat.core.link.PcControl
import dagger.Binds
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import java.io.File
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class LockBindingsModule {
    @Binds @Singleton abstract fun bindLockClock(impl: com.avek.chat.platform.android.AndroidLockClock): LockClock
    @Binds @Singleton abstract fun bindPcControl(impl: DefaultLinkRepository): PcControl
}

/** The app lock (UI-WIRE v4 section 13). `lock/` is excluded from backups. */
@Module
@InstallIn(SingletonComponent::class)
object LockModule {
    @Provides
    @Singleton
    fun provideAppLock(@ApplicationContext context: Context, clock: LockClock): AppLockManager =
        AppLockManager(FileLockStore(File(context.filesDir, "lock")), clock)
}
