package com.avek.chat.core.domain.usecase

import com.avek.chat.core.common.AppDispatchers
import com.avek.chat.core.common.IdGenerator
import com.avek.chat.core.common.TimeProvider
import com.avek.chat.core.domain.engine.GenerationEvent
import com.avek.chat.core.domain.engine.GenerationRequest
import com.avek.chat.core.domain.engine.InferenceEngine
import com.avek.chat.core.domain.repository.ConversationRepository
import com.avek.chat.core.domain.repository.ModelRepository
import com.avek.chat.core.model.Message
import com.avek.chat.core.model.MessageStatus
import com.avek.chat.core.model.Role
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import javax.inject.Inject

/**
 * Streams an assistant reply for the latest user turn of a conversation.
 *
 * The reply is persisted when it starts, periodically while streaming (so a
 * process death loses at most a fraction of a second), and once more when it
 * completes, is stopped by the user, or fails.
 */
class GenerateReplyUseCase @Inject constructor(
    private val repository: ConversationRepository,
    private val models: ModelRepository,
    private val engine: InferenceEngine,
    private val classifier: TaskClassifier,
    private val ids: IdGenerator,
    private val time: TimeProvider,
    private val dispatchers: AppDispatchers,
) {
    operator fun invoke(conversationId: String, options: ChatOptions): Flow<StreamingReply> = flow {
        val history = repository.getMessages(conversationId)
        val prompt = history.lastOrNull { it.isUser }?.content.orEmpty()
        val model = models.find(options.modelId)
        val depth = model.clampDepth(options.depth)
        val task = if (options.task.isAuto) classifier.classify(prompt) else options.task

        var message = Message(
            id = ids.newId(),
            conversationId = conversationId,
            role = Role.ASSISTANT,
            content = "",
            createdAt = maxOf(time.now(), (history.lastOrNull()?.createdAt ?: 0L) + 1),
            thinking = if (depth.thinks) "" else null,
            modelId = model.id,
            requestedTask = options.task,
            resolvedTask = task,
            depth = depth,
            status = MessageStatus.STREAMING,
        )
        var phase = if (depth.thinks) ReplyPhase.THINKING else ReplyPhase.ANSWERING
        var activity: String? = null

        repository.upsertMessage(message)
        emit(StreamingReply(message, phase, activity))

        val request = GenerationRequest(model, task, depth, prompt, history, options.speed)
        var lastPersist = time.now()
        try {
            engine.generate(request).collect { event ->
                when (event) {
                    is GenerationEvent.ThinkingStep -> {
                        activity = event.title
                        val existing = message.thinking.orEmpty()
                        val separator = if (existing.isEmpty()) "" else "\n\n"
                        message = message.copy(thinking = "$existing$separator**${event.title}**\n")
                    }
                    is GenerationEvent.ThinkingDelta ->
                        message = message.copy(thinking = message.thinking.orEmpty() + event.text)
                    is GenerationEvent.ThinkingFinished -> {
                        message = message.copy(thinkingDurationMs = event.durationMs)
                        phase = ReplyPhase.ANSWERING
                        activity = null
                    }
                    is GenerationEvent.SourceFound ->
                        message = message.copy(sources = message.sources + event.source)
                    is GenerationEvent.AnswerDelta -> {
                        phase = ReplyPhase.ANSWERING
                        message = message.copy(content = message.content + event.text)
                    }
                    GenerationEvent.Finished -> Unit
                }
                emit(StreamingReply(message, phase, activity))

                val now = time.now()
                if (now - lastPersist >= PERSIST_INTERVAL_MS) {
                    repository.upsertMessage(message)
                    lastPersist = now
                }
            }
            message = message.copy(status = MessageStatus.COMPLETE)
            finish(message, options)
            emit(StreamingReply(message, ReplyPhase.DONE, null))
        } catch (cancellation: CancellationException) {
            withContext(NonCancellable) { finish(message.copy(status = MessageStatus.STOPPED), options) }
            throw cancellation
        } catch (error: Exception) {
            withContext(NonCancellable) { finish(message.copy(status = MessageStatus.ERROR), options) }
            throw error
        }
    }.flowOn(dispatchers.default)

    private suspend fun finish(message: Message, options: ChatOptions) {
        repository.upsertMessage(message)
        repository.refreshSummary(message.conversationId, message.modelId ?: options.modelId, options.task)
    }

    private companion object {
        const val PERSIST_INTERVAL_MS = 750L
    }
}
