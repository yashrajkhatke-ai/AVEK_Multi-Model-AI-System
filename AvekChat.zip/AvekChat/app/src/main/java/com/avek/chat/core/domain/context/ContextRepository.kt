package com.avek.chat.core.domain.context

import com.avek.chat.core.link.HarnessApi
import com.avek.chat.core.link.LinkRepository
import com.avek.chat.core.link.wire.ContextDataDto
import com.avek.chat.core.link.wire.LinkEvent
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

/** Blue below 70 %, yellow from 70 %, red from 85 % (the app's thresholds, UI-WIRE section 13). */
object ContextThresholds {
    const val YELLOW = 0.70f
    const val RED = 0.85f

    enum class Level { BLUE, YELLOW, RED }

    /** Used / circle; null when there is nothing to draw. May exceed 1 (the popup shows the real value). */
    fun fraction(data: ContextDataDto?): Float? =
        if (data == null || data.circleTokens <= 0) null else data.usedTokens.toFloat() / data.circleTokens

    fun level(fraction: Float): Level = when {
        fraction >= RED -> Level.RED
        fraction >= YELLOW -> Level.YELLOW
        else -> Level.BLUE
    }

    /** Degrees of the pie, clockwise from 12 o'clock; the drawing stops at the full circle. */
    fun sweep(fraction: Float): Float = 360f * fraction.coerceIn(0f, 1f)
}

/**
 * The context circle of the open chat (UI-WIRE 9a): `context.get` when a chat opens, when the
 * model changes and after a reconnect; then every `chat.context` for that chat replaces it.
 */
class ContextRepository(
    private val link: LinkRepository,
    private val api: HarnessApi,
    private val scope: CoroutineScope,
) {
    private val _current = MutableStateFlow<ContextDataDto?>(null)
    val current: StateFlow<ContextDataDto?> = _current

    @Volatile
    private var chatId: String? = null

    @Volatile
    private var modelId: String? = null

    fun start() {
        scope.launch {
            link.events.collect { event ->
                when (event) {
                    is LinkEvent.ChatContext -> if (event.data.chatId == chatId) _current.value = event.data
                    is LinkEvent.Refresh -> refresh()
                    else -> Unit
                }
            }
        }
    }

    /**
     * The chat on screen and the model in its chip. A new chat (no id) is sized from the model's
     * card ([newChatCircleTokens]) with nothing used.
     */
    fun show(chatId: String?, modelId: String?, modelName: String?, newChatCircleTokens: Int?) {
        val changed = chatId != this.chatId || modelId != this.modelId
        this.chatId = chatId
        this.modelId = modelId
        if (chatId == null) {
            _current.value = newChatCircleTokens?.takeIf { it > 0 }?.let { ContextDataDto(chatId = "", modelId = modelId, modelName = modelName, circleTokens = it) }
            return
        }
        if (changed) {
            if (_current.value?.chatId != chatId) _current.value = null
            refresh()
        }
    }

    fun refresh() {
        val id = chatId ?: return
        val model = modelId
        if (api.revision < 2) return
        scope.launch {
            try {
                val data = api.contextGet(id, model)
                if (data.chatId == chatId || data.chatId.isEmpty()) _current.value = data.copy(chatId = id)
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
            }
        }
    }
}
