package com.avek.chat.feature.downloads

import androidx.compose.runtime.Immutable
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.avek.chat.core.data.downloads.DownloadManager
import com.avek.chat.core.data.downloads.DownloadedChatInfo
import com.avek.chat.core.domain.chat.OpenChatBus
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@Immutable
data class DownloadsUiState(
    val chats: List<DownloadedChatInfo> = emptyList(),
    val loading: Boolean = true,
) {
    val totalBytes: Long get() = chats.sumOf { it.sizeBytes }
}

@HiltViewModel
class DownloadsViewModel @Inject constructor(
    private val downloads: DownloadManager,
    private val openChat: OpenChatBus,
) : ViewModel() {

    val uiState: StateFlow<DownloadsUiState> = downloads.info
        .map { DownloadsUiState(it.sortedByDescending { chat -> chat.chat.updatedAt }, loading = false) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), DownloadsUiState())

    fun open(chatId: String) = openChat.open(chatId)

    fun remove(chatId: String) {
        viewModelScope.launch {
            try {
                downloads.remove(chatId)
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
                // The local copy is already gone; the PC is told on the next connection.
            }
        }
    }

    fun removeAll() {
        viewModelScope.launch {
            try {
                downloads.removeAll()
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
            }
        }
    }
}
