package com.avek.chat.core.model

/**
 * What kind of work the assistant should optimise for. [AUTO] lets the
 * task router classify every message individually.
 */
enum class TaskMode(
    val label: String,
    val tagline: String,
    /** The `options.mode` / `mode` value of the wire protocol. */
    val wire: String,
    val isAuto: Boolean = false,
) {
    AUTO("Auto", "The PC picks the best mode for every message", "auto", isAuto = true),
    GENERAL("General", "Everyday questions and conversation", "general"),
    DEEP_RESEARCH("Deep research", "Multi-step investigation with cited sources", "research"),
    CODING("Coding", "Write, review, refactor and debug code", "coding"),
    WRITING("Writing", "Drafts, edits, tone and structure", "writing"),
    ANALYSIS("Analysis", "Reason through data, trade-offs and decisions", "analysis"),
    MATH("Math", "Rigorous step-by-step problem solving", "math"),
    BRAINSTORM("Brainstorm", "Divergent ideas, angles and options", "brainstorm"),
    LEARN("Learn", "Explanations that build real intuition", "learn");

    companion object {
        val concrete: List<TaskMode> = entries.filterNot { it.isAuto }

        fun fromName(name: String?): TaskMode =
            entries.firstOrNull { it.name == name } ?: AUTO

        /** Unknown modes from a newer PC fall back to [AUTO]. */
        fun fromWire(mode: String?): TaskMode =
            entries.firstOrNull { it.wire == mode } ?: AUTO
    }
}
