package com.avek.chat.core.model

/**
 * What kind of work the assistant should optimise for. [AUTO] lets the
 * task router classify every message individually.
 */
enum class TaskMode(
    val label: String,
    val tagline: String,
    val isAuto: Boolean = false,
) {
    AUTO("Auto", "Detects the best mode for every message", isAuto = true),
    GENERAL("General", "Everyday questions and conversation"),
    DEEP_RESEARCH("Deep research", "Multi-step investigation with cited sources"),
    CODING("Coding", "Write, review, refactor and debug code"),
    WRITING("Writing", "Drafts, edits, tone and structure"),
    ANALYSIS("Analysis", "Reason through data, trade-offs and decisions"),
    MATH("Math", "Rigorous step-by-step problem solving"),
    BRAINSTORM("Brainstorm", "Divergent ideas, angles and options"),
    LEARN("Learn", "Explanations that build real intuition");

    companion object {
        val concrete: List<TaskMode> = entries.filterNot { it.isAuto }

        fun fromName(name: String?): TaskMode =
            entries.firstOrNull { it.name == name } ?: AUTO
    }
}
