package com.avek.chat.feature.customize

import com.avek.chat.core.model.settings.FontChoice
import com.avek.chat.core.model.settings.FontChoice.Companion.google
import com.avek.chat.core.model.settings.FontRole
import com.avek.chat.core.model.settings.FontSettings

/** A named, curated set of fonts for every role. Applying one keeps sizes. */
data class FontPairing(
    val name: String,
    val description: String,
    val fonts: Map<FontRole, FontChoice>,
) {
    fun applyTo(settings: FontSettings): FontSettings =
        fonts.entries.fold(settings) { acc, (role, font) -> acc.with(role, acc[role].copy(font = font)) }
}

object FontPairings {
    private fun pairing(
        name: String,
        description: String,
        ui: FontChoice,
        heading: FontChoice,
        user: FontChoice,
        answer: FontChoice,
        thinking: FontChoice,
        code: FontChoice,
    ) = FontPairing(
        name,
        description,
        mapOf(
            FontRole.INTERFACE to ui,
            FontRole.HEADING to heading,
            FontRole.USER_MESSAGE to user,
            FontRole.ANSWER to answer,
            FontRole.THINKING to thinking,
            FontRole.CODE to code,
        ),
    )

    val all: List<FontPairing> = listOf(
        pairing("Avek", "Calm serif answers, crisp sans UI", google("Inter"), google("Newsreader"), google("Inter"), google("Source Serif 4"), google("Inter"), google("JetBrains Mono")),
        pairing("Editorial", "Magazine-grade contrast", google("Inter"), google("Playfair Display"), google("Inter"), google("Lora"), google("Lora"), google("IBM Plex Mono")),
        pairing("Modern", "Geometric and confident", google("Manrope"), google("Bricolage Grotesque"), google("Manrope"), google("Manrope"), google("DM Sans"), google("Geist Mono")),
        pairing("Technical", "Engineered, precise", google("IBM Plex Sans"), google("IBM Plex Sans"), google("IBM Plex Sans"), google("IBM Plex Serif"), google("IBM Plex Sans"), google("IBM Plex Mono")),
        pairing("Literary", "Bookish and timeless", google("Lato"), google("Cormorant Garamond"), google("Lato"), google("EB Garamond"), google("Crimson Pro"), google("Fira Code")),
        pairing("Friendly", "Rounded and warm", google("Nunito"), google("Quicksand"), google("Nunito"), google("Nunito"), google("Shantell Sans"), google("Fira Code")),
        pairing("Handwritten", "Notebook vibes", google("Lexend"), google("Caveat"), google("Patrick Hand"), google("Kalam"), google("Caveat"), google("Victor Mono")),
        pairing("Terminal", "Monospace everything", google("JetBrains Mono"), google("Space Mono"), google("JetBrains Mono"), google("IBM Plex Mono"), google("Martian Mono"), google("JetBrains Mono")),
        pairing("Accessible", "Maximum legibility", google("Atkinson Hyperlegible"), google("Atkinson Hyperlegible"), google("Atkinson Hyperlegible"), google("Atkinson Hyperlegible"), google("Lexend"), google("Fira Code")),
        pairing("Studio", "Contemporary display", google("Figtree"), google("Instrument Serif"), google("Figtree"), google("Literata"), google("Figtree"), google("Geist Mono")),
        pairing("System", "Built-in fonts, works offline", FontChoice.SystemSans, FontChoice.SystemSerif, FontChoice.SystemSans, FontChoice.SystemSerif, FontChoice.SystemSans, FontChoice.SystemMono),
    )
}
