package com.avek.chat.feature.chat.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.Build
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.Code
import androidx.compose.material.icons.outlined.Functions
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.Insights
import androidx.compose.material.icons.outlined.Language
import androidx.compose.material.icons.outlined.Lightbulb
import androidx.compose.material.icons.outlined.Memory
import androidx.compose.material.icons.outlined.Psychology
import androidx.compose.material.icons.outlined.School
import androidx.compose.material.icons.outlined.TravelExplore
import androidx.compose.material.icons.outlined.ViewAgenda
import androidx.compose.material.icons.outlined.EditNote
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.avek.chat.core.designsystem.theme.AvekTheme
import com.avek.chat.core.designsystem.theme.avekPill
import com.avek.chat.core.designsystem.theme.avekShape
import com.avek.chat.core.model.ModelLoadState
import com.avek.chat.core.model.RemoteModel

/** A meter of a card: label and 1..5 value. */
@Immutable
data class CardMeter(val label: String, val value: Int, val slim: Boolean) {
    val description: String get() = "$label $value of 5"
}

@Immutable
data class CardChip(val key: String, val label: String)

/**
 * Everything a model card shows, derived the same way for every model (UI-WIRE v3 section 8.2:
 * one template, no per-model or per-kind decisions). The first chip is always the context chip.
 */
@Immutable
data class ModelCardContent(
    val id: String,
    val title: String,
    val badge: String?,
    val tagline: String,
    val description: String,
    val meters: List<CardMeter>,
    val chips: List<CardChip>,
    val state: ModelLoadState,
    val stateLabel: String?,
    val sizeLabel: String?,
    val speedLabel: String?,
) {
    companion object {
        fun from(model: RemoteModel): ModelCardContent {
            // The context chip comes first whatever order the list arrived in.
            val chips = model.capabilities.map { CardChip(it.key, it.label) }
                .sortedBy { if (it.key == CONTEXT_KEY) 0 else 1 }
            return ModelCardContent(
                id = model.id,
                title = model.name,
                badge = model.badge,
                tagline = model.tagline,
                description = model.description,
                meters = listOf(
                    CardMeter("Intelligence", model.intelligence.coerceIn(0, 5), slim = false),
                    CardMeter("Speed", model.speed.coerceIn(0, 5), slim = false),
                    CardMeter("Thinking", model.thinking.coerceIn(0, 5), slim = true),
                ),
                chips = chips,
                state = model.state,
                stateLabel = stateLabel(model.state),
                sizeLabel = model.sizeBytes.takeIf { it > 0 }?.let(::formatBytes),
                speedLabel = model.measuredTps?.let { "%.0f tok/s".format(it) },
            )
        }

        const val CONTEXT_KEY = "context"

        fun stateLabel(state: ModelLoadState): String? = when (state) {
            ModelLoadState.READY -> "Ready"
            ModelLoadState.LOADING -> "Loading"
            ModelLoadState.UNLOADED -> "Not loaded"
            ModelLoadState.ERROR -> "Error"
            ModelLoadState.UNKNOWN -> null
        }

        fun formatBytes(bytes: Long): String = when {
            bytes >= 1_000_000_000 -> "%.1f GB".format(bytes / 1_000_000_000.0)
            bytes >= 1_000_000 -> "${bytes / 1_000_000} MB"
            else -> "${bytes / 1000} KB"
        }
    }
}

/** An icon for a capability chip, by its key; anything unknown gets a neutral icon. */
fun chipIcon(key: String): ImageVector = when (key.lowercase()) {
    "context" -> Icons.Outlined.ViewAgenda
    "thinking" -> Icons.Outlined.Psychology
    "vision" -> Icons.Outlined.Image
    "tools" -> Icons.Outlined.Build
    "code", "coding" -> Icons.Outlined.Code
    "multilingual" -> Icons.Outlined.Language
    "research" -> Icons.Outlined.TravelExplore
    "analysis" -> Icons.Outlined.Insights
    "math" -> Icons.Outlined.Functions
    "writing" -> Icons.Outlined.EditNote
    "learn" -> Icons.Outlined.School
    "brainstorm" -> Icons.Outlined.Lightbulb
    "general" -> Icons.Outlined.ChatBubbleOutline
    "memory" -> Icons.Outlined.Memory
    else -> Icons.Outlined.AutoAwesome
}

/** The one card used for every model. */
@Composable
fun ModelCard(model: RemoteModel, selected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val content = ModelCardContent.from(model)
    val colors = AvekTheme.colors
    val border by animateColorAsState(if (selected) colors.accent else colors.outline.copy(alpha = 0.7f), label = "model-border")
    Column(
        modifier
            .fillMaxWidth()
            .clip(avekShape(20.dp))
            .background(if (selected) colors.accentContainer else colors.surface)
            .border(if (selected) 1.5.dp else 1.dp, border, avekShape(20.dp))
            .clickable(onClick = onClick)
            .padding(16.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(content.title, style = AvekTheme.type.headline, color = colors.textPrimary, maxLines = 1)
            if (content.badge != null) {
                Spacer(Modifier.width(10.dp))
                Text(
                    content.badge,
                    style = AvekTheme.type.label.copy(fontWeight = FontWeight.SemiBold),
                    color = colors.accent,
                    maxLines = 1,
                    modifier = Modifier
                        .clip(avekPill())
                        .background(colors.accent.copy(alpha = 0.12f))
                        .padding(horizontal = 10.dp, vertical = 3.dp),
                )
            }
            Spacer(Modifier.weight(1f))
            if (selected) Icon(Icons.Filled.CheckCircle, contentDescription = "Selected", tint = colors.accent, modifier = Modifier.size(28.dp))
        }
        if (content.tagline.isNotBlank()) {
            Spacer(Modifier.height(4.dp))
            Text(content.tagline, style = AvekTheme.type.title.copy(fontWeight = FontWeight.Normal), color = colors.textSecondary)
        }
        AnimatedVisibility(selected && content.description.isNotBlank()) {
            Text(content.description, style = AvekTheme.type.body, color = colors.textSecondary, modifier = Modifier.padding(top = 6.dp))
        }
        Spacer(Modifier.height(14.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(28.dp)) {
            content.meters.forEach { Meter(it) }
        }
        Spacer(Modifier.height(14.dp))
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            content.chips.forEach { CapabilityChip(it) }
        }
        if (content.stateLabel != null || content.sizeLabel != null || content.speedLabel != null) {
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (content.stateLabel != null) {
                    ModelStateDot(content.state, Modifier.size(10.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(content.stateLabel, style = AvekTheme.type.caption, color = colors.textSecondary)
                }
                listOfNotNull(content.sizeLabel, content.speedLabel).forEach {
                    Text("  ·  $it", style = AvekTheme.type.caption, color = colors.textTertiary)
                }
            }
        }
    }
}

@Composable
private fun Meter(meter: CardMeter) {
    val colors = AvekTheme.colors
    Column(Modifier.semantics(mergeDescendants = true) { contentDescription = meter.description }) {
        Text(meter.label, style = AvekTheme.type.body, color = colors.textSecondary)
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(if (meter.slim) 3.dp else 5.dp)) {
            repeat(5) { i ->
                val on = i < meter.value
                Box(
                    Modifier
                        .size(width = if (meter.slim) 6.dp else 18.dp, height = if (meter.slim) 14.dp else 14.dp)
                        .clip(avekShape(if (meter.slim) 3.dp else 4.dp))
                        .background(if (on) colors.accent else colors.accent.copy(alpha = 0.16f)),
                )
            }
        }
    }
}

@Composable
private fun CapabilityChip(chip: CardChip) {
    val colors = AvekTheme.colors
    Row(
        Modifier
            .clip(avekPill())
            .background(colors.textPrimary.copy(alpha = 0.05f))
            .padding(horizontal = 12.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(chipIcon(chip.key), contentDescription = null, tint = colors.textSecondary, modifier = Modifier.size(16.dp))
        Spacer(Modifier.width(6.dp))
        Text(chip.label, style = AvekTheme.type.body, color = colors.textSecondary)
    }
}

/** Grey = not loaded, spinner = loading, green = ready, red = error, nothing = unknown. */
@Composable
fun ModelStateDot(state: ModelLoadState, modifier: Modifier = Modifier) {
    val colors = AvekTheme.colors
    when (state) {
        ModelLoadState.LOADING -> CircularProgressIndicator(modifier, color = colors.accent, strokeWidth = 1.5.dp)
        ModelLoadState.UNKNOWN -> Unit
        else -> Box(
            modifier
                .clip(CircleShape)
                .background(
                    when (state) {
                        ModelLoadState.READY -> Color(0xFF2E9E5B)
                        ModelLoadState.ERROR -> colors.danger
                        else -> colors.textTertiary.copy(alpha = 0.6f)
                    },
                ),
        )
    }
}
