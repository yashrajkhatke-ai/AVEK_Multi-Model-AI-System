package com.avek.chat.feature.connection

import androidx.compose.runtime.Immutable
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.avek.chat.core.domain.repository.SettingsRepository
import com.avek.chat.core.link.LinkRepository
import com.avek.chat.core.link.PcControl
import com.avek.chat.core.link.RekeyOutcome
import com.avek.chat.core.link.crypto.AvekProtocol
import com.avek.chat.core.link.route.ConnectionState
import com.avek.chat.core.link.route.NetworkEnvironment
import com.avek.chat.core.link.route.RouteKind
import com.avek.chat.core.link.route.RouteMode
import com.avek.chat.core.link.store.PairedPcStore
import com.avek.chat.core.link.wire.RoutesData
import com.avek.chat.core.model.settings.ConnectionSettings
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

/** The routes as Settings → Connection shows them (section 8.9): only what the PC sent. */
@Immutable
data class RoutesUi(
    val wifiAddresses: List<String> = emptyList(),
    val tailscaleName: String? = null,
    val tailscaleInstalled: Boolean = false,
    val ngrokUrl: String? = null,
    val ngrokState: String? = null,
    val ngrokError: String? = null,
) {
    companion object {
        fun from(routes: RoutesData?, tailscaleInstalled: Boolean) = RoutesUi(
            wifiAddresses = routes?.wifi?.addresses?.map { a -> if (a.`interface`.isBlank()) a.address else "${a.address} (${a.`interface`})" }.orEmpty(),
            tailscaleName = routes?.tailscale?.let { it.dns?.takeIf { d -> d.isNotBlank() } ?: it.host.takeIf { h -> h.isNotBlank() } },
            tailscaleInstalled = tailscaleInstalled,
            ngrokUrl = routes?.ngrok?.url?.takeIf { it.isNotBlank() },
            ngrokState = routes?.ngrok?.state?.takeIf { it.isNotBlank() },
            ngrokError = routes?.ngrok?.error?.takeIf { it.isNotBlank() },
        )
    }
}

/** "Replace this device's keys": progress and result. */
sealed interface RekeyUi {
    data object Idle : RekeyUi
    data object Running : RekeyUi
    data object Done : RekeyUi
    data object Pending : RekeyUi
    data class Failed(val message: String) : RekeyUi
}

@Immutable
data class ConnectionScreenState(
    val settings: ConnectionSettings = ConnectionSettings(),
    val paired: Paired? = null,
    val status: String = "",
    val connected: Boolean = false,
    val demo: Boolean = false,
    /** The PC no longer knows this device: offer "Pair again" (the grant is kept until then). */
    val forgotten: Boolean = false,
    /** The loop stopped on something only the person can fix (wrong PC). */
    val failed: Boolean = false,
    val notice: String? = null,
    val routeInUse: RouteKind? = null,
    val routes: RoutesUi = RoutesUi(),
    val routeMode: RouteMode = RouteMode.Auto,
    val rekey: RekeyUi = RekeyUi.Idle,
) {
    @Immutable
    data class Paired(val serverName: String, val serverId: String, val deviceName: String, val deviceId: String, val fingerprint: String?)
}

/**
 * Settings → Connection (UI-WIRE v4 section 13): a status line, the routes and the one in use, the
 * route setting, Reconnect, Replace this device's keys, Forget this PC.
 */
@HiltViewModel
class ConnectionViewModel @Inject constructor(
    private val settingsRepository: SettingsRepository,
    private val store: PairedPcStore,
    private val link: LinkRepository,
    private val control: PcControl,
    private val environment: NetworkEnvironment,
) : ViewModel() {

    private val _messages = Channel<String>(Channel.BUFFERED)
    val messages: Flow<String> = _messages.receiveAsFlow()

    private val rekey = MutableStateFlow<RekeyUi>(RekeyUi.Idle)

    /** Ticks every second, only while "trying again in 8 s" is counting down. */
    private val clock: Flow<Long> = link.state.flatMapLatest { state ->
        if (state is ConnectionState.Unreachable && state.retryAtMs != null) {
            flow {
                while (true) {
                    emit(System.currentTimeMillis())
                    delay(1_000)
                }
            }
        } else {
            flowOf(System.currentTimeMillis())
        }
    }

    val uiState: StateFlow<ConnectionScreenState> = combine(
        settingsRepository.settings, store.pc, link.state, clock, rekey,
    ) { settings, pc, state, now, rekeyState ->
        val demo = settings.connection.demoMode
        ConnectionScreenState(
            settings = settings.connection,
            paired = pc?.let {
                ConnectionScreenState.Paired(
                    it.serverName,
                    it.serverId,
                    it.deviceName,
                    it.deviceId,
                    runCatching { AvekProtocol.fingerprintText(it.serverPub) }.getOrNull(),
                )
            },
            status = describe(state, demo, now),
            connected = demo || state is ConnectionState.Connected,
            demo = demo,
            forgotten = !demo && state is ConnectionState.Forgotten,
            failed = !demo && state is ConnectionState.Failed,
            notice = (state as? ConnectionState.NeedsPairing)?.notice,
            routeInUse = (state as? ConnectionState.Connected)?.route?.takeIf { !demo },
            routes = RoutesUi.from(pc?.routes, environment.tailscaleInstalled()),
            routeMode = RouteMode.entries.firstOrNull { it.name == settings.connection.routeMode } ?: RouteMode.Auto,
            rekey = rekeyState,
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), ConnectionScreenState())

    fun reconnect() = link.reconnect()

    fun setRouteMode(mode: RouteMode) = updateConnection { it.copy(routeMode = mode.name) }

    /** "Replace this device's keys" (section 4.1), after the confirm dialog. */
    fun replaceKeys() {
        if (rekey.value == RekeyUi.Running) return
        rekey.value = RekeyUi.Running
        viewModelScope.launch {
            rekey.value = when (val outcome = control.replaceKeys()) {
                RekeyOutcome.Done -> RekeyUi.Done
                RekeyOutcome.Pending -> RekeyUi.Pending
                is RekeyOutcome.Failed -> RekeyUi.Failed(outcome.message)
            }
        }
    }

    fun dismissRekey() {
        if (rekey.value != RekeyUi.Running) rekey.value = RekeyUi.Idle
    }

    /** "Forget this PC": tells the PC when connected, then deletes the keys, the sealed secrets and the stored PC. */
    fun forget() {
        viewModelScope.launch {
            control.forget()
            _messages.trySend("This PC was forgotten")
        }
    }

    fun setWorkInBackground(enabled: Boolean) = updateConnection { it.copy(workInBackground = enabled) }

    fun setDemoMode(enabled: Boolean) = updateConnection { it.copy(demoMode = enabled) }

    fun setKeepListsSeconds(seconds: Int) = updateConnection {
        it.copy(keepListsSeconds = seconds.coerceIn(ConnectionSettings.MIN_KEEP_LISTS_SECONDS, ConnectionSettings.MAX_KEEP_LISTS_SECONDS))
    }

    private fun updateConnection(transform: (ConnectionSettings) -> ConnectionSettings) {
        viewModelScope.launch { settingsRepository.update { it.copy(connection = transform(it.connection)) } }
    }
}
