package com.avek.chat.feature.connection

import androidx.compose.runtime.Immutable
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.avek.chat.core.common.DeviceInfo
import com.avek.chat.core.domain.repository.SettingsRepository
import com.avek.chat.core.link.HarnessApi
import com.avek.chat.core.link.LinkRepository
import com.avek.chat.core.link.crypto.HandshakeException
import com.avek.chat.core.link.discovery.DiscoveredServer
import com.avek.chat.core.link.pairing.PairingManager
import com.avek.chat.core.link.route.ConnectionState
import com.avek.chat.core.link.store.PairedPcStore
import com.avek.chat.core.link.transport.HostPort
import com.avek.chat.core.model.settings.ConnectionSettings
import com.avek.chat.core.model.settings.RouteSpec
import com.avek.chat.core.model.settings.UserSettings
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.IOException
import javax.inject.Inject

/** The pairing dialog of the Connection screen. */
@Immutable
data class PairingForm(
    val discovered: List<DiscoveredServer> = emptyList(),
    /** Which discovered PC is chosen (by `serverId`); null = use the typed address. */
    val selectedServerId: String? = null,
    val manualAddress: String = "",
    /** The code as typed, uppercase with a dash after every 4 characters. */
    val code: String = "",
    val deviceName: String = "",
    val busy: Boolean = false,
    val error: String? = null,
    /** Set once pairing worked: the PC's name. */
    val pairedWith: String? = null,
) {
    val codeComplete: Boolean get() = code.count { it != '-' } == CODE_LENGTH
    val hasTarget: Boolean get() = selectedServerId != null || HostPort.parse(manualAddress) != null
    val canPair: Boolean get() = !busy && codeComplete && hasTarget && deviceName.isNotBlank()

    companion object {
        const val CODE_LENGTH = 12

        /** Uppercases, keeps letters and digits, stops at 12 and puts a dash after every 4. */
        fun formatCode(raw: String): String =
            raw.uppercase().filter { it.isLetterOrDigit() }.take(CODE_LENGTH).chunked(4).joinToString("-")
    }
}

@Immutable
data class ConnectionScreenState(
    val settings: ConnectionSettings = ConnectionSettings(),
    val paired: Paired? = null,
    val status: String = "",
    val connected: Boolean = false,
    val demo: Boolean = false,
    /** Non-null while the pairing dialog is open. */
    val form: PairingForm? = null,
) {
    @Immutable
    data class Paired(val serverName: String, val deviceName: String, val address: String?)
}

@HiltViewModel
class ConnectionViewModel @Inject constructor(
    private val settingsRepository: SettingsRepository,
    private val store: PairedPcStore,
    private val pairing: PairingManager,
    private val link: LinkRepository,
    private val api: HarnessApi,
    private val device: DeviceInfo,
) : ViewModel() {

    private val form = MutableStateFlow<PairingForm?>(null)
    private var discovery: Job? = null

    private val _messages = Channel<String>(Channel.BUFFERED)
    val messages: Flow<String> = _messages.receiveAsFlow()

    val uiState: StateFlow<ConnectionScreenState> = combine(
        settingsRepository.settings, store.pc, link.state, form,
    ) { settings: UserSettings, pc, state: ConnectionState, form ->
        val demo = settings.connection.demoMode
        ConnectionScreenState(
            settings = settings.connection,
            paired = pc?.let { ConnectionScreenState.Paired(it.serverName, it.deviceName, it.lastHost?.let { host -> "$host:${it.lastPort}" }) },
            status = describe(state, demo),
            connected = demo || state is ConnectionState.Connected,
            demo = demo,
            form = form,
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), ConnectionScreenState())

    // ------------------------------------------------------------------ pairing

    fun openPairing() {
        form.value = PairingForm(deviceName = device.model)
        discovery?.cancel()
        discovery = viewModelScope.launch {
            try {
                pairing.discover().collect { found ->
                    form.update { f ->
                        f?.copy(
                            discovered = found,
                            // A single PC on the network is the obvious choice.
                            selectedServerId = f.selectedServerId ?: found.singleOrNull()?.serverId.takeIf { f.manualAddress.isBlank() },
                        )
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
                // Discovery is a convenience; the manual address always works.
            }
        }
    }

    fun closePairing() {
        discovery?.cancel()
        form.value = null
    }

    fun selectServer(serverId: String) = form.update { it?.copy(selectedServerId = serverId, manualAddress = "", error = null) }

    fun onManualAddress(text: String) = form.update { it?.copy(manualAddress = text, selectedServerId = if (text.isBlank()) it.selectedServerId else null, error = null) }

    fun onCode(text: String) = form.update { it?.copy(code = PairingForm.formatCode(text), error = null) }

    fun onDeviceName(text: String) = form.update { it?.copy(deviceName = text.take(40), error = null) }

    fun pair() {
        val current = form.value ?: return
        if (!current.canPair) return
        val target = current.selectedServerId?.let { id -> current.discovered.firstOrNull { it.serverId == id }?.target }
            ?: HostPort.parse(current.manualAddress)
            ?: return
        form.update { it?.copy(busy = true, error = null) }
        viewModelScope.launch {
            try {
                val pc = pairing.pair(target, current.code, current.deviceName.trim())
                discovery?.cancel()
                form.update { it?.copy(busy = false, pairedWith = pc.serverName) }
                // Pairing succeeded: start using it.
                if (!uiState.value.demo) link.reconnect()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                form.update { it?.copy(busy = false, error = explain(e, target)) }
            }
        }
    }

    // ------------------------------------------------------------------ the paired PC

    fun reconnect() = link.reconnect()

    fun unpair() {
        viewModelScope.launch {
            // Tell the PC while we still can; wipe the secret either way.
            if (link.state.value is ConnectionState.Connected && !uiState.value.demo) {
                runCatching { api.deviceUnpair() }
            }
            link.disconnect()
            pairing.forget()
            _messages.trySend("Unpaired")
        }
    }

    // ------------------------------------------------------------------ settings

    fun setWorkInBackground(enabled: Boolean) = updateConnection { it.copy(workInBackground = enabled) }

    fun setDemoMode(enabled: Boolean) = updateConnection { it.copy(demoMode = enabled) }

    fun setKeepListsSeconds(seconds: Int) = updateConnection {
        it.copy(keepListsSeconds = seconds.coerceIn(ConnectionSettings.MIN_KEEP_LISTS_SECONDS, ConnectionSettings.MAX_KEEP_LISTS_SECONDS))
    }

    fun moveRoute(index: Int, delta: Int) = updateConnection { c ->
        val target = index + delta
        if (index !in c.routes.indices || target !in c.routes.indices) c
        else c.copy(routes = c.routes.toMutableList().also { list -> list.add(target, list.removeAt(index)) })
    }

    /** Adds a typed `ip:port`. Returns false (and says why) when it is not an address or already listed. */
    fun addHost(text: String): Boolean {
        val parsed = HostPort.parse(text)
        if (parsed == null) {
            _messages.trySend("Enter an address like 192.168.43.5 or 192.168.43.5:7810")
            return false
        }
        val spec = RouteSpec.Host(parsed.host, parsed.port)
        if (uiState.value.settings.routes.contains(spec)) {
            _messages.trySend("That address is already in the list")
            return false
        }
        updateConnection { it.copy(routes = it.routes + spec) }
        return true
    }

    fun removeRoute(index: Int) = updateConnection { c ->
        if (c.routes.getOrNull(index) is RouteSpec.Host) c.copy(routes = c.routes.filterIndexed { i, _ -> i != index }) else c
    }

    private fun updateConnection(transform: (ConnectionSettings) -> ConnectionSettings) {
        viewModelScope.launch { settingsRepository.update { it.copy(connection = transform(it.connection)) } }
    }

    private fun explain(e: Throwable, target: HostPort): String = when (e) {
        is HandshakeException.Denied -> when (e.reason) {
            "bad-code" -> "That code is not right. Check it on the laptop."
            "expired" -> "The code expired. Run pair.ts again for a new one."
            "no-code" -> "The PC has no active code. Run pair.ts first."
            "rate-limited" -> "Too many wrong tries. Run pair.ts again for a new code."
            else -> "The PC refused: ${e.reason}"
        }
        is HandshakeException.Timeout -> "The PC did not answer in time."
        is HandshakeException.ClosedByPeer -> "The PC closed the connection (${e.reason.ifBlank { e.code.toString() }})."
        is HandshakeException.UntrustedServer -> "That PC could not prove its identity."
        is HandshakeException -> e.message ?: "Pairing failed."
        is IOException -> "Could not reach $target. Is the phone on the same Wi-Fi?"
        else -> e.message ?: "Pairing failed."
    }
}
