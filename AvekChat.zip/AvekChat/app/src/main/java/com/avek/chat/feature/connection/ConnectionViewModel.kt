package com.avek.chat.feature.connection

import androidx.compose.runtime.Immutable
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.avek.chat.core.domain.repository.SettingsRepository
import com.avek.chat.core.link.HarnessApi
import com.avek.chat.core.link.LinkRepository
import com.avek.chat.core.link.crypto.AvekProtocol
import com.avek.chat.core.link.pairing.PairingManager
import com.avek.chat.core.link.route.ConnectionState
import com.avek.chat.core.link.store.PairedPcStore
import com.avek.chat.core.model.settings.ConnectionSettings
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@Immutable
data class ConnectionScreenState(
    val settings: ConnectionSettings = ConnectionSettings(),
    val paired: Paired? = null,
    val status: String = "",
    val address: String? = null,
    val connected: Boolean = false,
    val demo: Boolean = false,
    /** The PC no longer knows this device: offer "Pair again" (the grant is kept until then). */
    val forgotten: Boolean = false,
    /** The loop stopped on something only the person can fix (wrong PC). */
    val failed: Boolean = false,
    val notice: String? = null,
) {
    @Immutable
    data class Paired(val serverName: String, val serverId: String, val deviceName: String, val fingerprint: String?)
}

/** Settings → Connection (UI-WIRE v3 section 13): a status line, the live address, Reconnect, Forget this PC. */
@HiltViewModel
class ConnectionViewModel @Inject constructor(
    private val settingsRepository: SettingsRepository,
    private val store: PairedPcStore,
    private val pairing: PairingManager,
    private val link: LinkRepository,
    private val api: HarnessApi,
) : ViewModel() {

    private val _messages = Channel<String>(Channel.BUFFERED)
    val messages: Flow<String> = _messages.receiveAsFlow()

    /** Ticks every second, only while "trying again in 8 s" is counting down. */
    private val clock: Flow<Long> = link.state.flatMapLatest { state ->
        if (state is ConnectionState.Unreachable && state.retryAtMs != null) {
            flow {
                while (true) {
                    emit(System.currentTimeMillis())
                    delay(1_000)
                }
            }
        } else {
            flowOf(System.currentTimeMillis())
        }
    }

    val uiState: StateFlow<ConnectionScreenState> = combine(
        settingsRepository.settings, store.pc, link.state, clock,
    ) { settings, pc, state, now ->
        val demo = settings.connection.demoMode
        ConnectionScreenState(
            settings = settings.connection,
            paired = pc?.let {
                ConnectionScreenState.Paired(it.serverName, it.serverId, it.deviceName, runCatching { AvekProtocol.fingerprintText(it.serverPub) }.getOrNull())
            },
            status = describe(state, demo, now),
            address = when (state) {
                is ConnectionState.Connected -> state.address
                is ConnectionState.Connecting -> state.address
                else -> null
            },
            connected = demo || state is ConnectionState.Connected,
            demo = demo,
            forgotten = !demo && state is ConnectionState.Forgotten,
            failed = !demo && state is ConnectionState.Failed,
            notice = (state as? ConnectionState.NeedsPairing)?.notice,
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), ConnectionScreenState())

    fun reconnect() = link.reconnect()

    /** "Forget this PC": tells the PC when connected, then deletes the Keystore key and the stored PC. */
    fun forget() {
        viewModelScope.launch {
            if (link.state.value is ConnectionState.Connected && !uiState.value.demo) {
                runCatching { api.deviceUnpair() }
            }
            link.disconnect()
            pairing.forget()
            _messages.trySend("This PC was forgotten")
        }
    }

    fun setWorkInBackground(enabled: Boolean) = updateConnection { it.copy(workInBackground = enabled) }

    fun setDemoMode(enabled: Boolean) = updateConnection { it.copy(demoMode = enabled) }

    fun setKeepListsSeconds(seconds: Int) = updateConnection {
        it.copy(keepListsSeconds = seconds.coerceIn(ConnectionSettings.MIN_KEEP_LISTS_SECONDS, ConnectionSettings.MAX_KEEP_LISTS_SECONDS))
    }

    private fun updateConnection(transform: (ConnectionSettings) -> ConnectionSettings) {
        viewModelScope.launch { settingsRepository.update { it.copy(connection = transform(it.connection)) } }
    }
}
