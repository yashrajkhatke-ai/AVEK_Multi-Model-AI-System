package com.avek.chat.feature.chat.profiles

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Remove
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.unit.dp
import com.avek.chat.core.designsystem.theme.AvekTheme
import kotlin.math.roundToInt

class EditorActions(
    val onName: (String) -> Unit,
    val onRtx: (Int) -> Unit,
    val onIgpu: (Int) -> Unit,
    val onPreset: (LayerPreset) -> Unit,
    val onContext: (Int) -> Unit,
    val onSlots: (Int) -> Unit,
    val onCacheType: (String) -> Unit,
    val onNote: (String) -> Unit,
    val onSave: () -> Unit,
    val onCancel: () -> Unit,
)

/**
 * New / Copy / Edit a load profile (task D.3): name, RTX and iGPU sliders with the CPU as the live
 * remainder, presets as starting points, context (steps of 1,024), slots, cache type, note. The app
 * does not estimate memory: Save, and the PC's estimate appears on the card.
 */
@Composable
fun ProfileEditorScreen(draft: EditorDraft, connected: Boolean, actions: EditorActions) {
    val colors = AvekTheme.colors
    val fieldColors = OutlinedTextFieldDefaults.colors(
        focusedBorderColor = colors.accent,
        unfocusedBorderColor = colors.outline,
        focusedLabelColor = colors.accent,
        cursorColor = colors.accent,
    )
    Column(
        Modifier
            .fillMaxWidth()
            .heightIn(max = 760.dp)
            .verticalScroll(rememberScrollState())
            .padding(start = 20.dp, end = 20.dp, bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text(
            when {
                draft.id != null -> "Edit profile"
                else -> "New profile"
            },
            style = AvekTheme.type.headline,
            color = colors.textPrimary,
        )
        OutlinedTextField(
            value = draft.name,
            onValueChange = actions.onName,
            label = { Text("Name (1 to ${EditorDraft.MAX_NAME} characters)") },
            singleLine = true,
            textStyle = AvekTheme.type.body.copy(color = colors.textPrimary),
            colors = fieldColors,
            modifier = Modifier.fillMaxWidth(),
        )

        val presets = LayerPlan.presets(draft.total, draft.hasRtx, draft.hasIgpu)
        Text("Start from", style = AvekTheme.type.label, color = colors.textSecondary)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            presets.forEach { preset ->
                FilterChip(
                    selected = preset.layers == draft.layers,
                    onClick = { actions.onPreset(preset) },
                    label = { Text(preset.name) },
                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = colors.accentContainer),
                )
            }
        }

        LayerBar(draft.layers, draft.total)
        Text("${LayerPlan.numbers(draft.layers)} (of ${draft.total} layers)", style = AvekTheme.type.bodySmall, color = colors.textPrimary)
        if (draft.hasRtx) {
            LayerSlider("RTX", ProcessorColors.rtx, draft.layers.rtx, draft.total, actions.onRtx)
        }
        if (draft.hasIgpu) {
            LayerSlider("iGPU", ProcessorColors.igpu, draft.layers.igpu, draft.total, actions.onIgpu)
        }
        Text(
            "CPU: ${draft.layers.cpu} layers (the rest)",
            style = AvekTheme.type.bodySmall,
            color = colors.textSecondary,
        )

        // Context: steps of 1,024 between the PC's limits, shown in K, with - and + buttons.
        val min = draft.limits.minContext
        val max = draft.limits.maxContext.coerceAtLeast(min)
        Text("Context: ${LayerPlan.contextK(draft.contextTokens)} tokens", style = AvekTheme.type.label, color = colors.textPrimary)
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { actions.onContext(draft.contextTokens - 1024) }) { Icon(Icons.Outlined.Remove, "Smaller context", tint = colors.textPrimary) }
            Slider(
                value = draft.contextTokens.toFloat(),
                onValueChange = { actions.onContext(it.roundToInt()) },
                valueRange = min.toFloat()..max.toFloat(),
                colors = SliderDefaults.colors(thumbColor = colors.accent, activeTrackColor = colors.accent),
                modifier = Modifier.weight(1f).semantics { stateDescription = "${LayerPlan.contextK(draft.contextTokens)} context" },
            )
            IconButton(onClick = { actions.onContext(draft.contextTokens + 1024) }) { Icon(Icons.Outlined.Add, "Larger context", tint = colors.textPrimary) }
        }

        // Slots: a stepper 1..maxSlots.
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Slots", style = AvekTheme.type.label, color = colors.textPrimary, modifier = Modifier.weight(1f))
            IconButton(onClick = { actions.onSlots(draft.slots - 1) }, enabled = draft.slots > 1) { Icon(Icons.Outlined.Remove, "Fewer slots", tint = colors.textPrimary) }
            Text("${draft.slots}", style = AvekTheme.type.title, color = colors.textPrimary, modifier = Modifier.semantics { stateDescription = "${draft.slots} slots" })
            IconButton(onClick = { actions.onSlots(draft.slots + 1) }, enabled = draft.slots < draft.limits.maxSlots) { Icon(Icons.Outlined.Add, "More slots", tint = colors.textPrimary) }
        }

        Text("Cache", style = AvekTheme.type.label, color = colors.textPrimary)
        SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
            draft.limits.cacheTypes.forEachIndexed { index, type ->
                SegmentedButton(
                    selected = draft.cacheType == type,
                    onClick = { actions.onCacheType(type) },
                    shape = SegmentedButtonDefaults.itemShape(index, draft.limits.cacheTypes.size),
                ) { Text(type) }
            }
        }

        OutlinedTextField(
            value = draft.note,
            onValueChange = actions.onNote,
            label = { Text("Note (optional)") },
            textStyle = AvekTheme.type.body.copy(color = colors.textPrimary),
            colors = fieldColors,
            modifier = Modifier.fillMaxWidth(),
        )
        Text("Save to see the memory estimate", style = AvekTheme.type.caption, color = colors.textTertiary)
        draft.error?.let { Text(it, style = AvekTheme.type.bodySmall, color = colors.danger) }
        if (!connected) Text("Not connected", style = AvekTheme.type.bodySmall, color = colors.danger)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = actions.onCancel) { Text("Cancel", color = colors.textSecondary) }
            Spacer(Modifier.width(8.dp))
            Button(
                onClick = actions.onSave,
                enabled = draft.canSave && connected,
                colors = ButtonDefaults.buttonColors(containerColor = colors.accent, contentColor = colors.onAccent),
            ) { Text(if (draft.saving) "Saving..." else "Save") }
        }
    }
}

@Composable
private fun LayerSlider(label: String, color: Color, value: Int, total: Int, onChange: (Int) -> Unit) {
    val colors = AvekTheme.colors
    Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(label, style = AvekTheme.type.label, color = colors.textPrimary, modifier = Modifier.weight(1f))
            Text("$value layers", style = AvekTheme.type.label, color = colors.textPrimary)
        }
        Slider(
            value = value.toFloat(),
            onValueChange = { onChange(it.roundToInt()) },
            valueRange = 0f..total.coerceAtLeast(1).toFloat(),
            steps = (total - 1).coerceAtLeast(0),
            colors = SliderDefaults.colors(thumbColor = color, activeTrackColor = color),
            modifier = Modifier.semantics { stateDescription = "$label $value of $total layers" },
        )
    }
}
