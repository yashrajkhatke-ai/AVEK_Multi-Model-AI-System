package com.avek.chat.core.markdown

/** Block-level Markdown AST. Inline formatting is kept as raw text and styled at render time. */
sealed interface MdBlock {
    data class Heading(val level: Int, val text: String) : MdBlock
    data class Paragraph(val text: String) : MdBlock
    data class Code(val language: String, val code: String, val closed: Boolean) : MdBlock
    data class Bullets(val items: List<MdListItem>) : MdBlock
    data class Numbered(val start: Int, val items: List<MdListItem>) : MdBlock
    data class Quote(val text: String) : MdBlock
    data class Table(val header: List<String>, val rows: List<List<String>>) : MdBlock
    data object Rule : MdBlock
}

data class MdListItem(val text: String, val indent: Int)

/**
 * A small, forgiving, streaming-friendly Markdown parser. Unclosed code fences
 * are treated as "still streaming" rather than as errors.
 */
object MarkdownParser {

    private val heading = Regex("^(#{1,6})\\s+(.*)$")
    private val rule = Regex("^\\s*(-{3,}|\\*{3,}|_{3,})\\s*$")
    private val bullet = Regex("^(\\s*)[-*+]\\s+(.*)$")
    private val numbered = Regex("^(\\s*)(\\d+)[.)]\\s+(.*)$")
    private val fence = Regex("^\\s*```\\s*([\\w+#.-]*)\\s*$")
    private val tableSeparator = Regex("^\\s*\\|?\\s*:?-{2,}:?\\s*(\\|\\s*:?-{2,}:?\\s*)*\\|?\\s*$")

    fun parse(source: String): List<MdBlock> {
        val lines = source.replace("\r\n", "\n").split('\n')
        val blocks = mutableListOf<MdBlock>()
        val paragraph = StringBuilder()
        var i = 0

        fun flushParagraph() {
            if (paragraph.isNotBlank()) blocks += MdBlock.Paragraph(paragraph.toString().trim())
            paragraph.clear()
        }

        while (i < lines.size) {
            val line = lines[i]
            val fenceMatch = fence.matchEntire(line)
            when {
                fenceMatch != null -> {
                    flushParagraph()
                    val language = fenceMatch.groupValues[1]
                    val code = StringBuilder()
                    i++
                    var closed = false
                    while (i < lines.size) {
                        if (lines[i].trim().startsWith("```")) {
                            closed = true
                            break
                        }
                        if (code.isNotEmpty()) code.append('\n')
                        code.append(lines[i])
                        i++
                    }
                    blocks += MdBlock.Code(language, code.toString(), closed)
                }
                line.isBlank() -> flushParagraph()
                heading.matches(line) -> {
                    flushParagraph()
                    val m = heading.matchEntire(line)!!
                    blocks += MdBlock.Heading(m.groupValues[1].length, m.groupValues[2].trim())
                }
                rule.matches(line) -> {
                    flushParagraph()
                    blocks += MdBlock.Rule
                }
                line.trimStart().startsWith("|") && i + 1 < lines.size && tableSeparator.matches(lines[i + 1]) -> {
                    flushParagraph()
                    val header = cells(line)
                    i += 2
                    val rows = mutableListOf<List<String>>()
                    while (i < lines.size && lines[i].trimStart().startsWith("|")) {
                        rows += cells(lines[i]).let { row ->
                            if (row.size < header.size) row + List(header.size - row.size) { "" } else row.take(header.size)
                        }
                        i++
                    }
                    blocks += MdBlock.Table(header, rows)
                    continue
                }
                line.trimStart().startsWith(">") -> {
                    flushParagraph()
                    val quote = StringBuilder()
                    while (i < lines.size && lines[i].trimStart().startsWith(">")) {
                        if (quote.isNotEmpty()) quote.append(' ')
                        quote.append(lines[i].trimStart().removePrefix(">").trim())
                        i++
                    }
                    blocks += MdBlock.Quote(quote.toString())
                    continue
                }
                bullet.matches(line) -> {
                    flushParagraph()
                    val items = mutableListOf<MdListItem>()
                    while (i < lines.size) {
                        val m = bullet.matchEntire(lines[i]) ?: break
                        items += MdListItem(m.groupValues[2], m.groupValues[1].length / 2)
                        i++
                    }
                    blocks += MdBlock.Bullets(items)
                    continue
                }
                numbered.matches(line) -> {
                    flushParagraph()
                    val items = mutableListOf<MdListItem>()
                    val start = numbered.matchEntire(line)!!.groupValues[2].toIntOrNull() ?: 1
                    while (i < lines.size) {
                        val m = numbered.matchEntire(lines[i]) ?: break
                        items += MdListItem(m.groupValues[3], m.groupValues[1].length / 2)
                        i++
                    }
                    blocks += MdBlock.Numbered(start, items)
                    continue
                }
                else -> {
                    if (paragraph.isNotEmpty()) paragraph.append('\n')
                    paragraph.append(line.trim())
                }
            }
            i++
        }
        flushParagraph()
        return blocks
    }

    private fun cells(line: String): List<String> =
        line.trim().removePrefix("|").removeSuffix("|").split('|').map { it.trim() }
}
