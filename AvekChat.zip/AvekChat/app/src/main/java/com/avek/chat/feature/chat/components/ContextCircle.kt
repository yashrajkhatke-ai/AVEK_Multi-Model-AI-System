package com.avek.chat.feature.chat.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.avek.chat.core.designsystem.theme.AvekTheme
import com.avek.chat.core.domain.context.ContextThresholds
import com.avek.chat.core.domain.trace.TurnTelemetry
import com.avek.chat.core.link.wire.ContextDataDto
import java.util.Locale

/** Blue / yellow / red for a fill fraction. */
fun contextColor(fraction: Float): Color = when (ContextThresholds.level(fraction)) {
    ContextThresholds.Level.BLUE -> Color(0xFF2F7CF6)
    ContextThresholds.Level.YELLOW -> Color(0xFFF2B705)
    ContextThresholds.Level.RED -> Color(0xFFE53935)
}

/**
 * The context circle between the microphone and the send arrow: the whole circle is the model's
 * chat window, the pie (clockwise from 12 o'clock) is what is used. No data: an empty dashed ring.
 */
@Composable
fun ContextCircle(data: ContextDataDto?, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val colors = AvekTheme.colors
    val fraction = ContextThresholds.fraction(data)
    val percent = fraction?.let { (it * 100).toInt() }
    Box(
        modifier
            .size(36.dp)
            .clip(CircleShape)
            .then(if (fraction != null) Modifier.clickable(onClick = onClick) else Modifier)
            .semantics { contentDescription = if (percent == null) "Context window: no data" else "Context window $percent percent full" },
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.size(22.dp)) {
            val stroke = 1.6.dp.toPx()
            val radius = size.minDimension / 2 - stroke / 2
            if (fraction == null) {
                drawCircle(colors.outline, radius, style = Stroke(stroke, pathEffect = PathEffect.dashPathEffect(floatArrayOf(4f, 4f))))
            } else {
                val color = contextColor(fraction)
                drawCircle(colors.outline, radius, style = Stroke(stroke))
                drawArc(color, -90f, ContextThresholds.sweep(fraction), useCenter = true, topLeft = Offset(stroke * 1.6f, stroke * 1.6f), size = Size(size.width - stroke * 3.2f, size.height - stroke * 3.2f))
                drawArc(color, -90f, ContextThresholds.sweep(fraction), useCenter = false, style = Stroke(stroke), topLeft = Offset(stroke / 2, stroke / 2), size = Size(size.width - stroke, size.height - stroke))
            }
        }
    }
}

private fun tokens(n: Int?): String = when {
    n == null -> "-"
    n >= 10_000 -> String.format(Locale.US, "%.0fK", n / 1000.0)
    n >= 1_000 -> String.format(Locale.US, "%.1fK", n / 1000.0)
    else -> n.toString()
}

private fun tps(v: Double?): String = when {
    v == null || v <= 0 -> "-"
    v >= 100 -> "${v.toInt()} tok/s"
    else -> String.format(Locale.US, "%.1f tok/s", v)
}

private fun ms(v: Long?): String = when {
    v == null -> "-"
    v < 1000 -> "$v ms"
    else -> String.format(Locale.US, "%.1f s", v / 1000.0)
}

/** The popup of the circle: every number of the context, the last call and (live) the running turn. */
@Composable
fun ContextPopup(data: ContextDataDto, live: TurnTelemetry?, demo: Boolean, onDismiss: () -> Unit) {
    val colors = AvekTheme.colors
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = colors.chatBackground,
        scrimColor = colors.scrim,
    ) {
        ContextDetails(data, live, demo, Modifier.navigationBarsPadding().padding(start = 20.dp, end = 20.dp, bottom = 24.dp))
    }
}

@Composable
fun ContextDetails(data: ContextDataDto, live: TurnTelemetry?, demo: Boolean, modifier: Modifier = Modifier) {
    val colors = AvekTheme.colors
    val fraction = ContextThresholds.fraction(data) ?: 0f
    Column(modifier.fillMaxWidth().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        if (demo) Text("Demo mode: simulated numbers", style = AvekTheme.type.caption, color = colors.thinkingGlow)
        Text(data.modelName ?: data.modelId ?: "Context window", style = AvekTheme.type.title, color = colors.textPrimary)
        Row(verticalAlignment = Alignment.Bottom) {
            Text("${tokens(data.usedTokens)} / ${tokens(data.circleTokens)}", style = AvekTheme.type.headline.copy(fontWeight = FontWeight.SemiBold), color = colors.textPrimary)
            Spacer(Modifier.width(10.dp))
            Text("${(fraction * 100).toInt()}%", style = AvekTheme.type.title.copy(fontWeight = FontWeight.SemiBold), color = contextColor(fraction))
        }
        CategoryBar(data)
        data.categories.forEachIndexed { i, c ->
            val share = if (data.promptTokens > 0) c.tokens * 100 / data.promptTokens else 0
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(8.dp).clip(CircleShape).background(categoryColor(i)))
                Spacer(Modifier.width(8.dp))
                Text(c.label, style = AvekTheme.type.bodySmall, color = colors.textSecondary, modifier = Modifier.weight(1f))
                Text("${tokens(c.tokens)} · $share%", style = AvekTheme.type.bodySmall, color = colors.textPrimary)
            }
        }
        Text(if (data.exact) "Exact (counted by the model server)" else "Estimated split", style = AvekTheme.type.caption, color = colors.textTertiary)
        HorizontalDivider(color = colors.outline.copy(alpha = 0.4f))
        Line("Window now", tokens(data.windowTokens))
        Line("Older messages are summarised at", tokens(data.compactAtTokens))
        data.lastStep?.let {
            HorizontalDivider(color = colors.outline.copy(alpha = 0.4f))
            Text("Last model call", style = AvekTheme.type.label, color = colors.textPrimary)
            Line("Speed", tps(it.tps))
            Line("Average speed", tps(it.avgTps))
            Line("Time to first token", ms(it.ttftMs))
            Line("Prompt / generated", "${tokens(it.promptTokens)} / ${tokens(it.completionTokens)}")
        }
        data.lastTurn?.let {
            HorizontalDivider(color = colors.outline.copy(alpha = 0.4f))
            Text("Last turn", style = AvekTheme.type.label, color = colors.textPrimary)
            Line("Prompt / generated", "${tokens(it.promptTokens)} / ${tokens(it.completionTokens)}")
            Line("Steps", "${it.steps}")
            Line("Duration", ms(it.durationMs))
        }
        if (live != null && live.live) {
            HorizontalDivider(color = colors.outline.copy(alpha = 0.4f))
            Text("Now", style = AvekTheme.type.label, color = colors.textPrimary)
            Line("Phase", live.currentPhase?.label?.ifEmpty { live.currentPhase?.phase } ?: "-")
            Line("Speed", tps(live.tps))
            Line("Step", live.latestGen?.step?.toString() ?: "-")
            if (live.steps.isNotEmpty()) Line("Reasoning / answer / tool call", "${live.reasoningTokens} / ${live.answerTokens} / ${live.toolCallTokens}")
        }
    }
}

@Composable
private fun Line(label: String, value: String) {
    Row(Modifier.fillMaxWidth()) {
        Text(label, style = AvekTheme.type.bodySmall, color = AvekTheme.colors.textSecondary, modifier = Modifier.weight(1f))
        Text(value, style = AvekTheme.type.bodySmall.copy(fontWeight = FontWeight.Medium), color = AvekTheme.colors.textPrimary)
    }
}

private val CATEGORY_COLORS = listOf(
    Color(0xFF2F7CF6), Color(0xFF7E57C2), Color(0xFF26A69A), Color(0xFF8D6E63),
    Color(0xFFEF6C00), Color(0xFF5C6BC0), Color(0xFFEC407A), Color(0xFF9CCC65),
)

private fun categoryColor(index: Int) = CATEGORY_COLORS[index % CATEGORY_COLORS.size]

/** One bar for the whole circle: a segment per category, markers for the window and the summarising point. */
@Composable
private fun CategoryBar(data: ContextDataDto) {
    val colors = AvekTheme.colors
    val total = data.circleTokens.coerceAtLeast(1).toFloat()
    Canvas(Modifier.fillMaxWidth().height(12.dp)) {
        val h = size.height
        drawRoundRect(colors.outline.copy(alpha = 0.35f), size = Size(size.width, h), cornerRadius = CornerRadius(h / 2))
        var x = 0f
        data.categories.forEachIndexed { i, c ->
            val w = size.width * c.tokens / total
            drawRect(categoryColor(i), Offset(x, 0f), Size(w, h))
            x += w
        }
        if (data.compactAtTokens > 0) {
            val mx = size.width * (data.compactAtTokens / total).coerceAtMost(1f)
            drawLine(Color(0xFFF2B705), Offset(mx, -3f), Offset(mx, h + 3f), strokeWidth = 2f)
        }
        if (data.windowTokens > 0) {
            val wx = size.width * (data.windowTokens / total).coerceAtMost(1f)
            drawLine(colors.textSecondary, Offset(wx, -3f), Offset(wx, h + 3f), strokeWidth = 2f)
        }
    }
}
