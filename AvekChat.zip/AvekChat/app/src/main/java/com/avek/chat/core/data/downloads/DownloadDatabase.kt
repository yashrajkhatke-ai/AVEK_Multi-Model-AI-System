package com.avek.chat.core.data.downloads

import androidx.room.ColumnInfo
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase
import androidx.room.Transaction
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "downloaded_chats")
data class DownloadedChatEntity(
    @PrimaryKey @ColumnInfo(name = "chat_id") val chatId: String,
    val title: String,
    @ColumnInfo(name = "created_at") val createdAt: Long,
    @ColumnInfo(name = "updated_at") val updatedAt: Long,
    @ColumnInfo(name = "model_id") val modelId: String?,
    val mode: String,
    @ColumnInfo(name = "turn_count") val turnCount: Int,
    val preview: String,
    val starred: Boolean,
    val archived: Boolean,
    @ColumnInfo(name = "downloaded_at") val downloadedAt: Long,
)

@Entity(
    tableName = "downloaded_turns",
    primaryKeys = ["chat_id", "prompt_id"],
    foreignKeys = [
        ForeignKey(
            entity = DownloadedChatEntity::class,
            parentColumns = ["chat_id"],
            childColumns = ["chat_id"],
            onDelete = ForeignKey.CASCADE,
        ),
    ],
    indices = [Index(value = ["chat_id", "created_at"])],
)
data class DownloadedTurnEntity(
    @ColumnInfo(name = "chat_id") val chatId: String,
    @ColumnInfo(name = "prompt_id") val promptId: String,
    @ColumnInfo(name = "created_at") val createdAt: Long,
    /** The turn exactly as the PC sent it (`TurnView` JSON). */
    val json: String,
)

data class ChatSizeRow(
    @ColumnInfo(name = "chat_id") val chatId: String,
    val bytes: Long,
)

@Dao
abstract class DownloadedDao {

    @Query("SELECT * FROM downloaded_chats ORDER BY updated_at DESC")
    abstract fun observeChats(): Flow<List<DownloadedChatEntity>>

    @Query("SELECT chat_id FROM downloaded_chats")
    abstract fun observeIds(): Flow<List<String>>

    @Query("SELECT chat_id, SUM(LENGTH(json)) AS bytes FROM downloaded_turns GROUP BY chat_id")
    abstract fun observeSizes(): Flow<List<ChatSizeRow>>

    @Query("SELECT chat_id FROM downloaded_chats")
    abstract suspend fun ids(): List<String>

    @Query("SELECT * FROM downloaded_chats WHERE chat_id = :chatId")
    abstract suspend fun chat(chatId: String): DownloadedChatEntity?

    @Query("SELECT * FROM downloaded_turns WHERE chat_id = :chatId ORDER BY created_at ASC, prompt_id ASC")
    abstract suspend fun turns(chatId: String): List<DownloadedTurnEntity>

    @Upsert
    abstract suspend fun upsertChat(chat: DownloadedChatEntity)

    @Upsert
    abstract suspend fun upsertTurn(turn: DownloadedTurnEntity)

    @Upsert
    abstract suspend fun upsertTurns(turns: List<DownloadedTurnEntity>)

    @Query("DELETE FROM downloaded_turns WHERE chat_id = :chatId")
    abstract suspend fun deleteTurns(chatId: String)

    @Query("DELETE FROM downloaded_chats WHERE chat_id = :chatId")
    abstract suspend fun deleteChat(chatId: String)

    @Transaction
    open suspend fun replace(chat: DownloadedChatEntity, turns: List<DownloadedTurnEntity>) {
        deleteTurns(chat.chatId)
        upsertChat(chat)
        upsertTurns(turns)
    }
}

/** Only downloaded chats live here; the PC holds everything else. */
@Database(
    entities = [DownloadedChatEntity::class, DownloadedTurnEntity::class],
    version = 2,
    exportSchema = true,
)
abstract class DownloadDatabase : RoomDatabase() {
    abstract fun downloadedDao(): DownloadedDao

    companion object {
        const val NAME = "avek-downloads.db"
    }
}
