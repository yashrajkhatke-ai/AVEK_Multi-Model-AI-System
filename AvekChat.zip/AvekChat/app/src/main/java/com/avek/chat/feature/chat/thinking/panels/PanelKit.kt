package com.avek.chat.feature.chat.thinking.panels

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.withFrameMillis
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.avek.chat.core.designsystem.theme.AvekTheme
import com.avek.chat.core.designsystem.theme.ColorMath
import com.avek.chat.core.domain.trace.TokenKind
import kotlinx.coroutines.delay

/** Colors of the thinking block, derived from the theme so every theme (light and dark) works. */
@Stable
class ThinkingPalette(
    val accent: Color,
    val text: Color,
    val muted: Color,
    val faint: Color,
    val track: Color,
    val surface: Color,
    val reasoning: Color,
    val answer: Color,
    val toolCall: Color,
    val danger: Color,
    val success: Color,
    val warn: Color,
    private val categories: List<Color>,
) {
    fun category(key: String): Color = when (key) {
        "instructions" -> categories[0]
        "tools" -> categories[1]
        "summary" -> categories[2]
        "history" -> categories[3]
        "user" -> categories[4]
        "assistant" -> categories[5]
        "toolCalls" -> categories[6]
        "toolResults" -> categories[7]
        else -> muted
    }

    fun kind(kind: TokenKind): Color = when (kind) {
        TokenKind.REASONING -> reasoning
        TokenKind.ANSWER -> answer
        TokenKind.TOOL_CALL -> toolCall
    }

    fun level(level: String): Color = when (level) {
        "error" -> danger
        "warn" -> warn
        else -> muted
    }
}

@Composable
fun rememberThinkingPalette(): ThinkingPalette {
    val c = AvekTheme.colors
    return remember(c) {
        val base = c.thinkingGlow
        val shift = { hue: Float, light: Float -> ColorMath.shift(base, lightnessDelta = light, hueDelta = hue) }
        ThinkingPalette(
            accent = base,
            text = c.textPrimary,
            muted = c.textSecondary,
            faint = c.textTertiary,
            track = c.outline.copy(alpha = 0.45f),
            surface = c.thinkingSurface,
            reasoning = base,
            answer = shift(150f, 0f),
            toolCall = shift(-70f, 0.05f),
            danger = c.danger,
            success = c.success,
            warn = if (c.isDark) Color(0xFFFFD180) else Color(0xFFB26A00),
            categories = listOf(
                shift(0f, 0f), shift(40f, 0.04f), shift(80f, 0f), shift(120f, 0.04f),
                shift(170f, 0f), shift(210f, 0.04f), shift(260f, 0f), shift(300f, 0.04f),
            ),
        )
    }
}

/**
 * The device clock for live drawing: every frame while [live] (smooth bars and timers), every
 * 250 ms with reduced motion (values still update), and frozen when the turn is over.
 */
@Composable
fun rememberNow(live: Boolean): State<Long> {
    val reduce = AvekTheme.motion.reduceMotion
    return produceState(System.currentTimeMillis(), live, reduce) {
        value = System.currentTimeMillis()
        if (!live) return@produceState
        while (true) {
            if (reduce) delay(250) else withFrameMillis { }
            value = System.currentTimeMillis()
        }
    }
}

/** A 0..1 pulse for "this is happening now"; constant 1 with reduced motion. */
@Composable
fun rememberPulse(active: Boolean): State<Float> {
    val reduce = AvekTheme.motion.reduceMotion
    if (!active || reduce) return remember { androidx.compose.runtime.mutableFloatStateOf(1f) }
    val transition = rememberInfiniteTransition(label = "pulse")
    return transition.animateFloat(0.35f, 1f, infiniteRepeatable(tween(700, easing = LinearEasing), RepeatMode.Reverse), label = "pulse")
}

@Composable
fun PanelTitle(text: String, modifier: Modifier = Modifier, trailing: String? = null) {
    Row(modifier.fillMaxWidth().padding(bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(text.uppercase(), style = AvekTheme.type.caption.copy(fontWeight = FontWeight.SemiBold), color = AvekTheme.colors.textSecondary, modifier = Modifier.weight(1f))
        if (trailing != null) Text(trailing, style = AvekTheme.type.caption, color = AvekTheme.colors.textTertiary)
    }
}

/** "No data yet" line: shown instead of any invented value. */
@Composable
fun NoData(text: String, modifier: Modifier = Modifier) {
    Text(text, style = AvekTheme.type.caption, color = AvekTheme.colors.textTertiary, modifier = modifier.padding(vertical = 4.dp))
}

@Composable
fun Dot(color: Color, size: Int = 8, alpha: Float = 1f) {
    Box(Modifier.size(size.dp).alpha(alpha).clip(CircleShape).background(color))
}

@Composable
fun Chip(text: String, color: Color, modifier: Modifier = Modifier, filled: Boolean = false, alpha: Float = 1f) {
    Text(
        text,
        style = AvekTheme.type.caption.copy(fontWeight = FontWeight.Medium),
        color = if (filled) AvekTheme.colors.onAccent else color,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        modifier = modifier
            .alpha(alpha)
            .clip(RoundedCornerShape(50))
            .background(if (filled) color else color.copy(alpha = 0.14f))
            .padding(horizontal = 8.dp, vertical = 3.dp),
    )
}

/** A label/value pair (dashboard tiles, ledgers). */
@Composable
fun Stat(label: String, value: String, modifier: Modifier = Modifier, valueColor: Color = AvekTheme.colors.textPrimary) {
    Column(modifier) {
        Text(label, style = AvekTheme.type.caption, color = AvekTheme.colors.textTertiary, maxLines = 1)
        Text(value, style = AvekTheme.type.label.copy(fontWeight = FontWeight.SemiBold), color = valueColor, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun Legend(items: List<Pair<String, Color>>, modifier: Modifier = Modifier) {
    androidx.compose.foundation.layout.FlowRow(modifier, horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        items.forEach { (label, color) ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Dot(color, 7)
                Spacer(Modifier.width(4.dp))
                Text(label, style = AvekTheme.type.caption, color = AvekTheme.colors.textSecondary)
            }
        }
    }
}
