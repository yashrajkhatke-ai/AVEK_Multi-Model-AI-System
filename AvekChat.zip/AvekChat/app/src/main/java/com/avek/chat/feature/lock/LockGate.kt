package com.avek.chat.feature.lock

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Fingerprint
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material.icons.outlined.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.avek.chat.core.designsystem.theme.AvekTheme
import com.avek.chat.core.domain.lock.AppLockManager
import com.avek.chat.core.domain.lock.LockState

/** The phone's own fingerprint / PIN prompt (Android: BiometricPrompt with BIOMETRIC_STRONG | DEVICE_CREDENTIAL). */
interface PhoneAuthenticator {
    /** False when the phone has no screen lock or biometrics at all: the app password alone is asked. */
    fun available(): Boolean

    /** Shows the prompt; [onResult] gets true when the person passed it. */
    fun authenticate(onResult: (Boolean) -> Unit)
}

val LocalPhoneAuthenticator = staticCompositionLocalOf<PhoneAuthenticator?> { null }

/**
 * The root gate (section 13): until the phone's fingerprint/PIN and the app password pass, nothing
 * of the app is shown. [content] is composed for the first time only after the first unlock (so no
 * screen loads anything while locked); a later lock covers it with an opaque screen and keeps its state.
 */
@Composable
fun LockGate(state: LockUi, actions: LockActions, content: @Composable () -> Unit) {
    var opened by remember { mutableStateOf(false) }
    val lock = state.lock
    val showContent = lock == LockState.Unlocked || (lock == LockState.NoPassword && !state.onboardingDone)
    if (showContent) opened = true
    Box(Modifier.fillMaxSize()) {
        if (opened) content()
        if (!showContent) {
            Box(Modifier.fillMaxSize().background(AvekTheme.colors.chatBackground)) {
                when (lock) {
                    LockState.NoPassword -> CreatePasswordScreen(state, actions)
                    is LockState.Locked -> if (lock.biometricPassed) PasswordScreen(state, actions) else PhoneCheckScreen(actions)
                    LockState.Broken -> BrokenScreen(state, actions)
                    LockState.Unlocked -> Unit
                }
            }
        }
    }
}

class LockActions(
    val onBiometricPassed: () -> Unit,
    val onCreate: (CharArray, CharArray) -> Unit,
    val onUnlock: (CharArray) -> Unit,
    val onForgetAll: () -> Unit,
    val onClearError: () -> Unit,
)

@Composable
private fun LockColumn(content: @Composable () -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.safeDrawing)
            .verticalScroll(rememberScrollState())
            .imePadding()
            .padding(horizontal = 28.dp, vertical = 32.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) { content() }
}

@Composable
private fun LockIcon(fingerprint: Boolean = false) {
    val colors = AvekTheme.colors
    Spacer(Modifier.height(32.dp))
    Box(Modifier.size(76.dp).clip(CircleShape).background(colors.accentContainer), contentAlignment = Alignment.Center) {
        Icon(if (fingerprint) Icons.Outlined.Fingerprint else Icons.Outlined.Lock, null, tint = colors.accent, modifier = Modifier.size(38.dp))
    }
}

/** Step 1 on every open: the phone's fingerprint or PIN (asked at once). */
@Composable
private fun PhoneCheckScreen(actions: LockActions) {
    val colors = AvekTheme.colors
    val authenticator = LocalPhoneAuthenticator.current
    var failed by remember { mutableStateOf(false) }
    fun ask() {
        if (authenticator == null || !authenticator.available()) {
            actions.onBiometricPassed()
        } else {
            authenticator.authenticate { ok -> if (ok) actions.onBiometricPassed() else failed = true }
        }
    }
    LaunchedEffect(Unit) { ask() }
    LockColumn {
        LockIcon(fingerprint = true)
        Text("AVEK is locked", style = AvekTheme.type.display, color = colors.textPrimary, textAlign = TextAlign.Center)
        Text(
            "Use your fingerprint or the phone's PIN, then your app password.",
            style = AvekTheme.type.body,
            color = colors.textSecondary,
            textAlign = TextAlign.Center,
        )
        if (failed) Text("Not unlocked.", style = AvekTheme.type.bodySmall, color = colors.danger)
        Button(
            onClick = {
                failed = false
                ask()
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = colors.accent, contentColor = colors.onAccent),
        ) { Text("Unlock") }
    }
}

/** Step 2: the app password (PBKDF2, constant-time compare, lockout after 10 wrong). */
@Composable
private fun PasswordScreen(state: LockUi, actions: LockActions) {
    val colors = AvekTheme.colors
    var text by remember { mutableStateOf("") }
    var confirmForget by remember { mutableStateOf(false) }
    DisposableEffect(Unit) { onDispose { text = "" } }
    val locked = state.lockoutMs > 0
    fun submit() {
        if (text.isEmpty() || state.busy || locked) return
        val chars = text.toCharArray()
        text = ""
        actions.onUnlock(chars)
    }
    LockColumn {
        LockIcon()
        Text("Enter your app password", style = AvekTheme.type.headline, color = colors.textPrimary, textAlign = TextAlign.Center)
        PasswordField(
            value = text,
            onChange = {
                text = it
                actions.onClearError()
            },
            label = "App password",
            enabled = !locked && !state.busy,
            imeAction = ImeAction.Done,
            onDone = ::submit,
        )
        when {
            locked -> Text(
                "Too many wrong passwords. Try again in ${formatWait(state.lockoutMs)}.",
                style = AvekTheme.type.bodySmall,
                color = colors.danger,
                textAlign = TextAlign.Center,
            )
            state.error != null -> Text(state.error, style = AvekTheme.type.bodySmall, color = colors.danger)
        }
        Button(
            onClick = ::submit,
            enabled = text.isNotEmpty() && !state.busy && !locked,
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = colors.accent, contentColor = colors.onAccent),
        ) {
            if (state.busy) CircularProgressIndicator(Modifier.size(18.dp), color = colors.onAccent, strokeWidth = 2.dp) else Text("Unlock")
        }
        Spacer(Modifier.height(12.dp))
        TextButton(onClick = { confirmForget = true }) { Text("Forget this PC and start over", color = colors.textSecondary) }
    }
    if (confirmForget) ForgetAllDialog(onDismiss = { confirmForget = false }, onConfirm = {
        confirmForget = false
        actions.onForgetAll()
    })
}

/** First launch (after pairing): the app password, twice, at least 8 characters. No recovery exists. */
@Composable
private fun CreatePasswordScreen(state: LockUi, actions: LockActions) {
    val colors = AvekTheme.colors
    var first by remember { mutableStateOf("") }
    var second by remember { mutableStateOf("") }
    DisposableEffect(Unit) {
        onDispose {
            first = ""
            second = ""
        }
    }
    val tooShort = first.isNotEmpty() && first.length < AppLockManager.MIN_LENGTH
    val mismatch = second.isNotEmpty() && second != first
    val canSave = first.length >= AppLockManager.MIN_LENGTH && first == second && !state.busy
    fun save() {
        if (!canSave) return
        val a = first.toCharArray()
        val b = second.toCharArray()
        first = ""
        second = ""
        actions.onCreate(a, b)
    }
    LockColumn {
        LockIcon()
        Text("Set an app password", style = AvekTheme.type.headline, color = colors.textPrimary, textAlign = TextAlign.Center)
        Text(
            "Every time you open AVEK it asks for your fingerprint or PIN and then this password. There is no way to recover it: if you forget it, you forget this PC and pair again.",
            style = AvekTheme.type.bodySmall,
            color = colors.textSecondary,
            textAlign = TextAlign.Center,
        )
        PasswordField(first, { first = it; actions.onClearError() }, "Password (at least ${AppLockManager.MIN_LENGTH} characters)", imeAction = ImeAction.Next)
        if (tooShort) Text("At least ${AppLockManager.MIN_LENGTH} characters.", style = AvekTheme.type.bodySmall, color = colors.textTertiary)
        if (first.length >= AppLockManager.MIN_LENGTH) Text(strengthHint(first), style = AvekTheme.type.bodySmall, color = colors.textTertiary)
        PasswordField(second, { second = it; actions.onClearError() }, "The same password again", imeAction = ImeAction.Done, onDone = ::save)
        if (mismatch) Text("The two passwords are not the same.", style = AvekTheme.type.bodySmall, color = colors.danger)
        state.error?.let { Text(it, style = AvekTheme.type.bodySmall, color = colors.danger) }
        Button(
            onClick = ::save,
            enabled = canSave,
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = colors.accent, contentColor = colors.onAccent),
        ) {
            if (state.busy) CircularProgressIndicator(Modifier.size(18.dp), color = colors.onAccent, strokeWidth = 2.dp) else Text("Set password")
        }
    }
}

/** The stored password check value cannot be read: only starting over helps. */
@Composable
private fun BrokenScreen(state: LockUi, actions: LockActions) {
    val colors = AvekTheme.colors
    var confirm by remember { mutableStateOf(false) }
    LockColumn {
        LockIcon()
        Text("The app lock cannot be read", style = AvekTheme.type.headline, color = colors.textPrimary, textAlign = TextAlign.Center)
        Text(
            "The stored app password is damaged, so it cannot be checked. Forget this PC and start over to use the app again.",
            style = AvekTheme.type.body,
            color = colors.textSecondary,
            textAlign = TextAlign.Center,
        )
        OutlinedButton(onClick = { confirm = true }, enabled = !state.busy, modifier = Modifier.fillMaxWidth()) {
            Text("Forget this PC and start over", color = colors.danger)
        }
    }
    if (confirm) ForgetAllDialog(onDismiss = { confirm = false }, onConfirm = {
        confirm = false
        actions.onForgetAll()
    })
}

@Composable
private fun ForgetAllDialog(onDismiss: () -> Unit, onConfirm: () -> Unit) {
    val colors = AvekTheme.colors
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = colors.surface,
        title = { Text("Forget this PC and start over?", color = colors.textPrimary) },
        text = {
            Text(
                "This deletes this device's keys and secrets, forgets the PC and removes the app password. You pair again with a new 12-digit code and set a new password.",
                color = colors.textSecondary,
            )
        },
        confirmButton = { TextButton(onClick = onConfirm) { Text("Start over", color = colors.danger) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = colors.textSecondary) } },
    )
}

@Composable
fun PasswordField(
    value: String,
    onChange: (String) -> Unit,
    label: String,
    enabled: Boolean = true,
    imeAction: ImeAction = ImeAction.Done,
    onDone: () -> Unit = {},
) {
    val colors = AvekTheme.colors
    var visible by remember { mutableStateOf(false) }
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        singleLine = true,
        enabled = enabled,
        visualTransformation = if (visible) VisualTransformation.None else PasswordVisualTransformation(),
        keyboardOptions = KeyboardOptions(autoCorrectEnabled = false, keyboardType = KeyboardType.Password, imeAction = imeAction),
        keyboardActions = KeyboardActions(onDone = { onDone() }),
        trailingIcon = {
            IconButton(onClick = { visible = !visible }) {
                Icon(if (visible) Icons.Outlined.VisibilityOff else Icons.Outlined.Visibility, if (visible) "Hide" else "Show", tint = colors.textSecondary)
            }
        },
        textStyle = AvekTheme.type.body.copy(color = colors.textPrimary),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = colors.accent,
            unfocusedBorderColor = colors.outline,
            focusedLabelColor = colors.accent,
            cursorColor = colors.accent,
        ),
        modifier = Modifier.fillMaxWidth(),
    )
}

/** A hint only, never a rule: longer and more varied is better. */
fun strengthHint(password: String): String {
    var kinds = 0
    if (password.any { it.isLowerCase() }) kinds++
    if (password.any { it.isUpperCase() }) kinds++
    if (password.any { it.isDigit() }) kinds++
    if (password.any { !it.isLetterOrDigit() }) kinds++
    return when {
        password.length >= 14 && kinds >= 3 -> "Strong"
        password.length >= 10 && kinds >= 2 -> "Good"
        else -> "Weak: a longer password with different kinds of characters is safer"
    }
}

fun formatWait(ms: Long): String {
    val seconds = (ms + 999) / 1000
    val minutes = seconds / 60
    return if (minutes >= 1) "$minutes min ${seconds % 60} s" else "$seconds s"
}

/** [LockGate] bound to its view model (used at the root of the activity). */
@Composable
fun LockRoute(viewModel: LockViewModel = androidx.hilt.navigation.compose.hiltViewModel(), content: @Composable () -> Unit) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val actions = remember(viewModel) {
        LockActions(
            onBiometricPassed = viewModel::onBiometricPassed,
            onCreate = viewModel::createPassword,
            onUnlock = viewModel::unlock,
            onForgetAll = viewModel::forgetAndStartOver,
            onClearError = viewModel::clearError,
        )
    }
    LockGate(state, actions, content)
}
