package com.avek.chat.core.model.settings

import kotlinx.serialization.Serializable

@Serializable
enum class ThinkingAnimation(val label: String, val description: String) {
    SPARK("Spark", "A breathing, rotating star"),
    ORBIT("Orbit", "Satellites circling a core"),
    PULSE("Pulse", "Concentric ripples"),
    WAVE("Wave", "Dots riding a sine wave"),
    SHIMMER("Shimmer", "Light sweeping across text"),
    MORPH("Morph", "A liquid, shape-shifting blob"),
    GALAXY("Galaxy", "A spiral of drifting particles"),
    HELIX("Helix", "Two strands twisting in 3D"),
    BARS("Equalizer", "Bars dancing to the rhythm"),
    CONSTELLATION("Constellation", "Stars linking into ideas"),
}

@Serializable
enum class EntranceAnimation(val label: String) {
    NONE("None"),
    FADE("Fade"),
    RISE("Rise"),
    SCALE("Scale"),
    SLIDE("Slide"),
}

@Serializable
enum class CursorStyle(val label: String) {
    NONE("None"),
    BAR("Bar"),
    BLOCK("Block"),
    DOT("Dot"),
    SPARK("Spark"),
}

@Serializable
data class MotionSettings(
    val thinkingAnimation: ThinkingAnimation = ThinkingAnimation.SPARK,
    /** 0.5x .. 2x */
    val animationSpeed: Float = 1f,
    val entrance: EntranceAnimation = EntranceAnimation.RISE,
    val cursor: CursorStyle = CursorStyle.DOT,
    val reduceMotion: Boolean = false,
    val haptics: Boolean = true,
    val streamingSpeed: Float = 1f,
)
