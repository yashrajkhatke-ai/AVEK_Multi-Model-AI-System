package com.avek.chat.feature.chat

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.avek.chat.core.common.IdGenerator
import com.avek.chat.core.common.TimeProvider
import com.avek.chat.core.data.downloads.DownloadManager
import com.avek.chat.core.data.remote.toDomain
import com.avek.chat.core.domain.chat.AskCoordinator
import com.avek.chat.core.domain.chat.AttachmentSourceFactory
import com.avek.chat.core.domain.chat.AttachmentUploader
import com.avek.chat.core.domain.chat.ChatOptions
import com.avek.chat.core.domain.chat.GenerateReplyUseCase
import com.avek.chat.core.domain.chat.OpenChatBus
import com.avek.chat.core.domain.chat.PromptRequest
import com.avek.chat.core.domain.chat.ReplyPhase
import com.avek.chat.core.domain.chat.StreamingReply
import com.avek.chat.core.domain.chat.TurnFollower
import com.avek.chat.core.domain.chat.UploadProgress
import com.avek.chat.core.domain.lists.ListMemoryRegistry
import com.avek.chat.core.domain.lists.ModelPickerController
import com.avek.chat.core.domain.repository.ChatRepository
import com.avek.chat.core.domain.repository.ModelRepository
import com.avek.chat.core.domain.repository.SettingsRepository
import com.avek.chat.core.link.AppVisibility
import com.avek.chat.core.link.HarnessApi
import com.avek.chat.core.link.LinkRepository
import com.avek.chat.core.link.rpc.RpcException
import com.avek.chat.core.link.wire.ErrorCodes
import com.avek.chat.core.link.wire.LinkEvent
import com.avek.chat.core.model.AskRequest
import com.avek.chat.core.model.AttachmentInfo
import com.avek.chat.core.model.Conversation
import com.avek.chat.core.model.Feedback
import com.avek.chat.core.model.Message
import com.avek.chat.core.model.MessageStatus
import com.avek.chat.core.model.RemoteModel
import com.avek.chat.core.model.TaskMode
import com.avek.chat.core.model.ThinkingDepth
import com.avek.chat.core.model.ToolCall
import com.avek.chat.core.model.settings.ChatDefaults
import com.avek.chat.core.model.settings.UserSettings
import com.avek.chat.feature.connection.ConnectionUi
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import com.avek.chat.core.domain.chat.oncePerFrame
import javax.inject.Inject

@HiltViewModel
class ChatViewModel @Inject constructor(
    private val chats: ChatRepository,
    private val models: ModelRepository,
    private val settingsRepository: SettingsRepository,
    private val api: HarnessApi,
    private val link: LinkRepository,
    private val generateReply: GenerateReplyUseCase,
    private val follower: TurnFollower,
    private val uploader: AttachmentUploader,
    private val sourceFactory: AttachmentSourceFactory,
    private val asks: AskCoordinator,
    private val downloads: DownloadManager,
    private val openChat: OpenChatBus,
    private val visibility: AppVisibility,
    private val ids: IdGenerator,
    private val modelStates: com.avek.chat.core.domain.models.ModelStateTracker,
    private val preloader: com.avek.chat.core.domain.models.ModelPreloader,
    traces: com.avek.chat.core.domain.trace.TraceRepository,
    private val frameClock: com.avek.chat.core.domain.chat.FrameClock,
    registry: ListMemoryRegistry,
    time: TimeProvider,
) : ViewModel() {

    /** Composer text lives in snapshot state so typing never round-trips through a Flow. */
    var draft by mutableStateOf("")
        private set

    private val sessionStartedAt = time.now()

    private data class Paging(
        val next: String? = null,
        val loadingFirst: Boolean = false,
        val loadingOlder: Boolean = false,
        val error: String? = null,
    )

    private sealed interface DefaultModel {
        data object Idle : DefaultModel
        data object Loading : DefaultModel
        data class Ready(val model: RemoteModel) : DefaultModel
        data object None : DefaultModel
    }

    // ------------------------------------------------------------------ what is open

    private val activeId = MutableStateFlow<String?>(null)
    private val chatInfo = MutableStateFlow<Conversation?>(null)
    private val loaded = MutableStateFlow<List<Message>>(emptyList())
    private val paging = MutableStateFlow(Paging())
    private val streams = MutableStateFlow<Map<String, StreamingReply>>(emptyMap())
    private val awaitingAck = MutableStateFlow(false)
    private val picked = MutableStateFlow<RemoteModel?>(null)
    private val defaultModel = MutableStateFlow<DefaultModel>(DefaultModel.Idle)
    private val attachments = MutableStateFlow<List<PendingAttachment>>(emptyList())
    private val toolViews = MutableStateFlow<Map<String, ToolViewState>>(emptyMap())
    private val thinkingLoading = MutableStateFlow<Set<String>>(emptySet())

    private var viewToken = 0
    private var pendingAck: Job? = null
    private var defaultJob: Job? = null
    private val uploadJobs = HashMap<String, Job>()
    private val drafts = HashMap<String?, String>()
    private val modelNames = HashMap<String, String>()
    private var pickerOpen = false

    private val _events = Channel<ChatEvent>(Channel.BUFFERED)
    val events: Flow<ChatEvent> = _events.receiveAsFlow()

    private val settings: StateFlow<UserSettings> =
        settingsRepository.settings.stateIn(viewModelScope, SharingStarted.Eagerly, UserSettings())

    /** What the thinking blocks of this screen read (telemetry, style, inspector data). */
    val thinking: com.avek.chat.feature.chat.thinking.ThinkingEnvironment =
        com.avek.chat.feature.chat.thinking.ThinkingEnvironmentImpl(traces, settingsRepository, viewModelScope) { settings.value.connection.demoMode }

    private val connection: StateFlow<ConnectionUi> =
        combine(link.state, settings.map { it.connection.demoMode }.distinctUntilChanged()) { state, demo -> ConnectionUi.from(state, demo) }
            .stateIn(viewModelScope, SharingStarted.Eagerly, ConnectionUi())

    /** The model sheet: a skeleton first, then models one by one. */
    val modelPicker = ModelPickerController(viewModelScope, models, { settings.value.connection.keepListsSeconds }, registry)

    /** The picker's models with their live load state (`model.state`). */
    val pickerModels: StateFlow<com.avek.chat.core.domain.lists.ModelPickerState> =
        combine(modelPicker.state, modelStates.states) { picker, states ->
            picker.copy(models = picker.models.map { m -> states[m.id]?.let { m.copy(state = it.state) } ?: m })
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), com.avek.chat.core.domain.lists.ModelPickerState())

    /** The first open question from the PC, if any (shown as a sheet over the chat). */
    val pendingAsk: StateFlow<AskRequest?> =
        asks.pending.map { it.firstOrNull() }.stateIn(viewModelScope, SharingStarted.Eagerly, null)

    val connectionUi: StateFlow<ConnectionUi> get() = connection

    /** First launch with no PC paired: the pairing screen is shown once as onboarding. */
    val needsOnboarding: StateFlow<Boolean> =
        combine(link.state, settings) { state, s ->
            state is com.avek.chat.core.link.route.ConnectionState.NeedsPairing && !s.connection.onboardingDone && !s.connection.demoMode
        }.stateIn(viewModelScope, SharingStarted.Eagerly, false)

    private data class Core(
        val id: String?,
        val info: Conversation?,
        val messages: List<Message>,
        val paging: Paging,
        val stream: StreamingReply?,
    )

    private data class Extras(
        val picked: RemoteModel?,
        val default: DefaultModel,
        val attachments: List<PendingAttachment>,
        val toolViews: Map<String, ToolViewState>,
        val thinkingLoading: Set<String>,
    )

    private data class Env(
        val settings: UserSettings,
        val connection: ConnectionUi,
        val downloaded: Set<String>,
        val awaitingAck: Boolean,
    )

    private val core = combine(activeId, chatInfo, loaded, paging, streams) { id, info, messages, pg, st ->
        Core(id, info, messages, pg, st[id])
    }
    private val extras = combine(picked, defaultModel, attachments, toolViews, thinkingLoading, ::Extras)
    private val env = combine(settings, connection, downloads.downloadedIds, awaitingAck, ::Env)
    private val loadInfo = combine(modelStates.states, preloader.status) { states, status -> states to status }

    val uiState: StateFlow<ChatUiState> = combine(core, extras, env, loadInfo) { c, x, e, (states, status) ->
        val live = c.stream
        ChatUiState(
            conversationId = c.id,
            title = c.info?.title,
            isStarred = c.info?.isStarred == true,
            isDownloaded = c.id != null && c.id in e.downloaded,
            messages = overlay(c.messages, live),
            streaming = live,
            isGenerating = live != null || e.awaitingAck,
            loadingChat = c.paging.loadingFirst,
            loadError = c.paging.error,
            hasOlder = c.paging.next != null,
            loadingOlder = c.paging.loadingOlder,
            model = chipFor(c, x).let { chip ->
                val id = chip.id
                if (id == null) chip
                else chip.copy(
                    loadState = states[id]?.state ?: com.avek.chat.core.model.ModelLoadState.UNKNOWN,
                    waiting = status?.modelId == id && status.waiting,
                    error = if (states[id]?.state == com.avek.chat.core.model.ModelLoadState.ERROR) {
                        states[id]?.error ?: "The model could not be loaded"
                    } else {
                        status?.takeIf { it.modelId == id }?.error
                    },
                )
            },
            task = e.settings.defaults.taskMode,
            depth = e.settings.defaults.depth,
            profileName = e.settings.profile.displayName,
            connection = e.connection,
            attachments = x.attachments,
            toolViews = x.toolViews,
            thinkingLoading = x.thinkingLoading,
            sessionStartedAt = sessionStartedAt,
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), initialState())

    init {
        viewModelScope.launch { link.events.collect(::onLinkEvent) }
        // Returning to the app: look at the open chat again (the link may have been quiet meanwhile).
        viewModelScope.launch {
            visibility.visible.drop(1).filter { it }.collect { if (connection.value.connected) refreshAll() }
        }
        // Names of the models we have seen, so a chat's model shows its name without loading the list.
        viewModelScope.launch { modelPicker.state.collect { s -> s.models.forEach { modelNames[it.id] = it.name } } }
        viewModelScope.launch { openChat.pending.filter { it != null }.collect { id -> if (id != null) { openChat.consume(id); openConversation(id) } } }
        // Preload (section 8.2): whenever the chat screen shows a model and the link is up.
        viewModelScope.launch {
            combine(core, extras, connection) { c, x, conn -> if (conn.connected && !conn.demo) chipFor(c, x).id else null }
                .distinctUntilChanged()
                .collect { id -> if (id != null) preloader.want(id) }
        }
        // The link may already be up when this screen is created (no Refresh event is coming then).
        viewModelScope.launch {
            connection.map { it.connected }.distinctUntilChanged().collect { connected ->
                if (connected && activeId.value == null && defaultModel.value is DefaultModel.Idle) loadDefaultModel()
            }
        }
    }

    /** A model's name when we have seen it (default model, picker, picked); its id otherwise. */
    fun modelNameOf(id: String?): String? = id?.let { modelNames[it] ?: it }

    // ------------------------------------------------------------------ composer

    fun updateDraft(text: String) {
        val wasEmpty = draft.isEmpty()
        draft = text
        // Typing started: make sure the model is loading (once per typing session).
        if (text.isEmpty()) {
            typingArmed = true
        } else if (wasEmpty && typingArmed) {
            typingArmed = false
            preloader.want(uiState.value.model.id)
        }
    }

    private var typingArmed = true

    fun useSuggestion(prompt: String, task: TaskMode) {
        draft = prompt
        selectTask(task)
    }

    fun selectModel(model: RemoteModel) {
        modelNames[model.id] = model.name
        picked.value = model
        preloader.want(model.id, immediate = true)
    }

    fun selectTask(task: TaskMode) = updateDefaults { it.copy(taskMode = task) }
    fun selectDepth(depth: ThinkingDepth) = updateDefaults { it.copy(depth = depth) }

    fun onModelSheetOpened() {
        pickerOpen = true
        modelPicker.opened()
    }

    fun onModelSheetClosed() {
        pickerOpen = false
        modelPicker.closed()
    }

    fun send() {
        val text = draft.trim()
        if (text.isEmpty()) return
        val current = uiState.value
        if (!current.canSend(draft)) {
            if (!current.connection.connected) fail("PC not reachable")
            return
        }
        val ready = attachments.value.filter { it.status == AttachStatus.READY }
        val savedDraft = draft
        val savedAttachments = attachments.value
        draft = ""
        attachments.value = emptyList()
        startPrompt(
            PromptRequest(
                chatId = activeId.value,
                text = text,
                options = currentOptions(),
                attachmentIds = ready.mapNotNull { it.attachmentId },
                attachments = ready.map { AttachmentInfo(it.name, "", it.size) },
                uiKey = "u-${ids.newId()}",
            ),
        ) {
            draft = savedDraft
            attachments.value = savedAttachments
        }
    }

    /** Asks the PC to stop the running turn (or abandons a prompt that was not acknowledged yet). */
    fun stop() {
        val reply = activeId.value?.let { streams.value[it] }
        if (reply == null) {
            pendingAck?.cancel()
            awaitingAck.value = false
            return
        }
        viewModelScope.launch {
            try {
                api.turnCancel(reply.message.conversationId, reply.message.promptId)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                fail(friendly(e))
            }
        }
    }

    // ------------------------------------------------------------------ attachments

    fun attach(uris: List<String>) {
        for (uri in uris) {
            val source = sourceFactory.create(uri)
            if (source == null) {
                fail("Could not read that file")
                continue
            }
            val key = ids.newId()
            attachments.update { it + PendingAttachment(key, source.name, source.size, 0f, AttachStatus.UPLOADING) }
            uploadJobs[key] = viewModelScope.launch {
                try {
                    uploader.upload(source).collect { progress ->
                        when (progress) {
                            is UploadProgress.Sending -> updateAttachment(key) { it.copy(progress = progress.fraction) }
                            is UploadProgress.Done -> updateAttachment(key) {
                                it.copy(progress = 1f, status = AttachStatus.READY, attachmentId = progress.attachmentId)
                            }
                        }
                    }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    updateAttachment(key) { it.copy(status = AttachStatus.FAILED, error = friendly(e)) }
                    fail("${source.name}: ${friendly(e)}")
                } finally {
                    uploadJobs.remove(key)
                }
            }
        }
    }

    /** Removes a chip; a running upload is cancelled, which sends `attach.abort`. */
    fun removeAttachment(key: String) {
        uploadJobs.remove(key)?.cancel()
        attachments.update { list -> list.filterNot { it.key == key } }
    }

    private fun updateAttachment(key: String, transform: (PendingAttachment) -> PendingAttachment) {
        attachments.update { list -> list.map { if (it.key == key) transform(it) else it } }
    }

    // ------------------------------------------------------------------ messages

    fun regenerate(reply: Message) {
        val promptId = reply.promptId ?: return
        val user = loaded.value.firstOrNull { it.isUser && it.promptId == promptId } ?: return
        rewindAndAsk(promptId, user.content)
    }

    fun editAndResend(message: Message, newText: String) {
        val promptId = message.promptId ?: return
        if (newText.isBlank()) return
        rewindAndAsk(promptId, newText.trim())
    }

    private fun rewindAndAsk(promptId: String, text: String) {
        val chatId = activeId.value ?: return
        if (!connection.value.connected) return fail("PC not reachable")
        viewModelScope.launch {
            try {
                chats.rewind(chatId, promptId)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                return@launch fail(friendly(e))
            }
            if (activeId.value == chatId) loaded.update { list -> list.takeWhile { it.promptId != promptId } }
            startPrompt(PromptRequest(chatId, text, currentOptions(), uiKey = "u-${ids.newId()}")) { draft = text }
        }
    }

    fun setFeedback(message: Message, feedback: Feedback) {
        val chatId = activeId.value ?: return
        val promptId = message.promptId ?: return
        val value = if (message.feedback == feedback) Feedback.NONE else feedback
        viewModelScope.launch {
            try {
                chats.feedback(chatId, promptId, value)
                loaded.update { list -> list.map { if (it.id == message.id) it.copy(feedback = value) else it } }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                fail(friendly(e))
            }
        }
    }

    /** The reasoning text of an old turn is fetched when the person expands it (`turn.get`). */
    fun loadThinking(message: Message) {
        val chatId = activeId.value ?: return
        val promptId = message.promptId ?: return
        if (message.thinking != null || !message.hasThinking || message.id in thinkingLoading.value) return
        if (streams.value[chatId]?.message?.id == message.id) return
        thinkingLoading.update { it + message.id }
        viewModelScope.launch {
            try {
                val turn = chats.turn(chatId, promptId, withThinking = true)
                val text = turn.assistant.thinking.orEmpty()
                loaded.update { list -> list.map { if (it.id == message.id) it.copy(thinking = text) else it } }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                fail(friendly(e))
            } finally {
                thinkingLoading.update { it - message.id }
            }
        }
    }

    /** The body of a tool call is fetched when the person expands the card (`tool.get`). */
    fun loadTool(message: Message, call: ToolCall) {
        val chatId = activeId.value ?: return
        val promptId = message.promptId ?: return
        val key = toolKey(promptId, call.callId)
        if (call.isRunning || toolViews.value[key] is ToolViewState.Loaded || toolViews.value[key] == ToolViewState.Loading) return
        toolViews.update { it + (key to ToolViewState.Loading) }
        viewModelScope.launch {
            try {
                val view = chats.tool(chatId, promptId, call.callId)
                toolViews.update { it + (key to ToolViewState.Loaded(view)) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                toolViews.update { it + (key to ToolViewState.Failed(friendly(e))) }
            }
        }
    }

    // ------------------------------------------------------------------ paging

    /** The 4th-oldest loaded turn became visible: fetch 20 more turns into the past (once per page). */
    fun loadOlder() {
        val chatId = activeId.value ?: return
        val state = paging.value
        val cursor = state.next ?: return
        if (state.loadingOlder || state.loadingFirst) return
        val token = viewToken
        paging.update { it.copy(loadingOlder = true) }
        viewModelScope.launch {
            try {
                val page = chats.open(chatId, OLDER_TURNS, cursor)
                if (token != viewToken) return@launch
                loaded.update { current -> page.messages.filter { m -> current.none { it.id == m.id } } + current }
                paging.update { it.copy(next = page.next, loadingOlder = false) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (token == viewToken) paging.update { it.copy(loadingOlder = false) }
                fail(friendly(e))
            }
        }
    }

    fun retryLoad() {
        val id = activeId.value ?: return
        paging.value = Paging(loadingFirst = true)
        loadFirstPage(id, viewToken)
    }

    // ------------------------------------------------------------- conversation

    fun newChat() {
        if (activeId.value == null && loaded.value.isEmpty()) {
            draft = ""
            return
        }
        switchView(null)
    }

    fun openConversation(id: String) {
        if (activeId.value == id) return
        switchView(id)
    }

    fun toggleStar() {
        val id = activeId.value ?: return
        val starred = chatInfo.value?.isStarred == true
        mutate { chats.setChat(id, starred = !starred) }
    }

    fun rename(title: String) {
        val id = activeId.value ?: return
        if (title.isBlank()) return
        mutate { chats.setChat(id, title = title.trim()) }
    }

    fun deleteActive() {
        val id = activeId.value ?: return
        viewModelScope.launch {
            try {
                chats.delete(id)
                if (activeId.value == id) switchView(null)
                _events.trySend(ChatEvent.Info("Conversation deleted"))
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                fail(friendly(e))
            }
        }
    }

    fun toggleDownload() {
        val id = activeId.value ?: return
        val downloaded = uiState.value.isDownloaded
        viewModelScope.launch {
            try {
                if (downloaded) {
                    downloads.remove(id)
                    _events.trySend(ChatEvent.Info("Removed from this device"))
                } else {
                    _events.trySend(ChatEvent.Info("Downloading…"))
                    downloads.download(id)
                    _events.trySend(ChatEvent.Info("Downloaded: readable without the PC"))
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                fail(friendly(e))
            }
        }
    }

    // ------------------------------------------------------------------ doubts

    fun answerAsk(ask: AskRequest, decision: String) = answer { asks.decide(ask, decision) }

    fun answerAskText(ask: AskRequest, text: String) = answer { asks.reply(ask, text) }

    private fun answer(block: suspend () -> Unit) {
        viewModelScope.launch {
            try {
                block()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                fail(friendly(e))
            }
        }
    }

    // ------------------------------------------------------------------ internals

    private fun mutate(block: suspend () -> Conversation) {
        viewModelScope.launch {
            try {
                chatInfo.value = block()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                fail(friendly(e))
            }
        }
    }

    private fun currentOptions(): ChatOptions {
        val d = settings.value.defaults
        return ChatOptions(modelId = picked.value?.id, task = d.taskMode, depth = d.depth)
    }

    private fun startPrompt(request: PromptRequest, restore: () -> Unit) {
        val token = viewToken
        consume(token, awaitAck = true, restore = restore) { generateReply(request) }
    }

    /**
     * Runs a stream of [StreamingReply] snapshots into [streams]; when it ends the finished
     * messages are committed to the open chat (if it is still the one on screen).
     */
    private fun consume(token: Int, awaitAck: Boolean, restore: (() -> Unit)? = null, source: () -> Flow<StreamingReply>) {
        val job = viewModelScope.launch {
            if (awaitAck) awaitingAck.value = true
            var chatId: String? = null
            try {
                // Every token is applied in the data layer; the screen gets at most one update per frame.
                source().oncePerFrame(frameClock).collect { snapshot ->
                    val id = snapshot.message.conversationId
                    if (chatId == null) {
                        chatId = id
                        if (awaitAck) {
                            awaitingAck.value = false
                            if (token == viewToken) {
                                // A new chat now exists on the PC.
                                if (activeId.value == null) activeId.value = id
                                snapshot.chat?.let { chatInfo.value = it }
                            }
                        }
                    }
                    streams.update { it + (id to snapshot) }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (chatId == null) restore?.invoke()
                fail(friendly(e))
            } finally {
                if (awaitAck) awaitingAck.value = false
                chatId?.let(::finish)
            }
        }
        if (awaitAck) pendingAck = job
    }

    private fun finish(chatId: String) {
        val last = streams.value[chatId]
        streams.update { it - chatId }
        if (last != null && activeId.value == chatId) {
            loaded.update { mergeById(it, listOf(last.user, last.message)) }
        }
    }

    private fun switchView(id: String?) {
        drafts[activeId.value] = draft
        draft = drafts.remove(id).orEmpty()
        viewToken++
        activeId.value = id
        chatInfo.value = null
        loaded.value = emptyList()
        paging.value = Paging(loadingFirst = id != null)
        picked.value = null
        toolViews.value = emptyMap()
        thinkingLoading.value = emptySet()
        awaitingAck.value = false
        typingArmed = true
        if (id != null) loadFirstPage(id, viewToken) else if (connection.value.connected) loadDefaultModel()
    }

    private fun loadFirstPage(chatId: String, token: Int) {
        viewModelScope.launch {
            try {
                val page = chats.open(chatId, FIRST_TURNS, null)
                if (token != viewToken) return@launch
                loaded.value = page.messages
                page.chat?.let { chatInfo.value = it }
                paging.value = Paging(next = page.next)
                followIfRunning(chatId, token)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (token == viewToken) paging.value = Paging(error = friendly(e))
            }
        }
    }

    /** The PC, or a downloaded copy, may show a turn that is still running: attach to its events. */
    private fun followIfRunning(chatId: String, token: Int) {
        if (streams.value.containsKey(chatId)) return
        val messages = loaded.value
        val assistant = messages.lastOrNull { !it.isUser } ?: return
        if (assistant.status != MessageStatus.STREAMING && assistant.status != MessageStatus.WAITING) return
        if (!connection.value.connected) return
        val user = messages.lastOrNull { it.isUser && it.promptId == assistant.promptId } ?: return
        val initial = StreamingReply(
            user = user,
            message = assistant,
            phase = if (assistant.content.isNotEmpty() || !assistant.hasThinking) ReplyPhase.ANSWERING else ReplyPhase.THINKING,
            activity = null,
        )
        consume(token, awaitAck = false) { follower.follow(initial, link.events) }
    }

    private fun refreshAll() {
        val id = activeId.value
        if (id == null) {
            loadDefaultModel()
            return
        }
        val token = viewToken
        viewModelScope.launch {
            try {
                val page = chats.open(id, FIRST_TURNS, null)
                if (token != viewToken) return@launch
                page.chat?.let { chatInfo.value = it }
                val firstCreated = page.messages.firstOrNull()?.createdAt ?: Long.MAX_VALUE
                loaded.update { current ->
                    val older = current.filter { it.createdAt < firstCreated && page.messages.none { m -> m.id == it.id } }
                    mergeById(older, page.messages, keepKeysFrom = current)
                }
                if (paging.value.next == null && paging.value.error == null && loaded.value.size <= page.messages.size) {
                    paging.update { it.copy(next = page.next) }
                }
                paging.update { it.copy(error = null, loadingFirst = false) }
                followIfRunning(id, token)
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
                // Silent: the next refresh (or the retry button) tries again.
            }
        }
    }

    private fun loadDefaultModel() {
        if (defaultJob?.isActive == true) return
        defaultModel.value = DefaultModel.Loading
        defaultJob = viewModelScope.launch {
            try {
                val model = models.defaultModel()
                if (model != null) modelNames[model.id] = model.name
                defaultModel.value = if (model == null) DefaultModel.None else DefaultModel.Ready(model)
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
                defaultModel.value = DefaultModel.Idle
            }
        }
    }

    private fun onLinkEvent(event: LinkEvent) {
        when (event) {
            LinkEvent.Refresh -> {
                refreshAll()
                preloader.want(uiState.value.model.id)
            }
            is LinkEvent.ModelsChanged -> {
                if (activeId.value == null) {
                    defaultJob?.cancel()
                    loadDefaultModel()
                }
                if (pickerOpen) modelPicker.reload()
            }
            is LinkEvent.ChatUpdated -> if (event.chat.chatId == activeId.value) chatInfo.value = event.chat.toDomain()
            is LinkEvent.ChatDeleted -> if (event.chatId == activeId.value) {
                switchView(null)
                _events.trySend(ChatEvent.Info("This chat was deleted on the PC"))
            }
            else -> Unit
        }
    }

    private fun updateDefaults(transform: (ChatDefaults) -> ChatDefaults) {
        viewModelScope.launch { settingsRepository.update { it.copy(defaults = transform(it.defaults)) } }
    }

    private fun fail(message: String) {
        _events.trySend(ChatEvent.Error(message))
    }

    private fun friendly(e: Throwable): String = when {
        e is RpcException -> when (e.code) {
            ErrorCodes.BUSY -> "This chat is still answering. Wait for it to finish."
            ErrorCodes.NO_MODEL -> "No model is ready on the PC."
            ErrorCodes.TOO_LARGE -> e.message ?: "That is too large."
            RpcException.NOT_CONNECTED -> "PC not reachable."
            RpcException.TIMEOUT -> "The PC did not answer in time."
            RpcException.CONNECTION_LOST -> "The connection to the PC was lost."
            RpcException.NOT_FOUND_LOCAL -> "That chat is not downloaded, and the PC is not reachable."
            else -> e.message ?: "Something went wrong."
        }
        else -> e.message ?: "Something went wrong."
    }

    private fun chipFor(c: Core, x: Extras): ModelChip {
        x.picked?.let { return ModelChip(it.id, it.name, loading = false) }
        c.info?.modelId?.let { return ModelChip(it, modelNames[it] ?: it, loading = false) }
        if (c.id != null) return ModelChip(loading = c.info == null && c.paging.error == null)
        return when (val d = x.default) {
            is DefaultModel.Ready -> ModelChip(d.model.id, d.model.name, loading = false)
            DefaultModel.None -> ModelChip(loading = false, noneAvailable = true)
            else -> ModelChip(loading = true)
        }
    }

    private fun initialState() = ChatUiState(
        conversationId = null,
        title = null,
        isStarred = false,
        isDownloaded = false,
        messages = emptyList(),
        streaming = null,
        isGenerating = false,
        loadingChat = false,
        loadError = null,
        hasOlder = false,
        loadingOlder = false,
        model = ModelChip(),
        task = TaskMode.AUTO,
        depth = ThinkingDepth.BALANCED,
        profileName = "",
        connection = ConnectionUi(),
        attachments = emptyList(),
        toolViews = emptyMap(),
        thinkingLoading = emptySet(),
        sessionStartedAt = sessionStartedAt,
    )

    companion object {
        /** `chat.get {limit:12}` when a chat opens (UI-WIRE section 13). */
        const val FIRST_TURNS = 12

        /** `{limit:20, after:next}` when the 4th-oldest turn becomes visible. */
        const val OLDER_TURNS = 20

        /** Visible index (counting user + assistant messages) of the 4th-oldest turn's last message. */
        const val OLDER_TRIGGER_INDEX = 7

        fun toolKey(promptId: String, callId: String) = "$promptId:$callId"

        /** Replaces messages that share an id (keeping the list key, so nothing flickers) and appends new ones. */
        internal fun mergeById(base: List<Message>, incoming: List<Message>, keepKeysFrom: List<Message> = base): List<Message> {
            val keys = keepKeysFrom.associate { it.id to it.uiKey }
            val result = base.toMutableList()
            for (message in incoming) {
                val fixed = keys[message.id]?.let { message.copy(uiKey = it) } ?: message
                val index = result.indexOfFirst { it.id == message.id }
                if (index >= 0) result[index] = fixed else result += fixed
            }
            return result
        }

        /** The live messages replace their persisted twins (same id) or follow the list. */
        internal fun overlay(loaded: List<Message>, live: StreamingReply?): List<Message> =
            if (live == null) loaded else mergeById(loaded, listOf(live.user, live.message))
    }
}
