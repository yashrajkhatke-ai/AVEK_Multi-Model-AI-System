package com.avek.chat.feature.chat

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.avek.chat.core.common.TimeProvider
import com.avek.chat.core.domain.repository.ConversationRepository
import com.avek.chat.core.domain.repository.ModelRepository
import com.avek.chat.core.domain.repository.SettingsRepository
import com.avek.chat.core.domain.usecase.ChatOptions
import com.avek.chat.core.domain.usecase.EditUserMessageUseCase
import com.avek.chat.core.domain.usecase.GenerateReplyUseCase
import com.avek.chat.core.domain.usecase.PrepareRegenerationUseCase
import com.avek.chat.core.domain.usecase.SendMessageUseCase
import com.avek.chat.core.domain.usecase.StreamingReply
import com.avek.chat.core.domain.usecase.TaskClassifier
import com.avek.chat.core.model.Feedback
import com.avek.chat.core.model.Message
import com.avek.chat.core.model.TaskMode
import com.avek.chat.core.model.ThinkingDepth
import com.avek.chat.core.model.settings.UserSettings
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.emptyFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ChatViewModel @Inject constructor(
    private val conversations: ConversationRepository,
    private val models: ModelRepository,
    private val settingsRepository: SettingsRepository,
    private val sendMessage: SendMessageUseCase,
    private val generateReply: GenerateReplyUseCase,
    private val prepareRegeneration: PrepareRegenerationUseCase,
    private val editUserMessage: EditUserMessageUseCase,
    private val classifier: TaskClassifier,
    time: TimeProvider,
) : ViewModel() {

    /** Composer text lives in snapshot state so typing never round-trips through a Flow. */
    var draft by mutableStateOf("")
        private set

    private val sessionStartedAt = time.now()
    private val activeId = MutableStateFlow<String?>(null)
    private val streaming = MutableStateFlow<StreamingReply?>(null)
    private val busy = MutableStateFlow(false)
    private var generation: Job? = null

    private val _events = Channel<ChatEvent>(Channel.BUFFERED)
    val events: Flow<ChatEvent> = _events.receiveAsFlow()

    private val settings: StateFlow<UserSettings> =
        settingsRepository.settings.stateIn(viewModelScope, SharingStarted.Eagerly, UserSettings())

    private val messages = activeId.flatMapLatest { id ->
        if (id == null) flowOf(emptyList()) else conversations.observeMessages(id)
    }

    private val conversation = activeId.flatMapLatest { id ->
        if (id == null) flowOf(null) else conversations.observeConversation(id)
    }

    private val live = combine(streaming, busy) { reply, isBusy -> reply to isBusy }

    val uiState: StateFlow<ChatUiState> =
        combine(activeId, conversation, messages, live, settings) { id, conv, persisted, (reply, isBusy), s ->
            val replyHere = reply?.takeIf { it.message.conversationId == id }
            ChatUiState(
                conversationId = id,
                title = conv?.title,
                isStarred = conv?.isStarred == true,
                messages = merge(persisted, replyHere?.message),
                streaming = replyHere,
                // A reply streaming into another conversation doesn't block this one's UI.
                isGenerating = isBusy && (reply == null || replyHere != null),
                model = models.find(s.defaults.modelId),
                models = models.models,
                task = s.defaults.taskMode,
                requestedDepth = s.defaults.depth,
                profileName = s.profile.displayName,
                sessionStartedAt = sessionStartedAt,
            )
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), initialState())

    /** Live preview of what Auto mode would pick for the current draft. */
    val detectedTask: StateFlow<TaskMode?> = snapshotFlow { draft }
        .debounce(180)
        .map { text -> if (text.isBlank()) null else classifier.classify(text) }
        .distinctUntilChanged()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    init {
        // If the open conversation is deleted (e.g. from the sidebar), fall back to a new chat.
        viewModelScope.launch {
            activeId.flatMapLatest { id ->
                if (id == null) emptyFlow() else conversations.observeConversation(id).map { id to it }
            }.collect { (id, conv) ->
                if (conv == null && activeId.value == id) activeId.value = null
            }
        }
    }

    // ------------------------------------------------------------------ composer

    fun updateDraft(text: String) {
        draft = text
    }

    fun useSuggestion(prompt: String, task: TaskMode) {
        draft = prompt
        selectTask(task)
    }

    fun selectModel(id: String) = updateDefaults { it.copy(modelId = id) }
    fun selectTask(task: TaskMode) = updateDefaults { it.copy(taskMode = task) }
    fun selectDepth(depth: ThinkingDepth) = updateDefaults { it.copy(depth = depth) }

    fun send() {
        val text = draft.trim()
        if (text.isEmpty()) return
        draft = ""
        val options = currentOptions()
        launchGeneration {
            val id = sendMessage(activeId.value, text, options, settings.value.defaults.autoTitle)
            activeId.value = id
            stream(id, options)
        }
    }

    fun stop() {
        generation?.cancel()
    }

    // ------------------------------------------------------------------ messages

    fun regenerate(reply: Message) {
        val options = currentOptions()
        launchGeneration {
            prepareRegeneration(reply)
            stream(reply.conversationId, options)
        }
    }

    fun editAndResend(message: Message, newText: String) {
        if (newText.isBlank()) return
        val options = currentOptions()
        launchGeneration {
            editUserMessage(message, newText, options.modelId, options.task)
            stream(message.conversationId, options)
        }
    }

    fun setFeedback(message: Message, feedback: Feedback) {
        viewModelScope.launch {
            conversations.setFeedback(message.id, if (message.feedback == feedback) Feedback.NONE else feedback)
        }
    }

    // ------------------------------------------------------------- conversation

    fun newChat() {
        activeId.value = null
        draft = ""
    }

    fun openConversation(id: String) {
        if (activeId.value == id) return
        activeId.value = id
        draft = ""
    }

    fun toggleStar() {
        val id = activeId.value ?: return
        val starred = uiState.value.isStarred
        viewModelScope.launch { conversations.setStarred(id, !starred) }
    }

    fun rename(title: String) {
        val id = activeId.value ?: return
        if (title.isBlank()) return
        viewModelScope.launch { conversations.rename(id, title) }
    }

    fun deleteActive() {
        val id = activeId.value ?: return
        generation?.cancel()
        viewModelScope.launch {
            conversations.delete(id)
            _events.send(ChatEvent.Info("Conversation deleted"))
        }
    }

    // ------------------------------------------------------------------ helpers

    private fun currentOptions(): ChatOptions {
        val s = settings.value
        return ChatOptions(
            modelId = s.defaults.modelId,
            task = s.defaults.taskMode,
            depth = s.defaults.depth,
            speed = s.appearance.motion.streamingSpeed,
        )
    }

    private fun launchGeneration(block: suspend () -> Unit) {
        generation?.cancel()
        generation = viewModelScope.launch {
            busy.value = true
            try {
                block()
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Exception) {
                _events.send(ChatEvent.Error(error.message ?: "Something went wrong"))
            } finally {
                busy.value = false
            }
        }
    }

    private suspend fun stream(conversationId: String, options: ChatOptions) {
        try {
            generateReply(conversationId, options).collect { streaming.value = it }
        } finally {
            streaming.value = null
        }
    }

    private fun updateDefaults(transform: (com.avek.chat.core.model.settings.ChatDefaults) -> com.avek.chat.core.model.settings.ChatDefaults) {
        viewModelScope.launch { settingsRepository.update { it.copy(defaults = transform(it.defaults)) } }
    }

    private fun initialState() = ChatUiState(
        conversationId = null,
        title = null,
        isStarred = false,
        messages = emptyList(),
        streaming = null,
        isGenerating = false,
        model = models.defaultModel,
        models = models.models,
        task = TaskMode.AUTO,
        requestedDepth = ThinkingDepth.BALANCED,
        profileName = "",
        sessionStartedAt = sessionStartedAt,
    )

    private companion object {
        fun merge(persisted: List<Message>, live: Message?): List<Message> {
            if (live == null) return persisted
            val index = persisted.indexOfFirst { it.id == live.id }
            return if (index >= 0) persisted.toMutableList().also { it[index] = live } else persisted + live
        }
    }
}
