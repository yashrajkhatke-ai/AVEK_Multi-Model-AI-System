package com.avek.chat.core.designsystem.theme

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Hue in degrees [0, 360), saturation and lightness in [0, 1]. */
data class Hsl(val hue: Float, val saturation: Float, val lightness: Float)

object ColorMath {

    fun hsl(hue: Float, saturation: Float, lightness: Float, alpha: Float = 1f): Color =
        Color.hsl(
            hue = ((hue % 360f) + 360f) % 360f,
            saturation = saturation.coerceIn(0f, 1f),
            lightness = lightness.coerceIn(0f, 1f),
            alpha = alpha.coerceIn(0f, 1f),
        )

    fun toHsl(color: Color): Hsl {
        val r = color.red
        val g = color.green
        val b = color.blue
        val maxC = max(r, max(g, b))
        val minC = min(r, min(g, b))
        val l = (maxC + minC) / 2f
        if (maxC == minC) return Hsl(0f, 0f, l)
        val d = maxC - minC
        val s = if (l > 0.5f) d / (2f - maxC - minC) else d / (maxC + minC)
        val h = when (maxC) {
            r -> ((g - b) / d + (if (g < b) 6f else 0f))
            g -> ((b - r) / d + 2f)
            else -> ((r - g) / d + 4f)
        } * 60f
        return Hsl(h, s, l)
    }

    fun contrast(a: Color, b: Color): Float {
        val la = a.luminance()
        val lb = b.luminance()
        return (max(la, lb) + 0.05f) / (min(la, lb) + 0.05f)
    }

    fun mix(a: Color, b: Color, fraction: Float): Color = lerp(a, b, fraction.coerceIn(0f, 1f))

    fun isLight(color: Color): Boolean = color.luminance() > 0.45f

    /**
     * Returns [preferred] if it is readable on [background]; otherwise nudges its
     * lightness away from the background until [minRatio] is met.
     */
    fun readableOn(background: Color, preferred: Color? = null, minRatio: Float = 4.5f): Color {
        val start = preferred ?: if (isLight(background)) Color(0xFF1A1A1A) else Color(0xFFF7F7F5)
        if (contrast(start, background) >= minRatio) return start
        // Walk the preferred colour's lightness both ways; take the smallest change that works.
        val hsl = toHsl(start)
        for (step in 1..40) {
            val delta = step * 0.025f
            for (sign in floatArrayOf(-1f, 1f)) {
                val lightness = hsl.lightness + sign * delta
                if (lightness < 0f || lightness > 1f) continue
                val candidate = hsl(hsl.hue, hsl.saturation, lightness)
                if (contrast(candidate, background) >= minRatio) return candidate
            }
        }
        // Pure black or white always clears 4.5:1 against any opaque background.
        return if (contrast(Color.Black, background) >= contrast(Color.White, background)) Color.Black else Color.White
    }

    fun shift(color: Color, lightnessDelta: Float = 0f, saturationDelta: Float = 0f, hueDelta: Float = 0f): Color {
        val hsl = toHsl(color)
        return hsl(hsl.hue + hueDelta, hsl.saturation + saturationDelta, hsl.lightness + lightnessDelta, color.alpha)
    }

    fun hueDistance(a: Float, b: Float): Float {
        val d = abs(a - b) % 360f
        return if (d > 180f) 360f - d else d
    }

    fun toHex(color: Color, includeAlpha: Boolean = color.alpha < 1f): String {
        fun channel(v: Float) = (v.coerceIn(0f, 1f) * 255f + 0.5f).toInt()
        val rgb = (channel(color.red) shl 16) or (channel(color.green) shl 8) or channel(color.blue)
        return if (includeAlpha) "#%02X%06X".format(channel(color.alpha), rgb) else "#%06X".format(rgb)
    }

    fun parseHex(text: String): Color? {
        val clean = text.trim().removePrefix("#")
        val value = clean.toLongOrNull(16) ?: return null
        return when (clean.length) {
            3 -> {
                val r = (value shr 8 and 0xF) * 17
                val g = (value shr 4 and 0xF) * 17
                val b = (value and 0xF) * 17
                Color(0xFF000000 or (r shl 16) or (g shl 8) or b)
            }
            6 -> Color(0xFF000000 or value)
            8 -> Color(value)
            else -> null
        }
    }
}

/** Hue in degrees, saturation and value in [0, 1]. */
data class Hsv(val hue: Float, val saturation: Float, val value: Float) {
    fun toColor(alpha: Float = 1f): Color =
        Color.hsv(((hue % 360f) + 360f) % 360f, saturation.coerceIn(0f, 1f), value.coerceIn(0f, 1f), alpha.coerceIn(0f, 1f))

    companion object {
        fun from(color: Color): Hsv {
            val r = color.red
            val g = color.green
            val b = color.blue
            val maxC = max(r, max(g, b))
            val minC = min(r, min(g, b))
            val d = maxC - minC
            val h = when {
                d == 0f -> 0f
                maxC == r -> 60f * (((g - b) / d) % 6f)
                maxC == g -> 60f * (((b - r) / d) + 2f)
                else -> 60f * (((r - g) / d) + 4f)
            }
            return Hsv((h + 360f) % 360f, if (maxC == 0f) 0f else d / maxC, maxC)
        }
    }
}
