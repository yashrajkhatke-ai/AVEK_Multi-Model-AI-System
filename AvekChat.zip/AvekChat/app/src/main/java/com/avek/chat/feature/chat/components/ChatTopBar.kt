package com.avek.chat.feature.chat.components

import androidx.compose.animation.AnimatedContent
import com.avek.chat.core.designsystem.theme.avekShape
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.DriveFileRenameOutline
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.KeyboardArrowDown
import com.avek.chat.core.designsystem.component.AvekMenuIcon
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material.icons.outlined.Palette
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.StarOutline
import androidx.compose.material.icons.outlined.AddComment
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.avek.chat.core.designsystem.theme.AvekTheme
import com.avek.chat.feature.chat.ModelChip
import androidx.compose.material.icons.outlined.CloudDownload
import androidx.compose.material.icons.outlined.DownloadDone
import androidx.compose.material.icons.outlined.Cable
import androidx.compose.foundation.background

/** Height of the top app bar, excluding the status bar. */
val TopBarHeight = 64.dp

@Composable
fun ChatTopBar(
    model: ModelChip,
    title: String?,
    isStarred: Boolean,
    isDownloaded: Boolean,
    hasConversation: Boolean,
    onMenu: () -> Unit,
    onModelClick: () -> Unit,
    onNewChat: () -> Unit,
    onToggleStar: () -> Unit,
    onRename: () -> Unit,
    onDelete: () -> Unit,
    onToggleDownload: () -> Unit,
    onOpenDownloads: () -> Unit,
    onOpenConnection: () -> Unit,
    onCustomize: () -> Unit,
    onSettings: () -> Unit,
) {
    val colors = AvekTheme.colors
    var overflow by remember { mutableStateOf(false) }

    CenterAlignedTopAppBar(
        colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
            // Transparent: the conversation fades out underneath (see fadingEdges).
            containerColor = androidx.compose.ui.graphics.Color.Transparent,
            scrolledContainerColor = androidx.compose.ui.graphics.Color.Transparent,
            navigationIconContentColor = colors.textPrimary,
            actionIconContentColor = colors.textPrimary,
        ),
        navigationIcon = {
            IconButton(onClick = onMenu) { AvekMenuIcon(colors.textPrimary, contentDescription = "Open history") }
        },
        title = {
            Column(
                Modifier
                    .clip(avekShape(12.dp))
                    .clickable(onClick = onModelClick)
                    .padding(horizontal = 10.dp, vertical = 4.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    AnimatedContent(model.label to model.loading, transitionSpec = { fadeIn() togetherWith fadeOut() }, label = "model") { (name, loading) ->
                        if (loading) {
                            // A neutral placeholder while the PC is being asked: never a made-up name.
                            Box(
                                Modifier
                                    .padding(vertical = 5.dp)
                                    .size(width = 84.dp, height = 14.dp)
                                    .clip(avekShape(7.dp))
                                    .background(colors.outline.copy(alpha = 0.45f)),
                            )
                        } else {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                ModelStateDot(model.loadState, Modifier.size(9.dp))
                                if (model.loadState != com.avek.chat.core.model.ModelLoadState.UNKNOWN) Spacer(Modifier.width(6.dp))
                                Text(name, style = AvekTheme.type.title, color = colors.textPrimary, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 180.dp))
                            }
                        }
                    }
                    Spacer(Modifier.width(2.dp))
                    Icon(Icons.Outlined.KeyboardArrowDown, null, tint = colors.textSecondary, modifier = Modifier.size(18.dp))
                }
                if (title != null) {
                    Text(
                        title,
                        style = AvekTheme.type.caption,
                        color = colors.textSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.width(200.dp),
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                    )
                }
            }
        },
        actions = {
            IconButton(onClick = onNewChat) { Icon(Icons.Outlined.AddComment, contentDescription = "New chat") }
            Box {
                IconButton(onClick = { overflow = true }) { Icon(Icons.Outlined.MoreVert, contentDescription = "More") }
                DropdownMenu(expanded = overflow, onDismissRequest = { overflow = false }, containerColor = colors.surface) {
                    if (hasConversation) {
                        MenuItem(if (isStarred) "Unstar" else "Star", if (isStarred) Icons.Filled.Star else Icons.Outlined.StarOutline) {
                            overflow = false
                            onToggleStar()
                        }
                        MenuItem("Rename", Icons.Outlined.DriveFileRenameOutline) {
                            overflow = false
                            onRename()
                        }
                        MenuItem(
                            if (isDownloaded) "Remove download" else "Download",
                            if (isDownloaded) Icons.Outlined.DownloadDone else Icons.Outlined.CloudDownload,
                        ) {
                            overflow = false
                            onToggleDownload()
                        }
                        MenuItem("Delete", Icons.Outlined.DeleteOutline, danger = true) {
                            overflow = false
                            onDelete()
                        }
                        HorizontalDivider(color = colors.outline.copy(alpha = 0.6f))
                    }
                    MenuItem("Downloaded chats", Icons.Outlined.DownloadDone) {
                        overflow = false
                        onOpenDownloads()
                    }
                    MenuItem("Connection", Icons.Outlined.Cable) {
                        overflow = false
                        onOpenConnection()
                    }
                    MenuItem("Customize", Icons.Outlined.Palette) {
                        overflow = false
                        onCustomize()
                    }
                    MenuItem("Settings", Icons.Outlined.Settings) {
                        overflow = false
                        onSettings()
                    }
                }
            }
        },
    )
}

@Composable
internal fun MenuItem(label: String, icon: ImageVector, danger: Boolean = false, onClick: () -> Unit) {
    val colors = AvekTheme.colors
    val tint = if (danger) colors.danger else colors.textPrimary
    DropdownMenuItem(
        text = { Text(label, style = AvekTheme.type.body, color = tint) },
        leadingIcon = { Icon(icon, null, tint = if (danger) colors.danger else colors.textSecondary) },
        onClick = onClick,
    )
}
