package com.avek.chat.platform.android

import android.content.Context
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import com.avek.chat.core.link.route.NetworkEnvironment
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.drop
import javax.inject.Inject
import javax.inject.Singleton

/**
 * The phone's network as the route racer needs it: changes of the default network
 * (`ConnectivityManager.NetworkCallback`), whether the Tailscale app is installed (declared in
 * `<queries>`), and whether a VPN is active.
 */
@Singleton
class AndroidNetworkEnvironment @Inject constructor(
    @ApplicationContext private val context: Context,
) : NetworkEnvironment {

    private val connectivity = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

    override val changes: Flow<Unit> = callbackFlow {
        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                trySend(Unit)
            }

            override fun onLost(network: Network) {
                trySend(Unit)
            }
        }
        val registered = runCatching { connectivity.registerDefaultNetworkCallback(callback) }.isSuccess
        awaitClose { if (registered) runCatching { connectivity.unregisterNetworkCallback(callback) } }
    }.drop(1) // the first onAvailable is the current network, not a change

    override fun tailscaleInstalled(): Boolean = try {
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            context.packageManager.getPackageInfo(TAILSCALE_PACKAGE, PackageManager.PackageInfoFlags.of(0))
        } else {
            @Suppress("DEPRECATION")
            context.packageManager.getPackageInfo(TAILSCALE_PACKAGE, 0)
        }
        true
    } catch (_: PackageManager.NameNotFoundException) {
        false
    }

    override fun vpnActive(): Boolean = runCatching {
        connectivity.allNetworks.any { connectivity.getNetworkCapabilities(it)?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true }
    }.getOrDefault(false)

    private companion object {
        const val TAILSCALE_PACKAGE = "com.tailscale.ipn"
    }
}
