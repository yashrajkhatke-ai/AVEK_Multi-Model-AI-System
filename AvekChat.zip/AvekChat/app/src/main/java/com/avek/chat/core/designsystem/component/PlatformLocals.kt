package com.avek.chat.core.designsystem.component

import androidx.compose.runtime.staticCompositionLocalOf

/** Platform share sheet. The Android implementation fires an ACTION_SEND chooser. */
fun interface ShareHandler {
    fun share(text: String)
}

val LocalShareHandler = staticCompositionLocalOf { ShareHandler { } }
