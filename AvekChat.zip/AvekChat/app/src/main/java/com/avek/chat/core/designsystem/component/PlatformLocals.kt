package com.avek.chat.core.designsystem.component

import androidx.compose.runtime.staticCompositionLocalOf

/** Platform share sheet. The Android implementation fires an ACTION_SEND chooser. */
fun interface ShareHandler {
    fun share(text: String)
}

val LocalShareHandler = staticCompositionLocalOf { ShareHandler { } }

/** The system file picker (Storage Access Framework on Android). Results are content URI strings. */
fun interface FilePicker {
    fun pick(mimeTypes: List<String>, onPicked: (List<String>) -> Unit)
}

val LocalFilePicker = staticCompositionLocalOf { FilePicker { _, _ -> } }

/** Things only the activity can do: runtime permission, battery-optimisation exemption. */
interface PlatformActions {
    /** Asks for the notification permission where it exists (Android 13+); calls back with the result. */
    fun requestNotificationPermission(onResult: (Boolean) -> Unit)

    fun isIgnoringBatteryOptimizations(): Boolean

    /** Opens the system dialog that offers to exempt the app from battery optimisation. */
    fun requestIgnoreBatteryOptimizations()
}

object NoPlatformActions : PlatformActions {
    override fun requestNotificationPermission(onResult: (Boolean) -> Unit) = onResult(true)
    override fun isIgnoringBatteryOptimizations() = true
    override fun requestIgnoreBatteryOptimizations() = Unit
}

val LocalPlatformActions = staticCompositionLocalOf<PlatformActions> { NoPlatformActions }
