package com.avek.chat.core.link.crypto

import com.avek.chat.core.link.transport.RawChannel
import com.avek.chat.core.link.wire.WireJson
import com.avek.chat.core.link.transport.RawMessage
import kotlinx.coroutines.withTimeout
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put

/** Everything that can go wrong while pairing or opening a session. */
sealed class HandshakeException(message: String, cause: Throwable? = null) : Exception(message, cause) {
    /** The PC refused: `no-code`, `bad-code`, `expired`, `rate-limited`, `unknown-device`, `revoked`. */
    class Denied(val reason: String) : HandshakeException("Denied: $reason")

    /** The server did not prove it knows the secret: it is not our PC. */
    class UntrustedServer : HandshakeException("Server failed to prove it knows the secret")

    class Protocol(message: String, cause: Throwable? = null) : HandshakeException(message, cause)

    class ClosedByPeer(val code: Int, val reason: String) : HandshakeException("Closed by peer ($code $reason)")

    class Timeout : HandshakeException("Handshake timed out")
}

class PairingGrant(
    val deviceId: String,
    val deviceSecret: ByteArray,
    val serverId: String,
    val serverName: String,
)

class SessionKeys(val clientToServer: ByteArray, val serverToClient: ByteArray)

/** Derived values of the pairing flow (UI-WIRE section 3, step 3). */
class PairDerivation(
    val transcript: ByteArray,
    val pairKey: ByteArray,
    val clientMac: ByteArray,
    val serverMac: ByteArray,
    val encKey: ByteArray,
)

/** Derived values of the session flow (UI-WIRE section 4, step 3). */
class SessionDerivation(
    val transcript: ByteArray,
    val macKey: ByteArray,
    val clientToServer: ByteArray,
    val serverToClient: ByteArray,
    val serverMac: ByteArray,
    val clientMac: ByteArray,
)

/** The pure key-derivation maths, shared by the client, the tests and the fake server. */
object HandshakeMath {

    fun normalizeCode(input: String): String = input.uppercase().filter { !it.isWhitespace() && it != '-' }

    fun pair(
        shared: ByteArray,
        normalizedCode: String,
        clientEpk: ByteArray,
        serverEpk: ByteArray,
        clientNonce: ByteArray,
        serverNonce: ByteArray,
    ): PairDerivation {
        val transcript = SecureCrypto.sha256(
            SecureCrypto.utf8("AVEK/1 pair"), byteArrayOf(0), clientEpk, serverEpk, clientNonce, serverNonce,
        )
        val pairKey = SecureCrypto.hkdf(
            ikm = shared + SecureCrypto.utf8(normalizedCode),
            salt = transcript,
            info = "avek pair key",
        )
        return PairDerivation(
            transcript = transcript,
            pairKey = pairKey,
            clientMac = SecureCrypto.hmacSha256(pairKey, SecureCrypto.utf8("client"), transcript),
            serverMac = SecureCrypto.hmacSha256(pairKey, SecureCrypto.utf8("server"), transcript),
            encKey = SecureCrypto.hkdf(pairKey, transcript, "avek pair enc"),
        )
    }

    fun session(
        deviceId: String,
        deviceSecret: ByteArray,
        shared: ByteArray,
        clientEpk: ByteArray,
        serverEpk: ByteArray,
        clientNonce: ByteArray,
        serverNonce: ByteArray,
    ): SessionDerivation {
        val transcript = SecureCrypto.sha256(
            SecureCrypto.utf8("AVEK/1 session"), byteArrayOf(0), SecureCrypto.utf8(deviceId), byteArrayOf(0),
            clientEpk, serverEpk, clientNonce, serverNonce,
        )
        val ikm = shared + deviceSecret
        val macKey = SecureCrypto.hkdf(ikm, transcript, "avek mac")
        return SessionDerivation(
            transcript = transcript,
            macKey = macKey,
            clientToServer = SecureCrypto.hkdf(ikm, transcript, "avek c2s"),
            serverToClient = SecureCrypto.hkdf(ikm, transcript, "avek s2c"),
            serverMac = SecureCrypto.hmacSha256(macKey, SecureCrypto.utf8("server"), transcript),
            clientMac = SecureCrypto.hmacSha256(macKey, SecureCrypto.utf8("client"), transcript),
        )
    }
}

/**
 * Client side of the two handshakes, as state machines over an abstract [RawChannel].
 * Phase 1 uses only JSON text frames; any binary frame here is a protocol error.
 */
class Handshake(
    private val keys: KeySource = SystemKeySource(),
    private val timeoutMs: Long = HANDSHAKE_TIMEOUT_MS,
) {

    /** Pairing (UI-WIRE section 3). The channel is left open; the server closes it with 4000. */
    suspend fun pair(channel: RawChannel, code: String, deviceName: String, platform: String = "android"): PairingGrant =
        guarded {
            val normalizedCode = HandshakeMath.normalizeCode(code)
            val pair = keys.newKeyPair()
            val clientNonce = keys.randomBytes(NONCE_BYTES)

            channel.sendText(
                json(
                    buildJsonObject {
                        put("t", "pair.hello")
                        put("v", PROTOCOL_VERSION)
                        put("epk", SecureCrypto.b64(pair.publicRaw))
                        put("nonce", SecureCrypto.b64(clientNonce))
                        put("name", deviceName)
                        put("platform", platform)
                    },
                ),
            )

            val hello = receiveText(channel)
            denyIfNeeded(hello)
            if (hello.string("t") != "pair.hello.ok") throw HandshakeException.Protocol("Expected pair.hello.ok")
            val serverEpk = SecureCrypto.unb64(hello.requireString("epk"))
            val serverNonce = SecureCrypto.unb64(hello.requireString("nonce"))
            validateHello(serverEpk, serverNonce)

            val shared = SecureCrypto.ecdh(pair.privateKey, serverEpk)
            val derived = HandshakeMath.pair(shared, normalizedCode, pair.publicRaw, serverEpk, clientNonce, serverNonce)

            channel.sendText(json(buildJsonObject {
                put("t", "pair.proof")
                put("mac", SecureCrypto.b64(derived.clientMac))
            }))

            val done = receiveText(channel)
            denyIfNeeded(done)
            if (done.string("t") != "pair.done") throw HandshakeException.Protocol("Expected pair.done")

            // The server MAC proves it knew the code, so it is checked BEFORE decrypting anything.
            val serverMac = SecureCrypto.unb64(done.requireString("mac"))
            if (!SecureCrypto.constantTimeEquals(serverMac, derived.serverMac)) throw HandshakeException.UntrustedServer()

            val plaintext = try {
                SecureCrypto.aesGcmOpen(
                    key = derived.encKey,
                    nonce = SecureCrypto.unb64(done.requireString("iv")),
                    aad = derived.transcript,
                    sealed = SecureCrypto.unb64(done.requireString("data")),
                )
            } catch (e: java.security.GeneralSecurityException) {
                throw HandshakeException.Protocol("Could not open the pairing grant", e)
            }
            val grant = WireJson.parseToJsonElement(plaintext.toString(Charsets.UTF_8)).jsonObject
            PairingGrant(
                deviceId = grant.requireString("deviceId"),
                deviceSecret = SecureCrypto.unb64(grant.requireString("deviceSecret")),
                serverId = grant.requireString("serverId"),
                serverName = grant.requireString("serverName"),
            )
        }

    /** Session handshake (UI-WIRE section 4). On success the next frames are binary AVEK-SEC/1 frames. */
    suspend fun session(channel: RawChannel, deviceId: String, deviceSecret: ByteArray): SessionKeys =
        guarded {
            val pair = keys.newKeyPair()
            val clientNonce = keys.randomBytes(NONCE_BYTES)

            channel.sendText(json(buildJsonObject {
                put("t", "hello")
                put("v", PROTOCOL_VERSION)
                put("deviceId", deviceId)
                put("epk", SecureCrypto.b64(pair.publicRaw))
                put("nonce", SecureCrypto.b64(clientNonce))
            }))

            val hello = receiveText(channel)
            if (hello.string("t") == "hello.denied") throw HandshakeException.Denied(hello.string("reason") ?: "denied")
            if (hello.string("t") != "hello.ok") throw HandshakeException.Protocol("Expected hello.ok")
            val serverEpk = SecureCrypto.unb64(hello.requireString("epk"))
            val serverNonce = SecureCrypto.unb64(hello.requireString("nonce"))
            validateHello(serverEpk, serverNonce)

            val shared = SecureCrypto.ecdh(pair.privateKey, serverEpk)
            val derived = HandshakeMath.session(deviceId, deviceSecret, shared, pair.publicRaw, serverEpk, clientNonce, serverNonce)

            val serverMac = SecureCrypto.unb64(hello.requireString("mac"))
            if (!SecureCrypto.constantTimeEquals(serverMac, derived.serverMac)) throw HandshakeException.UntrustedServer()

            channel.sendText(json(buildJsonObject {
                put("t", "hello.proof")
                put("mac", SecureCrypto.b64(derived.clientMac))
            }))
            SessionKeys(derived.clientToServer, derived.serverToClient)
        }

    // ------------------------------------------------------------------ helpers

    private suspend fun <T> guarded(block: suspend () -> T): T = try {
        withTimeout(timeoutMs) { block() }
    } catch (e: kotlinx.coroutines.TimeoutCancellationException) {
        throw HandshakeException.Timeout()
    } catch (e: HandshakeException) {
        throw e
    } catch (e: IllegalArgumentException) {
        throw HandshakeException.Protocol("Malformed handshake message", e)
    } catch (e: kotlinx.serialization.SerializationException) {
        throw HandshakeException.Protocol("Malformed handshake message", e)
    } catch (e: java.security.GeneralSecurityException) {
        throw HandshakeException.Protocol("Cryptographic failure during handshake", e)
    }

    private suspend fun receiveText(channel: RawChannel): JsonObject =
        when (val message = channel.incoming.receive()) {
            is RawMessage.Text -> WireJson.parseToJsonElement(message.text).jsonObject
            is RawMessage.Binary -> throw HandshakeException.Protocol("Binary frame during the clear phase")
            is RawMessage.Closed -> throw HandshakeException.ClosedByPeer(message.code, message.reason)
        }

    private fun denyIfNeeded(message: JsonObject) {
        if (message.string("t") == "pair.denied") throw HandshakeException.Denied(message.string("reason") ?: "denied")
    }

    private fun validateHello(epk: ByteArray, nonce: ByteArray) {
        if (epk.size != SecureCrypto.PUBLIC_KEY_BYTES) throw HandshakeException.Protocol("Bad public key length")
        if (nonce.size != NONCE_BYTES) throw HandshakeException.Protocol("Bad nonce length")
    }

    private fun json(obj: JsonObject): String = Json.encodeToString(JsonObject.serializer(), obj)

    private fun JsonObject.string(key: String): String? = (this[key] as? JsonPrimitive)?.contentOrNull

    private fun JsonObject.requireString(key: String): String =
        this[key]?.jsonPrimitive?.contentOrNull ?: throw HandshakeException.Protocol("Missing field '$key'")

    companion object {
        const val PROTOCOL_VERSION = 2
        const val NONCE_BYTES = 16
        const val HANDSHAKE_TIMEOUT_MS = 10_000L
    }
}
