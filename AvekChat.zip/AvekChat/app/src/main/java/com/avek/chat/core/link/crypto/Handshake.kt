package com.avek.chat.core.link.crypto

import com.avek.chat.core.link.store.IdentityVault
import com.avek.chat.core.link.transport.RawChannel
import com.avek.chat.core.link.transport.RawMessage
import com.avek.chat.core.link.wire.WireJson
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.withTimeout
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put

/** Everything that can go wrong while pairing or opening a session (UI-WIRE v3 sections 3 and 4). */
sealed class HandshakeException(message: String, cause: Throwable? = null) : Exception(message, cause) {
    /** The PC sent `pair.denied` (`denied` = the person refused, `closed` = the window ran out). */
    class Denied(val reason: String) : HandshakeException("Denied: $reason")

    /** Close 4401 during pairing: the pairing window is not open (or the PC refused). */
    class WindowClosed : HandshakeException("The pairing window is not open on the PC")

    /** Close 4409: another device is pairing right now. */
    class Busy : HandshakeException("Another device is pairing right now")

    /** Close 4401 during a session handshake: the PC does not know this device any more. */
    class Forgotten : HandshakeException("The PC does not know this device")

    /** The other side did not prove it owns the pinned (or announced) key: it is not our PC. */
    class NotOurPc(detail: String) : HandshakeException(detail)

    /** The person said the six digits do not match. */
    class Cancelled : HandshakeException("Pairing cancelled")

    class Protocol(message: String, cause: Throwable? = null) : HandshakeException(message, cause)

    class ClosedByPeer(val code: Int, val reason: String) : HandshakeException("Closed by peer ($code $reason)")

    class Timeout : HandshakeException("Handshake timed out")
}

class SessionKeys(val clientToServer: ByteArray, val serverToClient: ByteArray)

/** What pairing pins: the PC's identity. */
class PairedServer(val serverId: String, val serverName: String, val serverPub: ByteArray, val deviceId: String)

/** The digits both screens show, with the PC's name. */
data class PairingDigits(val sas: String, val serverName: String) {
    val formatted: String get() = AvekProtocol.formatSas(sas)
}

/**
 * Client side of the two handshakes as state machines over an abstract [RawChannel].
 * Phase 1 uses only JSON text frames; a binary frame here is a protocol error.
 */
class Handshake(
    private val keys: KeySource = SystemKeySource(),
    private val timeoutMs: Long = HANDSHAKE_TIMEOUT_MS,
    private val approvalTimeoutMs: Long = APPROVAL_TIMEOUT_MS,
) {

    /**
     * Pairing (section 3). [confirm] shows the six digits and returns the person's answer (Yes = true).
     * [onAwaitingApproval] is called once the confirmation is sent and the PC must approve.
     */
    suspend fun pair(
        channel: RawChannel,
        identity: IdentityVault,
        deviceName: String,
        confirm: suspend (PairingDigits) -> Boolean,
        onAwaitingApproval: () -> Unit = {},
        platform: String = "android",
    ): PairedServer = guarded(pairing = true) {
        identity.create()
        val devicePub = identity.publicKey()
        val clientNonce = keys.randomBytes(NONCE_BYTES)
        val name = deviceName.filter { !it.isISOControl() }.take(MAX_NAME).ifBlank { "Android" }
        val commit = AvekProtocol.pairCommit(name, platform, devicePub, clientNonce)

        channel.sendText(json(buildJsonObject {
            put("t", "pair.hello")
            put("v", AvekProtocol.VERSION)
            put("commit", SecureCrypto.b64(commit))
            put("name", name)
            put("platform", platform)
        }))

        val hello = withTimeout(timeoutMs) { receiveText(channel, pairing = true) }
        denyIfNeeded(hello)
        if (hello.string("t") != "pair.hello.ok") throw HandshakeException.Protocol("Expected pair.hello.ok")
        val serverPub = SecureCrypto.unb64(hello.requireString("srvPub"))
        val serverNonce = SecureCrypto.unb64(hello.requireString("nonce"))
        if (!SecureCrypto.isValidPublicKey(serverPub)) throw HandshakeException.NotOurPc("The PC sent an invalid key")
        if (serverNonce.size != NONCE_BYTES) throw HandshakeException.Protocol("Bad nonce length")
        val serverId = hello.requireString("serverId")
        if (serverId != AvekProtocol.serverIdOf(serverPub)) throw HandshakeException.NotOurPc("The PC's id does not match its key")
        val serverName = hello.string("serverName").orEmpty().ifBlank { serverId }

        channel.sendText(json(buildJsonObject {
            put("t", "pair.reveal")
            put("devPub", SecureCrypto.b64(devicePub))
            put("nonce", SecureCrypto.b64(clientNonce))
        }))

        val transcript = AvekProtocol.pairTranscript(commit, serverPub, serverNonce, devicePub, clientNonce)
        val digits = PairingDigits(AvekProtocol.pairSas(transcript), serverName)
        if (!confirm(digits)) {
            channel.close(1000, "")
            throw HandshakeException.Cancelled()
        }

        channel.sendText(json(buildJsonObject {
            put("t", "pair.confirm")
            put("sig", SecureCrypto.b64(identity.sign(AvekProtocol.pairClientMessage(transcript))))
        }))
        onAwaitingApproval()

        val done = withTimeout(approvalTimeoutMs) { receiveText(channel, pairing = true) }
        denyIfNeeded(done)
        if (done.string("t") != "pair.done") throw HandshakeException.Protocol("Expected pair.done")
        val signature = SecureCrypto.unb64(done.requireString("sig"))
        if (!SecureCrypto.verify(serverPub, AvekProtocol.pairServerMessage(transcript), signature)) {
            throw HandshakeException.NotOurPc("The PC's confirmation signature is wrong")
        }
        val deviceId = done.requireString("deviceId")
        if (deviceId != AvekProtocol.deviceIdOf(devicePub)) throw HandshakeException.NotOurPc("The PC registered a different device id")
        channel.close(1000, "")
        PairedServer(serverId, serverName, serverPub, deviceId)
    }

    /** Session handshake (section 4). On success the next frames are binary AVEK-SEC/2 frames. */
    suspend fun session(channel: RawChannel, identity: IdentityVault, pinnedServerPub: ByteArray): SessionKeys =
        guarded(pairing = false) {
            withTimeout(timeoutMs) {
                val devicePub = identity.publicKey()
                val ephemeral = keys.newKeyPair()
                val clientNonce = keys.randomBytes(NONCE_BYTES)

                channel.sendText(json(buildJsonObject {
                    put("t", "hello")
                    put("v", AvekProtocol.VERSION)
                    put("deviceId", AvekProtocol.deviceIdOf(devicePub))
                    put("epk", SecureCrypto.b64(ephemeral.publicRaw))
                    put("nonce", SecureCrypto.b64(clientNonce))
                }))

                val hello = receiveText(channel, pairing = false)
                if (hello.string("t") != "hello.ok") throw HandshakeException.Protocol("Expected hello.ok")
                val serverEpk = SecureCrypto.unb64(hello.requireString("epk"))
                val serverNonce = SecureCrypto.unb64(hello.requireString("nonce"))
                if (!SecureCrypto.isValidPublicKey(serverEpk)) throw HandshakeException.Protocol("Invalid ephemeral key")
                if (serverNonce.size != NONCE_BYTES) throw HandshakeException.Protocol("Bad nonce length")

                val shared = SecureCrypto.ecdh(ephemeral.privateKey, serverEpk)
                val derived = AvekProtocol.sessionKeys(shared, pinnedServerPub, devicePub, ephemeral.publicRaw, serverEpk, clientNonce, serverNonce)

                // The PC must prove it owns the pinned key before anything else is sent.
                val signatureOk = SecureCrypto.verify(pinnedServerPub, derived.serverMessage, SecureCrypto.unb64(hello.requireString("sig")))
                val macOk = SecureCrypto.constantTimeEquals(SecureCrypto.unb64(hello.requireString("mac")), derived.serverMac)
                if (!signatureOk || !macOk) {
                    channel.close(1000, "")
                    throw HandshakeException.NotOurPc("This is not the PC you paired with")
                }

                channel.sendText(json(buildJsonObject {
                    put("t", "hello.proof")
                    put("sig", SecureCrypto.b64(identity.sign(derived.clientMessage)))
                    put("mac", SecureCrypto.b64(derived.clientMac))
                }))
                SessionKeys(derived.clientToServer, derived.serverToClient)
            }
        }

    // ------------------------------------------------------------------ helpers

    private suspend fun <T> guarded(pairing: Boolean, block: suspend () -> T): T = try {
        block()
    } catch (e: TimeoutCancellationException) {
        throw HandshakeException.Timeout()
    } catch (e: HandshakeException) {
        throw e
    } catch (e: IllegalArgumentException) {
        throw HandshakeException.Protocol("Malformed handshake message", e)
    } catch (e: kotlinx.serialization.SerializationException) {
        throw HandshakeException.Protocol("Malformed handshake message", e)
    } catch (e: java.security.GeneralSecurityException) {
        throw HandshakeException.Protocol("Cryptographic failure during handshake", e)
    }

    private suspend fun receiveText(channel: RawChannel, pairing: Boolean): JsonObject =
        when (val message = channel.incoming.receive()) {
            is RawMessage.Text -> WireJson.parseToJsonElement(message.text).jsonObject
            is RawMessage.Binary -> throw HandshakeException.Protocol("Binary frame during the clear phase")
            is RawMessage.Closed -> throw closedError(message.code, message.reason, pairing)
        }

    private fun closedError(code: Int, reason: String, pairing: Boolean): HandshakeException = when (code) {
        4401 -> if (pairing) HandshakeException.WindowClosed() else HandshakeException.Forgotten()
        4409 -> HandshakeException.Busy()
        4408 -> HandshakeException.Timeout()
        else -> HandshakeException.ClosedByPeer(code, reason)
    }

    private fun denyIfNeeded(message: JsonObject) {
        if (message.string("t") == "pair.denied") throw HandshakeException.Denied(message.string("reason") ?: "denied")
    }

    private fun json(obj: JsonObject): String = Json.encodeToString(JsonObject.serializer(), obj)

    private fun JsonObject.string(key: String): String? = (this[key] as? JsonPrimitive)?.contentOrNull

    private fun JsonObject.requireString(key: String): String =
        this[key]?.jsonPrimitive?.contentOrNull ?: throw HandshakeException.Protocol("Missing field '$key'")

    companion object {
        const val NONCE_BYTES = 16
        const val MAX_NAME = 40
        const val HANDSHAKE_TIMEOUT_MS = 10_000L

        /** "The app's timeout for step 6 is 130 s." */
        const val APPROVAL_TIMEOUT_MS = 130_000L
    }
}
