package com.avek.chat.core.link.crypto

import com.avek.chat.core.link.store.DeviceKey
import com.avek.chat.core.link.store.DeviceSecrets
import com.avek.chat.core.link.transport.RawChannel
import com.avek.chat.core.link.transport.RawMessage
import com.avek.chat.core.link.wire.WireJson
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put

/** What can go wrong while opening a session (UI-WIRE v4 section 4). */
sealed class HandshakeException(message: String, cause: Throwable? = null) : Exception(message, cause) {
    /** Close 4401: the PC does not know this device (any more). */
    class Forgotten : HandshakeException("The PC does not know this device")

    /** Close 4409. */
    class Busy : HandshakeException("The PC is busy")

    /** Close 4429. */
    class RateLimited : HandshakeException("Too many attempts")

    /** `hello.ok` did not prove the pinned key and `dk`: it is not our PC, or the stored `dk` differs. */
    class NotOurPc(detail: String) : HandshakeException(detail)

    class Protocol(message: String, cause: Throwable? = null) : HandshakeException(message, cause)

    class ClosedByPeer(val code: Int, val reason: String) : HandshakeException("Closed by peer ($code)")

    class Timeout : HandshakeException("Handshake timed out")
}

class SessionKeys(val clientToServer: ByteArray, val serverToClient: ByteArray)

/** scrypt parameters of the code key. The app only accepts the ones of the spec ([STANDARD]). */
data class KdfParams(val n: Int, val r: Int, val p: Int) {
    companion object {
        val STANDARD = KdfParams(AvekProtocol.SCRYPT_N, AvekProtocol.SCRYPT_R, AvekProtocol.SCRYPT_P)
    }
}

/** What a successful pairing delivers (section 3, step 7). The caller seals [secrets] and wipes them. */
class PairingGrant(
    val deviceId: String,
    val serverId: String,
    val serverName: String,
    val serverPub: ByteArray,
    val secrets: DeviceSecrets,
) {
    override fun toString(): String = "PairingGrant($serverName, $serverId, $deviceId)"
}

/**
 * The result of a pairing. Every failure the PC causes (wrong code, wrong key on the PC, window
 * closed, a box that cannot be opened or does not verify) is the same [NotPaired]: the app is never
 * told why. Only the phone's own problems are told apart.
 */
sealed interface PairingResult {
    class Paired(val grant: PairingGrant) : PairingResult
    data object NotPaired : PairingResult

    /** Close 4409: another device is pairing right now. */
    data object WindowBusy : PairingResult

    /** The PC could not be reached at all. */
    data object NoRoute : PairingResult

    /** scrypt (about 128 MiB) ran out of memory. */
    data object NotEnoughMemory : PairingResult
}

/**
 * Pairing (section 3) over an abstract [RawChannel]: `pair.hello` → `pair.hello.ok` → scrypt
 * off the main thread → `pair.proof` → `pair.denied`/4401 or one binary frame (the box). The
 * channel is closed at the end, whatever happens.
 */
class PairingHandshake(
    private val keys: KeySource = SystemKeySource(),
    private val kdf: KdfParams = KdfParams.STANDARD,
    private val computeDispatcher: CoroutineDispatcher = Dispatchers.Default,
    private val helloTimeoutMs: Long = HELLO_TIMEOUT_MS,
    private val proofTimeoutMs: Long = PROOF_TIMEOUT_MS,
    private val scrypt: (ByteArray, ByteArray, KdfParams) -> ByteArray = { secret, salt, p -> AvekProtocol.scrypt(secret, salt, p.n, p.r, p.p) },
) {
    /**
     * Runs the exchange. [digits] are the 12 code digits as UTF-8 bytes; they are wiped here.
     * [onChecking] is called when the proof is about to be computed ("Checking the code...").
     */
    suspend fun pair(
        channel: RawChannel,
        key: DeviceKey,
        digits: ByteArray,
        deviceName: String,
        platform: String = "android",
        onChecking: () -> Unit = {},
    ): PairingResult {
        var codeKey: ByteArray? = null
        var shared: ByteArray? = null
        var boxKey: ByteArray? = null
        try {
            val devicePub = key.publicKey()
            val ephemeral = keys.newKeyPair()
            val clientNonce = keys.randomBytes(NONCE_BYTES)
            val name = cleanName(deviceName, MAX_NAME).ifBlank { "Android" }

            channel.sendText(json(buildJsonObject {
                put("t", "pair.hello")
                put("v", AvekProtocol.VERSION)
                put("devPub", SecureCrypto.b64(devicePub))
                put("epk", SecureCrypto.b64(ephemeral.publicRaw))
                put("nonce", SecureCrypto.b64(clientNonce))
                put("name", name)
                put("platform", cleanName(platform, MAX_PLATFORM))
            }))

            val hello = when (val m = withTimeout(helloTimeoutMs) { channel.incoming.receive() }) {
                is RawMessage.Text -> parse(m.text) ?: return PairingResult.NotPaired
                is RawMessage.Binary -> return PairingResult.NotPaired
                is RawMessage.Closed -> return closedResult(m.code)
            }
            if (hello.string("t") != "pair.hello.ok") return PairingResult.NotPaired
            val serverPub = hello.bytes("srvPub") ?: return PairingResult.NotPaired
            val serverEpk = hello.bytes("epk") ?: return PairingResult.NotPaired
            val serverNonce = hello.bytes("nonce") ?: return PairingResult.NotPaired
            val salt = hello.bytes("salt") ?: return PairingResult.NotPaired
            if (!SecureCrypto.isValidPublicKey(serverPub) || !SecureCrypto.isValidPublicKey(serverEpk)) return PairingResult.NotPaired
            if (serverNonce.size != NONCE_BYTES || salt.size != SALT_BYTES) return PairingResult.NotPaired
            val serverId = AvekProtocol.serverIdOf(serverPub)
            if (hello.string("serverId")?.let { it != serverId } == true) return PairingResult.NotPaired
            // A weaker scrypt would let a fake PC guess the code offline from our MAC: only the spec's parameters.
            if (!kdfAccepted(hello)) return PairingResult.NotPaired
            val serverName = cleanName(hello.string("serverName").orEmpty(), MAX_NAME).ifBlank { serverId }

            onChecking()
            codeKey = try {
                withContext(computeDispatcher) { scrypt(digits, salt, kdf) }
            } catch (e: OutOfMemoryError) {
                return PairingResult.NotEnoughMemory
            }
            shared = SecureCrypto.ecdh(ephemeral.privateKey, serverEpk)
            val transcript = AvekProtocol.pairTranscript(serverPub, devicePub, ephemeral.publicRaw, serverEpk, clientNonce, serverNonce, salt)

            channel.sendText(json(buildJsonObject {
                put("t", "pair.proof")
                put("sig", SecureCrypto.b64(key.sign(AvekProtocol.pairClientMessage(transcript))))
                put("mac", SecureCrypto.b64(AvekProtocol.pairClientMac(codeKey, transcript)))
            }))

            val box = when (val m = withTimeout(proofTimeoutMs) { channel.incoming.receive() }) {
                is RawMessage.Binary -> m.bytes
                is RawMessage.Text -> return PairingResult.NotPaired // `pair.denied` or anything else
                is RawMessage.Closed -> return closedResult(m.code)
            }
            boxKey = AvekProtocol.pairBoxKey(shared, codeKey, transcript)
            val plain = try {
                AvekProtocol.openBox(boxKey, box)
            } catch (e: FrameException) {
                return PairingResult.NotPaired
            }
            val content = try {
                parse(plain.toString(Charsets.UTF_8))
            } finally {
                plain.fill(0)
            } ?: return PairingResult.NotPaired

            val signature = content.bytes("sig") ?: return PairingResult.NotPaired
            val mac = content.bytes("mac") ?: return PairingResult.NotPaired
            val signatureOk = SecureCrypto.verify(serverPub, AvekProtocol.pairServerMessage(transcript), signature)
            val macOk = SecureCrypto.constantTimeEquals(mac, AvekProtocol.pairServerMac(codeKey, transcript))
            if (!signatureOk || !macOk) return PairingResult.NotPaired
            if (content.string("serverId") != serverId) return PairingResult.NotPaired
            val deviceId = AvekProtocol.deviceIdOf(devicePub)
            if (content.string("deviceId") != deviceId) return PairingResult.NotPaired
            val dk = content.bytes("dk")?.takeIf { it.size == SECRET_BYTES } ?: return PairingResult.NotPaired
            val rk = content.bytes("rk")?.takeIf { it.size == SECRET_BYTES } ?: return PairingResult.NotPaired

            return PairingResult.Paired(PairingGrant(deviceId, serverId, serverName, serverPub, DeviceSecrets(dk, rk)))
        } catch (e: TimeoutCancellationException) {
            return PairingResult.NotPaired
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: OutOfMemoryError) {
            return PairingResult.NotEnoughMemory
        } catch (e: kotlinx.coroutines.channels.ClosedReceiveChannelException) {
            return PairingResult.NotPaired
        } catch (e: Exception) {
            // Malformed messages, bad points, a socket that died: all look the same to the person.
            return PairingResult.NotPaired
        } finally {
            digits.fill(0)
            codeKey?.fill(0)
            shared?.fill(0)
            boxKey?.fill(0)
            channel.close(1000, "")
        }
    }

    private fun kdfAccepted(hello: JsonObject): Boolean {
        val k = hello["kdf"] as? JsonObject ?: return true
        val n = (k["N"] as? JsonPrimitive)?.intOrNull ?: return false
        val r = (k["r"] as? JsonPrimitive)?.intOrNull ?: return false
        val p = (k["p"] as? JsonPrimitive)?.intOrNull ?: return false
        return KdfParams(n, r, p) == kdf
    }

    private fun closedResult(code: Int): PairingResult = if (code == 4409) PairingResult.WindowBusy else PairingResult.NotPaired

    companion object {
        const val HELLO_TIMEOUT_MS = 10_000L

        /** "The app's timeout for step 5 is 130 s." */
        const val PROOF_TIMEOUT_MS = 130_000L
        const val SALT_BYTES = 16
        const val SECRET_BYTES = 32
    }
}

/** What a session handshake needs from the grant. */
class SessionGrant(
    val deviceId: String,
    val key: DeviceKey,
    val serverPub: ByteArray,
    val dk: ByteArray,
    /** True for the first connection with a new key after a replacement (`slot:"next"`). */
    val slotNext: Boolean = false,
)

/**
 * Session handshake (section 4). The PC must prove the pinned key and `dk` (`hello.ok.sig` and
 * `hello.ok.mac`) before anything else is sent. On success the next frames are binary frames.
 */
class SessionHandshake(
    private val keys: KeySource = SystemKeySource(),
    private val timeoutMs: Long = HANDSHAKE_TIMEOUT_MS,
) {
    suspend fun open(channel: RawChannel, grant: SessionGrant): SessionKeys = guarded {
        withTimeout(timeoutMs) {
            val devicePub = grant.key.publicKey()
            val ephemeral = keys.newKeyPair()
            val clientNonce = keys.randomBytes(NONCE_BYTES)

            channel.sendText(json(buildJsonObject {
                put("t", "hello")
                put("v", AvekProtocol.VERSION)
                put("deviceId", grant.deviceId)
                put("epk", SecureCrypto.b64(ephemeral.publicRaw))
                put("nonce", SecureCrypto.b64(clientNonce))
                if (grant.slotNext) put("slot", "next")
            }))

            val hello = when (val message = channel.incoming.receive()) {
                is RawMessage.Text -> WireJson.parseToJsonElement(message.text).jsonObject
                is RawMessage.Binary -> throw HandshakeException.Protocol("Binary frame during the clear phase")
                is RawMessage.Closed -> throw closedError(message.code, message.reason)
            }
            if (hello.string("t") != "hello.ok") throw HandshakeException.Protocol("Expected hello.ok")
            val serverEpk = SecureCrypto.unb64(hello.requireString("epk"))
            val serverNonce = SecureCrypto.unb64(hello.requireString("nonce"))
            if (!SecureCrypto.isValidPublicKey(serverEpk)) throw HandshakeException.Protocol("Invalid ephemeral key")
            if (serverNonce.size != NONCE_BYTES) throw HandshakeException.Protocol("Bad nonce length")

            val shared = SecureCrypto.ecdh(ephemeral.privateKey, serverEpk)
            try {
                val derived = AvekProtocol.sessionKeys(shared, grant.serverPub, devicePub, ephemeral.publicRaw, serverEpk, clientNonce, serverNonce, grant.dk)
                try {
                    // The PC must prove the pinned key and the device's `dk` before anything else is sent.
                    val signatureOk = SecureCrypto.verify(grant.serverPub, derived.serverMessage, SecureCrypto.unb64(hello.requireString("sig")))
                    val macOk = SecureCrypto.constantTimeEquals(SecureCrypto.unb64(hello.requireString("mac")), derived.serverMac)
                    if (!signatureOk || !macOk) {
                        channel.close(1000, "")
                        throw HandshakeException.NotOurPc("This is not the PC you paired with")
                    }
                    channel.sendText(json(buildJsonObject {
                        put("t", "hello.proof")
                        put("sig", SecureCrypto.b64(grant.key.sign(derived.clientMessage)))
                        put("mac", SecureCrypto.b64(derived.clientMac))
                    }))
                    SessionKeys(derived.clientToServer.copyOf(), derived.serverToClient.copyOf())
                } finally {
                    derived.mix.fill(0)
                    derived.macKey.fill(0)
                    derived.clientToServer.fill(0)
                    derived.serverToClient.fill(0)
                }
            } finally {
                shared.fill(0)
            }
        }
    }

    private suspend fun <T> guarded(block: suspend () -> T): T = try {
        block()
    } catch (e: TimeoutCancellationException) {
        throw HandshakeException.Timeout()
    } catch (e: HandshakeException) {
        throw e
    } catch (e: kotlinx.coroutines.channels.ClosedReceiveChannelException) {
        throw HandshakeException.ClosedByPeer(1006, "")
    } catch (e: IllegalArgumentException) {
        throw HandshakeException.Protocol("Malformed handshake message", e)
    } catch (e: kotlinx.serialization.SerializationException) {
        throw HandshakeException.Protocol("Malformed handshake message", e)
    } catch (e: java.security.GeneralSecurityException) {
        throw HandshakeException.Protocol("Cryptographic failure during handshake", e)
    }

    private fun closedError(code: Int, reason: String): HandshakeException = when (code) {
        4401 -> HandshakeException.Forgotten()
        4409 -> HandshakeException.Busy()
        4429 -> HandshakeException.RateLimited()
        4408 -> HandshakeException.Timeout()
        else -> HandshakeException.ClosedByPeer(code, reason)
    }

    private fun JsonObject.requireString(key: String): String =
        this[key]?.jsonPrimitive?.contentOrNull ?: throw HandshakeException.Protocol("Missing field '$key'")

    companion object {
        const val HANDSHAKE_TIMEOUT_MS = 10_000L
    }
}

const val NONCE_BYTES = 16
private const val MAX_NAME = 40
private const val MAX_PLATFORM = 32

private fun cleanName(text: String, max: Int): String = text.filter { !it.isISOControl() }.trim().take(max)

private fun json(obj: JsonObject): String = Json.encodeToString(JsonObject.serializer(), obj)

private fun parse(text: String): JsonObject? = runCatching { WireJson.parseToJsonElement(text).jsonObject }.getOrNull()

private fun JsonObject.string(key: String): String? = (this[key] as? JsonPrimitive)?.takeIf { it.isString }?.contentOrNull

private fun JsonObject.bytes(key: String): ByteArray? = string(key)?.let { runCatching { SecureCrypto.unb64(it) }.getOrNull() }
