package com.avek.chat.core.model

import kotlinx.serialization.Serializable

enum class Role { USER, ASSISTANT }

/** [WAITING] = the turn is paused on a question to the person (an `ask`). */
enum class MessageStatus { COMPLETE, STREAMING, WAITING, STOPPED, ERROR }

enum class Feedback { NONE, POSITIVE, NEGATIVE }

@Serializable
data class SourceRef(
    val title: String,
    val domain: String,
    val snippet: String,
    val url: String = "",
)

/** A tool the PC used during a turn. [ok] is null while it runs; [body] is loaded lazily with `tool.get`. */
data class ToolCall(
    val callId: String,
    val name: String,
    val title: String,
    val detail: String? = null,
    val ok: Boolean? = null,
    val body: String? = null,
) {
    val isRunning: Boolean get() = ok == null
}

/** The expanded view of a tool call (`tool.get`). [style] is `text`, `diff`, `command` or `list`. */
data class ToolView(
    val callId: String,
    val title: String,
    val detail: String,
    val body: String,
    val style: String,
)

data class AttachmentInfo(val name: String, val mime: String, val size: Long)

/**
 * One side of a turn. A protocol turn (`TurnView`) maps to a user message and an assistant message
 * that share a [promptId]. [thinking] is lazy: [hasThinking] without text means "load on expand".
 */
data class Message(
    val id: String,
    val conversationId: String,
    val role: Role,
    val content: String,
    val createdAt: Long,
    val promptId: String? = null,
    /** Stable list key; survives the optimistic message being replaced by the server's. */
    val uiKey: String = id,
    val thinking: String? = null,
    val hasThinking: Boolean = thinking != null,
    val thinkingDurationMs: Long = 0L,
    val modelId: String? = null,
    val requestedTask: TaskMode = TaskMode.AUTO,
    val resolvedTask: TaskMode? = null,
    val depth: ThinkingDepth = ThinkingDepth.INSTANT,
    val status: MessageStatus = MessageStatus.COMPLETE,
    val feedback: Feedback = Feedback.NONE,
    val sources: List<SourceRef> = emptyList(),
    val tools: List<ToolCall> = emptyList(),
    val attachments: List<AttachmentInfo> = emptyList(),
    val error: String? = null,
) {
    val isUser: Boolean get() = role == Role.USER
    val isStreaming: Boolean get() = status == MessageStatus.STREAMING || status == MessageStatus.WAITING
}

enum class AskKind { APPROVAL, QUESTION }

/** A question from the PC ("doubt"): an approval with choices, or a free-text question. */
data class AskRequest(
    val askId: String,
    val chatId: String?,
    val promptId: String?,
    val kind: AskKind,
    val tool: String?,
    val summary: String,
    val detail: String?,
    val choices: List<String>,
)
