package com.avek.chat.core.model

import kotlinx.serialization.Serializable

enum class Role { USER, ASSISTANT }

enum class MessageStatus { COMPLETE, STREAMING, STOPPED, ERROR }

enum class Feedback { NONE, POSITIVE, NEGATIVE }

@Serializable
data class SourceRef(
    val title: String,
    val domain: String,
    val snippet: String,
)

data class Message(
    val id: String,
    val conversationId: String,
    val role: Role,
    val content: String,
    val createdAt: Long,
    val thinking: String? = null,
    val thinkingDurationMs: Long = 0L,
    val modelId: String? = null,
    val requestedTask: TaskMode = TaskMode.AUTO,
    val resolvedTask: TaskMode? = null,
    val depth: ThinkingDepth = ThinkingDepth.INSTANT,
    val status: MessageStatus = MessageStatus.COMPLETE,
    val feedback: Feedback = Feedback.NONE,
    val sources: List<SourceRef> = emptyList(),
) {
    val isUser: Boolean get() = role == Role.USER
    val isStreaming: Boolean get() = status == MessageStatus.STREAMING
}
