package com.avek.chat.core.link.rpc

/**
 * Applies streaming deltas using the offset rules of UI-WIRE section 9.
 * Offsets count UTF-16 code units, i.e. exactly `String.length` / `substring`.
 *
 * With current length `L` and a delta at offset `o`:
 *  - `o == L`  append the text;
 *  - `o <  L`  the first `L - o` units are a duplicate: append only what is new;
 *  - `o >  L`  something was missed: ignore the delta and signal that the turn must be reloaded.
 */
class TextAssembler {

    sealed interface Outcome {
        /** [added] was appended to the text. */
        data class Appended(val added: String) : Outcome

        /** The delta was entirely a duplicate. */
        data object Duplicate : Outcome

        /** A gap was detected: reload the turn with `turn.get`, then call [reset]. */
        data object Reload : Outcome
    }

    private val texts = HashMap<String, StringBuilder>()

    /** Sets the full text known so far (e.g. after `turn.get`). */
    fun reset(key: String, text: String) {
        texts[key] = StringBuilder(text)
    }

    fun text(key: String): String = texts[key]?.toString().orEmpty()

    fun length(key: String): Int = texts[key]?.length ?: 0

    fun apply(key: String, offset: Int, text: String): Outcome {
        val builder = texts.getOrPut(key) { StringBuilder() }
        val length = builder.length
        return when {
            offset == length -> {
                if (text.isEmpty()) Outcome.Duplicate else {
                    builder.append(text)
                    Outcome.Appended(text)
                }
            }
            offset < length -> {
                val overlap = length - offset
                if (text.length > overlap) {
                    val added = text.substring(overlap)
                    builder.append(added)
                    Outcome.Appended(added)
                } else {
                    Outcome.Duplicate
                }
            }
            else -> Outcome.Reload
        }
    }

    fun clear() = texts.clear()
}
