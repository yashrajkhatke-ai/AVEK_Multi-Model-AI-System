package com.avek.chat.core.link.rpc

/**
 * Applies streaming deltas using the offset rules of UI-WIRE section 9.
 * Offsets count UTF-16 code units, i.e. exactly `String.length` / `substring`.
 *
 * With current length `L` and a delta at offset `o`:
 *  - `o == L`  append the text;
 *  - `o <  L`  the first `L - o` units are a duplicate: append only what is new;
 *  - `o >  L`  something was missed: ignore the delta and signal that the turn must be reloaded.
 */
class TextAssembler {

    sealed interface Outcome {
        /** [added] was appended to the text. */
        data class Appended(val added: String) : Outcome

        /** The delta was entirely a duplicate. */
        data object Duplicate : Outcome

        /** A gap was detected: reload the turn with `turn.get`, then call [reset]. */
        data object Reload : Outcome
    }

    private val texts = HashMap<String, StringBuilder>()

    /** Sets the full text known so far (e.g. after `turn.get`). */
    fun reset(key: String, text: String) {
        texts[key] = StringBuilder(text)
    }

    fun text(key: String): String = texts[key]?.toString().orEmpty()

    fun length(key: String): Int = texts[key]?.length ?: 0

    fun apply(key: String, offset: Int, text: String): Outcome {
        val builder = texts.getOrPut(key) { StringBuilder() }
        val length = builder.length
        return when {
            offset == length -> {
                if (text.isEmpty()) Outcome.Duplicate else {
                    builder.append(text)
                    Outcome.Appended(text)
                }
            }
            offset < length -> {
                val overlap = length - offset
                if (text.length > overlap) {
                    val added = text.substring(overlap)
                    builder.append(added)
                    Outcome.Appended(added)
                } else {
                    Outcome.Duplicate
                }
            }
            else -> Outcome.Reload
        }
    }

    fun clear() = texts.clear()

    companion object {
        /** The key of a turn's thinking or answer text: `(chatId, promptId)` identifies a turn. */
        fun turnKey(chatId: String, promptId: String, part: String): String = "$chatId\u0000$promptId\u0000$part"

        /** The key of a tool call's argument text inside a turn: `(chatId, promptId, step, index)`. */
        fun toolCallKey(chatId: String, promptId: String, step: Int, index: Int): String =
            "$chatId\u0000$promptId\u0000tool\u0000$step\u0000$index"

        /**
         * The same offset rule as [apply] for an immutable text: returns the new text, the same
         * instance when the delta was a duplicate, or null when something was missed (reload).
         */
        fun merge(current: String, offset: Int, text: String): String? {
            val length = current.length
            return when {
                offset == length -> if (text.isEmpty()) current else current + text
                offset < length -> {
                    val overlap = length - offset
                    if (text.length > overlap) current + text.substring(overlap) else current
                }
                else -> null
            }
        }
    }
}
