package com.avek.chat.feature.chat.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import com.avek.chat.core.common.TimeFormat
import com.avek.chat.core.designsystem.theme.AvekTheme
import com.avek.chat.core.designsystem.theme.ColorMath
import com.avek.chat.core.model.Message
import com.avek.chat.core.model.settings.BubbleStyle
import com.avek.chat.core.model.settings.UserAlignment

@Composable
fun UserMessage(
    message: Message,
    canEdit: Boolean,
    actions: MessageActions,
    modifier: Modifier = Modifier,
) {
    val colors = AvekTheme.colors
    val layout = AvekTheme.layout
    val atEnd = layout.userAlignment == UserAlignment.END
    var menuOpen by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf(false) }
    val corner = layout.bubbleCornerDp.dp
    val tail = (layout.bubbleCornerDp / 4).coerceAtLeast(3).dp
    val shape = if (atEnd) {
        RoundedCornerShape(topStart = corner, topEnd = corner, bottomEnd = tail, bottomStart = corner)
    } else {
        RoundedCornerShape(topStart = corner, topEnd = corner, bottomEnd = corner, bottomStart = tail)
    }

    val (background, textColor) = when (layout.bubbleStyle) {
        BubbleStyle.FILLED -> Modifier.background(colors.userBubble, shape) to colors.userText
        BubbleStyle.TINTED -> Modifier.background(colors.accentContainer, shape) to colors.textPrimary
        BubbleStyle.OUTLINED -> Modifier.border(1.5.dp, colors.accent.copy(alpha = 0.55f), shape) to colors.textPrimary
        BubbleStyle.GRADIENT -> Modifier.background(
            Brush.linearGradient(listOf(colors.accent, ColorMath.shift(colors.accent, hueDelta = 38f, lightnessDelta = -0.04f))),
            shape,
        ) to colors.onAccent
        BubbleStyle.MINIMAL -> Modifier to colors.textPrimary
    }

    BoxWithConstraints(modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = (6 * layout.density.scale).dp)) {
        val maxBubble = maxWidth * layout.bubbleWidthFraction
        Column(
            Modifier.fillMaxWidth(),
            horizontalAlignment = if (atEnd) Alignment.End else Alignment.Start,
        ) {
            if (editing) {
                EditBox(
                    initial = message.content,
                    onCancel = { editing = false },
                    onSave = {
                        editing = false
                        actions.onEdit(message, it)
                    },
                )
            } else {
                Box {
                    Box(
                        Modifier
                            .widthIn(max = maxBubble)
                            .clip(shape)
                            .then(background)
                            .combinedClickable(onClick = {}, onLongClick = { menuOpen = true })
                            .padding(
                                horizontal = if (layout.bubbleStyle == BubbleStyle.MINIMAL) 2.dp else 16.dp,
                                vertical = if (layout.bubbleStyle == BubbleStyle.MINIMAL) 2.dp else (11 * layout.density.scale.coerceAtLeast(0.85f)).dp,
                            ),
                    ) {
                        if (layout.bubbleStyle == BubbleStyle.MINIMAL) {
                            Text(
                                buildAnnotatedString {
                                    withStyle(SpanStyle(fontWeight = FontWeight.SemiBold, color = colors.accent)) { append("You  ") }
                                    append(message.content)
                                },
                                style = AvekTheme.type.userMessage,
                                color = textColor,
                            )
                        } else {
                            Text(message.content, style = AvekTheme.type.userMessage, color = textColor)
                        }
                    }
                    DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }, containerColor = colors.surface) {
                        DropdownMenuItem(
                            text = { Text("Copy", color = colors.textPrimary) },
                            leadingIcon = { Icon(Icons.Outlined.ContentCopy, null, tint = colors.textSecondary) },
                            onClick = {
                                menuOpen = false
                                actions.onCopy(message.content)
                            },
                        )
                        if (canEdit) {
                            DropdownMenuItem(
                                text = { Text("Edit & resend", color = colors.textPrimary) },
                                leadingIcon = { Icon(Icons.Outlined.Edit, null, tint = colors.textSecondary) },
                                onClick = {
                                    menuOpen = false
                                    editing = true
                                },
                            )
                        }
                    }
                }
            }
            if (layout.showTimestamps && !editing) {
                Spacer(Modifier.height(4.dp))
                MetaLabel(TimeFormat.clock(message.createdAt), colors.textTertiary)
            }
        }
    }
}

@Composable
private fun EditBox(initial: String, onCancel: () -> Unit, onSave: (String) -> Unit) {
    val colors = AvekTheme.colors
    var text by remember { mutableStateOf(initial) }
    Column(Modifier.fillMaxWidth()) {
        OutlinedTextField(
            value = text,
            onValueChange = { text = it },
            textStyle = AvekTheme.type.userMessage.copy(color = colors.textPrimary),
            shape = RoundedCornerShape(18.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = colors.accent,
                unfocusedBorderColor = colors.outline,
                cursorColor = colors.accent,
                focusedContainerColor = colors.surface,
                unfocusedContainerColor = colors.surface,
            ),
            modifier = Modifier.fillMaxWidth(),
        )
        Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.End) {
            TextButton(onClick = onCancel) { Text("Cancel", color = colors.textSecondary) }
            Spacer(Modifier.width(4.dp))
            Box(
                Modifier
                    .clip(RoundedCornerShape(50))
                    .background(colors.accent)
                    .clickable(enabled = text.isNotBlank()) { onSave(text) }
                    .padding(horizontal = 16.dp, vertical = 9.dp),
            ) {
                Text("Save & resend", style = AvekTheme.type.label, color = colors.onAccent)
            }
        }
    }
}
