package com.avek.chat.feature.chat.thinking.styles

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import com.avek.chat.core.designsystem.theme.AvekTheme
import com.avek.chat.core.domain.trace.TurnTelemetry
import com.avek.chat.feature.chat.thinking.ThinkingFormat
import com.avek.chat.feature.chat.thinking.ThinkingMode
import com.avek.chat.feature.chat.thinking.panels.ConsolePanel
import com.avek.chat.feature.chat.thinking.panels.ContextBarPanel
import com.avek.chat.feature.chat.thinking.panels.DashboardPanel
import com.avek.chat.feature.chat.thinking.panels.HeatStripPanel
import com.avek.chat.feature.chat.thinking.panels.LoopGraphPanel
import com.avek.chat.feature.chat.thinking.panels.PhaseTimelinePanel
import com.avek.chat.feature.chat.thinking.panels.PipelinePanel
import com.avek.chat.feature.chat.thinking.panels.RadialRingsPanel
import com.avek.chat.feature.chat.thinking.panels.RuntimePanel
import com.avek.chat.feature.chat.thinking.panels.ThoughtStreamPanel
import com.avek.chat.feature.chat.thinking.panels.ThroughputPanel
import com.avek.chat.feature.chat.thinking.panels.TickerPanel
import com.avek.chat.feature.chat.thinking.panels.TokenLedgerPanel
import com.avek.chat.feature.chat.thinking.panels.ToolCardsPanel
import com.avek.chat.feature.chat.thinking.panels.WaterfallPanel
import com.avek.chat.feature.chat.thinking.panels.minimalLine
import com.avek.chat.feature.chat.thinking.panels.rememberNow

/*
 * The 16 display styles of the thinking block (v3 task E). Every style has the same signature and
 * is built from the reusable panels; everything shown comes from the turn's telemetry.
 */

private val ThinkingMode.compact: Boolean get() = this == ThinkingMode.Compact

@Composable
fun MinimalLineStyle(t: TurnTelemetry, thinkingText: String, mode: ThinkingMode, modifier: Modifier = Modifier) {
    val now by rememberNow(t.live)
    Text(
        minimalLine(t, ThinkingFormat.phaseLabel(t, t.live), t.elapsedMs(now)).ifEmpty { ThinkingFormat.NONE },
        style = AvekTheme.type.label,
        color = AvekTheme.colors.textSecondary,
        maxLines = if (mode.compact) 1 else 2,
        overflow = TextOverflow.Ellipsis,
        modifier = modifier.fillMaxWidth(),
    )
}

@Composable
fun TokenTickerStyle(t: TurnTelemetry, thinkingText: String, mode: ThinkingMode, modifier: Modifier = Modifier) =
    TickerPanel(t, thinkingText, mode.compact, modifier)

@Composable
fun PhaseTimelineStyle(t: TurnTelemetry, thinkingText: String, mode: ThinkingMode, modifier: Modifier = Modifier) {
    val now by rememberNow(t.live)
    PhaseTimelinePanel(t, now, mode.compact, modifier)
}

@Composable
fun PipelineStyle(t: TurnTelemetry, thinkingText: String, mode: ThinkingMode, modifier: Modifier = Modifier) {
    val now by rememberNow(t.live)
    PipelinePanel(t, now, mode.compact, modifier)
}

@Composable
fun ContextBarStyle(t: TurnTelemetry, thinkingText: String, mode: ThinkingMode, modifier: Modifier = Modifier) =
    ContextBarPanel(t, mode.compact, modifier)

@Composable
fun TokenLedgerStyle(t: TurnTelemetry, thinkingText: String, mode: ThinkingMode, modifier: Modifier = Modifier) =
    TokenLedgerPanel(t, mode.compact, modifier)

@Composable
fun ThroughputStyle(t: TurnTelemetry, thinkingText: String, mode: ThinkingMode, modifier: Modifier = Modifier) =
    ThroughputPanel(t, mode.compact, modifier)

@Composable
fun ToolInspectorStyle(t: TurnTelemetry, thinkingText: String, mode: ThinkingMode, modifier: Modifier = Modifier) =
    ToolCardsPanel(t, mode.compact, modifier)

@Composable
fun HarnessConsoleStyle(t: TurnTelemetry, thinkingText: String, mode: ThinkingMode, modifier: Modifier = Modifier) {
    var paused by remember { mutableStateOf(false) }
    Column(modifier.fillMaxWidth()) {
        ConsolePanel(t, mode.compact, paused, Modifier.clickable(enabled = !mode.compact) { paused = !paused })
        if (!mode.compact) {
            Text(
                if (paused) "Tap to follow the log again" else "Tap to pause",
                style = AvekTheme.type.caption, color = AvekTheme.colors.textTertiary,
            )
        }
    }
}

@Composable
fun RuntimeStyle(t: TurnTelemetry, thinkingText: String, mode: ThinkingMode, modifier: Modifier = Modifier) =
    RuntimePanel(t.runtime, mode.compact, modifier)

@Composable
fun WaterfallStyle(t: TurnTelemetry, thinkingText: String, mode: ThinkingMode, modifier: Modifier = Modifier) {
    val now by rememberNow(t.live)
    WaterfallPanel(t, now, mode.compact, modifier)
}

@Composable
fun HeatStripStyle(t: TurnTelemetry, thinkingText: String, mode: ThinkingMode, modifier: Modifier = Modifier) =
    HeatStripPanel(t, mode.compact, modifier)

@Composable
fun DashboardStyle(t: TurnTelemetry, thinkingText: String, mode: ThinkingMode, modifier: Modifier = Modifier) {
    val now by rememberNow(t.live)
    DashboardPanel(t, ThinkingFormat.phaseLabel(t, t.live), t.elapsedMs(now), mode.compact, modifier)
}

@Composable
fun ThoughtStreamStyle(t: TurnTelemetry, thinkingText: String, mode: ThinkingMode, modifier: Modifier = Modifier) =
    ThoughtStreamPanel(t, thinkingText, mode.compact, modifier)

@Composable
fun AgentLoopStyle(t: TurnTelemetry, thinkingText: String, mode: ThinkingMode, modifier: Modifier = Modifier) =
    LoopGraphPanel(t, mode.compact, modifier)

@Composable
fun RadialRingsStyle(t: TurnTelemetry, thinkingText: String, mode: ThinkingMode, modifier: Modifier = Modifier) =
    RadialRingsPanel(t, mode.compact, modifier)
