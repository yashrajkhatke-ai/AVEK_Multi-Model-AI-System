package com.avek.chat.di

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.core.DataStoreFactory
import androidx.datastore.core.handlers.ReplaceFileCorruptionHandler
import androidx.datastore.dataStoreFile
import androidx.room.Room
import com.avek.chat.core.common.AppDispatchers
import com.avek.chat.core.common.DefaultAppDispatchers
import com.avek.chat.core.common.IdGenerator
import com.avek.chat.core.common.SystemTimeProvider
import com.avek.chat.core.common.TimeProvider
import com.avek.chat.core.common.UuidGenerator
import com.avek.chat.core.data.downloads.DownloadDatabase
import com.avek.chat.core.data.settings.UserSettingsSerializer
import com.avek.chat.core.domain.repository.SettingsRepository
import com.avek.chat.core.model.settings.UserSettings
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideDispatchers(): AppDispatchers = DefaultAppDispatchers()

    @Provides
    @Singleton
    fun provideTimeProvider(): TimeProvider = SystemTimeProvider()

    @Provides
    @Singleton
    fun provideIdGenerator(): IdGenerator = UuidGenerator()

    @Provides
    @Singleton
    @ApplicationScope
    fun provideApplicationScope(): CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    /** Only downloaded chats live in Room now; the PC holds everything else. */
    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): DownloadDatabase =
        Room.databaseBuilder(context, DownloadDatabase::class.java, DownloadDatabase.NAME)
            // Older builds kept every chat here; those copies are no longer wanted.
            .fallbackToDestructiveMigration()
            .build()

    @Provides
    @Singleton
    fun provideSettingsDataStore(
        @ApplicationContext context: Context,
        dispatchers: AppDispatchers,
    ): DataStore<UserSettings> = DataStoreFactory.create(
        serializer = UserSettingsSerializer,
        corruptionHandler = ReplaceFileCorruptionHandler { UserSettingsSerializer.defaultValue },
        scope = CoroutineScope(dispatchers.io + SupervisorJob()),
        produceFile = { context.dataStoreFile("user_settings.json") },
    )

    /** The latest settings, readable without suspending (route list, "keep lists" seconds…). */
    @Provides
    @Singleton
    fun provideSettingsState(repository: SettingsRepository, @ApplicationScope scope: CoroutineScope): StateFlow<UserSettings> =
        repository.settings.stateIn(scope, SharingStarted.Eagerly, UserSettings())
}
