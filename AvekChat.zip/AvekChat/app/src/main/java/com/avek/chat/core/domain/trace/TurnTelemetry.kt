package com.avek.chat.core.domain.trace

import com.avek.chat.core.link.wire.TraceContextDto
import com.avek.chat.core.link.wire.TraceGenDto
import com.avek.chat.core.link.wire.TraceLogDto
import com.avek.chat.core.link.wire.TraceRuntimeDto
import com.avek.chat.core.link.wire.TraceToolDto

/** Identifies a turn: a `promptId` is only unique inside its chat (UI-WIRE v3 section 9). */
data class TurnKey(val chatId: String, val promptId: String)

/** A tool call inside a turn: `(step, index)` from `writing` to `done`. */
data class CallKey(val step: Int, val index: Int)

/** One phase of the harness's work (`trace.phase` start + end, paired by `id`). */
data class PhaseSpan(
    val id: String,
    val phase: String,
    val label: String,
    val detail: String?,
    val step: Int?,
    val startT: Long?,
    val endT: Long?,
    val ms: Long?,
) {
    val open: Boolean get() = endT == null && startT != null

    /** Measured duration; while open, what has passed until [nowT] (PC clock). */
    fun durationMs(nowT: Long): Long? = ms ?: if (startT != null && endT != null) endT - startT else if (startT != null) (nowT - startT).coerceAtLeast(0) else null
}

/** A `trace.phase` event as it arrived (the phase history ring). */
data class PhaseMark(val id: String, val phase: String, val state: String, val label: String, val step: Int?, val t: Long)

/** One throughput sample from `trace.gen` (PC clock). */
data class TpsSample(val t: Long, val step: Int, val tps: Double, val totalTokens: Int)

enum class TokenKind { REASONING, ANSWER, TOOL_CALL }

/**
 * One streamed delta as the device received it ([atMs], device clock). The harness sends one delta
 * per token, so these are the real token cells of the heat strip.
 */
data class TokenCell(val index: Int, val kind: TokenKind, val atMs: Long, val chars: Int)

/** The streamed argument text of a tool call (`toolcall.delta`). [gap] = a delta was missed. */
data class ToolArgs(val callId: String?, val name: String?, val text: String, val gap: Boolean = false)

/**
 * Everything the thinking block knows about one turn, built only from real events (v3 task D.3).
 * Immutable; [TraceReducer] produces the next value.
 */
data class TurnTelemetry(
    val key: TurnKey,
    val modelId: String = "",
    val modelName: String = "",
    val live: Boolean = false,
    /** Turn start on the PC clock, when known (from a snapshot, or the first trace event). */
    val startedAt: Long? = null,
    val endedAt: Long? = null,
    /** Device time when the turn was first seen (for "elapsed" when the PC clock is not comparable). */
    val firstSeenAt: Long? = null,
    val phases: List<PhaseSpan> = emptyList(),
    val phaseHistory: List<PhaseMark> = emptyList(),
    val context: TraceContextDto? = null,
    /** Every `trace.context` of the turn (latest per step), to animate growth and compaction. */
    val contexts: List<TraceContextDto> = emptyList(),
    /** Latest `trace.gen` per step, ordered by step. */
    val steps: List<TraceGenDto> = emptyList(),
    val tools: Map<CallKey, TraceToolDto> = emptyMap(),
    val toolArgs: Map<CallKey, ToolArgs> = emptyMap(),
    val runtime: TraceRuntimeDto? = null,
    val logs: List<TraceLogDto> = emptyList(),
    val tpsSamples: List<TpsSample> = emptyList(),
    val tokens: List<TokenCell> = emptyList(),
    /** Total deltas received (the cells ring only keeps the last ones). */
    val tokenCount: Int = 0,
    val thinkingLength: Int = 0,
    val answerLength: Int = 0,
    /** Device time of the last trace event (stale detection). */
    val lastEventAt: Long? = null,
    /** The snapshot from `trace.get` was applied. */
    val fromSnapshot: Boolean = false,
    /** The built-in demo is the source: there is no harness telemetry. */
    val demo: Boolean = false,
) {
    // ------------------------------------------------------------------ derived only from the data above

    /** The phase shown as "now": the most recently started open phase, else null. */
    val currentPhase: PhaseSpan? get() = phases.filter { it.open }.maxByOrNull { it.startT ?: 0 }

    val lastPhase: PhaseSpan? get() = currentPhase ?: phases.maxByOrNull { it.endT ?: it.startT ?: 0 }

    val latestGen: TraceGenDto? get() = steps.lastOrNull()

    val reasoningTokens: Int get() = steps.sumOf { it.tokens.reasoning }
    val answerTokens: Int get() = steps.sumOf { it.tokens.answer }
    val toolCallTokens: Int get() = steps.sumOf { it.tokens.toolCall }
    val generatedTokens: Int get() = steps.sumOf { it.tokens.total }

    /** All step token counts are server counts. */
    val tokensExact: Boolean get() = steps.isNotEmpty() && steps.all { it.tokens.exact }

    /** Prompt and completion totals of the whole turn (the latest `turn` object). */
    val promptTokens: Int? get() = steps.maxByOrNull { it.t }?.turn?.promptTokens
    val completionTokens: Int? get() = steps.maxByOrNull { it.t }?.turn?.completionTokens

    val ttftMs: Long? get() = steps.firstOrNull()?.ttftMs
    val tps: Double? get() = latestGen?.takeIf { it.state != "prefill" }?.tps
    val avgTps: Double? get() = latestGen?.avgTps?.takeIf { it > 0 }
    val stepCount: Int get() = steps.size
    val toolCount: Int get() = tools.size

    /** Context fill 0..1 of the window the chat holds now. */
    val contextFill: Float? get() = context?.let { c -> if (c.window > 0) (c.promptTokens.toFloat() / c.window).coerceIn(0f, 1f) else null }

    /** Turn elapsed on the PC clock (from the `turn` totals) when the harness reported it. */
    val turnElapsedMs: Long? get() = steps.maxByOrNull { it.t }?.turn?.elapsedMs

    /** "Waiting for the harness...": a live turn with no trace event for more than 3 s. */
    fun isStale(nowMs: Long): Boolean = live && lastEventAt != null && nowMs - lastEventAt > STALE_MS

    fun silenceMs(nowMs: Long): Long = lastEventAt?.let { nowMs - it } ?: 0

    /** The newest PC timestamp seen in any trace event. */
    val latestT: Long?
        get() = listOfNotNull(
            phases.maxOfOrNull { maxOf(it.startT ?: 0, it.endT ?: 0) }.takeIf { it != 0L },
            steps.maxOfOrNull { it.t },
            context?.t,
            tools.values.maxOfOrNull { it.t },
            logs.lastOrNull()?.t,
        ).maxOrNull()

    /** The PC clock now, estimated from the newest event and the device time since it arrived. */
    fun pcNow(nowMs: Long): Long? = latestT?.let { t -> if (live && lastEventAt != null) t + (nowMs - lastEventAt).coerceAtLeast(0) else t }

    /**
     * How long the turn has run: device-measured while live (from when it was first seen, or
     * [fallbackStart]), the PC's measurement afterwards.
     */
    fun elapsedMs(nowMs: Long, fallbackStart: Long? = null): Long? = when {
        live -> listOfNotNull(firstSeenAt, fallbackStart?.takeIf { it > 0 }).minOrNull()?.let { (nowMs - it).coerceAtLeast(0) } ?: turnElapsedMs
        startedAt != null && endedAt != null -> endedAt - startedAt
        else -> turnElapsedMs
    }

    val hasTrace: Boolean get() = phases.isNotEmpty() || steps.isNotEmpty() || context != null || tools.isNotEmpty() || runtime != null

    companion object {
        const val STALE_MS = 3_000L
        const val MAX_LOGS = 200
        const val MAX_PHASE_HISTORY = 400
        const val MAX_TPS_SAMPLES = 600
        const val TPS_WINDOW_MS = 60_000L
        const val MAX_TOKEN_CELLS = 600
    }
}
