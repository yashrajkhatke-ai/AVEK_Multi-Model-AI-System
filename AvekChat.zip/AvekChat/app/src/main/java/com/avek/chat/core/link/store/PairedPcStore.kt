package com.avek.chat.core.link.store

import com.avek.chat.core.link.crypto.SecureCrypto
import com.avek.chat.core.link.wire.WireJson
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.serialization.Serializable
import java.io.File

/** The one PC this device is paired with. [deviceSecret] never leaves memory in clear text. */
class PairedPc(
    val deviceId: String,
    val deviceSecret: ByteArray,
    val serverId: String,
    val serverName: String,
    val deviceName: String,
    val lastHost: String? = null,
    val lastPort: Int = 7810,
    val epoch: String? = null,
    val lastSeq: Long = 0,
) {
    fun copy(
        serverName: String = this.serverName,
        deviceName: String = this.deviceName,
        lastHost: String? = this.lastHost,
        lastPort: Int = this.lastPort,
        epoch: String? = this.epoch,
        lastSeq: Long = this.lastSeq,
    ) = PairedPc(deviceId, deviceSecret, serverId, serverName, deviceName, lastHost, lastPort, epoch, lastSeq)

    override fun toString(): String = "PairedPc($serverName, device=$deviceId)"
}

interface PairedPcStore {
    val pc: StateFlow<PairedPc?>
    fun save(pc: PairedPc)
    fun update(transform: (PairedPc) -> PairedPc)
    fun clear()
}

/** File-backed store; the secret is encrypted by a [SecretVault], everything else is plain JSON. */
class FilePairedPcStore(
    private val file: File,
    private val vault: SecretVault,
) : PairedPcStore {

    @Serializable
    private class Stored(
        val deviceId: String,
        val secret: String,
        val serverId: String,
        val serverName: String,
        val deviceName: String,
        val lastHost: String? = null,
        val lastPort: Int = 7810,
        val epoch: String? = null,
        val lastSeq: Long = 0,
    )

    private val state = MutableStateFlow(load())
    override val pc: StateFlow<PairedPc?> = state

    @Synchronized
    override fun save(pc: PairedPc) {
        write(pc)
        state.value = pc
    }

    @Synchronized
    override fun update(transform: (PairedPc) -> PairedPc) {
        val current = state.value ?: return
        val next = transform(current)
        write(next)
        state.value = next
    }

    @Synchronized
    override fun clear() {
        file.delete()
        state.value = null
    }

    private fun write(pc: PairedPc) {
        val stored = Stored(
            deviceId = pc.deviceId,
            secret = SecureCrypto.b64(vault.encrypt(pc.deviceSecret)),
            serverId = pc.serverId,
            serverName = pc.serverName,
            deviceName = pc.deviceName,
            lastHost = pc.lastHost,
            lastPort = pc.lastPort,
            epoch = pc.epoch,
            lastSeq = pc.lastSeq,
        )
        file.parentFile?.mkdirs()
        val temp = File(file.parentFile, file.name + ".tmp")
        temp.writeText(WireJson.encodeToString(Stored.serializer(), stored))
        if (!temp.renameTo(file)) {
            file.delete()
            check(temp.renameTo(file)) { "Could not write ${file.name}" }
        }
    }

    private fun load(): PairedPc? {
        if (!file.exists()) return null
        return try {
            val stored = WireJson.decodeFromString(Stored.serializer(), file.readText())
            PairedPc(
                deviceId = stored.deviceId,
                deviceSecret = vault.decrypt(SecureCrypto.unb64(stored.secret)),
                serverId = stored.serverId,
                serverName = stored.serverName,
                deviceName = stored.deviceName,
                lastHost = stored.lastHost,
                lastPort = stored.lastPort,
                epoch = stored.epoch,
                lastSeq = stored.lastSeq,
            )
        } catch (e: Exception) {
            // A lost Keystore key (restore, factory reset of the key) or a corrupt file: pair again.
            file.delete()
            null
        }
    }
}
