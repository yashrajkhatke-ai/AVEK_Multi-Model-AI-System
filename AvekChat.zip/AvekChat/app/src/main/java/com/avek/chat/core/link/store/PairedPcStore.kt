package com.avek.chat.core.link.store

import com.avek.chat.core.link.crypto.SecureCrypto
import com.avek.chat.core.link.wire.WireJson
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.jsonObject
import java.io.File

/**
 * The PC this device is paired with (UI-WIRE v3 section 3). It holds no secret: the device's
 * private key is in the Keystore and the PC's public key is public data that is pinned here.
 */
class PairedPc(
    val serverId: String,
    val serverName: String,
    val serverPub: ByteArray,
    val deviceName: String,
    val lastHost: String? = null,
    val lastPort: Int = DEFAULT_PORT,
    val epoch: String? = null,
    val lastSeq: Long = 0,
) {
    fun copy(
        serverName: String = this.serverName,
        deviceName: String = this.deviceName,
        lastHost: String? = this.lastHost,
        lastPort: Int = this.lastPort,
        epoch: String? = this.epoch,
        lastSeq: Long = this.lastSeq,
    ) = PairedPc(serverId, serverName, serverPub, deviceName, lastHost, lastPort, epoch, lastSeq)

    override fun toString(): String = "PairedPc($serverName, $serverId)"

    companion object {
        const val DEFAULT_PORT = 7810
    }
}

interface PairedPcStore {
    val pc: StateFlow<PairedPc?>

    /** Set once when an old (v2) pairing was found and wiped: "This version pairs differently…". */
    val notice: StateFlow<String?>

    fun save(pc: PairedPc)
    fun update(transform: (PairedPc) -> PairedPc)
    fun clear()
    fun clearNotice()
}

/** File-backed store (plain JSON: nothing in it is secret). Excluded from backups. */
class FilePairedPcStore(private val file: File) : PairedPcStore {

    @Serializable
    private class Stored(
        val version: Int = VERSION,
        val serverId: String,
        val serverName: String,
        val serverPub: String,
        val deviceName: String,
        val lastHost: String? = null,
        val lastPort: Int = PairedPc.DEFAULT_PORT,
        val epoch: String? = null,
        val lastSeq: Long = 0,
    )

    private val _notice = MutableStateFlow<String?>(null)
    override val notice: StateFlow<String?> = _notice

    private val state = MutableStateFlow(load())
    override val pc: StateFlow<PairedPc?> = state

    @Synchronized
    override fun save(pc: PairedPc) {
        write(pc)
        state.value = pc
        _notice.value = null
    }

    @Synchronized
    override fun update(transform: (PairedPc) -> PairedPc) {
        val current = state.value ?: return
        val next = transform(current)
        write(next)
        state.value = next
    }

    @Synchronized
    override fun clear() {
        file.delete()
        state.value = null
    }

    override fun clearNotice() {
        _notice.value = null
    }

    private fun write(pc: PairedPc) {
        val stored = Stored(
            serverId = pc.serverId,
            serverName = pc.serverName,
            serverPub = SecureCrypto.b64(pc.serverPub),
            deviceName = pc.deviceName,
            lastHost = pc.lastHost,
            lastPort = pc.lastPort,
            epoch = pc.epoch,
            lastSeq = pc.lastSeq,
        )
        file.parentFile?.mkdirs()
        val temp = File(file.parentFile, file.name + ".tmp")
        temp.writeText(WireJson.encodeToString(Stored.serializer(), stored))
        if (!temp.renameTo(file)) {
            file.delete()
            check(temp.renameTo(file)) { "Could not write ${file.name}" }
        }
    }

    private fun load(): PairedPc? {
        if (!file.exists()) return null
        val text = runCatching { file.readText() }.getOrNull()
        val raw = text?.let { runCatching { WireJson.parseToJsonElement(it).jsonObject }.getOrNull() }
        // A v2 grant (with a shared `secret`): wipe it, nothing else, and ask to pair again.
        if (raw != null && isOldFormat(raw)) {
            wipe()
            _notice.value = MIGRATION_NOTICE
            return null
        }
        return try {
            val stored = WireJson.decodeFromString(Stored.serializer(), text!!)
            val pub = SecureCrypto.unb64(stored.serverPub)
            require(SecureCrypto.isValidPublicKey(pub))
            PairedPc(stored.serverId, stored.serverName, pub, stored.deviceName, stored.lastHost, stored.lastPort, stored.epoch, stored.lastSeq)
        } catch (e: Exception) {
            wipe() // corrupt: pair again
            null
        }
    }

    private fun isOldFormat(raw: JsonObject) = "secret" in raw || "deviceSecret" in raw || "serverPub" !in raw

    private fun wipe() {
        // Overwrite before deleting so the old secret does not linger in the file's blocks.
        runCatching { file.writeText(" ".repeat(file.length().toInt().coerceAtMost(64 * 1024))) }
        file.delete()
        File(file.parentFile, file.name + ".tmp").delete()
    }

    companion object {
        const val VERSION = 3
        const val MIGRATION_NOTICE = "This version pairs differently. Pair with your PC again."
    }
}
