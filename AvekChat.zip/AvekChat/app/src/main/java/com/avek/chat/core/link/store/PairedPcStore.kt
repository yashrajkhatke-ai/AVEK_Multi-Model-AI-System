package com.avek.chat.core.link.store

import com.avek.chat.core.link.crypto.SecureCrypto
import com.avek.chat.core.link.wire.RoutesData
import com.avek.chat.core.link.wire.WireJson
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.jsonObject
import java.io.File

/**
 * A key replacement in progress (UI-WIRE v4 section 4.1): the new identity alias and the new
 * secrets (sealed), kept next to the old ones until a `slot:"next"` connection reached `ready`.
 * [deadlineMs] (epoch ms) is when the PC's grace for the old key ends; after it the new key is dropped.
 */
class PendingRekey(val alias: String, val sealedSecrets: ByteArray, val deadlineMs: Long) {
    override fun toString(): String = "PendingRekey($alias)"
}

/**
 * The PC this device is paired with (the "grant", section 13). [deviceId] is stored and never
 * recomputed from the current key (it stays the same after a key replacement). [sealedSecrets]
 * holds `dk` ‖ `rk` sealed by the [SecretVault]; nothing else here is secret.
 */
class PairedPc(
    val deviceId: String,
    val identityAlias: String,
    val serverId: String,
    val serverName: String,
    val serverPub: ByteArray,
    val deviceName: String,
    val sealedSecrets: ByteArray,
    val routes: RoutesData? = null,
    val lastWifiHost: String? = null,
    val lastWifiPort: Int = DEFAULT_PORT,
    val lastConnectedAt: Long? = null,
    val epoch: String? = null,
    val lastSeq: Long = 0,
    val pendingRekey: PendingRekey? = null,
) {
    fun copy(
        identityAlias: String = this.identityAlias,
        serverName: String = this.serverName,
        deviceName: String = this.deviceName,
        sealedSecrets: ByteArray = this.sealedSecrets,
        routes: RoutesData? = this.routes,
        lastWifiHost: String? = this.lastWifiHost,
        lastWifiPort: Int = this.lastWifiPort,
        lastConnectedAt: Long? = this.lastConnectedAt,
        epoch: String? = this.epoch,
        lastSeq: Long = this.lastSeq,
        pendingRekey: PendingRekey? = this.pendingRekey,
    ) = PairedPc(
        deviceId, identityAlias, serverId, serverName, serverPub, deviceName, sealedSecrets,
        routes, lastWifiHost, lastWifiPort, lastConnectedAt, epoch, lastSeq, pendingRekey,
    )

    override fun toString(): String = "PairedPc($serverName, $serverId, $deviceId)"

    companion object {
        const val DEFAULT_PORT = 7810
    }
}

interface PairedPcStore {
    val pc: StateFlow<PairedPc?>

    /** Set once when an old (v3 or older) pairing was found and wiped: "This version pairs differently…". */
    val notice: StateFlow<String?>

    fun save(pc: PairedPc)
    fun update(transform: (PairedPc) -> PairedPc)
    fun clear()
    fun clearNotice()
}

/**
 * File-backed store. The stored routes are sealed with the [vault] like the secrets (section 13).
 * A grant of an older version (no sealed `dk`) is wiped on the first start, its Keystore key is
 * deleted through [onLegacyWiped], and [notice] asks the person to pair again. `link/` is excluded
 * from backups.
 */
class FilePairedPcStore(
    private val file: File,
    private val vault: SecretVault,
    private val onLegacyWiped: () -> Unit = {},
) : PairedPcStore {

    @Serializable
    private class StoredPending(val alias: String, val sealedSecrets: String, val deadlineMs: Long)

    @Serializable
    private class Stored(
        val version: Int = VERSION,
        val deviceId: String,
        val identityAlias: String,
        val serverId: String,
        val serverName: String,
        val serverPub: String,
        val deviceName: String,
        val sealedSecrets: String,
        val sealedRoutes: String? = null,
        val lastWifiHost: String? = null,
        val lastWifiPort: Int = PairedPc.DEFAULT_PORT,
        val lastConnectedAt: Long? = null,
        val epoch: String? = null,
        val lastSeq: Long = 0,
        val pendingRekey: StoredPending? = null,
    )

    private val _notice = MutableStateFlow<String?>(null)
    override val notice: StateFlow<String?> = _notice

    private val state = MutableStateFlow(load())
    override val pc: StateFlow<PairedPc?> = state

    @Synchronized
    override fun save(pc: PairedPc) {
        write(pc)
        state.value = pc
        _notice.value = null
    }

    @Synchronized
    override fun update(transform: (PairedPc) -> PairedPc) {
        val current = state.value ?: return
        val next = transform(current)
        write(next)
        state.value = next
    }

    @Synchronized
    override fun clear() {
        wipe()
        state.value = null
    }

    override fun clearNotice() {
        _notice.value = null
    }

    private fun write(pc: PairedPc) {
        val routes = pc.routes?.let { r ->
            val plain = WireJson.encodeToString(RoutesData.serializer(), r).toByteArray(Charsets.UTF_8)
            SecureCrypto.b64(vault.seal(plain))
        }
        val stored = Stored(
            deviceId = pc.deviceId,
            identityAlias = pc.identityAlias,
            serverId = pc.serverId,
            serverName = pc.serverName,
            serverPub = SecureCrypto.b64(pc.serverPub),
            deviceName = pc.deviceName,
            sealedSecrets = SecureCrypto.b64(pc.sealedSecrets),
            sealedRoutes = routes,
            lastWifiHost = pc.lastWifiHost,
            lastWifiPort = pc.lastWifiPort,
            lastConnectedAt = pc.lastConnectedAt,
            epoch = pc.epoch,
            lastSeq = pc.lastSeq,
            pendingRekey = pc.pendingRekey?.let { StoredPending(it.alias, SecureCrypto.b64(it.sealedSecrets), it.deadlineMs) },
        )
        file.parentFile?.mkdirs()
        val temp = File(file.parentFile, file.name + ".tmp")
        temp.writeText(WireJson.encodeToString(Stored.serializer(), stored))
        if (!temp.renameTo(file)) {
            file.delete()
            check(temp.renameTo(file)) { "Could not write ${file.name}" }
        }
    }

    private fun load(): PairedPc? {
        if (!file.exists()) return null
        val text = runCatching { file.readText() }.getOrNull()
        val raw = text?.let { runCatching { WireJson.parseToJsonElement(it).jsonObject }.getOrNull() }
        // A v3 (or v2) grant has no sealed `dk`: wipe it and its Keystore key, nothing else, and ask to pair again.
        if (raw != null && isOldFormat(raw)) {
            wipe()
            runCatching(onLegacyWiped)
            _notice.value = MIGRATION_NOTICE
            return null
        }
        return try {
            val stored = WireJson.decodeFromString(Stored.serializer(), text!!)
            val pub = SecureCrypto.unb64(stored.serverPub)
            require(SecureCrypto.isValidPublicKey(pub))
            // Unreadable routes are not fatal: the next `routes.get` refills them.
            val routes = stored.sealedRoutes?.let { sealed ->
                runCatching {
                    val plain = vault.open(SecureCrypto.unb64(sealed))
                    WireJson.decodeFromString(RoutesData.serializer(), plain.toString(Charsets.UTF_8))
                }.getOrNull()
            }
            PairedPc(
                deviceId = stored.deviceId,
                identityAlias = stored.identityAlias,
                serverId = stored.serverId,
                serverName = stored.serverName,
                serverPub = pub,
                deviceName = stored.deviceName,
                sealedSecrets = SecureCrypto.unb64(stored.sealedSecrets),
                routes = routes,
                lastWifiHost = stored.lastWifiHost,
                lastWifiPort = stored.lastWifiPort,
                lastConnectedAt = stored.lastConnectedAt,
                epoch = stored.epoch,
                lastSeq = stored.lastSeq,
                pendingRekey = stored.pendingRekey?.let { PendingRekey(it.alias, SecureCrypto.unb64(it.sealedSecrets), it.deadlineMs) },
            )
        } catch (e: Exception) {
            wipe() // corrupt: pair again
            null
        }
    }

    /** v2 kept a shared `secret`; v3 had a key pair but no `dk`. Only v4 has sealed secrets. */
    private fun isOldFormat(raw: JsonObject): Boolean =
        "sealedSecrets" !in raw || "secret" in raw || "deviceSecret" in raw

    private fun wipe() {
        // Overwrite before deleting so nothing old lingers in the file's blocks.
        runCatching { if (file.exists()) file.writeText(" ".repeat(file.length().toInt().coerceAtMost(64 * 1024))) }
        file.delete()
        File(file.parentFile, file.name + ".tmp").delete()
    }

    companion object {
        const val VERSION = 4
        const val MIGRATION_NOTICE = "This version pairs differently. Pair with your PC again."
    }
}

/** Opens and seals the grant's secrets. Callers wipe the returned [DeviceSecrets] after use. */
class GrantSecrets(private val vault: SecretVault) {
    fun open(sealed: ByteArray): DeviceSecrets = DeviceSecrets.decode(vault.open(sealed))

    fun seal(secrets: DeviceSecrets): ByteArray {
        val plain = secrets.encode()
        return try {
            vault.seal(plain)
        } finally {
            plain.fill(0)
        }
    }
}
