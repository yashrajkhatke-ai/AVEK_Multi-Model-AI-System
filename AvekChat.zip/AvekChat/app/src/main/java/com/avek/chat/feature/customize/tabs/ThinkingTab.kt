package com.avek.chat.feature.customize.tabs

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.avek.chat.core.designsystem.component.SectionHeader
import com.avek.chat.core.designsystem.component.SettingsCard
import com.avek.chat.core.designsystem.component.SwitchRow
import com.avek.chat.core.designsystem.theme.AvekTheme
import com.avek.chat.core.domain.timeline.TimelineReducer
import com.avek.chat.core.domain.timeline.TurnTimeline
import com.avek.chat.core.domain.trace.TurnKey
import com.avek.chat.core.link.wire.BlockDeltaDto
import com.avek.chat.core.link.wire.BlockEndDto
import com.avek.chat.core.link.wire.BlockStartDto
import com.avek.chat.core.link.wire.BlockStateDto
import com.avek.chat.core.link.wire.BlockSummaryDto
import com.avek.chat.core.link.wire.BlockToolDto
import com.avek.chat.core.link.wire.LinkEvent
import com.avek.chat.core.model.settings.ThinkingSettings
import com.avek.chat.feature.chat.thinking.LocalTimelineEnvironment
import com.avek.chat.feature.chat.thinking.TimelineEnvironment
import com.avek.chat.feature.chat.thinking.TimelineTurn
import com.avek.chat.feature.chat.thinking.ToolResults
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/** Customize → Thinking: how the thinking section behaves, with a scripted preview labelled "Sample". */
@Composable
fun ThinkingTab(settings: ThinkingSettings, onChange: ((ThinkingSettings) -> ThinkingSettings) -> Unit) {
    val colors = AvekTheme.colors
    LazyColumn(contentPadding = PaddingValues(bottom = 40.dp)) {
        item {
            SettingsCard(Modifier.padding(top = 16.dp)) {
                SwitchRow("Collapse a thinking block when it ends", settings.collapseWhenEnds, { v -> onChange { it.copy(collapseWhenEnds = v) } })
                HorizontalDivider(color = colors.outline.copy(alpha = 0.4f))
                SwitchRow("Keep the running group open", settings.keepRunningGroupOpen, { v -> onChange { it.copy(keepRunningGroupOpen = v) } })
            }
        }
        item { SectionHeader("Preview", subtitle = "Sample: a scripted turn, not your PC") }
        item { SamplePreview(settings) }
    }
}

private const val C = "sample"
private const val P = "p1"

/** The scripted sample, as the harness would send it (replayed in a loop). */
private val SAMPLE: List<LinkEvent> = buildList {
    add(LinkEvent.BlockStart(null, BlockStartDto(C, P, 1, "b1", kind = "thinking", title = "Figuring out what to do", from = 0)))
    "The person wants a short summary of the file. I will read it first, then write three bullet points. ".split(" ").forEachIndexed { i, w ->
        add(LinkEvent.BlockDelta(null, BlockDeltaDto(C, P, 0, "b1", "text", "$w ", offset = -1 - i)))
    }
    add(LinkEvent.BlockEnd(null, BlockEndDto(C, P, 0, "b1", ms = 2_400)))
    add(LinkEvent.BlockStart(null, BlockStartDto(C, P, 2, "b2", kind = "tool", title = "Tool calling for Read file", tool = BlockToolDto("read_file", "Read file"), state = "writing")))
    """{"path":"notes/plan.md"}""".chunked(4).forEach { add(LinkEvent.BlockDelta(null, BlockDeltaDto(C, P, 0, "b2", "args", it, offset = -1))) }
    add(LinkEvent.BlockState(null, BlockStateDto(C, P, 0, "b2", "running", "notes/plan.md")))
    add(LinkEvent.BlockEnd(null, BlockEndDto(C, P, 0, "b2", title = "Tool called for Read file", ms = 300, summary = BlockSummaryDto("Read 42 lines"), ok = true)))
    add(LinkEvent.BlockStart(null, BlockStartDto(C, P, 3, "b3", kind = "answer", title = "Answer", from = 0)))
    "Here is the summary in three points.".split(" ").forEach { add(LinkEvent.BlockDelta(null, BlockDeltaDto(C, P, 0, "b3", "text", "$it ", offset = -1))) }
    add(LinkEvent.BlockEnd(null, BlockEndDto(C, P, 0, "b3", ms = 400)))
}

/** Fills in the offsets (the script above leaves them to the replay so it stays readable). */
private fun withOffsets(state: TurnTimeline, event: LinkEvent): LinkEvent = if (event is LinkEvent.BlockDelta) {
    val block = state.blocks[event.data.id]
    val length = if (event.data.channel == "args") block?.args?.length ?: 0 else block?.text?.length ?: 0
    LinkEvent.BlockDelta(null, event.data.copy(offset = length))
} else event

@Composable
private fun SamplePreview(settings: ThinkingSettings) {
    var step by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(if (step >= SAMPLE.size) 2_500 else 90)
            step = if (step >= SAMPLE.size) 0 else step + 1
        }
    }
    val timeline = remember(step) {
        SAMPLE.take(step).fold(TurnTimeline(TurnKey(C, P), live = true)) { acc, e -> TimelineReducer.reduce(acc, withOffsets(acc, e)) }
            .let { if (step >= SAMPLE.size) it.copy(live = false) else it }
    }
    val env = remember(settings) {
        object : TimelineEnvironment {
            override val revision = 2
            override val demo = true
            override val settings: StateFlow<ThinkingSettings> = MutableStateFlow(settings)
            override fun timeline(chatId: String, promptId: String, live: Boolean): StateFlow<TurnTimeline> = MutableStateFlow(timeline)
            override fun loadTexts(chatId: String, promptId: String, ids: List<String>) = Unit
        }
    }
    CompositionLocalProvider(LocalTimelineEnvironment provides env) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp)) {
            Text("Sample", style = AvekTheme.type.caption, color = AvekTheme.colors.thinkingGlow)
            TimelineTurn(timeline, startedAt = 0L, results = ToolResults({ null }, {}), answer = { text, _ ->
                Text(text, style = AvekTheme.type.answer, color = AvekTheme.colors.assistantText)
            })
        }
    }
}
