package com.avek.chat.feature.customize.tabs

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.avek.chat.core.designsystem.component.SectionHeader
import com.avek.chat.core.designsystem.component.SettingsCard
import com.avek.chat.core.designsystem.component.SwitchRow
import com.avek.chat.core.designsystem.theme.AvekTheme
import com.avek.chat.core.designsystem.theme.avekShape
import com.avek.chat.core.domain.trace.TurnTelemetry
import com.avek.chat.core.model.settings.ThinkingSettings
import com.avek.chat.feature.chat.thinking.ThinkingMode
import com.avek.chat.feature.chat.thinking.ThinkingStyleCatalog

/** What the previews draw: the person's latest real turn (never sample data). */
class ThinkingPreview(val telemetry: TurnTelemetry, val thinkingText: String)

/** Customize → Thinking: the default style, expanded or collapsed, and the full reasoning text. */
@Composable
fun ThinkingTab(settings: ThinkingSettings, preview: ThinkingPreview?, onChange: ((ThinkingSettings) -> ThinkingSettings) -> Unit) {
    val colors = AvekTheme.colors
    LazyColumn(contentPadding = PaddingValues(bottom = 40.dp)) {
        item {
            SettingsCard(Modifier.padding(top = 16.dp)) {
                SwitchRow("Expand the thinking block by default", settings.expandedByDefault, { v -> onChange { it.copy(expandedByDefault = v) } })
                HorizontalDivider(color = colors.outline.copy(alpha = 0.4f))
                SwitchRow("Show the full reasoning text", settings.showFullReasoning, { v -> onChange { it.copy(showFullReasoning = v) } })
            }
        }
        item {
            SectionHeader(
                "Default style",
                subtitle = if (preview == null) "Send a prompt to see a preview" else "Previews use your latest turn",
            )
        }
        item(key = ThinkingStyleCatalog.AUTO) {
            StyleCard(
                name = ThinkingStyleCatalog.AUTO_NAME,
                description = ThinkingStyleCatalog.AUTO_DESCRIPTION,
                selected = settings.style == ThinkingStyleCatalog.AUTO,
                onClick = { onChange { it.copy(style = ThinkingStyleCatalog.AUTO) } },
            ) {
                if (preview != null) ThinkingStyleCatalog.resolve(ThinkingStyleCatalog.AUTO, preview.telemetry).content(preview.telemetry, preview.thinkingText, ThinkingMode.Compact, Modifier)
            }
        }
        items(ThinkingStyleCatalog.styles, key = { it.id }) { style ->
            StyleCard(
                name = style.name,
                description = style.description,
                selected = settings.style == style.id,
                onClick = { onChange { it.copy(style = style.id) } },
            ) {
                if (preview != null) style.content(preview.telemetry, preview.thinkingText, ThinkingMode.Compact, Modifier)
            }
        }
    }
}

@Composable
private fun StyleCard(name: String, description: String, selected: Boolean, onClick: () -> Unit, preview: @Composable () -> Unit) {
    val colors = AvekTheme.colors
    Column(
        Modifier
            .padding(horizontal = 16.dp, vertical = 5.dp)
            .fillMaxWidth()
            .clip(avekShape(16.dp))
            .background(if (selected) colors.accentContainer else colors.surface)
            .border(if (selected) 2.dp else 1.dp, if (selected) colors.accent else colors.outline, avekShape(16.dp))
            .clickable(onClick = onClick)
            .padding(14.dp),
    ) {
        Text(name, style = AvekTheme.type.label.copy(fontWeight = FontWeight.SemiBold), color = colors.textPrimary)
        Text(description, style = AvekTheme.type.caption, color = colors.textSecondary)
        Spacer(Modifier.height(8.dp))
        preview()
    }
}
