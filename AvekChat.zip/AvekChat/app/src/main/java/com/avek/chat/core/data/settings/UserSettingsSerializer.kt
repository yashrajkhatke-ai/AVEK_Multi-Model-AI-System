package com.avek.chat.core.data.settings

import androidx.datastore.core.CorruptionException
import androidx.datastore.core.Serializer
import com.avek.chat.core.model.settings.UserSettings
import kotlinx.serialization.SerializationException
import kotlinx.serialization.json.Json
import java.io.InputStream
import java.io.OutputStream

/** JSON-on-disk serializer for [UserSettings], tolerant to schema evolution. */
object UserSettingsSerializer : Serializer<UserSettings> {

    val json = Json {
        ignoreUnknownKeys = true
        coerceInputValues = true
        encodeDefaults = false
    }

    override val defaultValue: UserSettings = UserSettings()

    override suspend fun readFrom(input: InputStream): UserSettings =
        try {
            json.decodeFromString(UserSettings.serializer(), input.readBytes().decodeToString())
        } catch (e: SerializationException) {
            throw CorruptionException("Unable to read user settings", e)
        } catch (e: IllegalArgumentException) {
            throw CorruptionException("Unable to read user settings", e)
        }

    @Suppress("BlockingMethodInNonBlockingContext")
    override suspend fun writeTo(t: UserSettings, output: OutputStream) {
        output.write(json.encodeToString(UserSettings.serializer(), t).encodeToByteArray())
    }
}
