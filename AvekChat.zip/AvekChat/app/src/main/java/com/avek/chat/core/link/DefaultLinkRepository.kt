package com.avek.chat.core.link

import com.avek.chat.core.link.crypto.AvekProtocol
import com.avek.chat.core.link.crypto.SecureCrypto
import com.avek.chat.core.link.crypto.SessionGrant
import com.avek.chat.core.link.crypto.SessionHandshake
import com.avek.chat.core.link.discovery.KnockClient
import com.avek.chat.core.link.route.AutoConnect
import com.avek.chat.core.link.route.ConnectionState
import com.avek.chat.core.link.route.NetworkEnvironment
import com.avek.chat.core.link.route.NgrokRouteAttempt
import com.avek.chat.core.link.route.RouteAttempt
import com.avek.chat.core.link.route.RouteCredentials
import com.avek.chat.core.link.route.RouteInfoSync
import com.avek.chat.core.link.route.RouteKind
import com.avek.chat.core.link.route.RouteMode
import com.avek.chat.core.link.route.RouteRacer
import com.avek.chat.core.link.route.TailscaleRouteAttempt
import com.avek.chat.core.link.route.WifiRouteAttempt
import com.avek.chat.core.link.route.Won
import com.avek.chat.core.link.rpc.CloseInfo
import com.avek.chat.core.link.rpc.ListPart
import com.avek.chat.core.link.rpc.LiveLink
import com.avek.chat.core.link.rpc.RpcException
import com.avek.chat.core.link.rpc.SecureLinkSession
import com.avek.chat.core.link.store.DeviceKey
import com.avek.chat.core.link.store.DeviceSecrets
import com.avek.chat.core.link.store.GrantSecrets
import com.avek.chat.core.link.store.IdentityVault
import com.avek.chat.core.link.store.PairedPc
import com.avek.chat.core.link.store.PairedPcStore
import com.avek.chat.core.link.store.PendingRekey
import com.avek.chat.core.link.store.SecretVault
import com.avek.chat.core.link.transport.ChannelFactory
import com.avek.chat.core.link.transport.RawChannel
import com.avek.chat.core.link.transport.WifiBinding
import com.avek.chat.core.link.wire.EventDecoder
import com.avek.chat.core.link.wire.LinkEvent
import com.avek.chat.core.link.wire.ReadyDto
import com.avek.chat.core.link.wire.RekeyResultDto
import com.avek.chat.core.link.wire.ResumeResultDto
import com.avek.chat.core.link.wire.RoutesData
import com.avek.chat.core.link.wire.WireEvent
import com.avek.chat.core.link.wire.WireJson
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import java.util.concurrent.atomic.AtomicBoolean

/** The outcome of "Replace this device's keys" (section 4.1). */
sealed interface RekeyOutcome {
    data object Done : RekeyOutcome

    /** The new key is stored but not confirmed yet: the app keeps trying `slot:"next"` until the grace ends. */
    data object Pending : RekeyOutcome
    data class Failed(val message: String) : RekeyOutcome
}

/**
 * The real link (UI-WIRE v4): the pinned PC, the Keystore identity, the sealed `dk`/`rk`, and the
 * auto-connect loop racing Wi-Fi, Tailscale and ngrok (section 2.3). After every connection, in
 * this order: `routes.get` (stored sealed), `resume` (when the epoch matches), `subscribe`, then
 * [LinkEvent.Refresh] (screens refresh; the chat screen's preloader sends `model.load`).
 */
class DefaultLinkRepository(
    private val store: PairedPcStore,
    private val identity: IdentityVault,
    private val vault: SecretVault,
    private val knock: KnockClient,
    private val channels: ChannelFactory,
    private val environment: NetworkEnvironment,
    private val binding: WifiBinding,
    private val handshake: SessionHandshake,
    private val routeMode: StateFlow<RouteMode>,
    private val scope: CoroutineScope,
    private val nowMs: () -> Long = System::currentTimeMillis,
    private val readyTimeoutMs: Long = READY_TIMEOUT_MS,
    private val backoffMs: List<Long> = AutoConnect.BACKOFF_MS,
    private val racer: RouteRacer = RouteRacer(),
    private val pingIntervalMs: Long = SecureLinkSession.PING_INTERVAL_MS,
    private val silenceLimitMs: Long = SecureLinkSession.SILENCE_LIMIT_MS,
) : LinkRepository, PcControl {

    /** A verified link that is waiting to be handed over (events stay muted until [gate] opens). */
    private class Established(
        val session: SecureLinkSession,
        val ready: ReadyDto,
        val gate: AtomicBoolean,
        val route: RouteKind,
    ) : LiveLink by session

    private val secrets = GrantSecrets(vault)
    private val routesSync = RouteInfoSync(store)
    private val wanted = MutableStateFlow(false)
    private val override = MutableStateFlow<ConnectionState?>(null)
    private val waking = MutableStateFlow(false)
    private val _events = MutableSharedFlow<LinkEvent>(extraBufferCapacity = EVENT_BUFFER)
    private val _ready = MutableStateFlow<ReadyDto?>(null)
    private val _profile = MutableStateFlow(LinkProfile.FOREGROUND)
    private val traceWanted = MutableStateFlow(false)

    @Volatile
    private var current: Established? = null

    @Volatile
    private var lastSeq = 0L

    @Volatile
    private var lastPersistedAt = 0L

    private var bindingHeld = false

    private val loop = AutoConnect(
        scope = scope,
        pc = { store.pc.value },
        mode = { routeMode.value },
        candidates = ::candidates,
        attempts = ::attempts,
        describe = { link -> (link as Established).session.remote.toString() },
        onWinner = ::onWinner,
        onLost = ::onLost,
        nowMs = nowMs,
        backoffMs = backoffMs,
        racer = racer,
    )

    override val state: StateFlow<ConnectionState> =
        combine(combine(loop.state, override, store.pc, store.notice) { a, b, c, d -> Quad(a, b, c, d) }, wanted, waking) { q, isWanted, isWaking ->
            val (loopState, forced, pc, notice) = q
            when {
                pc == null -> ConnectionState.NeedsPairing(notice)
                forced != null -> forced
                !isWanted -> ConnectionState.Disconnected
                isWaking && loopState is ConnectionState.Connected -> loopState.copy(waking = true)
                isWaking && loopState is ConnectionState.Looking -> ConnectionState.WakingPc(loopState.pcName)
                else -> loopState
            }
        }.stateIn(scope, SharingStarted.Eagerly, ConnectionState.Disconnected)

    private data class Quad(val a: ConnectionState, val b: ConnectionState?, val c: PairedPc?, val d: String?)

    override val events: SharedFlow<LinkEvent> = _events.asSharedFlow()
    override val ready: StateFlow<ReadyDto?> = _ready
    override val profile: StateFlow<LinkProfile> = _profile

    init {
        cleanUpKeys()
        scope.launch {
            combine(wanted, store.pc.map { it?.serverId }.distinctUntilChanged()) { w, id -> w to id }
                .collect { (isWanted, serverId) -> reconcile(isWanted, serverId) }
        }
        // A network change (Wi-Fi back, VPN on, mobile data) while connecting is wanted: try at once.
        scope.launch {
            binding.available.drop(1).filter { it }.collect { kickIfWaiting() }
        }
        scope.launch { environment.changes.collect { kickIfWaiting() } }
        // The route setting changed: start over with the new choice.
        scope.launch { routeMode.drop(1).collect { if (wanted.value && store.pc.value != null) loop.restart() } }
        scope.launch { traceWanted.drop(1).collect { resubscribe() } }
    }

    // ------------------------------------------------------------------ public API

    override fun connect() {
        if (state.value is ConnectionState.Failed || state.value is ConnectionState.Forgotten) return
        wanted.value = true
        if (store.pc.value == null) return
        // App opened / back on screen: start, or cut a back-off wait short.
        if (!loop.isRunning) loop.start() else kickIfWaiting()
    }

    override fun disconnect() {
        wanted.value = false
    }

    /** "Reconnect" / "Retry": clears a stopped state and tries every route at once. */
    override fun reconnect() {
        override.value = null
        wanted.value = true
        if (store.pc.value != null) {
            if (current != null) loop.restart(clearBlocked = true) else loop.kick(clearBlocked = true)
        }
    }

    override fun setProfile(profile: LinkProfile) {
        val previous = _profile.value
        _profile.value = profile
        if (previous == profile) return
        val link = current ?: return
        scope.launch {
            try {
                link.session.rpc.call("subscribe", subscribeArgs())
                if (profile == LinkProfile.FOREGROUND) _events.emit(LinkEvent.Refresh)
            } catch (_: Exception) {
                // The connection is going away; the next connection subscribes again.
            }
        }
    }

    override fun setTraceWanted(wanted: Boolean) {
        traceWanted.value = wanted
    }

    override suspend fun call(op: String, args: JsonObject, timeoutMs: Long): JsonElement {
        val link = current ?: throw RpcException.notConnected()
        return link.session.rpc.call(op, args, timeoutMs)
    }

    override fun callList(op: String, args: JsonObject, timeoutMs: Long): Flow<ListPart> = flow {
        val link = current ?: throw RpcException.notConnected()
        emitAll(link.session.rpc.callList(op, args, timeoutMs))
    }

    /** The route of the live connection (`ready.route`, or the route that won). */
    override val currentRoute: RouteKind? get() = current?.let { RouteKind.fromWire(it.ready.route) ?: it.route }

    /**
     * "Replace this device's keys" (section 4.1): a new identity key, `device.rekey` signed by both
     * keys, the new secrets stored sealed next to the old ones, then a reconnect with `slot:"next"`.
     * The old key and secrets are deleted only when that connection reached `ready` ([onWinner]).
     */
    override suspend fun replaceKeys(): RekeyOutcome = replaceKeys(REKEY_CONFIRM_MS)

    suspend fun replaceKeys(confirmTimeoutMs: Long): RekeyOutcome {
        val pc = store.pc.value ?: return RekeyOutcome.Failed("No PC is paired")
        if (current == null) return RekeyOutcome.Failed("Connect to your PC first")
        if (pc.pendingRekey != null) return RekeyOutcome.Failed("A key replacement is already in progress")
        val newAlias = identity.nextAlias()
        var result: RekeyResultDto? = null
        try {
            identity.create(newAlias)
            val newPub = identity.publicKey(newAlias)
            val message = AvekProtocol.rekeyMessage(pc.deviceId, newPub)
            val raw = call(
                "device.rekey",
                buildJsonObject {
                    put("newPub", SecureCrypto.b64(newPub))
                    put("sig", SecureCrypto.b64(identity.sign(pc.identityAlias, message)))
                    put("sigNew", SecureCrypto.b64(identity.sign(newAlias, message)))
                },
                REKEY_CALL_MS,
            )
            result = WireJson.decodeFromJsonElement(RekeyResultDto.serializer(), raw)
        } catch (e: Exception) {
            identity.delete(newAlias)
            return RekeyOutcome.Failed(if (e is RpcException) e.message ?: "The PC refused" else "Could not create the new key")
        }
        val fresh = try {
            DeviceSecrets(SecureCrypto.unb64(result!!.dk), SecureCrypto.unb64(result.rk))
        } catch (e: Exception) {
            identity.delete(newAlias)
            return RekeyOutcome.Failed("The PC sent unusable keys")
        }
        val sealed = try {
            secrets.seal(fresh)
        } finally {
            fresh.wipe()
        }
        val deadline = nowMs() + result!!.graceSec.coerceAtLeast(0) * 1000L
        store.update { it.copy(pendingRekey = PendingRekey(newAlias, sealed, deadline)) }
        loop.restart(clearBlocked = true)
        val promoted = withTimeoutOrNull(confirmTimeoutMs) {
            store.pc.first { it == null || (it.identityAlias == newAlias && it.pendingRekey == null) }
        }
        return if (promoted != null) RekeyOutcome.Done else RekeyOutcome.Pending
    }

    /**
     * "Forget this PC": tells the PC (`device.unpair`) when connected, then deletes the Keystore keys,
     * the sealing key and the stored PC. Works offline too.
     */
    override suspend fun forget() {
        val link = current
        if (link != null) {
            runCatching { withTimeoutOrNull(UNPAIR_WAIT_MS) { link.session.rpc.call("device.unpair", JsonObject(emptyMap()), UNPAIR_WAIT_MS) } }
        }
        loop.stop()
        wanted.value = false
        override.value = null
        identity.aliases().forEach { identity.delete(it) }
        runCatching { vault.destroy() }
        store.clear()
    }

    // ------------------------------------------------------------------ lifecycle

    private fun kickIfWaiting() {
        if (wanted.value && store.pc.value != null && state.value !is ConnectionState.Connected) loop.kick()
    }

    private fun reconcile(isWanted: Boolean, serverId: String?) {
        if (isWanted && serverId != null) {
            if (!bindingHeld) {
                binding.acquire()
                bindingHeld = true
            }
            if (!loop.isRunning) loop.start()
        } else {
            loop.stop()
            waking.value = false
            if (bindingHeld) {
                binding.release()
                bindingHeld = false
            }
        }
    }

    /** Keys left behind by an interrupted pairing or replacement (not the current or the pending one) are deleted. */
    private fun cleanUpKeys() {
        runCatching {
            val pc = store.pc.value
            val keep = setOfNotNull(pc?.identityAlias, pc?.pendingRekey?.alias)
            identity.aliases().filter { it !in keep }.forEach { identity.delete(it) }
        }
    }

    /**
     * The credentials to try, in order (section 4.1). Normal: the current key. During a replacement,
     * before the grace ends: the new key with `slot:"next"`, the new key alone (the PC may have promoted
     * it already), then the old key. After the grace: the old key, then the new key alone.
     */
    private fun candidates(pc: PairedPc): List<RouteCredentials> {
        val current = credentials(pc, pc.identityAlias, pc.sealedSecrets, slotNext = false)
        val pending = pc.pendingRekey ?: return listOfNotNull(current)
        if (!identity.exists(pending.alias)) {
            store.update { it.copy(pendingRekey = null) }
            return listOfNotNull(current)
        }
        val next = credentials(pc, pending.alias, pending.sealedSecrets, slotNext = true)
        val alone = credentials(pc, pending.alias, pending.sealedSecrets, slotNext = false)
        return if (nowMs() < pending.deadlineMs) listOfNotNull(next, alone, current) else listOfNotNull(current, alone)
    }

    private fun credentials(pc: PairedPc, alias: String, sealed: ByteArray, slotNext: Boolean): RouteCredentials? {
        if (!identity.exists(alias)) return null
        val opened = runCatching { secrets.open(sealed) }.getOrNull() ?: return null
        return RouteCredentials(pc.deviceId, DeviceKey(identity, alias), opened.dk, opened.rk, slotNext)
    }

    private fun attempts(pc: PairedPc, credentials: RouteCredentials): List<RouteAttempt<LiveLink>> = listOf(
        WifiRouteAttempt(pc, credentials, knock, channels, ::establish),
        TailscaleRouteAttempt(pc, credentials, knock, channels, environment, ::establish),
        NgrokRouteAttempt(pc, credentials, channels, ::establish, nowMs),
    )

    private suspend fun establish(channel: RawChannel, route: RouteKind, credentials: RouteCredentials): LiveLink {
        val pc = store.pc.value ?: throw IllegalStateException("Not paired")
        val keys = handshake.open(channel, SessionGrant(credentials.deviceId, credentials.key, pc.serverPub, credentials.dk, credentials.slotNext))
        val gate = AtomicBoolean(false)
        val session = SecureLinkSession(
            channel = channel,
            keys = keys,
            scope = scope,
            onEvent = { wire -> if (gate.get()) onWire(wire) },
            onWaking = { on -> waking.value = on },
            nowMs = nowMs,
            pingIntervalMs = pingIntervalMs,
            silenceLimitMs = silenceLimitMs,
        )
        session.start()
        val ready = try {
            session.awaitReady(readyTimeoutMs)
        } catch (e: Throwable) {
            session.close()
            throw e
        }
        return Established(session, ready, gate, route)
    }

    private fun onWinner(won: Won) {
        val established = won.link as Established
        current = established
        waking.value = false
        _ready.value = established.ready
        established.gate.set(true)

        val pc = store.pc.value
        val sameEpoch = pc?.epoch == established.ready.epoch
        lastSeq = if (sameEpoch) pc?.lastSeq ?: 0 else 0
        val remote = established.session.remote
        val usedAlias = won.credentials.key.alias
        val oldAlias = pc?.identityAlias
        var dropAlias: String? = null
        store.update {
            var next = it.copy(
                lastWifiHost = if (won.route == RouteKind.WIFI) remote.host else it.lastWifiHost,
                lastWifiPort = if (won.route == RouteKind.WIFI) remote.port else it.lastWifiPort,
                lastConnectedAt = nowMs(),
                epoch = established.ready.epoch,
                lastSeq = lastSeq,
                serverName = established.ready.server.name.ifEmpty { it.serverName },
            )
            val pending = it.pendingRekey
            if (pending != null) {
                if (usedAlias == pending.alias) {
                    // Step 5: the PC promoted the new key; the old key and secrets go.
                    next = next.copy(identityAlias = pending.alias, sealedSecrets = pending.sealedSecrets, pendingRekey = null)
                    dropAlias = oldAlias
                } else {
                    // The old key connected: the replacement is over (grace ended or refused); drop the new key.
                    next = next.copy(pendingRekey = null)
                    dropAlias = pending.alias
                }
            }
            next
        }
        dropAlias?.let { alias -> runCatching { identity.delete(alias) } }
        scope.launch { afterConnect(established, sameEpoch) }
    }

    private fun onLost(info: CloseInfo) {
        current = null
        waking.value = false
        _ready.value = null
        persistSeq(force = true)
    }

    /** `routes.get`, `resume` (when the PC is the one we left), `subscribe`, pending asks, then Refresh. */
    private suspend fun afterConnect(link: Established, sameEpoch: Boolean) {
        val rpc = link.session.rpc
        try {
            val routes = WireJson.decodeFromJsonElement(RoutesData.serializer(), rpc.call("routes.get", JsonObject(emptyMap())))
            routesSync.apply(routes)
        } catch (_: Exception) {
            // Older stored routes stay; the next connection asks again.
        }
        try {
            val resumeFrom = lastSeq
            if (sameEpoch && resumeFrom > 0) {
                val result = rpc.call(
                    "resume",
                    buildJsonObject {
                        put("epoch", link.ready.epoch)
                        put("lastSeq", resumeFrom)
                    },
                )
                // `{replayed:n}` or `{gap:true}`: either way the Refresh below makes screens correct.
                WireJson.decodeFromJsonElement(ResumeResultDto.serializer(), result)
            }
            rpc.call("subscribe", subscribeArgs())
            link.ready.pendingAsks.forEach { _events.emit(LinkEvent.AskRequest(null, it)) }
            _events.emit(LinkEvent.Refresh)
        } catch (_: Exception) {
            // The link is closing; the loop reconnects and we run again.
        }
    }

    private suspend fun resubscribe() {
        val link = current ?: return
        runCatching { link.session.rpc.call("subscribe", subscribeArgs()) }
    }

    private suspend fun onWire(wire: WireEvent) {
        wire.seq?.let { seq ->
            if (seq > lastSeq) {
                lastSeq = seq
                persistSeq(force = false)
            }
        }
        val event = EventDecoder.decode(wire) ?: return
        if (event is LinkEvent.Bye && event.reason == "revoked") {
            override.value = ConnectionState.Forgotten
            loop.stop()
        }
        if (event is LinkEvent.RoutesChanged) routesSync.apply(event.data)
        _events.emit(event)
    }

    private fun persistSeq(force: Boolean) {
        val now = nowMs()
        if (!force && now - lastPersistedAt < PERSIST_INTERVAL_MS) return
        lastPersistedAt = now
        val seq = lastSeq
        store.update { it.copy(lastSeq = seq) }
    }

    private fun subscribeArgs(): JsonObject = buildJsonObject {
        put("topics", JsonArray(_profile.value.topics(traceWanted.value).map { JsonPrimitive(it) }))
    }

    companion object {
        const val READY_TIMEOUT_MS = 10_000L
        const val REKEY_CALL_MS = 15_000L
        const val REKEY_CONFIRM_MS = 30_000L
        const val UNPAIR_WAIT_MS = 5_000L
        private const val EVENT_BUFFER = 8192
        private const val PERSIST_INTERVAL_MS = 3_000L
    }
}
