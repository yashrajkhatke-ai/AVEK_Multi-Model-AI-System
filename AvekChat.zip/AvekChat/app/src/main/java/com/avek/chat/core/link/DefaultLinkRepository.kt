package com.avek.chat.core.link

import com.avek.chat.core.link.crypto.Handshake
import com.avek.chat.core.link.route.AutoConnect
import com.avek.chat.core.link.route.ConnectionState
import com.avek.chat.core.link.route.Reached
import com.avek.chat.core.link.route.Route
import com.avek.chat.core.link.rpc.CloseInfo
import com.avek.chat.core.link.rpc.ListPart
import com.avek.chat.core.link.rpc.LiveLink
import com.avek.chat.core.link.rpc.RpcException
import com.avek.chat.core.link.rpc.RpcTimeouts
import com.avek.chat.core.link.rpc.SecureLinkSession
import com.avek.chat.core.link.store.IdentityVault
import com.avek.chat.core.link.store.PairedPcStore
import com.avek.chat.core.link.transport.RawChannel
import com.avek.chat.core.link.transport.WifiBinding
import com.avek.chat.core.link.wire.EventDecoder
import com.avek.chat.core.link.wire.LinkEvent
import com.avek.chat.core.link.wire.ReadyDto
import com.avek.chat.core.link.wire.ResumeResultDto
import com.avek.chat.core.link.wire.WireEvent
import com.avek.chat.core.link.wire.WireJson
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import java.util.concurrent.atomic.AtomicBoolean

/**
 * The real link (UI-WIRE v3): the pinned PC + the Keystore identity + the auto-connect loop
 * (knock, WebSocket, AVEK-SEC/2 session). After every connection it resumes (when the epoch
 * matches) and then subscribes, persists `epoch` / `lastSeq`, and turns wire events into [LinkEvent]s.
 */
class DefaultLinkRepository(
    private val store: PairedPcStore,
    private val identity: IdentityVault,
    private val route: Route,
    private val binding: WifiBinding,
    private val handshake: Handshake,
    private val scope: CoroutineScope,
    private val nowMs: () -> Long = System::currentTimeMillis,
    private val readyTimeoutMs: Long = READY_TIMEOUT_MS,
    private val backoffMs: List<Long> = AutoConnect.BACKOFF_MS,
    private val attemptTimeoutMs: Long = AutoConnect.ATTEMPT_TIMEOUT_MS,
    private val pingIntervalMs: Long = SecureLinkSession.PING_INTERVAL_MS,
    private val silenceLimitMs: Long = SecureLinkSession.SILENCE_LIMIT_MS,
) : LinkRepository {

    /** A verified link that is waiting to be handed over (events stay muted until [gate] opens). */
    private class Established(
        val session: SecureLinkSession,
        val ready: ReadyDto,
        val gate: AtomicBoolean,
    ) : LiveLink by session

    private val wanted = MutableStateFlow(false)
    private val override = MutableStateFlow<ConnectionState?>(null)
    private val _events = MutableSharedFlow<LinkEvent>(extraBufferCapacity = EVENT_BUFFER)
    private val _ready = MutableStateFlow<ReadyDto?>(null)
    private val _profile = MutableStateFlow(LinkProfile.FOREGROUND)
    private val traceWanted = MutableStateFlow(false)

    @Volatile
    private var current: Established? = null

    @Volatile
    private var lastSeq = 0L

    @Volatile
    private var lastPersistedAt = 0L

    private var bindingHeld = false

    private val loop = AutoConnect(
        scope = scope,
        route = { route },
        pc = { store.pc.value },
        establish = ::establish,
        onWinner = ::onWinner,
        onLost = ::onLost,
        nowMs = nowMs,
        backoffMs = backoffMs,
        attemptTimeoutMs = attemptTimeoutMs,
    )

    override val state: StateFlow<ConnectionState> =
        combine(loop.state, override, store.pc, store.notice, wanted) { loopState, forced, pc, notice, isWanted ->
            when {
                pc == null -> ConnectionState.NeedsPairing(notice)
                forced != null -> forced
                !isWanted -> ConnectionState.Disconnected
                else -> loopState
            }
        }.stateIn(scope, SharingStarted.Eagerly, ConnectionState.Disconnected)

    override val events: SharedFlow<LinkEvent> = _events.asSharedFlow()
    override val ready: StateFlow<ReadyDto?> = _ready
    override val profile: StateFlow<LinkProfile> = _profile

    init {
        scope.launch {
            combine(wanted, store.pc.map { it?.serverId }.distinctUntilChanged()) { w, id -> w to id }
                .collect { (isWanted, serverId) -> reconcile(isWanted, serverId) }
        }
        // A Wi-Fi network became available while connecting is wanted: try at once.
        scope.launch {
            binding.available.drop(1).filter { it }.collect {
                if (wanted.value && state.value !is ConnectionState.Connected) loop.kick()
            }
        }
        scope.launch { traceWanted.drop(1).collect { resubscribe() } }
    }

    // ------------------------------------------------------------------ public API

    override fun connect() {
        if (state.value is ConnectionState.Failed || state.value is ConnectionState.Forgotten) return
        wanted.value = true
        if (store.pc.value == null) return
        // App opened / back on screen: start, or cut a back-off wait short.
        if (!loop.isRunning) loop.start() else if (state.value !is ConnectionState.Connected) loop.kick()
    }

    override fun disconnect() {
        wanted.value = false
    }

    /** The "Reconnect" button (and pairing): clears a stopped state and tries at once. */
    override fun reconnect() {
        override.value = null
        wanted.value = true
        if (store.pc.value != null) {
            if (current != null) loop.restart() else loop.kick()
        }
    }

    override fun setProfile(profile: LinkProfile) {
        val previous = _profile.value
        _profile.value = profile
        if (previous == profile) return
        val link = current ?: return
        scope.launch {
            try {
                link.session.rpc.call("subscribe", subscribeArgs())
                if (profile == LinkProfile.FOREGROUND) _events.emit(LinkEvent.Refresh)
            } catch (_: Exception) {
                // The connection is going away; the next connection subscribes again.
            }
        }
    }

    override fun setTraceWanted(wanted: Boolean) {
        traceWanted.value = wanted
    }

    override suspend fun call(op: String, args: JsonObject, timeoutMs: Long): JsonElement {
        val link = current ?: throw RpcException.notConnected()
        return link.session.rpc.call(op, args, timeoutMs)
    }

    override fun callList(op: String, args: JsonObject, timeoutMs: Long): Flow<ListPart> = flow {
        val link = current ?: throw RpcException.notConnected()
        emitAll(link.session.rpc.callList(op, args, timeoutMs))
    }

    // ------------------------------------------------------------------ lifecycle

    private fun reconcile(isWanted: Boolean, serverId: String?) {
        if (isWanted && serverId != null) {
            if (!bindingHeld) {
                binding.acquire()
                bindingHeld = true
            }
            if (!loop.isRunning) loop.start()
        } else {
            loop.stop()
            if (bindingHeld) {
                binding.release()
                bindingHeld = false
            }
        }
    }

    private suspend fun establish(channel: RawChannel): LiveLink {
        val pc = store.pc.value ?: throw IllegalStateException("Not paired")
        val keys = handshake.session(channel, identity, pc.serverPub)
        val gate = AtomicBoolean(false)
        val session = SecureLinkSession(
            channel = channel,
            keys = keys,
            scope = scope,
            onEvent = { wire -> if (gate.get()) onWire(wire) },
            nowMs = nowMs,
            pingIntervalMs = pingIntervalMs,
            silenceLimitMs = silenceLimitMs,
        )
        session.start()
        val ready = try {
            session.awaitReady(readyTimeoutMs)
        } catch (e: Throwable) {
            session.close()
            throw e
        }
        return Established(session, ready, gate)
    }

    private fun onWinner(link: LiveLink, reached: Reached) {
        val established = link as Established
        current = established
        _ready.value = established.ready
        established.gate.set(true)

        val sameEpoch = store.pc.value?.epoch == established.ready.epoch
        lastSeq = if (sameEpoch) store.pc.value?.lastSeq ?: 0 else 0
        val host = reached.address.substringBeforeLast(':')
        val port = reached.address.substringAfterLast(':').toIntOrNull() ?: established.session.remote.port
        store.update {
            it.copy(
                lastHost = host,
                lastPort = port,
                epoch = established.ready.epoch,
                lastSeq = lastSeq,
                serverName = established.ready.server.name.ifEmpty { it.serverName },
            )
        }
        scope.launch { afterConnect(established, sameEpoch) }
    }

    private fun onLost(info: CloseInfo) {
        current = null
        _ready.value = null
        persistSeq(force = true)
    }

    /** Resume first (when the PC is the one we left), then subscribe, hand over pending asks, tell screens to refresh. */
    private suspend fun afterConnect(link: Established, sameEpoch: Boolean) {
        try {
            val rpc = link.session.rpc
            val resumeFrom = lastSeq
            if (sameEpoch && resumeFrom > 0) {
                val result = rpc.call(
                    "resume",
                    buildJsonObject {
                        put("epoch", link.ready.epoch)
                        put("lastSeq", resumeFrom)
                    },
                )
                // `{replayed:n}` or `{gap:true}`: either way the Refresh below makes screens correct.
                WireJson.decodeFromJsonElement(ResumeResultDto.serializer(), result)
            }
            rpc.call("subscribe", subscribeArgs())
            link.ready.pendingAsks.forEach { _events.emit(LinkEvent.AskRequest(null, it)) }
            _events.emit(LinkEvent.Refresh)
        } catch (_: Exception) {
            // The link is closing; the loop reconnects and we run again.
        }
    }

    private suspend fun resubscribe() {
        val link = current ?: return
        runCatching { link.session.rpc.call("subscribe", subscribeArgs()) }
    }

    private suspend fun onWire(wire: WireEvent) {
        wire.seq?.let { seq ->
            if (seq > lastSeq) {
                lastSeq = seq
                persistSeq(force = false)
            }
        }
        val event = EventDecoder.decode(wire) ?: return
        if (event is LinkEvent.Bye && event.reason == "revoked") {
            override.value = ConnectionState.Forgotten
            loop.stop()
        }
        _events.emit(event)
    }

    private fun persistSeq(force: Boolean) {
        val now = nowMs()
        if (!force && now - lastPersistedAt < PERSIST_INTERVAL_MS) return
        lastPersistedAt = now
        val seq = lastSeq
        store.update { it.copy(lastSeq = seq) }
    }

    private fun subscribeArgs(): JsonObject = buildJsonObject {
        put("topics", JsonArray(_profile.value.topics(traceWanted.value).map { JsonPrimitive(it) }))
    }

    companion object {
        const val READY_TIMEOUT_MS = 10_000L
        private const val EVENT_BUFFER = 8192
        private const val PERSIST_INTERVAL_MS = 3_000L
    }
}
