package com.avek.chat.core.link

import com.avek.chat.core.link.crypto.Handshake
import com.avek.chat.core.link.crypto.HandshakeException
import com.avek.chat.core.link.route.ConnectionState
import com.avek.chat.core.link.route.Route
import com.avek.chat.core.link.route.RouteFactory
import com.avek.chat.core.link.route.RouteManager
import com.avek.chat.core.link.rpc.CloseInfo
import com.avek.chat.core.link.rpc.LinkClosedException
import com.avek.chat.core.link.rpc.ListPart
import com.avek.chat.core.link.rpc.LiveLink
import com.avek.chat.core.link.rpc.RpcException
import com.avek.chat.core.link.rpc.RpcTimeouts
import com.avek.chat.core.link.rpc.SecureLinkSession
import com.avek.chat.core.link.store.PairedPcStore
import com.avek.chat.core.link.transport.RawChannel
import com.avek.chat.core.link.transport.WifiBinding
import com.avek.chat.core.link.wire.EventDecoder
import com.avek.chat.core.link.wire.LinkEvent
import com.avek.chat.core.link.wire.ReadyDto
import com.avek.chat.core.link.wire.ResumeResultDto
import com.avek.chat.core.link.wire.WireEvent
import com.avek.chat.core.link.wire.WireJson
import com.avek.chat.core.model.settings.RouteSpec
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import java.util.concurrent.atomic.AtomicBoolean

/**
 * The real link: pairing storage + routes + AVEK-SEC/1 session.
 * Connects with [RouteManager], subscribes (and resumes) after every connection,
 * persists `epoch` / `lastSeq`, and turns wire events into [LinkEvent]s.
 */
class DefaultLinkRepository(
    private val store: PairedPcStore,
    private val routeSpecs: () -> List<RouteSpec>,
    private val routeFactory: RouteFactory,
    private val binding: WifiBinding,
    private val handshake: Handshake,
    private val scope: CoroutineScope,
    private val nowMs: () -> Long = System::currentTimeMillis,
    private val readyTimeoutMs: Long = READY_TIMEOUT_MS,
    private val staggerMs: Long = RouteManager.STAGGER_MS,
    private val attemptTimeoutMs: Long = RouteManager.ATTEMPT_TIMEOUT_MS,
    private val backoffMs: List<Long> = RouteManager.BACKOFF_MS,
    private val pingIntervalMs: Long = SecureLinkSession.PING_INTERVAL_MS,
    private val silenceLimitMs: Long = SecureLinkSession.SILENCE_LIMIT_MS,
) : LinkRepository {

    /** A verified link that is waiting to win the race (events stay muted until [gate] opens). */
    private class Established(
        val session: SecureLinkSession,
        val ready: ReadyDto,
        val gate: AtomicBoolean,
    ) : LiveLink by session

    private val wanted = MutableStateFlow(false)
    private val override = MutableStateFlow<ConnectionState?>(null)
    private val _events = MutableSharedFlow<LinkEvent>(extraBufferCapacity = EVENT_BUFFER)
    private val _ready = MutableStateFlow<ReadyDto?>(null)
    private val _profile = MutableStateFlow(LinkProfile.FOREGROUND)

    @Volatile
    private var current: Established? = null

    @Volatile
    private var lastSeq = 0L

    @Volatile
    private var lastPersistedAt = 0L

    private var bindingHeld = false
    private var runningIdentity: Pair<String?, String?>? = null

    private val manager = RouteManager(
        scope = scope,
        routes = ::buildRoutes,
        establish = ::establish,
        onWinner = ::onWinner,
        onLost = ::onLost,
        fatalReason = ::fatalReason,
        staggerMs = staggerMs,
        attemptTimeoutMs = attemptTimeoutMs,
        backoffMs = backoffMs,
    )

    override val state: StateFlow<ConnectionState> =
        combine(manager.state, override, store.pc, wanted) { managerState, forced, pc, isWanted ->
            when {
                forced != null && isWanted -> forced
                !isWanted -> ConnectionState.Disconnected
                pc == null -> ConnectionState.NotPaired
                else -> managerState
            }
        }.stateIn(scope, SharingStarted.Eagerly, ConnectionState.Disconnected)

    override val events: SharedFlow<LinkEvent> = _events.asSharedFlow()
    override val ready: StateFlow<ReadyDto?> = _ready
    override val profile: StateFlow<LinkProfile> = _profile

    init {
        scope.launch {
            combine(wanted, store.pc.map { it?.deviceId to it?.serverId }.distinctUntilChanged()) { w, id -> w to id }
                .collect { (isWanted, identity) -> reconcile(isWanted, identity) }
        }
    }

    // ------------------------------------------------------------------ public API

    override fun connect() {
        override.value = null
        wanted.value = true
    }

    override fun disconnect() {
        wanted.value = false
    }

    override fun reconnect() {
        override.value = null
        if (wanted.value && store.pc.value != null) manager.restart() else wanted.value = true
    }

    override fun setProfile(profile: LinkProfile) {
        val previous = _profile.value
        _profile.value = profile
        if (previous == profile) return
        val link = current ?: return
        scope.launch {
            try {
                link.session.rpc.call("subscribe", subscribeArgs(profile))
                if (profile == LinkProfile.FOREGROUND) _events.emit(LinkEvent.Refresh)
            } catch (_: Exception) {
                // The connection is going away; the next connection subscribes again.
            }
        }
    }

    override suspend fun call(op: String, args: JsonObject, timeoutMs: Long): JsonElement {
        val link = current ?: throw RpcException.notConnected()
        return link.session.rpc.call(op, args, timeoutMs)
    }

    override fun callList(op: String, args: JsonObject, timeoutMs: Long): Flow<ListPart> = flow {
        val link = current ?: throw RpcException.notConnected()
        emitAll(link.session.rpc.callList(op, args, timeoutMs))
    }

    // ------------------------------------------------------------------ lifecycle

    private fun reconcile(isWanted: Boolean, identity: Pair<String?, String?>) {
        val shouldRun = isWanted && identity.first != null
        if (shouldRun) {
            if (!bindingHeld) {
                binding.acquire()
                bindingHeld = true
            }
            if (runningIdentity != null && runningIdentity != identity) manager.restart() else manager.start()
            runningIdentity = identity
        } else {
            manager.stop()
            runningIdentity = null
            if (bindingHeld) {
                binding.release()
                bindingHeld = false
            }
        }
    }

    private fun buildRoutes(): List<Route> {
        val pc = store.pc.value ?: return emptyList()
        return routeFactory.build(routeSpecs(), pc) { store.pc.value }
    }

    private suspend fun establish(channel: RawChannel, route: Route): LiveLink {
        val pc = store.pc.value ?: throw IllegalStateException("Not paired")
        val keys = handshake.session(channel, pc.deviceId, pc.deviceSecret)
        val gate = AtomicBoolean(false)
        val session = SecureLinkSession(
            channel = channel,
            keys = keys,
            scope = scope,
            onEvent = { wire -> if (gate.get()) onWire(wire) },
            nowMs = nowMs,
            pingIntervalMs = pingIntervalMs,
            silenceLimitMs = silenceLimitMs,
        )
        session.start()
        val ready = try {
            session.awaitReady(readyTimeoutMs)
        } catch (e: Throwable) {
            session.close()
            throw e
        }
        return Established(session, ready, gate)
    }

    private fun onWinner(link: LiveLink, route: Route) {
        val established = link as Established
        current = established
        _ready.value = established.ready
        established.gate.set(true)

        val sameEpoch = store.pc.value?.epoch == established.ready.epoch
        lastSeq = if (sameEpoch) store.pc.value?.lastSeq ?: 0 else 0
        store.update {
            it.copy(
                lastHost = established.session.remote.host,
                lastPort = established.session.remote.port,
                epoch = established.ready.epoch,
                lastSeq = lastSeq,
                serverName = established.ready.server.name.ifEmpty { it.serverName },
            )
        }
        scope.launch { afterConnect(established, sameEpoch) }
    }

    private fun onLost(info: CloseInfo) {
        current = null
        _ready.value = null
        persistSeq(force = true)
    }

    /** Subscribe, resume if the harness is the same one we left, hand over pending asks, tell screens to refresh. */
    private suspend fun afterConnect(link: Established, sameEpoch: Boolean) {
        try {
            val rpc = link.session.rpc
            rpc.call("subscribe", subscribeArgs(_profile.value))
            val resumeFrom = lastSeq
            if (sameEpoch && resumeFrom > 0) {
                val result = rpc.call(
                    "resume",
                    buildJsonObject {
                        put("epoch", link.ready.epoch)
                        put("lastSeq", resumeFrom)
                    },
                )
                // `{replayed:n}` or `{gap:true}`: either way the Refresh below makes screens correct.
                WireJson.decodeFromJsonElement(ResumeResultDto.serializer(), result)
            }
            link.ready.pendingAsks.forEach { _events.emit(LinkEvent.AskRequest(null, it)) }
            _events.emit(LinkEvent.Refresh)
        } catch (_: Exception) {
            // The link is closing; RouteManager reconnects and we run again.
        }
    }

    private suspend fun onWire(wire: WireEvent) {
        wire.seq?.let { seq ->
            if (seq > lastSeq) {
                lastSeq = seq
                persistSeq(force = false)
            }
        }
        val event = EventDecoder.decode(wire) ?: return
        if (event is LinkEvent.Bye && event.reason == "revoked") {
            override.value = ConnectionState.Failed("This device was revoked on the PC. Pair again.")
            manager.stop()
        }
        _events.emit(event)
    }

    private fun persistSeq(force: Boolean) {
        val now = nowMs()
        if (!force && now - lastPersistedAt < PERSIST_INTERVAL_MS) return
        lastPersistedAt = now
        val seq = lastSeq
        store.update { it.copy(lastSeq = seq) }
    }

    private fun fatalReason(error: Throwable): String? = when {
        error is HandshakeException.Denied && error.reason in FATAL_DENIALS ->
            if (error.reason == "revoked") "This device was revoked on the PC. Pair again." else "The PC does not know this device. Pair again."
        error is HandshakeException.ClosedByPeer && error.code == 4401 -> "Not authorised by the PC. Pair again."
        error is LinkClosedException && error.info.isAuthFailure -> "Not authorised by the PC. Pair again."
        else -> null
    }

    private fun subscribeArgs(profile: LinkProfile): JsonObject = buildJsonObject {
        put("topics", JsonArray(profile.topics.map { JsonPrimitive(it) }))
    }

    companion object {
        const val READY_TIMEOUT_MS = 10_000L
        private const val EVENT_BUFFER = 4096
        private const val PERSIST_INTERVAL_MS = 3_000L
        private val FATAL_DENIALS = setOf("unknown-device", "revoked")
    }
}
