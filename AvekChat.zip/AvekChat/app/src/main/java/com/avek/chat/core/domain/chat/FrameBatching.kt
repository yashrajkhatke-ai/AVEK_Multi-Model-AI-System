package com.avek.chat.core.domain.chat

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.conflate
import kotlinx.coroutines.flow.transform

/** Suspends until the next display frame (Choreographer on Android, a fixed 16 ms tick elsewhere). */
fun interface FrameClock {
    suspend fun awaitFrame()
}

/**
 * Publishes at most one value per frame (UI-WIRE v3 section 9: render at most once per frame).
 * Every value carries the whole text received so far, so the values skipped between two frames
 * lose nothing: the next one published contains them. The last value is always delivered.
 */
fun <T> Flow<T>.oncePerFrame(clock: FrameClock): Flow<T> = conflate().transform {
    emit(it)
    clock.awaitFrame()
}
