package com.avek.chat.feature.chat.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.avek.chat.core.designsystem.component.fadingEdges
import com.avek.chat.core.designsystem.motion.entrance
import com.avek.chat.core.designsystem.theme.AvekTheme
import com.avek.chat.core.domain.chat.StreamingReply
import com.avek.chat.feature.chat.ChatViewModel
import com.avek.chat.feature.chat.ToolViewState
import androidx.compose.material3.CircularProgressIndicator
import com.avek.chat.core.model.Message
import com.avek.chat.core.model.settings.UserAlignment
import kotlinx.coroutines.launch

private const val BOTTOM_ANCHOR = "bottom-anchor"

/**
 * The conversation transcript. Follows the stream while you're at the bottom,
 * stops following as soon as you scroll up, and offers a jump-to-latest button.
 */
@Composable
fun MessageList(
    conversationId: String?,
    messages: List<Message>,
    streaming: StreamingReply?,
    modelNameFor: (String?) -> String?,
    isGenerating: Boolean,
    sessionStartedAt: Long,
    actions: MessageActions,
    toolViews: Map<String, ToolViewState>,
    thinkingLoading: Set<String>,
    loadingOlder: Boolean,
    onNearTop: () -> Unit,
    modifier: Modifier = Modifier,
    topInset: Dp = 0.dp,
) {
    val listState = rememberLazyListState()
    val scope = androidx.compose.runtime.rememberCoroutineScope()
    var stickToBottom by remember(conversationId) { mutableStateOf(true) }
    // One extra row at the top while older turns are loading.
    val headerRows = if (loadingOlder) 1 else 0
    val anchorIndex = messages.size + headerRows
    val motion = AvekTheme.motion

    // Track whether the user has scrolled away from the bottom.
    LaunchedEffect(listState) {
        snapshotFlow { listState.isScrollInProgress to listState.canScrollForward }
            .collect { (scrolling, canScrollForward) ->
                if (!canScrollForward) {
                    stickToBottom = true
                } else if (scrolling && listState.lastScrolledBackward) {
                    stickToBottom = false
                }
            }
    }

    // Jump to the end when a conversation opens.
    LaunchedEffect(conversationId, messages.isNotEmpty()) {
        if (messages.isNotEmpty()) listState.scrollToItem(messages.size)
    }

    // Older turns are added above: the list keeps what the person is looking at (items have stable keys).
    // The 4th-oldest loaded turn coming into view asks for the next page of 20.
    LaunchedEffect(listState) {
        snapshotFlow { listState.firstVisibleItemIndex }
            .collect { first -> if (first <= ChatViewModel.OLDER_TRIGGER_INDEX + headerRows) onNearTop() }
    }

    // Follow new content while pinned to the bottom (only the newest message counts, not older pages).
    val contentSignal = streaming?.let {
        it.message.content.length + (it.message.thinking?.length ?: 0) + it.message.sources.size + it.message.tools.size
    } ?: 0
    LaunchedEffect(messages.lastOrNull()?.uiKey, contentSignal) {
        if (stickToBottom && messages.isNotEmpty()) listState.scrollToItem(messages.size + (if (loadingOlder) 1 else 0))
    }

    val showJump by remember { derivedStateOf { listState.canScrollForward && !stickToBottom } }
    val lastUserId = messages.lastOrNull { it.isUser }?.id
    val lastAssistantId = messages.lastOrNull { !it.isUser }?.id
    val atEnd = AvekTheme.layout.userAlignment == UserAlignment.END

    Box(modifier) {
        LazyColumn(
            state = listState,
            contentPadding = PaddingValues(top = topInset + 20.dp, bottom = 20.dp),
            // Messages scroll up under the transparent top bar and dissolve into the background.
            modifier = Modifier
                .fillMaxSize()
                .fadingEdges(topHidden = topInset * 0.85f, topFade = 36.dp, bottomFade = 20.dp),
        ) {
            if (loadingOlder) {
                item(key = "loading-older") {
                    androidx.compose.foundation.layout.Box(Modifier.fillMaxWidth().padding(8.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(Modifier.size(20.dp), color = AvekTheme.colors.textTertiary, strokeWidth = 2.dp)
                    }
                }
            }
            items(messages, key = { it.uiKey }, contentType = { it.role }) { message ->
                val isNew = message.createdAt >= sessionStartedAt
                if (message.isUser) {
                    UserMessage(
                        message = message,
                        canEdit = message.id == lastUserId && !isGenerating,
                        actions = actions,
                        modifier = Modifier
                            .animateItem()
                            .entrance(motion.entrance, enabled = isNew && !motion.reduceMotion, fromEnd = atEnd),
                    )
                } else {
                    AssistantMessage(
                        message = message,
                        modelName = modelNameFor(message.modelId),
                        live = streaming?.takeIf { it.message.id == message.id },
                        isLast = message.id == lastAssistantId && !isGenerating,
                        actions = actions,
                        toolViews = toolViews,
                        thinkingLoading = message.id in thinkingLoading,
                        modifier = Modifier
                            .animateItem()
                            .entrance(motion.entrance, enabled = isNew && !motion.reduceMotion),
                    )
                }
            }
            item(key = BOTTOM_ANCHOR) { Spacer(Modifier.height(1.dp)) }
        }

        AnimatedVisibility(
            visible = showJump,
            enter = fadeIn() + scaleIn(),
            exit = fadeOut() + scaleOut(),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 12.dp),
        ) {
            val colors = AvekTheme.colors
            Box(
                Modifier
                    .size(40.dp)
                    .shadow(6.dp, CircleShape)
                    .clip(CircleShape)
                    .background(colors.surface)
                    .border(1.dp, colors.outline, CircleShape)
                    .clickable {
                        stickToBottom = true
                        scope.launch { listState.animateScrollToItem(anchorIndex) }
                    },
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Filled.ArrowDownward, contentDescription = "Jump to latest", tint = colors.textPrimary, modifier = Modifier.size(20.dp))
            }
        }
    }
}
