package com.avek.chat.core.domain.lists

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.concurrent.CopyOnWriteArrayList

/**
 * The countdown of UI-WIRE section 13 ("Memory of lists"). Loaded pages stay in memory while a view
 * (the sidebar, the model sheet) is in use. When it closes a countdown starts; reopening cancels it;
 * at zero [onExpire] drops everything. [trim] drops at once (low-memory signals).
 */
class ListMemoryController(
    private val scope: CoroutineScope,
    private val keepSeconds: () -> Int,
    private val onExpire: () -> Unit,
) {
    private var countdown: Job? = null

    /** True between [inUse] and [idle]: the view is showing the pages. */
    @Volatile
    var isActive: Boolean = false
        private set

    /** The view opened: cancel any countdown. */
    @Synchronized
    fun inUse() {
        isActive = true
        countdown?.cancel()
        countdown = null
    }

    /** The view closed: (re)start the countdown. */
    @Synchronized
    fun idle() {
        isActive = false
        countdown?.cancel()
        val seconds = keepSeconds().coerceIn(MIN_SECONDS, MAX_SECONDS)
        countdown = scope.launch {
            delay(seconds * 1000L)
            onExpire()
        }
    }

    @Synchronized
    fun trim() {
        countdown?.cancel()
        countdown = null
        onExpire()
    }

    companion object {
        const val MIN_SECONDS = 30
        const val MAX_SECONDS = 600
    }
}

/** All list memories of the app, so `onTrimMemory` can clear them together. */
class ListMemoryRegistry {
    private val controllers = CopyOnWriteArrayList<ListMemoryController>()

    fun register(controller: ListMemoryController) {
        controllers += controller
    }

    fun trimAll() = controllers.forEach { it.trim() }
}
