package com.avek.chat.core.data.link

import com.avek.chat.core.common.TimeProvider
import com.avek.chat.core.data.downloads.DemoIds
import com.avek.chat.core.data.fake.ResponseComposer
import com.avek.chat.core.domain.engine.GenerationEvent
import com.avek.chat.core.domain.engine.GenerationRequest
import com.avek.chat.core.domain.engine.InferenceEngine
import com.avek.chat.core.domain.usecase.TaskClassifier
import com.avek.chat.core.domain.usecase.TitleGenerator
import com.avek.chat.core.link.LinkProfile
import com.avek.chat.core.link.LinkRepository
import com.avek.chat.core.link.route.ConnectionState
import com.avek.chat.core.link.rpc.ListPart
import com.avek.chat.core.link.rpc.RpcException
import com.avek.chat.core.link.wire.AskRequestDto
import com.avek.chat.core.link.wire.AssistantPartDto
import com.avek.chat.core.link.wire.AttachBeginResultDto
import com.avek.chat.core.link.wire.AttachEndResultDto
import com.avek.chat.core.link.wire.AttachmentInfoDto
import com.avek.chat.core.link.wire.ChatDeletedDto
import com.avek.chat.core.link.wire.ChatEventDto
import com.avek.chat.core.link.wire.ChatGetPartDto
import com.avek.chat.core.link.wire.ChatListPartDto
import com.avek.chat.core.link.wire.ChatResultDto
import com.avek.chat.core.link.wire.ChatSummaryDto
import com.avek.chat.core.link.wire.DeltaDto
import com.avek.chat.core.link.wire.DownloadStatusItemDto
import com.avek.chat.core.link.wire.DownloadTurnDto
import com.avek.chat.core.link.wire.DownloadsSetResultDto
import com.avek.chat.core.link.wire.DownloadsStatusResultDto
import com.avek.chat.core.link.wire.ErrorCodes
import com.avek.chat.core.link.wire.LimitsDto
import com.avek.chat.core.link.wire.LinkEvent
import com.avek.chat.core.link.wire.ModelDto
import com.avek.chat.core.link.wire.ModelListPartDto
import com.avek.chat.core.link.wire.PromptAckDto
import com.avek.chat.core.link.wire.ReadyDto
import com.avek.chat.core.link.wire.RewindResultDto
import com.avek.chat.core.link.wire.ServerInfoDto
import com.avek.chat.core.link.wire.SourceDto
import com.avek.chat.core.link.wire.SourcesEventDto
import com.avek.chat.core.link.wire.StatusDto
import com.avek.chat.core.link.wire.ThinkingDto
import com.avek.chat.core.link.wire.ToolCallEventDto
import com.avek.chat.core.link.wire.ToolDto
import com.avek.chat.core.link.wire.ToolGetDto
import com.avek.chat.core.link.wire.ToolResultEventDto
import com.avek.chat.core.link.wire.TurnCompletedDto
import com.avek.chat.core.link.wire.TurnEndedDto
import com.avek.chat.core.link.wire.TurnFailedDto
import com.avek.chat.core.link.wire.TurnGetDto
import com.avek.chat.core.link.wire.TurnStartedDto
import com.avek.chat.core.link.wire.TurnViewDto
import com.avek.chat.core.link.wire.ToolViewDto
import com.avek.chat.core.link.wire.UserPartDto
import com.avek.chat.core.link.wire.WireJson
import com.avek.chat.core.model.TaskMode
import com.avek.chat.core.model.ThinkingDepth
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.KSerializer
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import java.time.Instant

/**
 * "Demo mode": a tiny in-process stand-in for the harness that speaks the same operations and
 * emits the same events, so every screen works without a PC. It reuses the scripted
 * [InferenceEngine]; chats live in memory only.
 */
class DemoLinkRepository(
    private val engine: InferenceEngine,
    private val composer: ResponseComposer,
    private val classifier: TaskClassifier,
    private val titles: TitleGenerator,
    private val time: TimeProvider,
    private val scope: CoroutineScope,
) : LinkRepository {

    private class DemoTool(val dto: ToolDto, val view: ToolViewDto)

    private class DemoTurn(
        val promptId: String,
        val createdAt: Long,
        var status: String,
        val modelId: String,
        val mode: String,
        val depth: Int,
        val userText: String,
        val attachments: List<AttachmentInfoDto>,
    ) {
        val answer = StringBuilder()
        val thinking = StringBuilder()
        var thinkingMs = 0L
        val tools = mutableListOf<DemoTool>()
        var sources: List<SourceDto> = emptyList()
        var error: String? = null
        var feedback = "none"
        var job: Job? = null
    }

    private class DemoChat(
        val id: String,
        var title: String,
        val createdAt: Long,
        var updatedAt: Long,
        var modelId: String?,
        var mode: String,
        var starred: Boolean = false,
        var archived: Boolean = false,
    ) {
        val turns = mutableListOf<DemoTurn>()
    }

    private val lock = Any()
    private val chats = LinkedHashMap<String, DemoChat>()
    private val downloads = mutableSetOf<String>()
    private val asks = HashMap<String, CompletableDeferred<String>>()
    private val uploads = HashMap<String, Triple<String, String, Long>>()
    private val attachments = HashMap<String, AttachmentInfoDto>()
    private var seeded = false
    private var chatCounter = 0
    private var promptCounter = 0
    private var uploadCounter = 0
    private var askCounter = 0
    private var seq = 0L

    private val models = listOf(
        ModelDto("demo-atlas", "Atlas 4", "text", "Simulated · most capable", 524_288, 1),
        ModelDto("demo-nova", "Nova 4", "text", "Simulated · fast and smart", 204_800, 2),
        ModelDto("demo-lumen", "Lumen 1", "vision", "Simulated · understands images", 131_072, 3),
        ModelDto("demo-forge", "Forge 2", "text", "Simulated · code specialist", 262_144, 4),
        ModelDto("demo-sage", "Sage 2", "text", "Simulated · long research", 1_048_576, 5),
        ModelDto("demo-muse", "Muse 3", "text", "Simulated · creative writing", 204_800, 6),
        ModelDto("demo-flash", "Flash 3.5", "text", "Simulated · fastest", 131_072, 7),
    )

    private val _events = MutableSharedFlow<LinkEvent>(extraBufferCapacity = 1024)
    override val events: SharedFlow<LinkEvent> = _events.asSharedFlow()
    override val state: StateFlow<ConnectionState> = MutableStateFlow(ConnectionState.Connected("demo", "Demo PC"))
    override val ready: StateFlow<ReadyDto?> = MutableStateFlow(
        ReadyDto(
            server = ServerInfoDto("s_demo", "Demo PC", "demo"),
            epoch = "e_demo",
            limits = LimitsDto(),
        ),
    )
    private val _profile = MutableStateFlow(LinkProfile.FOREGROUND)
    override val profile: StateFlow<LinkProfile> = _profile

    override fun connect() = Unit
    override fun disconnect() = Unit
    override fun setProfile(profile: LinkProfile) {
        _profile.value = profile
    }

    // ------------------------------------------------------------------ requests

    override suspend fun call(op: String, args: JsonObject, timeoutMs: Long): JsonElement {
        ensureSeeded()
        delay(LATENCY_MS)
        return when (op) {
            "ping" -> buildJsonObject { put("t", Instant.ofEpochMilli(time.now()).toString()) }
            "subscribe" -> buildJsonObject { put("topics", args["topics"] ?: JsonArray(emptyList())) }
            "resume" -> buildJsonObject { put("gap", true) }
            "models.list" -> modelsPart(args).first()
            "chats.list" -> chatsParts(args, singlePart = true).first().raw
            "chat.get" -> chatGetParts(args, singlePart = true).first().raw
            "turn.get" -> turnGet(args)
            "tool.get" -> toolGet(args)
            "chat.set" -> chatSet(args)
            "chat.delete" -> chatDelete(args)
            "chat.rewind" -> chatRewind(args)
            "turn.feedback" -> turnFeedback(args)
            "prompt" -> prompt(args)
            "turn.cancel" -> turnCancel(args)
            "ask.answer" -> askAnswer(args)
            "downloads.set" -> downloadsSet(args)
            "downloads.status" -> downloadsStatus(args)
            "attach.begin" -> attachBegin(args)
            "attach.chunk" -> buildJsonObject { put("received", (args["index"]?.jsonPrimitive?.intOrNull ?: 0) + 1) }
            "attach.end" -> attachEnd(args)
            "attach.abort" -> JsonObject(emptyMap())
            "device.rename", "device.unpair" -> JsonObject(emptyMap())
            else -> throw RpcException(ErrorCodes.UNKNOWN_OP, op)
        }
    }

    override fun callList(op: String, args: JsonObject, timeoutMs: Long): Flow<ListPart> = flow {
        ensureSeeded()
        delay(LATENCY_MS)
        val parts = when (op) {
            "models.list" -> modelsPart(args).map { it.toListPart() }
            "chats.list" -> chatsParts(args, singlePart = false)
            "chat.get" -> chatGetParts(args, singlePart = false)
            else -> throw RpcException(ErrorCodes.UNSUPPORTED, op)
        }
        parts.forEachIndexed { index, part ->
            if (index > 0) delay(PART_DELAY_MS)
            emit(part)
        }
    }

    // ------------------------------------------------------------------ lists

    private fun modelsPart(args: JsonObject): List<JsonObject> {
        val limit = args["limit"]
        return if (limit is JsonPrimitive && limit.isString) {
            models.mapIndexed { i, m ->
                encode(ModelListPartDto.serializer(), ModelListPartDto(listOf(m), models.size, if (i == models.lastIndex) null else "m${i + 1}"))
            }
        } else {
            listOf(encode(ModelListPartDto.serializer(), ModelListPartDto(models.take(limit?.jsonPrimitive?.intOrNull ?: 1), models.size, null)))
        }
    }

    private fun JsonObject.toListPart(): ListPart = ListPart(
        items = (this["items"] as? JsonArray)?.toList().orEmpty(),
        total = this["total"]?.jsonPrimitive?.intOrNull,
        next = (this["next"] as? JsonPrimitive)?.contentOrNull,
        more = false,
        raw = this,
    )

    private fun chatsParts(args: JsonObject, singlePart: Boolean): List<ListPart> {
        val query = args["query"]?.jsonPrimitive?.contentOrNull.orEmpty()
        val archived = args["archived"]?.jsonPrimitive?.booleanOrNull ?: false
        val starred = args["starred"]?.jsonPrimitive?.booleanOrNull ?: false
        val all = synchronized(lock) {
            chats.values
                .filter { it.archived == archived }
                .filter { !starred || it.starred }
                .filter { query.isBlank() || it.title.contains(query, ignoreCase = true) }
                .sortedByDescending { it.updatedAt }
                .map { it.toSummary() }
        }
        return pageOf(all, args, singlePart, PART_SIZE) { items, total, next ->
            encode(ChatListPartDto.serializer(), ChatListPartDto(items, total, next))
        }
    }

    private fun chatGetParts(args: JsonObject, singlePart: Boolean): List<ListPart> {
        val chat = findChat(args)
        val include = includes(args)
        val newestFirst = synchronized(lock) { chat.turns.sortedByDescending { it.createdAt }.map { it.toDto(include.first, include.second) } }
        val summary = synchronized(lock) { chat.toSummary() }
        val parts = pageOf(newestFirst, args, singlePart, TURN_PART_SIZE) { items, total, next ->
            encode(ChatGetPartDto.serializer(), ChatGetPartDto(null, items, total, next))
        }
        // The FIRST part also carries the chat summary.
        return parts.mapIndexed { index, part ->
            if (index == 0 && args["after"] == null) {
                val raw = JsonObject(part.raw + ("chat" to encode(ChatSummaryDto.serializer(), summary)))
                ListPart(part.items, part.total, part.next, part.more, raw)
            } else {
                part
            }
        }
    }

    private fun <T> pageOf(
        all: List<T>,
        args: JsonObject,
        singlePart: Boolean,
        partSize: Int,
        build: (List<T>, Int, String?) -> JsonObject,
    ): List<ListPart> {
        val start = args["after"]?.jsonPrimitive?.contentOrNull?.toIntOrNull() ?: 0
        val limitElement = args["limit"]
        val everything = limitElement is JsonPrimitive && limitElement.isString
        val limit = if (everything) Int.MAX_VALUE else limitElement?.jsonPrimitive?.intOrNull ?: 20
        val window = all.drop(start).take(limit)
        val chunks = if (everything && !singlePart) window.chunked(partSize).ifEmpty { listOf(emptyList()) } else listOf(window)
        var offset = start
        return chunks.mapIndexed { index, chunk ->
            offset += chunk.size
            val next = offset.takeIf { it < all.size && (!everything) || (it < all.size && index == chunks.lastIndex) }?.toString()
            val raw = build(chunk, all.size, if (everything && index < chunks.lastIndex) offset.toString() else next)
            ListPart(
                items = (raw["items"] as JsonArray).toList(),
                total = all.size,
                next = (raw["next"] as? JsonPrimitive)?.contentOrNull,
                more = index < chunks.lastIndex,
                raw = raw,
            )
        }
    }

    // ------------------------------------------------------------------ chats

    private fun turnGet(args: JsonObject): JsonElement {
        val chat = findChat(args)
        val (thinking, tools) = includes(args)
        val turn = synchronized(lock) { chat.turns.firstOrNull { it.promptId == args.string("promptId") } } ?: throw notFound("turn")
        return encode(TurnGetDto.serializer(), TurnGetDto(synchronized(lock) { turn.toDto(thinking, tools) }))
    }

    private fun toolGet(args: JsonObject): JsonElement {
        val chat = findChat(args)
        val tool = synchronized(lock) {
            chat.turns.firstOrNull { it.promptId == args.string("promptId") }?.tools?.firstOrNull { it.dto.callId == args.string("callId") }
        } ?: throw notFound("tool call")
        return encode(ToolGetDto.serializer(), ToolGetDto(tool.dto.callId, tool.dto.name, tool.dto.ok, tool.view))
    }

    private fun chatSet(args: JsonObject): JsonElement {
        val chat = findChat(args)
        val summary = synchronized(lock) {
            args.string("title")?.let { chat.title = it.trim().ifEmpty { chat.title } }
            args.string("modelId")?.let { chat.modelId = it }
            args.string("mode")?.let { chat.mode = it }
            args["starred"]?.jsonPrimitive?.booleanOrNull?.let { chat.starred = it }
            args["archived"]?.jsonPrimitive?.booleanOrNull?.let { chat.archived = it }
            chat.toSummary()
        }
        emit(LinkEvent.ChatUpdated(nextSeq(), summary))
        if (chat.id in downloads) emit(LinkEvent.DownloadChat(nextSeq(), summary))
        return encode(ChatResultDto.serializer(), ChatResultDto(summary))
    }

    private fun chatDelete(args: JsonObject): JsonElement {
        val chat = findChat(args)
        synchronized(lock) {
            chat.turns.forEach { it.job?.cancel() }
            chats.remove(chat.id)
        }
        emit(LinkEvent.ChatDeleted(nextSeq(), chat.id))
        if (downloads.remove(chat.id)) emit(LinkEvent.DownloadDeleted(nextSeq(), chat.id))
        return JsonObject(emptyMap())
    }

    private fun chatRewind(args: JsonObject): JsonElement {
        val chat = findChat(args)
        val removed: Int
        val summary: ChatSummaryDto
        synchronized(lock) {
            if (chat.turns.any { it.status == "in-progress" || it.status == "waiting" }) throw RpcException(ErrorCodes.BUSY, "A turn is running")
            val index = chat.turns.indexOfFirst { it.promptId == args.string("fromPromptId") }
            if (index < 0) throw notFound("turn")
            removed = chat.turns.size - index
            while (chat.turns.size > index) chat.turns.removeAt(chat.turns.lastIndex)
            summary = chat.toSummary()
        }
        emit(LinkEvent.ChatUpdated(nextSeq(), summary))
        return encode(RewindResultDto.serializer(), RewindResultDto(summary, removed))
    }

    private fun turnFeedback(args: JsonObject): JsonElement {
        val chat = findChat(args)
        synchronized(lock) {
            chat.turns.firstOrNull { it.promptId == args.string("promptId") }?.feedback = args.string("value") ?: "none"
        }
        return JsonObject(emptyMap())
    }

    // ------------------------------------------------------------------ asking

    private fun prompt(args: JsonObject): JsonElement {
        val text = args.string("text")?.trim().orEmpty()
        if (text.isEmpty()) throw RpcException(ErrorCodes.BAD_REQUEST, "text is required")
        val options = args["options"] as? JsonObject ?: JsonObject(emptyMap())
        val depth = options["depth"]?.jsonPrimitive?.intOrNull ?: 0
        val mode = options.string("mode") ?: "auto"
        val attachmentInfos = (args["attachments"] as? JsonArray)?.mapNotNull { attachments[it.jsonPrimitive.content] }.orEmpty()

        val chat: DemoChat
        val turn: DemoTurn
        val created: Boolean
        synchronized(lock) {
            val existing = args.string("chatId")?.let { chats[it] ?: throw notFound("chat") }
            if (existing != null && existing.turns.any { it.status == "in-progress" || it.status == "waiting" }) {
                throw RpcException(ErrorCodes.BUSY, "This chat already has a turn running")
            }
            created = existing == null
            chat = existing ?: DemoChat(
                id = "${DemoIds.PREFIX}${++chatCounter}",
                title = titles.generate(text),
                createdAt = time.now(),
                updatedAt = time.now(),
                modelId = null,
                mode = mode,
            ).also { chats[it.id] = it }
            val modelId = args.string("modelId") ?: chat.modelId ?: models.first().id
            if (models.none { it.id == modelId }) throw RpcException(ErrorCodes.NO_MODEL, "Unknown model")
            chat.modelId = modelId
            chat.mode = mode
            turn = DemoTurn("p%06d".format(++promptCounter), time.now(), "in-progress", modelId, mode, depth, text, attachmentInfos)
            chat.turns += turn
            chat.updatedAt = time.now()
        }
        val summary = synchronized(lock) { chat.toSummary() }
        turn.job = scope.launch { runTurn(chat, turn, created) }
        return encode(PromptAckDto.serializer(), PromptAckDto(chat.id, turn.promptId, summary))
    }

    private suspend fun runTurn(chat: DemoChat, turn: DemoTurn, created: Boolean) {
        val started = time.now()
        try {
            delay(40) // the acknowledgement is returned first
            if (created) emit(LinkEvent.ChatCreated(nextSeq(), synchronized(lock) { chat.toSummary() }))
            emit(LinkEvent.TurnStarted(nextSeq(), TurnStartedDto(chat.id, turn.promptId, turn.modelId, turn.mode, turn.depth)))

            val task = TaskMode.fromWire(turn.mode).let { if (it.isAuto) classifier.classify(turn.userText) else it }
            val model = models.first { it.id == turn.modelId }
            val depth = ThinkingDepth.fromLevel(turn.depth)

            // A doubt: the PC asks before doing something risky.
            var refused = false
            if (RISKY.containsMatchIn(turn.userText)) {
                refused = !askForApproval(chat, turn)
            }
            if (task == TaskMode.DEEP_RESEARCH) emitSearchTool(chat, turn)

            val request = GenerationRequest(task, depth, turn.userText, variant = chat.turns.indexOf(turn), tokensPerSecond = 40 + model.rank * 12)
            engine.generate(request).collect { event ->
                when (event) {
                    is GenerationEvent.ThinkingStep -> appendThinking(chat, turn, (if (turn.thinking.isEmpty()) "" else "\n\n") + "**${event.title}**\n")
                    is GenerationEvent.ThinkingDelta -> appendThinking(chat, turn, event.text)
                    is GenerationEvent.ThinkingFinished -> turn.thinkingMs = event.durationMs
                    is GenerationEvent.SourceFound -> {
                        val sources = synchronized(lock) {
                            turn.sources = turn.sources + SourceDto(event.source.title, event.source.domain, "https://${event.source.domain}", event.source.snippet)
                            turn.sources
                        }
                        emit(LinkEvent.Sources(nextSeq(), SourcesEventDto(chat.id, turn.promptId, sources)))
                    }
                    is GenerationEvent.AnswerDelta -> if (!refused) appendAnswer(chat, turn, event.text)
                    GenerationEvent.Finished -> Unit
                }
            }
            if (refused) appendAnswer(chat, turn, "Understood — I won't run that. Tell me what you'd like to do instead.")
            finishTurn(chat, turn, started)
        } catch (e: CancellationException) {
            withContext(NonCancellable) {
                synchronized(lock) { turn.status = "cancelled"; chat.updatedAt = time.now() }
                emit(LinkEvent.TurnCancelled(nextSeq(), TurnEndedDto(chat.id, turn.promptId)))
                emit(LinkEvent.ChatUpdated(nextSeq(), synchronized(lock) { chat.toSummary() }))
            }
            throw e
        } catch (e: Exception) {
            synchronized(lock) { turn.status = "failed"; turn.error = e.message }
            emit(LinkEvent.TurnFailed(nextSeq(), TurnFailedDto(chat.id, turn.promptId, e.message ?: "failed")))
        }
    }

    private suspend fun askForApproval(chat: DemoChat, turn: DemoTurn): Boolean {
        val askId = "k_demo_${++askCounter}"
        val answer = CompletableDeferred<String>()
        synchronized(lock) { asks[askId] = answer; turn.status = "waiting" }
        emit(
            LinkEvent.AskRequest(
                nextSeq(),
                AskRequestDto(
                    chatId = chat.id,
                    promptId = turn.promptId,
                    askId = askId,
                    kind = "approval",
                    tool = "shell",
                    summary = "Run a command on your PC?",
                    detail = turn.userText.take(200),
                ),
            ),
        )
        val decision = answer.await()
        synchronized(lock) { asks.remove(askId); turn.status = "in-progress" }
        emit(LinkEvent.AskResolved(nextSeq(), com.avek.chat.core.link.wire.AskResolvedDto(askId, decision, "this device")))
        return decision != "deny"
    }

    private suspend fun emitSearchTool(chat: DemoChat, turn: DemoTurn) {
        val callId = "t1"
        emit(LinkEvent.Status(nextSeq(), StatusDto(chat.id, turn.promptId, "search", "start", "Searching the web…")))
        emit(LinkEvent.ToolCall(nextSeq(), ToolCallEventDto(chat.id, turn.promptId, callId, "internet_research", "Searching the web", "12 queries")))
        synchronized(lock) {
            turn.tools += DemoTool(
                ToolDto(callId, "internet_research", null, "Searching the web"),
                ToolViewDto("Researched 12 pages", "12 queries", "1. Background and definitions\n2. Recent studies\n3. Counter-arguments\n4. Methodology critiques\n…", "list"),
            )
        }
        delay(900)
        synchronized(lock) {
            val tool = turn.tools.first { it.dto.callId == callId }
            turn.tools[turn.tools.indexOf(tool)] = DemoTool(tool.dto.copy(ok = true, title = "Researched 12 pages", body = tool.view.body), tool.view)
        }
        emit(LinkEvent.ToolResult(nextSeq(), ToolResultEventDto(chat.id, turn.promptId, callId, true, "Researched 12 pages")))
        emit(LinkEvent.Status(nextSeq(), StatusDto(chat.id, turn.promptId, "search", "done", "")))
    }

    private suspend fun appendThinking(chat: DemoChat, turn: DemoTurn, text: String) {
        val offset = synchronized(lock) { turn.thinking.length.also { turn.thinking.append(text) } }
        emit(LinkEvent.ThinkingDelta(nextSeq(), DeltaDto(chat.id, turn.promptId, text, offset)))
    }

    private suspend fun appendAnswer(chat: DemoChat, turn: DemoTurn, text: String) {
        val offset = synchronized(lock) { turn.answer.length.also { turn.answer.append(text) } }
        emit(LinkEvent.AnswerDelta(nextSeq(), DeltaDto(chat.id, turn.promptId, text, offset)))
    }

    private suspend fun finishTurn(chat: DemoChat, turn: DemoTurn, started: Long) {
        val summary: ChatSummaryDto
        val dto: TurnViewDto
        synchronized(lock) {
            turn.status = "completed"
            chat.updatedAt = time.now()
            summary = chat.toSummary()
            dto = turn.toDto(includeThinking = true, includeTools = true)
        }
        emit(
            LinkEvent.TurnCompleted(
                nextSeq(),
                TurnCompletedDto(chat.id, turn.promptId, "end", durationMs = time.now() - started, thinkingMs = turn.thinkingMs, title = chat.title, preview = preview(turn.answer.toString())),
            ),
        )
        emit(LinkEvent.ChatUpdated(nextSeq(), summary))
        if (chat.id in downloads) {
            emit(LinkEvent.DownloadTurn(nextSeq(), DownloadTurnDto(chat.id, dto)))
            emit(LinkEvent.DownloadChat(nextSeq(), summary))
        }
    }

    private fun turnCancel(args: JsonObject): JsonElement {
        val chat = findChat(args)
        val promptId = args.string("promptId")
        synchronized(lock) {
            chat.turns.filter { (promptId == null || it.promptId == promptId) && (it.status == "in-progress" || it.status == "waiting") }
                .forEach { it.job?.cancel() }
        }
        return JsonObject(emptyMap())
    }

    private fun askAnswer(args: JsonObject): JsonElement {
        val askId = args.string("askId") ?: throw RpcException(ErrorCodes.BAD_REQUEST, "askId")
        val answer = synchronized(lock) { asks[askId] } ?: throw RpcException(ErrorCodes.EXPIRED, "Already answered")
        answer.complete(args.string("decision") ?: args.string("text") ?: "allow")
        return JsonObject(emptyMap())
    }

    // ------------------------------------------------------------------ downloads and attachments

    private fun downloadsSet(args: JsonObject): JsonElement {
        val ids = args["chatIds"]?.jsonArray?.map { it.jsonPrimitive.content }.orEmpty()
        val accepted = synchronized(lock) { ids.filter { it in chats } }
        downloads.clear()
        downloads.addAll(accepted)
        return encode(DownloadsSetResultDto.serializer(), DownloadsSetResultDto(accepted))
    }

    private fun downloadsStatus(args: JsonObject): JsonElement {
        val ids = args["chatIds"]?.jsonArray?.map { it.jsonPrimitive.content }.orEmpty()
        val items = synchronized(lock) {
            ids.map { id ->
                val chat = chats[id]
                DownloadStatusItemDto(id, chat != null, chat?.let { iso(it.updatedAt) }.orEmpty(), chat?.turns?.size ?: 0)
            }
        }
        return encode(DownloadsStatusResultDto.serializer(), DownloadsStatusResultDto(items))
    }

    private fun attachBegin(args: JsonObject): JsonElement {
        val id = "u_demo_${++uploadCounter}"
        uploads[id] = Triple(args.string("name").orEmpty(), args.string("mime").orEmpty(), args["size"]?.jsonPrimitive?.content?.toLongOrNull() ?: 0L)
        return encode(AttachBeginResultDto.serializer(), AttachBeginResultDto(id, 262_144))
    }

    private fun attachEnd(args: JsonObject): JsonElement {
        val upload = uploads.remove(args.string("uploadId")) ?: throw notFound("upload")
        val id = "a_demo_${uploadCounter}_${attachments.size}"
        attachments[id] = AttachmentInfoDto(upload.first, upload.second, upload.third)
        return encode(AttachEndResultDto.serializer(), AttachEndResultDto(id, upload.first, upload.third))
    }

    // ------------------------------------------------------------------ helpers

    private fun ensureSeeded() {
        synchronized(lock) {
            if (seeded) return
            seeded = true
            seed()
        }
    }

    private fun emit(event: LinkEvent) {
        _events.tryEmit(event)
    }

    private fun nextSeq(): Long = synchronized(lock) { ++seq }

    private fun findChat(args: JsonObject): DemoChat =
        synchronized(lock) { chats[args.string("chatId")] } ?: throw notFound("chat")

    private fun notFound(what: String) = RpcException(ErrorCodes.NOT_FOUND, "No such $what")

    private fun includes(args: JsonObject): Pair<Boolean, Boolean> {
        val include = args["include"]?.jsonArray?.map { it.jsonPrimitive.content }.orEmpty()
        return ("thinking" in include) to ("tools" in include)
    }

    private fun JsonObject.string(key: String): String? = (this[key] as? JsonPrimitive)?.takeIf { it.isString }?.contentOrNull

    private fun <T> encode(serializer: KSerializer<T>, value: T): JsonObject =
        WireJson.encodeToJsonElement(serializer, value).jsonObject

    private fun iso(millis: Long) = Instant.ofEpochMilli(millis).toString()

    private fun preview(text: String) = text.replace(Regex("[#*`>|_]"), "").replace(Regex("\\s+"), " ").trim().take(120)

    private fun DemoChat.toSummary() = ChatSummaryDto(
        chatId = id,
        title = title,
        createdAt = iso(createdAt),
        updatedAt = iso(updatedAt),
        modelId = modelId,
        mode = mode,
        turnCount = turns.size,
        preview = turns.lastOrNull()?.answer?.toString()?.let(::preview).orEmpty(),
        starred = starred,
        archived = archived,
    )

    private fun DemoTurn.toDto(includeThinking: Boolean, includeTools: Boolean) = TurnViewDto(
        promptId = promptId,
        createdAt = iso(createdAt),
        status = status,
        modelId = modelId,
        mode = mode,
        depth = depth,
        user = UserPartDto(userText, attachments),
        assistant = AssistantPartDto(answer.toString()),
        thinking = if (depth > 0 && (thinking.isNotEmpty() || status == "in-progress")) {
            ThinkingDto(thinkingMs, if (includeThinking) thinking.toString() else null)
        } else {
            null
        },
        tools = tools.map { it.dto.copy(body = if (includeTools) it.dto.body ?: it.view.body else null) },
        sources = sources,
        error = error,
        feedback = feedback,
    )

    // ------------------------------------------------------------------ sample content

    private data class Seed(val prompt: String, val task: TaskMode, val modelId: String, val depth: ThinkingDepth, val hoursAgo: Long, val starred: Boolean = false, val archived: Boolean = false, val followUp: String? = null, val title: String? = null)

    private fun seed() {
        val now = time.now()
        listOf(
            Seed("Write a Kotlin retry helper with exponential backoff for flaky network calls", TaskMode.CODING, "demo-forge", ThinkingDepth.DEEP, 1, starred = true, followUp = "Can you add jitter and make it cancellation-safe?"),
            Seed("Research the impact of remote work on team productivity", TaskMode.DEEP_RESEARCH, "demo-sage", ThinkingDepth.EXTENDED, 3, title = "Remote work & productivity"),
            Seed("Brainstorm names for a cozy neighbourhood coffee shop", TaskMode.BRAINSTORM, "demo-muse", ThinkingDepth.LIGHT, 5),
            Seed("Explain how transformers use attention, like I'm new to ML", TaskMode.LEARN, "demo-lumen", ThinkingDepth.BALANCED, 26, followUp = "What's the difference between self-attention and cross-attention?"),
            Seed("Help me decide between renting and buying an apartment this year", TaskMode.ANALYSIS, "demo-atlas", ThinkingDepth.DEEP, 30, starred = true),
            Seed("Draft a warm welcome email for new members of our book club", TaskMode.WRITING, "demo-muse", ThinkingDepth.BALANCED, 52),
            Seed("Solve 2x + 6 = 14 and show each step", TaskMode.MATH, "demo-nova", ThinkingDepth.LIGHT, 75),
            Seed("Write a Python rate limiter for an API client", TaskMode.CODING, "demo-forge", ThinkingDepth.BALANCED, 98),
            Seed("Plan a relaxed three-day itinerary for Kyoto in autumn", TaskMode.GENERAL, "demo-nova", ThinkingDepth.BALANCED, 120, title = "Kyoto autumn itinerary"),
            Seed("What is the state of solid-state batteries for electric vehicles", TaskMode.DEEP_RESEARCH, "demo-atlas", ThinkingDepth.MAXIMUM, 160, starred = true),
            Seed("Explain the difference between TCP and UDP", TaskMode.LEARN, "demo-flash", ThinkingDepth.INSTANT, 260),
            Seed("Write a short poem about the first rain of the monsoon", TaskMode.WRITING, "demo-muse", ThinkingDepth.LIGHT, 400),
            Seed("Write a SQL query for monthly active users with growth", TaskMode.CODING, "demo-forge", ThinkingDepth.BALANCED, 520),
            Seed("Analyze the pros and cons of a four-day work week", TaskMode.ANALYSIS, "demo-atlas", ThinkingDepth.EXTENDED, 720),
            Seed("Brainstorm weekend project ideas to learn Jetpack Compose", TaskMode.BRAINSTORM, "demo-nova", ThinkingDepth.BALANCED, 1100),
            Seed("Give me a beginner's overview of index funds", TaskMode.GENERAL, "demo-nova", ThinkingDepth.LIGHT, 1500, archived = true),
            Seed("Summarize the history of the printing press", TaskMode.LEARN, "demo-sage", ThinkingDepth.DEEP, 2200),
        ).plus(olderChats).forEach { seed ->
            val start = now - seed.hoursAgo * HOUR
            val chat = DemoChat("${DemoIds.PREFIX}${++chatCounter}", seed.title ?: titles.generate(seed.prompt), start, start, seed.modelId, seed.task.wire, seed.starred, seed.archived)
            var cursor = start
            listOfNotNull(seed.prompt, seed.followUp).forEachIndexed { index, prompt ->
                val turn = DemoTurn("p%06d".format(++promptCounter), cursor, "completed", seed.modelId, seed.task.wire, seed.depth.level, prompt, emptyList())
                val script = composer.compose(prompt, seed.task, seed.depth, index)
                turn.answer.append(script.answer)
                if (script.thinking.isNotEmpty()) {
                    turn.thinking.append(script.thinking.joinToString("\n\n") { "**${it.title}**\n${it.text}" })
                    turn.thinkingMs = 2_500L + seed.depth.level * 4_100L
                }
                turn.sources = script.sources.map { SourceDto(it.title, it.domain, "https://${it.domain}", it.snippet) }
                if (seed.task == TaskMode.DEEP_RESEARCH) {
                    turn.tools += DemoTool(
                        ToolDto("t1", "internet_research", true, "Researched 12 pages", "1. Background\n2. Recent studies\n3. Counter-arguments"),
                        ToolViewDto("Researched 12 pages", "12 queries", "1. Background\n2. Recent studies\n3. Counter-arguments", "list"),
                    )
                }
                chat.turns += turn
                cursor += 90_000
                chat.updatedAt = cursor
            }
            chats[chat.id] = chat
        }
    }

    /** Enough older chats that the sidebar's "See all" and paging are visible in demo mode. */
    private val olderChats: List<Seed> = listOf(
        "Explain recursion with a simple example" to TaskMode.LEARN,
        "Write a regex that validates an email address" to TaskMode.CODING,
        "Ideas for a team offsite on a small budget" to TaskMode.BRAINSTORM,
        "Compare PostgreSQL and MySQL for a small SaaS" to TaskMode.ANALYSIS,
        "Proofread this paragraph for tone" to TaskMode.WRITING,
        "What is the derivative of x squared times sin x" to TaskMode.MATH,
        "Plan a week of simple vegetarian dinners" to TaskMode.GENERAL,
        "How does public key cryptography work" to TaskMode.LEARN,
        "Refactor a long Kotlin function into smaller ones" to TaskMode.CODING,
        "Research the effects of sleep on memory" to TaskMode.DEEP_RESEARCH,
        "Write a cover letter opening for a design role" to TaskMode.WRITING,
        "Names for a hiking club newsletter" to TaskMode.BRAINSTORM,
        "Explain how a bill becomes law" to TaskMode.LEARN,
        "Debug a null pointer crash in a Compose screen" to TaskMode.CODING,
        "Is it worth learning Rust this year" to TaskMode.ANALYSIS,
        "Convert 72 degrees Fahrenheit to Celsius" to TaskMode.MATH,
        "Summarize the plot of a classic novel" to TaskMode.GENERAL,
        "Draft a polite reminder about an overdue invoice" to TaskMode.WRITING,
        "Birthday gift ideas for a coffee lover" to TaskMode.BRAINSTORM,
        "Research how vaccines are tested for safety" to TaskMode.DEEP_RESEARCH,
        "Explain the CAP theorem in plain words" to TaskMode.LEARN,
        "Write unit tests for a date parser" to TaskMode.CODING,
        "Pros and cons of remote-first hiring" to TaskMode.ANALYSIS,
        "Solve a system of two linear equations" to TaskMode.MATH,
        "Tips for a first marathon" to TaskMode.GENERAL,
        "Rewrite this announcement to be friendlier" to TaskMode.WRITING,
        "Startup ideas around local food waste" to TaskMode.BRAINSTORM,
        "How do tides work" to TaskMode.LEARN,
        "Write a bash script to rename files by date" to TaskMode.CODING,
        "Research the economics of urban gardens" to TaskMode.DEEP_RESEARCH,
        "Explain compound interest with numbers" to TaskMode.LEARN,
        "Outline a talk on accessible design" to TaskMode.WRITING,
        "Compare two budgeting methods" to TaskMode.ANALYSIS,
        "Fun facts about octopuses" to TaskMode.GENERAL,
        "Gradle build is slow, how can I speed it up" to TaskMode.CODING,
        "Describe the water cycle for a ten year old" to TaskMode.LEARN,
        "Ideas for a rainy-day family game" to TaskMode.BRAINSTORM,
        "Percentages: what is 18 percent of 240" to TaskMode.MATH,
        "Write a thank-you note to a mentor" to TaskMode.WRITING,
        "Research how bridges handle wind loads" to TaskMode.DEEP_RESEARCH,
        "Explain what an API gateway does" to TaskMode.LEARN,
        "Weekend trip ideas within three hours of a city" to TaskMode.GENERAL,
    ).mapIndexed { i, (prompt, task) ->
        Seed(prompt, task, "demo-nova", ThinkingDepth.LIGHT, 2400L + i * 60L)
    }

    private companion object {
        const val HOUR = 3_600_000L
        const val LATENCY_MS = 60L
        const val PART_DELAY_MS = 40L
        const val PART_SIZE = 10
        const val TURN_PART_SIZE = 6
        val RISKY = Regex("\\b(run|execute|install|delete|remove)\\b", RegexOption.IGNORE_CASE)
    }
}
