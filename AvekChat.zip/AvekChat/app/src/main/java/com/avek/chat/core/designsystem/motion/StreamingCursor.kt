package com.avek.chat.core.designsystem.motion

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.avek.chat.core.model.settings.CursorStyle
import kotlin.math.PI
import kotlin.math.sin

/** The caret shown at the tail of a streaming answer. */
@Composable
fun StreamingCursor(style: CursorStyle, color: Color, modifier: Modifier = Modifier.size(14.dp, 18.dp)) {
    if (style == CursorStyle.NONE) return
    val phase = rememberPhase(if (style == CursorStyle.SPARK) 1800 else 1000, label = "cursor")
    Canvas(modifier) {
        val t = phase.value
        val blink = if (t < 0.55f) 1f else 0.15f
        when (style) {
            CursorStyle.BAR -> drawRoundRect(
                color.copy(alpha = blink),
                topLeft = Offset(size.width * 0.3f, size.height * 0.1f),
                size = Size(size.width * 0.16f, size.height * 0.8f),
                cornerRadius = CornerRadius(4f),
            )
            CursorStyle.BLOCK -> drawRoundRect(
                color.copy(alpha = 0.25f + 0.6f * blink),
                topLeft = Offset(size.width * 0.1f, size.height * 0.12f),
                size = Size(size.width * 0.6f, size.height * 0.76f),
                cornerRadius = CornerRadius(3f),
            )
            CursorStyle.DOT -> {
                val pulse = 0.7f + 0.3f * sin((t * 2 * PI).toFloat())
                drawCircle(color, radius = size.minDimension * 0.28f * pulse, center = Offset(size.width * 0.45f, size.height * 0.55f))
            }
            CursorStyle.SPARK -> drawSpark(t, color, intensity = 0.4f)
            CursorStyle.NONE -> Unit
        }
    }
}
