package com.avek.chat.core.model.settings

import com.avek.chat.core.model.TaskMode
import com.avek.chat.core.model.ThinkingDepth
import kotlinx.serialization.Serializable

/**
 * Everything the user can configure, persisted as a single JSON document.
 * New fields must always have defaults so older files keep decoding.
 */
@Serializable
data class UserSettings(
    val profile: Profile = Profile(),
    val defaults: ChatDefaults = ChatDefaults(),
    val appearance: AppearanceSettings = AppearanceSettings(),
    val connection: ConnectionSettings = ConnectionSettings(),
    val thinking: ThinkingSettings = ThinkingSettings(),
)

/** Customize → Thinking: how the thinking section behaves. */
@Serializable
data class ThinkingSettings(
    /** A thinking block closes by itself when it ends (unless the person pinned it). */
    val collapseWhenEnds: Boolean = true,
    /** The group that is running stays open until its answer starts. */
    val keepRunningGroupOpen: Boolean = true,
)


@Serializable
data class Profile(
    val displayName: String = "",
    val plan: String = "Pro plan",
)

/** Defaults for a new chat. The model is never stored: the PC decides the default one. */
@Serializable
data class ChatDefaults(
    val taskMode: TaskMode = TaskMode.AUTO,
    val depth: ThinkingDepth = ThinkingDepth.BALANCED,
)
