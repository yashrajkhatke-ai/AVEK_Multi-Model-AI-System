package com.avek.chat.core.model.settings

import com.avek.chat.core.model.TaskMode
import com.avek.chat.core.model.ThinkingDepth
import kotlinx.serialization.Serializable

/**
 * Everything the user can configure, persisted as a single JSON document.
 * New fields must always have defaults so older files keep decoding.
 */
@Serializable
data class UserSettings(
    val profile: Profile = Profile(),
    val defaults: ChatDefaults = ChatDefaults(),
    val appearance: AppearanceSettings = AppearanceSettings(),
    val connection: ConnectionSettings = ConnectionSettings(),
    val thinking: ThinkingSettings = ThinkingSettings(),
    val security: SecuritySettings = SecuritySettings(),
)

/** Settings → Security (UI-WIRE v4 section 13, "App lock"). The password itself is not here. */
@Serializable
data class SecuritySettings(
    /** Minutes the app stays unlocked after leaving the screen: 0 (ask every time), 1, 5 or 10. */
    val graceMinutes: Int = 0,
    /** Off by default: `FLAG_SECURE` hides the app from screenshots and the recents list. */
    val allowScreenshots: Boolean = false,
) {
    companion object {
        val GRACE_OPTIONS = listOf(0, 1, 5, 10)
    }
}

/** Customize → Thinking: how the thinking section behaves. */
@Serializable
data class ThinkingSettings(
    /** A thinking block closes by itself when it ends (unless the person pinned it). */
    val collapseWhenEnds: Boolean = true,
    /** The group that is running stays open until its answer starts. */
    val keepRunningGroupOpen: Boolean = true,
)


@Serializable
data class Profile(
    val displayName: String = "",
    val plan: String = "Pro plan",
)

/** Defaults for a new chat. The model is never stored: the PC decides the default one. */
@Serializable
data class ChatDefaults(
    val taskMode: TaskMode = TaskMode.AUTO,
    val depth: ThinkingDepth = ThinkingDepth.BALANCED,
)
