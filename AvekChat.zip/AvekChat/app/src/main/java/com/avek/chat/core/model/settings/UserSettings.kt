package com.avek.chat.core.model.settings

import com.avek.chat.core.model.TaskMode
import com.avek.chat.core.model.ThinkingDepth
import kotlinx.serialization.Serializable

/**
 * Everything the user can configure, persisted as a single JSON document.
 * New fields must always have defaults so older files keep decoding.
 */
@Serializable
data class UserSettings(
    val profile: Profile = Profile(),
    val defaults: ChatDefaults = ChatDefaults(),
    val appearance: AppearanceSettings = AppearanceSettings(),
    val connection: ConnectionSettings = ConnectionSettings(),
    val thinking: ThinkingSettings = ThinkingSettings(),
)

/** Customize → Thinking: how the thinking block looks by default. */
@Serializable
data class ThinkingSettings(
    /** A style id of the catalog, or [AUTO]. */
    val style: String = AUTO,
    val expandedByDefault: Boolean = false,
    /** Show the full reasoning text under the style when expanded. */
    val showFullReasoning: Boolean = false,
) {
    companion object {
        const val AUTO = "auto"
    }
}

@Serializable
data class Profile(
    val displayName: String = "",
    val plan: String = "Pro plan",
)

/** Defaults for a new chat. The model is never stored: the PC decides the default one. */
@Serializable
data class ChatDefaults(
    val taskMode: TaskMode = TaskMode.AUTO,
    val depth: ThinkingDepth = ThinkingDepth.BALANCED,
)
