package com.avek.chat.core.model.settings

import com.avek.chat.core.model.TaskMode
import com.avek.chat.core.model.ThinkingDepth
import kotlinx.serialization.Serializable

/**
 * Everything the user can configure, persisted as a single JSON document.
 * New fields must always have defaults so older files keep decoding.
 */
@Serializable
data class UserSettings(
    val profile: Profile = Profile(),
    val defaults: ChatDefaults = ChatDefaults(),
    val appearance: AppearanceSettings = AppearanceSettings(),
    val hasSeededDemoContent: Boolean = false,
)

@Serializable
data class Profile(
    val displayName: String = "",
    val plan: String = "Pro plan",
)

@Serializable
data class ChatDefaults(
    val modelId: String = "avek-nova",
    val taskMode: TaskMode = TaskMode.AUTO,
    val depth: ThinkingDepth = ThinkingDepth.BALANCED,
    val autoTitle: Boolean = true,
)
