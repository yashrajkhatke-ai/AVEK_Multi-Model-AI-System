package com.avek.chat.core.domain.models

import com.avek.chat.core.data.remote.parseInstant
import com.avek.chat.core.link.HarnessApi
import com.avek.chat.core.link.LinkRepository
import com.avek.chat.core.link.wire.LinkEvent
import com.avek.chat.core.link.wire.ModelStateDto
import com.avek.chat.core.model.ModelLoadState
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/** The load state of one model on the PC, as the PC reported it. */
data class ModelStateInfo(
    val modelId: String,
    val state: ModelLoadState,
    val sinceMs: Long = 0,
    val loadMs: Long? = null,
    val error: String? = null,
    val reason: String? = null,
)

/**
 * What is loaded on the PC right now (UI-WIRE v3 section 8.2): seeded from `ready.modelStates`
 * (or `models.state` when `ready` carried none), kept live by `model.state` events, and cleared
 * when the link goes away (a state that is not known is shown as nothing, not as "unloaded").
 */
class ModelStateTracker(
    private val link: LinkRepository,
    private val api: HarnessApi,
    private val scope: CoroutineScope,
) {
    private val _states = MutableStateFlow<Map<String, ModelStateInfo>>(emptyMap())
    val states: StateFlow<Map<String, ModelStateInfo>> = _states

    fun stateOf(modelId: String): ModelLoadState = _states.value[modelId]?.state ?: ModelLoadState.UNKNOWN

    fun start() {
        scope.launch {
            link.ready.collect { ready ->
                if (ready == null) {
                    _states.value = emptyMap()
                } else if (ready.modelStates.isNotEmpty()) {
                    _states.value = ready.modelStates.associate { it.modelId to it.toInfo() }
                } else {
                    refresh()
                }
            }
        }
        scope.launch {
            link.events.collect { event ->
                if (event is LinkEvent.ModelState) apply(event.data)
            }
        }
    }

    /** `models.state`: the full picture (after a reconnect when `ready` had none). */
    suspend fun refresh() {
        try {
            val items = api.modelsState().items
            _states.value = items.associate { it.modelId to it.toInfo() }
        } catch (e: CancellationException) {
            throw e
        } catch (_: Exception) {
            // Not connected or not supported: keep what we have.
        }
    }

    fun apply(dto: ModelStateDto) {
        _states.update { it + (dto.modelId to dto.toInfo()) }
    }

    private fun ModelStateDto.toInfo() = ModelStateInfo(
        modelId = modelId,
        state = ModelLoadState.fromWire(state),
        sinceMs = parseInstant(since),
        loadMs = loadMs,
        error = error,
        reason = reason,
    )
}
