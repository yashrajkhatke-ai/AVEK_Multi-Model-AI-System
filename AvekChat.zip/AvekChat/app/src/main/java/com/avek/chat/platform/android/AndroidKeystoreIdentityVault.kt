package com.avek.chat.platform.android

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import com.avek.chat.core.link.crypto.SecureCrypto
import com.avek.chat.core.link.store.IdentityVault
import com.avek.chat.core.link.store.VaultException
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.PrivateKey
import java.security.Signature
import java.security.interfaces.ECPublicKey
import java.security.spec.ECGenParameterSpec
import javax.inject.Inject
import javax.inject.Singleton

/**
 * The device identities of UI-WIRE v4 section 3: EC secp256r1 signing keys in the Android Keystore
 * under the aliases `avek.identity.<n>` (StrongBox when the device has it, otherwise the normal
 * hardware-backed Keystore). Not tied to a fingerprint prompt: the app reconnects in the background.
 * The private keys never leave the Keystore.
 */
@Singleton
class AndroidKeystoreIdentityVault @Inject constructor() : IdentityVault {

    private fun keyStore(): KeyStore = KeyStore.getInstance(PROVIDER).apply { load(null) }

    override fun exists(alias: String): Boolean = runCatching { keyStore().containsAlias(alias) }.getOrDefault(false)

    @Synchronized
    override fun create(alias: String) {
        if (exists(alias)) return
        try {
            generate(alias, strongBox = true)
        } catch (_: Exception) {
            // No StrongBox (StrongBoxUnavailableException) or it refused: the normal Keystore.
            runCatching { keyStore().deleteEntry(alias) }
            try {
                generate(alias, strongBox = false)
            } catch (e: Exception) {
                throw VaultException("Could not create the device key", e)
            }
        }
    }

    private fun generate(alias: String, strongBox: Boolean) {
        val builder = KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_SIGN)
            .setAlgorithmParameterSpec(ECGenParameterSpec("secp256r1"))
            .setDigests(KeyProperties.DIGEST_SHA256)
            .setUserAuthenticationRequired(false)
        if (strongBox && android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.P) builder.setIsStrongBoxBacked(true)
        val generator = KeyPairGenerator.getInstance(KeyProperties.KEY_ALGORITHM_EC, PROVIDER)
        generator.initialize(builder.build())
        generator.generateKeyPair()
    }

    override fun publicKey(alias: String): ByteArray {
        val certificate = keyStore().getCertificate(alias) ?: throw VaultException("No device key")
        return SecureCrypto.encodePublicKey(certificate.publicKey as ECPublicKey)
    }

    override fun sign(alias: String, message: ByteArray): ByteArray {
        val key = keyStore().getKey(alias, null) as? PrivateKey ?: throw VaultException("No device key")
        return Signature.getInstance("SHA256withECDSA").run {
            initSign(key)
            update(message)
            sign()
        }
    }

    override fun delete(alias: String) {
        runCatching { keyStore().deleteEntry(alias) }
    }

    override fun aliases(): List<String> = runCatching {
        keyStore().aliases().toList().filter { it.startsWith(IdentityVault.ALIAS_PREFIX) }
    }.getOrDefault(emptyList())

    /** The single key of version 3 (deleted by the migration). */
    fun deleteLegacyKey() {
        runCatching { keyStore().deleteEntry(LEGACY_ALIAS) }
    }

    private companion object {
        const val PROVIDER = "AndroidKeyStore"
        const val LEGACY_ALIAS = "avek_device_identity_v3"
    }
}
