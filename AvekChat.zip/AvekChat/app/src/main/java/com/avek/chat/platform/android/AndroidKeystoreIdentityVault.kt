package com.avek.chat.platform.android

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import com.avek.chat.core.link.crypto.SecureCrypto
import com.avek.chat.core.link.store.IdentityVault
import com.avek.chat.core.link.store.VaultException
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.PrivateKey
import java.security.Signature
import java.security.interfaces.ECPublicKey
import java.security.spec.ECGenParameterSpec
import javax.inject.Inject
import javax.inject.Singleton

/**
 * The device identity of UI-WIRE v3 section 3: an EC secp256r1 signing key created in the Android
 * Keystore (StrongBox when the device has it, otherwise the normal hardware-backed Keystore). The
 * private key never leaves the Keystore; only the public point and signatures come out.
 */
@Singleton
class AndroidKeystoreIdentityVault @Inject constructor() : IdentityVault {

    private fun keyStore(): KeyStore = KeyStore.getInstance(PROVIDER).apply { load(null) }

    override fun exists(): Boolean = runCatching { keyStore().containsAlias(ALIAS) }.getOrDefault(false)

    @Synchronized
    override fun create() {
        if (exists()) return
        try {
            generate(strongBox = true)
        } catch (_: Exception) {
            // No StrongBox (android.security.keystore.StrongBoxUnavailableException) or it refused: normal Keystore.
            runCatching { keyStore().deleteEntry(ALIAS) }
            try {
                generate(strongBox = false)
            } catch (e: Exception) {
                throw VaultException("Could not create the device key", e)
            }
        }
    }

    private fun generate(strongBox: Boolean) {
        val builder = KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_SIGN)
            .setAlgorithmParameterSpec(ECGenParameterSpec("secp256r1"))
            .setDigests(KeyProperties.DIGEST_SHA256)
            .setUserAuthenticationRequired(false)
        if (strongBox && android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.P) builder.setIsStrongBoxBacked(true)
        val generator = KeyPairGenerator.getInstance(KeyProperties.KEY_ALGORITHM_EC, PROVIDER)
        generator.initialize(builder.build())
        generator.generateKeyPair()
    }

    override fun publicKey(): ByteArray {
        val certificate = keyStore().getCertificate(ALIAS) ?: throw VaultException("No device key")
        return SecureCrypto.encodePublicKey(certificate.publicKey as ECPublicKey)
    }

    override fun sign(message: ByteArray): ByteArray {
        val key = keyStore().getKey(ALIAS, null) as? PrivateKey ?: throw VaultException("No device key")
        return Signature.getInstance("SHA256withECDSA").run {
            initSign(key)
            update(message)
            sign()
        }
    }

    override fun delete() {
        runCatching { keyStore().deleteEntry(ALIAS) }
    }

    private companion object {
        const val PROVIDER = "AndroidKeyStore"
        const val ALIAS = "avek_device_identity_v3"
    }
}
