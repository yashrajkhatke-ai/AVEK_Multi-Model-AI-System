package com.avek.chat.platform.android

import android.content.Context
import com.avek.chat.core.data.fonts.FontCatalogSource
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject

/** Reads the bundled Google Fonts catalogue from `assets/font_catalog.tsv`. */
class AssetFontCatalogSource @Inject constructor(
    @ApplicationContext private val context: Context,
) : FontCatalogSource {
    override suspend fun readLines(): List<String> =
        context.assets.open(ASSET).bufferedReader().useLines { it.toList() }

    private companion object {
        const val ASSET = "font_catalog.tsv"
    }
}
