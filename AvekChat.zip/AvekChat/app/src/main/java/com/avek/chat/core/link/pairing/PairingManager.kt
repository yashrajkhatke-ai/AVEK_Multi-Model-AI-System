package com.avek.chat.core.link.pairing

import com.avek.chat.core.link.crypto.Handshake
import com.avek.chat.core.link.discovery.BeaconSource
import com.avek.chat.core.link.discovery.DiscoveredServer
import com.avek.chat.core.link.store.PairedPc
import com.avek.chat.core.link.store.PairedPcStore
import com.avek.chat.core.link.transport.ChannelFactory
import com.avek.chat.core.link.transport.HostPort
import com.avek.chat.core.link.transport.WifiBinding
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.onCompletion
import kotlinx.coroutines.flow.scan
import kotlinx.coroutines.flow.map

/** Pairing (UI-WIRE section 3): finds PCs on the network and exchanges the one-time code for a device secret. */
class PairingManager(
    private val store: PairedPcStore,
    private val channels: ChannelFactory,
    private val beacons: BeaconSource,
    private val binding: WifiBinding,
    private val handshake: Handshake = Handshake(),
) {
    /** PCs heard on the network, accumulated by `serverId`, newest information first. */
    fun discover(): Flow<List<DiscoveredServer>> =
        beacons.beacons()
            .scan(emptyMap<String, DiscoveredServer>()) { known, beacon ->
                known + (beacon.serverId to DiscoveredServer(beacon.serverId, beacon.name, HostPort(beacon.host, beacon.port)))
            }
            .map { it.values.sortedBy { server -> server.name.lowercase() } }

    /**
     * Pairs with the PC at [target]. Wrong code, expired code and rate limiting arrive as
     * [com.avek.chat.core.link.crypto.HandshakeException]. On success the grant is stored.
     */
    suspend fun pair(target: HostPort, code: String, deviceName: String): PairedPc {
        binding.acquire()
        try {
            val channel = channels.open(target)
            try {
                val grant = handshake.pair(channel, code, deviceName)
                val pc = PairedPc(
                    deviceId = grant.deviceId,
                    deviceSecret = grant.deviceSecret,
                    serverId = grant.serverId,
                    serverName = grant.serverName,
                    deviceName = deviceName,
                    lastHost = target.host,
                    lastPort = target.port,
                )
                store.save(pc)
                return pc
            } finally {
                channel.close()
            }
        } finally {
            binding.release()
        }
    }

    /** Forgets the PC locally (wipes the secret). The caller sends `device.unpair` first when connected. */
    fun forget() = store.clear()
}
