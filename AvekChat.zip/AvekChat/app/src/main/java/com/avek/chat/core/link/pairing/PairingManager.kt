package com.avek.chat.core.link.pairing

import com.avek.chat.core.link.crypto.AvekProtocol
import com.avek.chat.core.link.crypto.PairingHandshake
import com.avek.chat.core.link.crypto.PairingResult
import com.avek.chat.core.link.discovery.FindClient
import com.avek.chat.core.link.discovery.FoundPc
import com.avek.chat.core.link.store.DeviceKey
import com.avek.chat.core.link.store.GrantSecrets
import com.avek.chat.core.link.store.IdentityVault
import com.avek.chat.core.link.store.PairedPc
import com.avek.chat.core.link.store.PairedPcStore
import com.avek.chat.core.link.transport.ChannelFactory
import com.avek.chat.core.link.transport.ChannelTarget
import com.avek.chat.core.link.transport.WifiBinding
import kotlinx.coroutines.CancellationException

/** Where to pair: a PC found by `find` on the Wi-Fi, or a Tailscale name/address the person typed. */
sealed interface PairTarget {
    data class Found(val pc: FoundPc) : PairTarget

    /** `ws://<host>:7810/ui` directly, over the default network (the pairing window lets anyone in). */
    data class Manual(val host: String) : PairTarget
}

/**
 * Pairing (UI-WIRE v4 section 3): finds PCs whose pairing window is open, creates a new identity
 * key, runs the two-secret exchange and stores the grant with `dk`/`rk` sealed. The code is held
 * only as a [CharArray] that the caller clears; the digits derived from it are wiped here.
 */
class PairingManager(
    private val store: PairedPcStore,
    private val identity: IdentityVault,
    private val secrets: GrantSecrets,
    private val channels: ChannelFactory,
    private val finder: FindClient,
    private val binding: WifiBinding,
    private val handshake: PairingHandshake = PairingHandshake(),
) {
    /** One round of `find` (about 5 s). Empty when no PC has its pairing window open. */
    suspend fun find(): List<FoundPc> = withWifi { finder.find() }

    suspend fun pair(target: PairTarget, code: CharArray, deviceName: String, onChecking: () -> Unit = {}): PairingResult {
        val digits = AvekProtocol.normalizeCodeDigits(code) ?: return PairingResult.NotPaired
        val alias = identity.nextAlias()
        var keep = false
        return try {
            identity.create(alias)
            val channelTarget = when (target) {
                is PairTarget.Found -> ChannelTarget.ws(target.pc.host, target.pc.port, viaWifi = true)
                is PairTarget.Manual -> ChannelTarget.ws(target.host.trim(), PairedPc.DEFAULT_PORT, viaWifi = false)
            }
            val channel = try {
                if (target is PairTarget.Found) withWifi { channels.open(channelTarget) } else channels.open(channelTarget)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                return PairingResult.NoRoute
            }
            val result = handshake.pair(channel, DeviceKey(identity, alias), digits, deviceName, onChecking = onChecking)
            if (result is PairingResult.Paired) {
                val grant = result.grant
                val sealed = try {
                    secrets.seal(grant.secrets)
                } finally {
                    grant.secrets.wipe()
                }
                // A new pairing replaces whatever was there (keys of an older pairing go).
                identity.aliases().filter { it != alias }.forEach { identity.delete(it) }
                store.save(
                    PairedPc(
                        deviceId = grant.deviceId,
                        identityAlias = alias,
                        serverId = grant.serverId,
                        serverName = grant.serverName,
                        serverPub = grant.serverPub,
                        deviceName = deviceName.trim().take(40).ifBlank { "Android" },
                        sealedSecrets = sealed,
                        lastWifiHost = (target as? PairTarget.Found)?.pc?.host,
                        lastWifiPort = (target as? PairTarget.Found)?.pc?.port ?: PairedPc.DEFAULT_PORT,
                    ),
                )
                keep = true
            }
            result
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            PairingResult.NotPaired
        } finally {
            digits.fill(0)
            if (!keep) runCatching { identity.delete(alias) }
        }
    }

    private suspend fun <T> withWifi(block: suspend () -> T): T {
        binding.acquire()
        try {
            return block()
        } finally {
            binding.release()
        }
    }
}
