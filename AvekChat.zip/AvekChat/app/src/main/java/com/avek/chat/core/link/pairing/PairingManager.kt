package com.avek.chat.core.link.pairing

import com.avek.chat.core.link.crypto.Handshake
import com.avek.chat.core.link.crypto.PairingDigits
import com.avek.chat.core.link.discovery.FindClient
import com.avek.chat.core.link.discovery.FoundPc
import com.avek.chat.core.link.store.IdentityVault
import com.avek.chat.core.link.store.PairedPc
import com.avek.chat.core.link.store.PairedPcStore
import com.avek.chat.core.link.transport.ChannelFactory
import com.avek.chat.core.link.transport.WifiBinding

/**
 * Pairing (UI-WIRE v3 section 3): finds PCs whose pairing window is open, then runs the
 * commit / reveal / six digits / approve exchange and pins the PC's key.
 */
class PairingManager(
    private val store: PairedPcStore,
    private val identity: IdentityVault,
    private val channels: ChannelFactory,
    private val finder: FindClient,
    private val binding: WifiBinding,
    private val handshake: Handshake = Handshake(),
) {
    /** One round of `find` (about 5 s). Empty when no PC has its pairing window open. */
    suspend fun find(): List<FoundPc> = withWifi { finder.find() }

    /**
     * Pairs with [pc]. [confirm] shows the six digits and returns the person's answer; [onAwaitingApproval]
     * is called once the PC must approve. Errors arrive as [com.avek.chat.core.link.crypto.HandshakeException].
     */
    suspend fun pair(
        pc: FoundPc,
        deviceName: String,
        confirm: suspend (PairingDigits) -> Boolean,
        onAwaitingApproval: () -> Unit,
    ): PairedPc = withWifi {
        identity.create()
        val channel = channels.open(pc.target)
        try {
            val server = handshake.pair(channel, identity, deviceName, confirm, onAwaitingApproval)
            val paired = PairedPc(
                serverId = server.serverId,
                serverName = server.serverName,
                serverPub = server.serverPub,
                deviceName = deviceName,
                lastHost = pc.host,
                lastPort = pc.port,
            )
            store.save(paired)
            paired
        } finally {
            channel.close()
        }
    }

    /** "Forget this PC": the stored PC and the device key both go (a new pairing makes a new key). */
    fun forget() {
        store.clear()
        identity.delete()
    }

    private suspend fun <T> withWifi(block: suspend () -> T): T {
        binding.acquire()
        try {
            return block()
        } finally {
            binding.release()
        }
    }
}
