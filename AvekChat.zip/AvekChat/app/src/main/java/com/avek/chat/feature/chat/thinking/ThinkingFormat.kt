package com.avek.chat.feature.chat.thinking

import com.avek.chat.core.domain.trace.TurnTelemetry
import java.util.Locale

/** The two sizes every style draws in: one or two lines (collapsed block) or the full panel. */
enum class ThinkingMode { Compact, Expanded }

/** Plain formatting of real numbers; "-" when there is no data yet (never a made-up value). */
object ThinkingFormat {
    const val NONE = "-"

    fun tokens(n: Int?): String = when {
        n == null -> NONE
        n >= 1_000_000 -> String.format(Locale.US, "%.1fM", n / 1_000_000.0)
        n >= 10_000 -> String.format(Locale.US, "%.0fK", n / 1_000.0)
        n >= 1_000 -> String.format(Locale.US, "%.1fK", n / 1_000.0)
        else -> n.toString()
    }

    fun ms(ms: Long?): String = when {
        ms == null -> NONE
        ms < 1_000 -> "$ms ms"
        ms < 60_000 -> String.format(Locale.US, "%.1f s", ms / 1000.0)
        else -> "${ms / 60_000} min ${(ms % 60_000) / 1000} s"
    }

    fun tps(tps: Double?): String = if (tps == null) NONE else if (tps >= 100) "${tps.toInt()} tok/s" else String.format(Locale.US, "%.1f tok/s", tps)

    fun percent(fraction: Float?): String = if (fraction == null) NONE else "${(fraction * 100).toInt()}%"

    fun mb(mb: Long?): String = when {
        mb == null -> NONE
        mb >= 1024 -> String.format(Locale.US, "%.1f GB", mb / 1024.0)
        else -> "$mb MB"
    }

    fun exact(exact: Boolean): String = if (exact) "exact" else "≈ estimate"

    /** Person-facing name of a phase key when the event had no label. */
    fun phaseName(phase: String): String = when (phase) {
        "queued" -> "Queued"
        "plugins" -> "Checking plug-ins"
        "attachments" -> "Reading attachments"
        "loading-model" -> "Loading the model"
        "opening-session" -> "Reserving memory"
        "building-context" -> "Building the prompt"
        "counting-tokens" -> "Counting tokens"
        "fitting-context" -> "Fitting the window"
        "growing-window" -> "Growing the window"
        "compacting" -> "Summarizing older turns"
        "prefill" -> "Reading the prompt"
        "thinking" -> "Thinking"
        "answering" -> "Answering"
        "writing-tool-call" -> "Writing a tool call"
        "running-tool" -> "Running a tool"
        "parking" -> "Lending memory"
        "resuming" -> "Taking memory back"
        "saving" -> "Saving"
        "done" -> "Done"
        else -> phase.replace('-', ' ').replaceFirstChar { it.uppercase() }
    }

    /** The phase line of the header: the open phase, or "Done" / "Stopped" when the turn ended. */
    fun phaseLabel(t: TurnTelemetry, isThinking: Boolean): String {
        val current = t.currentPhase
        return when {
            current != null -> current.label.ifEmpty { phaseName(current.phase) }
            t.live || isThinking -> t.lastPhase?.let { it.label.ifEmpty { phaseName(it.phase) } } ?: "Thinking"
            t.hasTrace -> "Done"
            else -> "Thought"
        }
    }

    /** Context category display order (the spec's keys). */
    val CATEGORY_ORDER = listOf("instructions", "tools", "summary", "history", "user", "assistant", "toolCalls", "toolResults")
}
