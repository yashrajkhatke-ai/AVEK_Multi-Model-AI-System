package com.avek.chat.core.domain.chat

import com.avek.chat.core.domain.repository.ChatRepository
import com.avek.chat.core.link.rpc.TextAssembler
import com.avek.chat.core.link.wire.LinkEvent
import com.avek.chat.core.model.MessageStatus
import com.avek.chat.core.model.TaskMode
import com.avek.chat.core.model.ThinkingDepth
import com.avek.chat.core.model.ToolCall
import com.avek.chat.core.data.remote.statusOf
import com.avek.chat.core.data.remote.toDomain
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.transformWhile

/**
 * Turns the events of ONE turn into [StreamingReply] snapshots. Deltas are applied with the
 * offset rules of UI-WIRE section 9 (so reconnects, resumes and late joins are always safe);
 * a gap triggers a reload of the turn with `turn.get`. Ends after `turn.completed`,
 * `turn.cancelled` or `turn.failed`.
 */
class TurnFollower(private val chats: ChatRepository) {

    fun follow(initial: StreamingReply, events: Flow<LinkEvent>): Flow<StreamingReply> {
        val chatId = initial.message.conversationId
        val promptId = checkNotNull(initial.message.promptId) { "A followed turn needs a promptId" }
        val answerKey = "$promptId:answer"
        val thinkingKey = "$promptId:thinking"
        val assembler = TextAssembler().apply {
            reset(answerKey, initial.message.content)
            reset(thinkingKey, initial.message.thinking.orEmpty())
        }
        var state = initial
        var askId: String? = null
        // Revision 2: the answer is the main model's answer blocks; the phase comes from the open block.
        var timeline = com.avek.chat.core.domain.timeline.TurnTimeline(com.avek.chat.core.domain.trace.TurnKey(chatId, promptId))

        suspend fun fromTimeline(): StreamingReply {
            if (timeline.toReload.isNotEmpty()) {
                try {
                    chats.timeline(chatId, promptId, timeline.toReload.toList())?.let {
                        timeline = com.avek.chat.core.domain.timeline.TimelineReducer.reduce(timeline, it)
                    }
                } catch (e: CancellationException) {
                    throw e
                } catch (_: Exception) {
                }
            }
            val open = timeline.openTopLevel
            val hasAnswer = timeline.topLevel.any { it.kind == com.avek.chat.core.domain.timeline.BlockKind.ANSWER }
            val content = if (hasAnswer) timeline.answerText else state.message.content
            val phase = when (open?.kind) {
                com.avek.chat.core.domain.timeline.BlockKind.ANSWER -> ReplyPhase.ANSWERING
                com.avek.chat.core.domain.timeline.BlockKind.THINKING, com.avek.chat.core.domain.timeline.BlockKind.TOOL -> ReplyPhase.THINKING
                else -> state.phase
            }
            return state.copy(
                message = state.message.copy(
                    content = content,
                    hasThinking = state.message.hasThinking || timeline.topLevel.any { it.kind != com.avek.chat.core.domain.timeline.BlockKind.ANSWER },
                ),
                phase = if (state.phase == ReplyPhase.DONE) ReplyPhase.DONE else phase,
                activity = if (open?.kind == com.avek.chat.core.domain.timeline.BlockKind.TOOL) open.title else if (open != null) null else state.activity,
            )
        }

        suspend fun reload(): StreamingReply {
            return try {
                val turn = chats.turn(chatId, promptId, withThinking = true)
                assembler.reset(answerKey, turn.assistant.content)
                assembler.reset(thinkingKey, turn.assistant.thinking.orEmpty())
                val done = turn.assistant.status != MessageStatus.STREAMING && turn.assistant.status != MessageStatus.WAITING
                state.copy(
                    user = turn.user.copy(uiKey = state.user.uiKey),
                    message = turn.assistant.copy(uiKey = state.message.uiKey),
                    phase = if (done) ReplyPhase.DONE else if (turn.assistant.content.isNotEmpty()) ReplyPhase.ANSWERING else state.phase,
                    activity = if (done) null else state.activity,
                )
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
                state // keep what we have; the next delta triggers another attempt
            }
        }

        fun matches(event: LinkEvent): Boolean = when (event) {
            is LinkEvent.TurnStarted -> event.data.chatId == chatId && event.data.promptId == promptId
            is LinkEvent.ThinkingDelta -> event.data.chatId == chatId && event.data.promptId == promptId
            is LinkEvent.AnswerDelta -> event.data.chatId == chatId && event.data.promptId == promptId
            is LinkEvent.ToolCall -> event.data.chatId == chatId && event.data.promptId == promptId
            is LinkEvent.ToolResult -> event.data.chatId == chatId && event.data.promptId == promptId
            is LinkEvent.Status -> event.data.chatId == chatId && event.data.promptId == promptId
            is LinkEvent.Sources -> event.data.chatId == chatId && event.data.promptId == promptId
            is LinkEvent.AskRequest -> event.data.chatId == chatId && event.data.promptId == promptId
            is LinkEvent.AskResolved -> event.data.askId == askId
            // After a reconnect the turn may have moved on without us: look again.
            is LinkEvent.Refresh -> true
            is LinkEvent.TurnCompleted -> event.data.chatId == chatId && event.data.promptId == promptId
            is LinkEvent.TurnCancelled -> event.data.chatId == chatId && event.data.promptId == promptId
            is LinkEvent.TurnFailed -> event.data.chatId == chatId && event.data.promptId == promptId
            is LinkEvent.BlockStart -> event.data.chatId == chatId && event.data.promptId == promptId
            is LinkEvent.BlockTitle -> event.data.chatId == chatId && event.data.promptId == promptId
            is LinkEvent.BlockDelta -> event.data.chatId == chatId && event.data.promptId == promptId
            is LinkEvent.BlockState -> event.data.chatId == chatId && event.data.promptId == promptId
            is LinkEvent.BlockEnd -> event.data.chatId == chatId && event.data.promptId == promptId
            else -> false
        }

        return kotlinx.coroutines.flow.flow {
            emit(initial)
            if (initial.phase == ReplyPhase.DONE) return@flow
            events.transformWhile { event ->
                if (!matches(event)) return@transformWhile true
                val before = state
                var terminal = false
                when (event) {
                    is LinkEvent.TurnStarted -> {
                        val depth = ThinkingDepth.fromLevel(event.data.depth)
                        state = state.copy(
                            message = state.message.copy(
                                status = MessageStatus.STREAMING,
                                depth = depth,
                                modelId = event.data.modelId ?: state.message.modelId,
                                requestedTask = TaskMode.fromWire(event.data.mode),
                                hasThinking = depth.thinks || state.message.hasThinking,
                            ),
                            phase = if (depth.thinks && state.message.content.isEmpty()) ReplyPhase.THINKING else ReplyPhase.ANSWERING,
                        )
                    }
                    is LinkEvent.ThinkingDelta -> when (assembler.apply(thinkingKey, event.data.offset, event.data.text)) {
                        is TextAssembler.Outcome.Appended -> state = state.copy(
                            message = state.message.copy(thinking = assembler.text(thinkingKey), hasThinking = true),
                            phase = if (state.message.content.isEmpty()) ReplyPhase.THINKING else state.phase,
                        )
                        TextAssembler.Outcome.Duplicate -> Unit
                        TextAssembler.Outcome.Reload -> state = reload()
                    }
                    is LinkEvent.AnswerDelta -> when (assembler.apply(answerKey, event.data.offset, event.data.text)) {
                        is TextAssembler.Outcome.Appended -> state = state.copy(
                            message = state.message.copy(content = assembler.text(answerKey)),
                            phase = ReplyPhase.ANSWERING,
                        )
                        TextAssembler.Outcome.Duplicate -> Unit
                        TextAssembler.Outcome.Reload -> state = reload()
                    }
                    is LinkEvent.ToolCall -> {
                        val call = ToolCall(event.data.callId, event.data.name, event.data.title, event.data.detail, ok = null)
                        state = state.copy(
                            message = state.message.copy(tools = state.message.tools.upsert(call)),
                            activity = call.title,
                        )
                    }
                    is LinkEvent.ToolResult -> {
                        val tools = state.message.tools.map {
                            if (it.callId == event.data.callId) it.copy(ok = event.data.ok, title = event.data.title.ifEmpty { it.title }) else it
                        }.let { list ->
                            if (list.any { it.callId == event.data.callId }) list
                            else list + ToolCall(event.data.callId, "", event.data.title, null, event.data.ok)
                        }
                        state = state.copy(message = state.message.copy(tools = tools), activity = null)
                    }
                    is LinkEvent.Status -> state = state.copy(
                        activity = if (event.data.state == "done" || event.data.state == "error") null else event.data.text.ifEmpty { state.activity },
                    )
                    is LinkEvent.Sources -> state = state.copy(message = state.message.copy(sources = event.data.sources.map { it.toDomain() }))
                    is LinkEvent.AskRequest -> {
                        askId = event.data.askId
                        state = state.copy(message = state.message.copy(status = MessageStatus.WAITING))
                    }
                    is LinkEvent.AskResolved -> {
                        askId = null
                        state = state.copy(message = state.message.copy(status = MessageStatus.STREAMING))
                    }
                    is LinkEvent.TurnCompleted -> {
                        terminal = true
                        state = state.copy(
                            message = state.message.copy(
                                status = MessageStatus.COMPLETE,
                                thinkingDurationMs = event.data.thinkingMs.takeIf { it > 0 } ?: state.message.thinkingDurationMs,
                            ),
                            phase = ReplyPhase.DONE,
                            activity = null,
                        )
                    }
                    is LinkEvent.TurnCancelled -> {
                        terminal = true
                        state = state.copy(message = state.message.copy(status = MessageStatus.STOPPED), phase = ReplyPhase.DONE, activity = null)
                    }
                    is LinkEvent.TurnFailed -> {
                        terminal = true
                        state = state.copy(
                            message = state.message.copy(status = MessageStatus.ERROR, error = event.data.message),
                            phase = ReplyPhase.DONE,
                            activity = null,
                        )
                    }
                    is LinkEvent.Refresh -> state = reload()
                    is LinkEvent.BlockStart, is LinkEvent.BlockTitle, is LinkEvent.BlockDelta, is LinkEvent.BlockState, is LinkEvent.BlockEnd -> {
                        timeline = com.avek.chat.core.domain.timeline.TimelineReducer.reduce(timeline, event)
                        state = fromTimeline()
                    }
                    else -> Unit
                }
                if (state != before) emit(state)
                if (!terminal && state.phase == ReplyPhase.DONE) terminal = true // a reload found the turn already finished
                !terminal
            }.collect { emit(it) }
        }
    }

    private fun List<ToolCall>.upsert(call: ToolCall): List<ToolCall> =
        if (any { it.callId == call.callId }) map { if (it.callId == call.callId) call.copy(body = it.body) else it } else this + call
}
