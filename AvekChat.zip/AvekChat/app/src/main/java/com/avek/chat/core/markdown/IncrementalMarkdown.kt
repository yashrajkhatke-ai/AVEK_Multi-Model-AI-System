package com.avek.chat.core.markdown

/**
 * Streaming-friendly parsing (v3 task D.2): the answer grows by one token at a time, so only the
 * part after the last *settled* point is parsed again. A point is settled at a blank line outside a
 * code fence: there the parser holds no open block (paragraph, list, quote, table or fence), so
 * `parse(a + b) == parse(a) + parse(b)` for such a split. Completed blocks keep their position (a
 * stable key for the UI) and are never re-parsed; the result always equals a full parse.
 */
class IncrementalMarkdown {
    private var source: String = ""

    /** End of the settled prefix (just after a blank line outside a fence). */
    private var settledEnd = 0
    private var settledBlocks: List<MdBlock> = emptyList()

    /** Scan position (start of the first line not scanned yet) and whether it is inside a fence. */
    private var scanPos = 0
    private var inFence = false

    /** Number of blocks at the start of the last result that are settled (stable). */
    var settledCount: Int = 0
        private set

    fun update(markdown: String): List<MdBlock> {
        val text = if (markdown.indexOf('\r') >= 0) markdown.replace("\r\n", "\n") else markdown
        if (!text.startsWith(source) || text.length < settledEnd) reset()
        source = text

        var newSettled = settledEnd
        var pos = scanPos
        while (true) {
            val nl = text.indexOf('\n', pos)
            if (nl < 0) break // the last line is still being written
            val line = text.substring(pos, nl)
            if (!inFence && FENCE.matches(line)) {
                inFence = true
            } else if (inFence && line.trim().startsWith("```")) {
                inFence = false
            } else if (!inFence && line.isBlank()) {
                newSettled = nl + 1
            }
            pos = nl + 1
        }
        scanPos = pos
        if (newSettled > settledEnd) {
            settledBlocks = settledBlocks + MarkdownParser.parse(text.substring(settledEnd, newSettled))
            settledEnd = newSettled
        }
        settledCount = settledBlocks.size
        val tail = text.substring(settledEnd)
        return if (tail.isEmpty()) settledBlocks else settledBlocks + MarkdownParser.parse(tail)
    }

    private fun reset() {
        source = ""
        settledEnd = 0
        settledBlocks = emptyList()
        scanPos = 0
        inFence = false
        settledCount = 0
    }

    private companion object {
        /** Must match the opening-fence rule of [MarkdownParser]. */
        val FENCE = Regex("^\\s*```\\s*([\\w+#.-]*)\\s*$")
    }
}
