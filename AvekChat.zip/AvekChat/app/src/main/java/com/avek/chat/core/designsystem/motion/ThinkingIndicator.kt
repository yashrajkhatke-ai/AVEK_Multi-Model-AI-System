package com.avek.chat.core.designsystem.motion

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.runtime.State
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.dp
import com.avek.chat.core.model.settings.ThinkingAnimation
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

private const val TAU = (2 * PI).toFloat()

/**
 * A continuously running phase in [0, 1). Reading `.value` inside a draw
 * lambda means only the draw phase re-runs each frame — no recomposition.
 */
@Composable
fun rememberPhase(durationMillis: Int, animate: Boolean = true, label: String = "phase"): State<Float> {
    if (!animate) return remember { mutableFloatStateOf(0.3f) }
    val transition = rememberInfiniteTransition(label = label)
    return transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(durationMillis.coerceAtLeast(200), easing = LinearEasing), RepeatMode.Restart),
        label = label,
    )
}

/**
 * The animated "thinking" glyph. Ten distinct styles, all drawn on a Canvas.
 *
 * @param intensity 0..1, typically derived from the thinking depth — more
 *   particles, more rays, faster motion.
 * @param speed user-configured animation speed multiplier.
 */
@Composable
fun ThinkingIndicator(
    style: ThinkingAnimation,
    color: Color,
    modifier: Modifier = Modifier.size(22.dp),
    intensity: Float = 0.5f,
    speed: Float = 1f,
    animate: Boolean = true,
) {
    val k = intensity.coerceIn(0f, 1f)
    val base = when (style) {
        ThinkingAnimation.SHIMMER -> 1600
        ThinkingAnimation.GALAXY -> 6000
        ThinkingAnimation.CONSTELLATION -> 4200
        ThinkingAnimation.HELIX -> 2600
        else -> 2400
    }
    val duration = (base / speed.coerceIn(0.25f, 3f) / (0.8f + 0.4f * k)).toInt()
    val phase = rememberPhase(duration, animate, label = "thinking-${style.name}")
    Canvas(modifier) {
        val t = phase.value
        when (style) {
            ThinkingAnimation.SPARK -> drawSpark(t, color, k)
            ThinkingAnimation.ORBIT -> drawOrbit(t, color, 2 + (k * 3).toInt())
            ThinkingAnimation.PULSE -> drawPulse(t, color, 2 + (k * 2).toInt())
            ThinkingAnimation.WAVE -> drawWave(t, color, 3 + (k * 2).toInt())
            ThinkingAnimation.SHIMMER -> drawShimmerBars(t, color)
            ThinkingAnimation.MORPH -> drawMorph(t, color, k)
            ThinkingAnimation.GALAXY -> drawGalaxy(t, color, 16 + (k * 24).toInt())
            ThinkingAnimation.HELIX -> drawHelix(t, color)
            ThinkingAnimation.BARS -> drawBars(t, color, 4 + (k * 2).toInt())
            ThinkingAnimation.CONSTELLATION -> drawConstellation(t, color, 6 + (k * 4).toInt())
        }
    }
}

// ---------------------------------------------------------------------------
// Drawing primitives. Every function draws into the full DrawScope bounds.
// ---------------------------------------------------------------------------

internal fun DrawScope.drawSpark(t: Float, color: Color, intensity: Float, rays: Int = 8 + (intensity * 6).toInt()) {
    val r = size.minDimension / 2f
    val stroke = (size.minDimension * 0.085f).coerceAtLeast(1.5f)
    rotate(t * 180f) {
        for (i in 0 until rays) {
            val a = TAU * i / rays
            val wave = 0.5f + 0.5f * sin(TAU * (t * 2f + i.toFloat() / rays))
            val length = r * (if (i % 2 == 0) 0.62f else 0.45f + 0.1f * intensity) * (0.7f + 0.3f * wave) + r * 0.25f
            val start = center + Offset(cos(a), sin(a)) * (r * 0.16f)
            val end = center + Offset(cos(a), sin(a)) * length.coerceAtMost(r - stroke / 2)
            drawLine(color.copy(alpha = 0.65f + 0.35f * wave), start, end, strokeWidth = stroke, cap = StrokeCap.Round)
        }
    }
    drawCircle(color, radius = r * 0.14f, center = center)
}

internal fun DrawScope.drawOrbit(t: Float, color: Color, satellites: Int) {
    val r = size.minDimension / 2f
    val orbitR = r * 0.72f
    drawCircle(color.copy(alpha = 0.16f), radius = orbitR, center = center, style = Stroke(width = r * 0.06f))
    val corePulse = 0.85f + 0.15f * sin(TAU * t * 2f)
    drawCircle(color, radius = r * 0.2f * corePulse, center = center)
    for (i in 0 until satellites) {
        val speed = 1f + i * 0.35f
        val angle = TAU * (t * speed) + TAU * i / satellites
        val pos = center + Offset(cos(angle), sin(angle)) * orbitR
        // A short fading trail behind each satellite.
        for (trail in 0..3) {
            val ta = angle - trail * 0.22f
            val tp = center + Offset(cos(ta), sin(ta)) * orbitR
            drawCircle(color.copy(alpha = 0.5f / (trail + 1)), radius = r * (0.13f - trail * 0.02f), center = tp)
        }
        drawCircle(color, radius = r * 0.14f, center = pos)
    }
}

internal fun DrawScope.drawPulse(t: Float, color: Color, rings: Int) {
    val r = size.minDimension / 2f
    for (i in 0 until rings) {
        val p = (t + i.toFloat() / rings) % 1f
        drawCircle(
            color = color.copy(alpha = (1f - p) * 0.9f),
            radius = r * (0.2f + 0.78f * p),
            center = center,
            style = Stroke(width = r * 0.1f * (1f - p * 0.6f)),
        )
    }
    drawCircle(color, radius = r * (0.2f + 0.05f * sin(TAU * t)), center = center)
}

internal fun DrawScope.drawWave(t: Float, color: Color, dots: Int) {
    val w = size.width
    val h = size.height
    val radius = min(w / (dots * 2.6f), h * 0.16f)
    val spacing = (w - radius * 2) / (dots - 1).coerceAtLeast(1)
    for (i in 0 until dots) {
        val phase = TAU * (t - i * 0.12f)
        val y = h / 2 + sin(phase) * h * 0.28f
        val scale = 0.75f + 0.25f * ((sin(phase) + 1f) / 2f)
        drawCircle(color.copy(alpha = 0.55f + 0.45f * scale), radius = radius * scale, center = Offset(radius + i * spacing, y))
    }
}

internal fun DrawScope.drawShimmerBars(t: Float, color: Color) {
    val w = size.width
    val h = size.height
    val barH = h * 0.18f
    val widths = floatArrayOf(1f, 0.72f, 0.86f)
    val x = (-0.6f + 2.2f * t) * w
    val brush = Brush.linearGradient(
        colors = listOf(color.copy(alpha = 0.22f), color.copy(alpha = 0.95f), color.copy(alpha = 0.22f)),
        start = Offset(x - w * 0.45f, 0f),
        end = Offset(x + w * 0.45f, 0f),
    )
    widths.forEachIndexed { i, fraction ->
        val top = h * 0.14f + i * (barH + h * 0.1f)
        drawRoundRect(brush, topLeft = Offset(0f, top), size = Size(w * fraction, barH), cornerRadius = CornerRadius(barH / 2))
    }
}

internal fun DrawScope.drawMorph(t: Float, color: Color, intensity: Float) {
    val r = size.minDimension / 2f * 0.78f
    val path = Path()
    val steps = 72
    for (s in 0..steps) {
        val theta = TAU * s / steps
        val wobble = 1f +
            0.11f * sin(3 * theta + TAU * t) +
            (0.05f + 0.06f * intensity) * sin(5 * theta - TAU * 2 * t) +
            0.04f * cos(2 * theta + TAU * t)
        val p = center + Offset(cos(theta), sin(theta)) * (r * wobble)
        if (s == 0) path.moveTo(p.x, p.y) else path.lineTo(p.x, p.y)
    }
    path.close()
    drawPath(
        path,
        Brush.radialGradient(
            colors = listOf(color, color.copy(alpha = 0.55f)),
            center = center + Offset(cos(TAU * t), sin(TAU * t)) * (r * 0.25f),
            radius = r * 1.2f,
        ),
    )
}

internal fun DrawScope.drawGalaxy(t: Float, color: Color, particles: Int) {
    val r = size.minDimension / 2f
    val golden = 2.39996f
    for (i in 0 until particles) {
        val f = sqrt((i + 0.5f) / particles)
        val angle = i * golden + TAU * t * (1.6f - f)
        val pos = center + Offset(cos(angle), sin(angle)) * (r * 0.92f * f)
        val twinkle = 0.6f + 0.4f * sin(TAU * (t * 3f + i * 0.17f))
        drawCircle(color.copy(alpha = (1.05f - f * 0.6f) * twinkle), radius = r * (0.09f - 0.05f * f), center = pos)
    }
    drawCircle(color, radius = r * 0.12f, center = center)
}

internal fun DrawScope.drawHelix(t: Float, color: Color) {
    val w = size.width
    val h = size.height
    val rungs = 7
    val step = w / (rungs + 1)
    for (i in 1..rungs) {
        val phase = TAU * (t + i.toFloat() / rungs)
        val x = i * step
        val y1 = h / 2 + sin(phase) * h * 0.32f
        val y2 = h / 2 - sin(phase) * h * 0.32f
        val depth = (cos(phase) + 1f) / 2f
        drawLine(color.copy(alpha = 0.18f), Offset(x, y1), Offset(x, y2), strokeWidth = h * 0.04f)
        drawCircle(color.copy(alpha = 0.35f + 0.65f * depth), radius = h * (0.05f + 0.05f * depth), center = Offset(x, y1))
        drawCircle(color.copy(alpha = 0.35f + 0.65f * (1 - depth)), radius = h * (0.05f + 0.05f * (1 - depth)), center = Offset(x, y2))
    }
}

internal fun DrawScope.drawBars(t: Float, color: Color, bars: Int) {
    val w = size.width
    val h = size.height
    val gap = w * 0.08f
    val barW = (w - gap * (bars - 1)) / bars
    for (i in 0 until bars) {
        val level = 0.22f + 0.78f * abs(sin(TAU * t * (1f + i * 0.21f) + i * 1.3f))
        val barH = h * level
        drawRoundRect(
            color = color.copy(alpha = 0.55f + 0.45f * level),
            topLeft = Offset(i * (barW + gap), (h - barH) / 2),
            size = Size(barW, barH),
            cornerRadius = CornerRadius(barW / 2),
        )
    }
}

internal fun DrawScope.drawConstellation(t: Float, color: Color, stars: Int) {
    val w = size.width
    val h = size.height
    val points = (0 until stars).map { i ->
        // Deterministic pseudo-random layout that gently drifts.
        val px = ((i * 0.618034f + 0.13f) % 1f) * 0.8f + 0.1f
        val py = ((i * 0.381966f * 1.7f + 0.27f) % 1f) * 0.8f + 0.1f
        Offset(
            (px + 0.03f * sin(TAU * (t + i * 0.1f))) * w,
            (py + 0.03f * cos(TAU * (t + i * 0.13f))) * h,
        )
    }
    val progress = t * stars
    for (i in 0 until stars - 1) {
        val reveal = (progress - i).coerceIn(0f, 1f)
        if (reveal > 0f) {
            val a = points[i]
            val b = points[i + 1]
            drawLine(color.copy(alpha = 0.45f), a, a + (b - a) * reveal, strokeWidth = size.minDimension * 0.035f, cap = StrokeCap.Round)
        }
    }
    points.forEachIndexed { i, p ->
        val twinkle = 0.5f + 0.5f * sin(TAU * (t * 2f + i * 0.31f))
        drawCircle(color.copy(alpha = 0.5f + 0.5f * twinkle), radius = size.minDimension * (0.04f + 0.03f * twinkle), center = p)
    }
}
