package com.avek.chat

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import android.view.WindowManager
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.avek.chat.core.designsystem.component.FilePicker
import com.avek.chat.core.designsystem.component.LocalFilePicker
import com.avek.chat.core.designsystem.component.LocalPlatformActions
import com.avek.chat.core.designsystem.component.LocalShareHandler
import com.avek.chat.core.designsystem.component.PlatformActions
import com.avek.chat.core.domain.chat.OpenChatBus
import com.avek.chat.platform.android.AvekNotifications
import com.avek.chat.core.designsystem.component.ShareHandler
import com.avek.chat.core.designsystem.theme.AvekTheme
import com.avek.chat.core.designsystem.theme.FontResolver
import com.avek.chat.core.designsystem.theme.isDark
import com.avek.chat.navigation.AvekNavHost
import com.avek.chat.core.domain.lock.AppLockManager
import com.avek.chat.feature.lock.LocalPhoneAuthenticator
import com.avek.chat.feature.lock.LockRoute
import com.avek.chat.platform.android.BiometricAuthenticator
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class MainActivity : FragmentActivity() {

    @Inject lateinit var fontResolver: FontResolver
    @Inject lateinit var openChat: OpenChatBus
    @Inject lateinit var appLock: AppLockManager
    @Inject lateinit var settingsState: kotlinx.coroutines.flow.StateFlow<com.avek.chat.core.model.settings.UserSettings>

    /**
     * True while something this activity started itself is on top (the file picker, the share sheet, a
     * permission dialog): coming back from it is not "returning to the app". (The fingerprint/PIN prompt
     * needs no flag: it only shows while the app is locked, when leaving and returning change nothing.)
     */
    @Volatile
    private var ownScreenOnTop = false

    private val phoneAuthenticator by lazy { BiometricAuthenticator(this) { } }

    private val viewModel: MainViewModel by viewModels()

    private val shareHandler = ShareHandler { text ->
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
        }
        ownScreenOnTop = true
        startActivity(Intent.createChooser(send, null))
    }

    // ---- system file picker (Storage Access Framework)
    private var pickCallback: ((List<String>) -> Unit)? = null
    private val pickDocuments = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        val callback = pickCallback
        pickCallback = null
        callback?.invoke(uris.map(Uri::toString))
    }
    private val filePicker = FilePicker { mimeTypes, onPicked ->
        pickCallback = onPicked
        ownScreenOnTop = true
        pickDocuments.launch(mimeTypes.toTypedArray())
    }

    // ---- notification permission and battery optimisation
    private var permissionCallback: ((Boolean) -> Unit)? = null
    private val requestPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        val callback = permissionCallback
        permissionCallback = null
        callback?.invoke(granted)
    }
    private val platformActions = object : PlatformActions {
        override fun requestNotificationPermission(onResult: (Boolean) -> Unit) {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
                ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
            ) {
                onResult(true)
            } else {
                permissionCallback = onResult
                ownScreenOnTop = true
                requestPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }

        override fun isIgnoringBatteryOptimizations(): Boolean =
            (getSystemService(POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(packageName)

        override fun requestIgnoreBatteryOptimizations() {
            // Offered, never forced: the system shows its own confirmation dialog.
            runCatching {
                ownScreenOnTop = true
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            }
        }
    }

    // ---- the app lock: every return to the foreground asks again (unless within the grace period)

    override fun onStart() {
        super.onStart()
        if (ownScreenOnTop) {
            ownScreenOnTop = false
        } else {
            appLock.onForeground(settingsState.value.security.graceMinutes)
        }
    }

    override fun onResume() {
        super.onResume()
        ownScreenOnTop = false
    }

    override fun onStop() {
        super.onStop()
        if (!isChangingConfigurations && !ownScreenOnTop) appLock.onBackground()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleChatIntent(intent)
    }

    /** A notification tap carries the chat to open. */
    private fun handleChatIntent(intent: Intent?) {
        intent?.getStringExtra(AvekNotifications.EXTRA_CHAT_ID)?.let { chatId ->
            intent.removeExtra(AvekNotifications.EXTRA_CHAT_ID)
            openChat.open(chatId)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        val splash = installSplashScreen()
        super.onCreate(savedInstanceState)
        // Secure until the settings say otherwise (the first frame must not be capturable either).
        window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        splash.setKeepOnScreenCondition { viewModel.uiState.value is MainUiState.Loading }
        enableEdgeToEdge()
        handleChatIntent(intent)

        setContent {
            val state by viewModel.uiState.collectAsStateWithLifecycle()
            when (val current = state) {
                MainUiState.Loading -> Unit
                is MainUiState.Ready -> {
                    val dark = current.appearance.isDark(isSystemInDarkTheme())
                    // FLAG_SECURE by default: no screenshots, hidden in the recents list ("Allow screenshots" turns it off).
                    LaunchedEffect(current.security.allowScreenshots) {
                        if (current.security.allowScreenshots) {
                            window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
                        } else {
                            window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
                        }
                    }
                    // Keep status / navigation bar icons legible on the active theme.
                    LaunchedEffect(dark) {
                        enableEdgeToEdge(
                            statusBarStyle = SystemBarStyle.auto(Color.TRANSPARENT, Color.TRANSPARENT) { dark },
                            navigationBarStyle = SystemBarStyle.auto(Color.TRANSPARENT, Color.TRANSPARENT) { dark },
                        )
                    }
                    CompositionLocalProvider(
                        LocalShareHandler provides shareHandler,
                        LocalFilePicker provides filePicker,
                        LocalPlatformActions provides platformActions,
                        LocalPhoneAuthenticator provides phoneAuthenticator,
                    ) {
                        AvekTheme(appearance = current.appearance, fontResolver = fontResolver) {
                            LockRoute { AvekNavHost() }
                        }
                    }
                }
            }
        }
    }
}
