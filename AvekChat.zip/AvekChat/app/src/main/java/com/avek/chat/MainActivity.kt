package com.avek.chat

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.avek.chat.core.designsystem.component.FilePicker
import com.avek.chat.core.designsystem.component.LocalFilePicker
import com.avek.chat.core.designsystem.component.LocalPlatformActions
import com.avek.chat.core.designsystem.component.LocalShareHandler
import com.avek.chat.core.designsystem.component.PlatformActions
import com.avek.chat.core.domain.chat.OpenChatBus
import com.avek.chat.platform.android.AvekNotifications
import com.avek.chat.core.designsystem.component.ShareHandler
import com.avek.chat.core.designsystem.theme.AvekTheme
import com.avek.chat.core.designsystem.theme.FontResolver
import com.avek.chat.core.designsystem.theme.isDark
import com.avek.chat.navigation.AvekNavHost
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    @Inject lateinit var fontResolver: FontResolver
    @Inject lateinit var openChat: OpenChatBus

    private val viewModel: MainViewModel by viewModels()

    private val shareHandler = ShareHandler { text ->
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
        }
        startActivity(Intent.createChooser(send, null))
    }

    // ---- system file picker (Storage Access Framework)
    private var pickCallback: ((List<String>) -> Unit)? = null
    private val pickDocuments = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        val callback = pickCallback
        pickCallback = null
        callback?.invoke(uris.map(Uri::toString))
    }
    private val filePicker = FilePicker { mimeTypes, onPicked ->
        pickCallback = onPicked
        pickDocuments.launch(mimeTypes.toTypedArray())
    }

    // ---- notification permission and battery optimisation
    private var permissionCallback: ((Boolean) -> Unit)? = null
    private val requestPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        val callback = permissionCallback
        permissionCallback = null
        callback?.invoke(granted)
    }
    private val platformActions = object : PlatformActions {
        override fun requestNotificationPermission(onResult: (Boolean) -> Unit) {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
                ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
            ) {
                onResult(true)
            } else {
                permissionCallback = onResult
                requestPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }

        override fun isIgnoringBatteryOptimizations(): Boolean =
            (getSystemService(POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(packageName)

        override fun requestIgnoreBatteryOptimizations() {
            // Offered, never forced: the system shows its own confirmation dialog.
            runCatching {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleChatIntent(intent)
    }

    /** A notification tap carries the chat to open. */
    private fun handleChatIntent(intent: Intent?) {
        intent?.getStringExtra(AvekNotifications.EXTRA_CHAT_ID)?.let { chatId ->
            intent.removeExtra(AvekNotifications.EXTRA_CHAT_ID)
            openChat.open(chatId)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        val splash = installSplashScreen()
        super.onCreate(savedInstanceState)
        splash.setKeepOnScreenCondition { viewModel.uiState.value is MainUiState.Loading }
        enableEdgeToEdge()
        handleChatIntent(intent)

        setContent {
            val state by viewModel.uiState.collectAsStateWithLifecycle()
            when (val current = state) {
                MainUiState.Loading -> Unit
                is MainUiState.Ready -> {
                    val dark = current.appearance.isDark(isSystemInDarkTheme())
                    // Keep status / navigation bar icons legible on the active theme.
                    LaunchedEffect(dark) {
                        enableEdgeToEdge(
                            statusBarStyle = SystemBarStyle.auto(Color.TRANSPARENT, Color.TRANSPARENT) { dark },
                            navigationBarStyle = SystemBarStyle.auto(Color.TRANSPARENT, Color.TRANSPARENT) { dark },
                        )
                    }
                    CompositionLocalProvider(
                        LocalShareHandler provides shareHandler,
                        LocalFilePicker provides filePicker,
                        LocalPlatformActions provides platformActions,
                    ) {
                        AvekTheme(appearance = current.appearance, fontResolver = fontResolver) {
                            AvekNavHost()
                        }
                    }
                }
            }
        }
    }
}
