package com.avek.chat

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.avek.chat.core.designsystem.component.LocalShareHandler
import com.avek.chat.core.designsystem.component.ShareHandler
import com.avek.chat.core.designsystem.theme.AvekTheme
import com.avek.chat.core.designsystem.theme.FontResolver
import com.avek.chat.core.designsystem.theme.isDark
import com.avek.chat.navigation.AvekNavHost
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    @Inject lateinit var fontResolver: FontResolver

    private val viewModel: MainViewModel by viewModels()

    private val shareHandler = ShareHandler { text ->
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
        }
        startActivity(Intent.createChooser(send, null))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        val splash = installSplashScreen()
        super.onCreate(savedInstanceState)
        splash.setKeepOnScreenCondition { viewModel.uiState.value is MainUiState.Loading }
        enableEdgeToEdge()

        setContent {
            val state by viewModel.uiState.collectAsStateWithLifecycle()
            when (val current = state) {
                MainUiState.Loading -> Unit
                is MainUiState.Ready -> {
                    val dark = current.appearance.isDark(isSystemInDarkTheme())
                    // Keep status / navigation bar icons legible on the active theme.
                    LaunchedEffect(dark) {
                        enableEdgeToEdge(
                            statusBarStyle = SystemBarStyle.auto(Color.TRANSPARENT, Color.TRANSPARENT) { dark },
                            navigationBarStyle = SystemBarStyle.auto(Color.TRANSPARENT, Color.TRANSPARENT) { dark },
                        )
                    }
                    CompositionLocalProvider(LocalShareHandler provides shareHandler) {
                        AvekTheme(appearance = current.appearance, fontResolver = fontResolver) {
                            AvekNavHost()
                        }
                    }
                }
            }
        }
    }
}
