package com.avek.chat.core.designsystem.theme

import androidx.compose.material3.Typography
import androidx.compose.runtime.Immutable
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import com.avek.chat.core.model.settings.FontRole
import com.avek.chat.core.model.settings.FontSettings
import com.avek.chat.core.model.settings.TextStyleSettings

/** Resolved, render-ready text styles for every role in the app. */
@Immutable
data class AvekTypography(
    val body: TextStyle,
    val bodySmall: TextStyle,
    val label: TextStyle,
    val caption: TextStyle,
    val title: TextStyle,
    val headline: TextStyle,
    val display: TextStyle,
    val userMessage: TextStyle,
    val answer: TextStyle,
    val thinking: TextStyle,
    val code: TextStyle,
) {
    operator fun get(role: FontRole): TextStyle = when (role) {
        FontRole.INTERFACE -> body
        FontRole.HEADING -> display
        FontRole.USER_MESSAGE -> userMessage
        FontRole.ANSWER -> answer
        FontRole.THINKING -> thinking
        FontRole.CODE -> code
    }

    fun toMaterial(): Typography {
        val base = Typography()
        return base.copy(
            displayLarge = display.copy(fontSize = display.fontSize * 1.4f),
            displayMedium = display.copy(fontSize = display.fontSize * 1.15f),
            displaySmall = display,
            headlineLarge = headline.copy(fontSize = 28.sp),
            headlineMedium = headline,
            headlineSmall = headline.copy(fontSize = 20.sp),
            titleLarge = title.copy(fontSize = 20.sp),
            titleMedium = title,
            titleSmall = title.copy(fontSize = 14.sp),
            bodyLarge = body.copy(fontSize = 16.sp),
            bodyMedium = body,
            bodySmall = bodySmall,
            labelLarge = label.copy(fontSize = 14.sp),
            labelMedium = label,
            labelSmall = caption,
        )
    }

    companion object {
        fun resolve(settings: FontSettings, resolver: FontResolver): AvekTypography {
            val ui = settings.interfaceText.toTextStyle(resolver)
            val heading = settings.heading.toTextStyle(resolver)
            val uiSize = settings.interfaceText.sizeSp
            return AvekTypography(
                body = ui,
                bodySmall = ui.copy(fontSize = (uiSize - 2f).sp, lineHeight = ((uiSize - 2f) * 1.4f).sp),
                label = ui.copy(fontSize = (uiSize - 2.5f).sp, fontWeight = FontWeight.Medium, lineHeight = ((uiSize - 2.5f) * 1.3f).sp),
                caption = ui.copy(fontSize = (uiSize - 4f).sp, lineHeight = ((uiSize - 4f) * 1.3f).sp),
                title = ui.copy(fontSize = (uiSize + 2f).sp, fontWeight = FontWeight.SemiBold, lineHeight = ((uiSize + 2f) * 1.3f).sp),
                headline = heading.copy(fontSize = (settings.heading.sizeSp * 0.8f).sp, lineHeight = (settings.heading.sizeSp * 0.8f * 1.25f).sp),
                display = heading,
                userMessage = settings.userMessage.toTextStyle(resolver),
                answer = settings.answer.toTextStyle(resolver),
                thinking = settings.thinking.toTextStyle(resolver),
                code = settings.code.toTextStyle(resolver),
            )
        }

        fun TextStyleSettings.toTextStyle(resolver: FontResolver): TextStyle = TextStyle(
            fontFamily = resolver.resolve(font),
            fontSize = sizeSp.sp,
            fontWeight = FontWeight(weight.coerceIn(100, 900)),
            fontStyle = if (italic) FontStyle.Italic else FontStyle.Normal,
            lineHeight = (sizeSp * lineHeight).sp,
            letterSpacing = letterSpacing.em,
        )
    }
}
