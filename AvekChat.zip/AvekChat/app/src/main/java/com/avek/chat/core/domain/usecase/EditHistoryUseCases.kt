package com.avek.chat.core.domain.usecase

import com.avek.chat.core.domain.repository.ConversationRepository
import com.avek.chat.core.model.Message
import com.avek.chat.core.model.TaskMode
import javax.inject.Inject

/** Drops an assistant reply (and anything after it) so it can be generated again. */
class PrepareRegenerationUseCase @Inject constructor(
    private val repository: ConversationRepository,
) {
    suspend operator fun invoke(reply: Message) {
        repository.deleteMessagesFrom(reply.conversationId, reply.createdAt)
    }
}

/** Rewrites a user message in place and truncates the conversation after it. */
class EditUserMessageUseCase @Inject constructor(
    private val repository: ConversationRepository,
) {
    suspend operator fun invoke(message: Message, newContent: String, modelId: String, task: TaskMode) {
        val content = newContent.trim()
        require(content.isNotEmpty()) { "Message cannot be empty" }
        repository.deleteMessagesFrom(message.conversationId, message.createdAt + 1)
        repository.upsertMessage(message.copy(content = content))
        repository.refreshSummary(message.conversationId, modelId, task)
    }
}
