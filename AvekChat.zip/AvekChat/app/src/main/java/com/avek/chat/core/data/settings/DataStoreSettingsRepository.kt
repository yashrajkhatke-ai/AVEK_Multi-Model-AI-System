package com.avek.chat.core.data.settings

import androidx.datastore.core.DataStore
import com.avek.chat.core.domain.repository.SettingsRepository
import com.avek.chat.core.model.settings.UserSettings
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import java.io.IOException
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class DataStoreSettingsRepository @Inject constructor(
    private val dataStore: DataStore<UserSettings>,
) : SettingsRepository {

    override val settings: Flow<UserSettings> = dataStore.data.catch { error ->
        if (error is IOException) emit(UserSettingsSerializer.defaultValue) else throw error
    }

    override suspend fun update(transform: (UserSettings) -> UserSettings) {
        dataStore.updateData { transform(it) }
    }
}
