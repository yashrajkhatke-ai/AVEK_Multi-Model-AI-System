package com.avek.chat.core.link.transport

/** One received datagram. */
class Datagram(val host: String, val port: Int, val data: ByteArray)

/** A UDP socket bound to the Wi-Fi network (broadcast enabled). */
interface UdpSocket {
    suspend fun send(host: String, port: Int, data: ByteArray)

    /** The next datagram, or null when nothing arrives within [timeoutMs]. */
    suspend fun receive(timeoutMs: Long): Datagram?

    fun close()
}

/** This device's IPv4 address on the Wi-Fi network and its prefix length (for the subnet broadcast and the /24 sweep). */
data class LocalAddress(val ip: String, val prefixLength: Int) {
    private val value: Long get() = ipToLong(ip)

    /** The subnet broadcast address, e.g. 192.168.43.255 for 192.168.43.17/24. */
    val broadcast: String
        get() {
            val bits = prefixLength.coerceIn(0, 32)
            val mask = if (bits == 0) 0L else (0xFFFFFFFFL shl (32 - bits)) and 0xFFFFFFFFL
            return longToIp((value and mask) or (mask.inv() and 0xFFFFFFFFL))
        }

    /** Every other host of the /24 this address is in (x.y.z.1 to x.y.z.254, without itself). */
    val hostsOf24: List<String>
        get() {
            val base = value and 0xFFFFFF00L
            return (1..254).map { longToIp(base or it.toLong()) }.filter { it != ip }
        }

    companion object {
        fun ipToLong(ip: String): Long = ip.split('.').fold(0L) { acc, part -> (acc shl 8) or (part.toLong() and 0xFF) }
        fun longToIp(value: Long): String = (3 downTo 0).joinToString(".") { ((value shr (it * 8)) and 0xFF).toString() }
    }
}

/** Opens UDP sockets for knocking. Android binds them to the Wi-Fi network and holds a multicast lock. */
interface UdpTransport {
    suspend fun open(): UdpSocket

    /** The Wi-Fi address, or null when it is not known. */
    fun localAddress(): LocalAddress?
}
