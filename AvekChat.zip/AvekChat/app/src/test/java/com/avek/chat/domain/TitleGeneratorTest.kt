package com.avek.chat.domain

import com.avek.chat.core.domain.usecase.TitleGenerator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class TitleGeneratorTest {

    private val generator = TitleGenerator()

    @Test
    fun `strips polite filler and capitalises`() {
        assertEquals("Explain quantum entanglement simply", generator.generate("hey can you please explain quantum entanglement simply?"))
    }

    @Test
    fun `uses only the first sentence`() {
        assertEquals("Plan a trip to Lisbon", generator.generate("Plan a trip to Lisbon. I like food and museums."))
    }

    @Test
    fun `ignores code blocks`() {
        assertEquals("Fix this", generator.generate("```kotlin\nfun main() {}\n```\nfix this"))
    }

    @Test
    fun `caps long titles`() {
        val title = generator.generate("Compare incredibly extraordinarily comprehensive multidimensional architectural considerations")
        assertTrue(title.length <= 48)
    }

    @Test
    fun `falls back for empty input`() {
        assertEquals(TitleGenerator.DEFAULT_TITLE, generator.generate("please"))
    }
}
