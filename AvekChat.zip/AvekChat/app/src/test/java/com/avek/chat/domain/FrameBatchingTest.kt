package com.avek.chat.domain

import com.avek.chat.core.domain.chat.FrameClock
import com.avek.chat.core.domain.chat.oncePerFrame
import com.avek.chat.core.link.rpc.TextAssembler
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.takeWhile
import kotlinx.coroutines.launch
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class FrameBatchingTest {

    @Test
    fun `many deltas in one frame give one flush and no text is lost`() = runTest {
        val frames = Channel<Unit>(Channel.UNLIMITED)
        val clock = FrameClock { frames.receive() }
        val source = MutableSharedFlow<String>(extraBufferCapacity = 1000)
        val published = mutableListOf<String>()
        backgroundScope.launch { source.takeWhile { it != "END" }.oncePerFrame(clock).collect { published += it } }
        runCurrent()

        val assembler = TextAssembler()
        val tokens = (0 until 200).map { "t$it " }
        var offset = 0
        tokens.take(100).forEach { t ->
            assembler.apply("a", offset, t); offset += t.length
            source.emit(assembler.text("a"))
        }
        runCurrent()
        assertEquals("the first value goes out, then waits for the frame", 1, published.size)
        frames.trySend(Unit); runCurrent()
        assertEquals("everything received during the frame is one flush", 2, published.size)
        assertEquals(tokens.take(100).joinToString(""), published.last())

        tokens.drop(100).forEach { t ->
            assembler.apply("a", offset, t); offset += t.length
            source.emit(assembler.text("a"))
        }
        repeat(5) { frames.trySend(Unit); runCurrent() }
        assertEquals(tokens.joinToString(""), published.last())
        assertTrue(published.size <= 4)
    }

    @Test
    fun `tool call arguments follow the offset rule per step and index`() {
        val a = TextAssembler()
        val k1 = TextAssembler.toolCallKey("c", "p", 1, 0)
        val k2 = TextAssembler.toolCallKey("c", "p", 1, 1)
        a.apply(k1, 0, "{\"pa")
        a.apply(k2, 0, "{\"q\"")
        a.apply(k1, 2, "pat") // overlap: only "t" is new
        assertEquals("{\"pat", a.text(k1))
        assertEquals("{\"q\"", a.text(k2))
        assertEquals(TextAssembler.Outcome.Reload, a.apply(k1, 99, "x"))
        assertEquals("{\"pat", a.text(k1))

        assertEquals("abc", TextAssembler.merge("ab", 1, "bc"))
        assertEquals("ab", TextAssembler.merge("ab", 0, "a"))
        assertNull(TextAssembler.merge("ab", 5, "x"))
    }
}
