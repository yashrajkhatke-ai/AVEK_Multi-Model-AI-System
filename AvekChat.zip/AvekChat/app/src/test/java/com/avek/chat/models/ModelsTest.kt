package com.avek.chat.models

import com.avek.chat.core.data.remote.toDomain
import com.avek.chat.core.domain.models.ModelPreloader
import com.avek.chat.core.domain.models.ModelStateTracker
import com.avek.chat.core.link.HarnessApi
import com.avek.chat.core.link.route.ConnectionState
import com.avek.chat.core.link.wire.CapabilityDto
import com.avek.chat.core.link.wire.LinkEvent
import com.avek.chat.core.link.wire.ModelDto
import com.avek.chat.core.link.wire.ModelStateDto
import com.avek.chat.core.link.wire.ReadyDto
import com.avek.chat.core.model.ModelLoadState
import com.avek.chat.domain.FakeLink
import com.avek.chat.feature.chat.components.ModelCardContent
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.test.TestScope
import kotlinx.coroutines.test.advanceTimeBy
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class ModelsTest {

    private inner class Rig(scope: TestScope, var demo: Boolean = false) {
        val link = FakeLink { op, args ->
            when (op) {
                "model.load" -> buildJsonObject { put("modelId", args["modelId"]!!.jsonPrimitive.content); put("state", "loading"); put("waiting", waiting) }
                "models.state" -> buildJsonObject { put("items", JsonArray(stateItems)) }
                else -> buildJsonObject { }
            }
        }
        var waiting = false
        var stateItems = listOf<kotlinx.serialization.json.JsonObject>()
        val api = HarnessApi(link)
        val tracker = ModelStateTracker(link, api, scope.backgroundScope)
        val preloader = ModelPreloader(api, link, tracker, { demo }, scope.backgroundScope)
        val loads get() = link.opsCalled("model.load").map { it["modelId"]!!.jsonPrimitive.content }
    }

    // ------------------------------------------------------------------ preload

    @Test
    fun `typing asks for the model once after 150 ms, and the latest request wins`() = runTest {
        val r = Rig(this)
        r.preloader.want("alpha")
        r.preloader.want("alpha")
        advanceTimeBy(100)
        r.preloader.want("beta") // changed the model before the debounce ran out
        advanceTimeBy(149)
        assertTrue(r.loads.isEmpty())
        advanceTimeBy(2)
        assertEquals(listOf("beta"), r.loads)
    }

    @Test
    fun `picking a model sends at once`() = runTest {
        val r = Rig(this)
        r.preloader.want("alpha", immediate = true)
        runCurrent()
        assertEquals(listOf("alpha"), r.loads)
    }

    @Test
    fun `a model that is ready or loading is not asked for again`() = runTest {
        val r = Rig(this)
        r.tracker.apply(ModelStateDto("alpha", "ready"))
        r.tracker.apply(ModelStateDto("beta", "loading"))
        r.preloader.want("alpha", immediate = true); runCurrent()
        r.preloader.want("beta", immediate = true); runCurrent()
        assertTrue(r.loads.isEmpty())
        r.tracker.apply(ModelStateDto("alpha", "unloaded", reason = "swap"))
        r.preloader.want("alpha", immediate = true); runCurrent()
        assertEquals(listOf("alpha"), r.loads)
    }

    @Test
    fun `nothing is sent when disconnected or in demo mode`() = runTest {
        val r = Rig(this)
        r.link.connectionState.value = ConnectionState.Unreachable("PC", 0L)
        r.preloader.want("alpha", immediate = true); runCurrent()
        r.link.connectionState.value = ConnectionState.Connected("PC", "10.0.0.2:7810")
        r.demo = true
        r.preloader.want("alpha", immediate = true); runCurrent()
        assertTrue(r.loads.isEmpty())
        r.demo = false
        r.preloader.want("alpha", immediate = true); runCurrent()
        assertEquals(listOf("alpha"), r.loads)
    }

    @Test
    fun `waiting true is shown on the chip`() = runTest {
        val r = Rig(this).apply { waiting = true }
        r.preloader.want("alpha", immediate = true); runCurrent()
        assertEquals(true, r.preloader.status.value?.waiting)
        assertEquals("alpha", r.preloader.status.value?.modelId)
    }

    // ------------------------------------------------------------------ state tracker

    @Test
    fun `the tracker seeds from ready, follows model state events and clears when the link goes`() = runTest {
        val r = Rig(this)
        val ready = r.link.ready as MutableStateFlow<ReadyDto?>
        ready.value = ReadyDto(modelStates = listOf(ModelStateDto("alpha", "ready"), ModelStateDto("beta", "unloaded")))
        r.tracker.start(); runCurrent()
        assertEquals(ModelLoadState.READY, r.tracker.stateOf("alpha"))
        r.link.emit(LinkEvent.ModelState(5, ModelStateDto("beta", "loading", reason = "preload"))); runCurrent()
        assertEquals(ModelLoadState.LOADING, r.tracker.stateOf("beta"))
        assertEquals("preload", r.tracker.states.value["beta"]?.reason)
        ready.value = null; runCurrent()
        assertEquals(ModelLoadState.UNKNOWN, r.tracker.stateOf("alpha"))
    }

    @Test
    fun `after a reconnect without states in ready the tracker asks models-state`() = runTest {
        val r = Rig(this)
        r.stateItems = listOf(buildJsonObject { put("modelId", "gamma"); put("state", "error"); put("error", "out of memory") })
        val ready = r.link.ready as MutableStateFlow<ReadyDto?>
        ready.value = null
        r.tracker.start(); runCurrent()
        ready.value = ReadyDto(); runCurrent()
        assertEquals(ModelLoadState.ERROR, r.tracker.stateOf("gamma"))
        assertEquals("out of memory", r.tracker.states.value["gamma"]?.error)
        assertEquals(1, r.link.opsCalled("models.state").size)
    }

    // ------------------------------------------------------------------ cards

    private fun fixtureModels(): List<ModelDto> {
        val stream = checkNotNull(javaClass.classLoader.getResourceAsStream("trace-fixture-v1.json"))
        val root = Json.parseToJsonElement(stream.bufferedReader().readText()).jsonObject
        val json = Json { ignoreUnknownKeys = true }
        return root.getValue("models").jsonArray.map { json.decodeFromJsonElement(ModelDto.serializer(), it) }
    }

    @Test
    fun `every model yields the same card structure with the context chip first`() {
        val models = fixtureModels() + ModelDto(
            "odd", "Odd one", "vision", 9,
            capabilities = listOf(CapabilityDto("vision", "Vision"), CapabilityDto("context", "8K context")),
        )
        val cards = models.map { ModelCardContent.from(it.toDomain()) }
        cards.forEach { card ->
            assertEquals(listOf("Intelligence", "Speed", "Thinking"), card.meters.map { it.label })
            assertEquals("context", card.chips.first().key)
        }
        assertEquals("Recommended", cards.first().badge)
        assertEquals("80K context", cards.first().chips.first().label)
        assertEquals("Careful and deep", cards.first().tagline)
        assertEquals("Not loaded", cards.first().stateLabel)
        assertNull(ModelCardContent.from(ModelDto("x", state = "something new").toDomain()).stateLabel)
    }

    @Test
    fun `the picker shows one card per model as the parts arrive`() = runTest {
        val link = FakeLink()
        val gate = kotlinx.coroutines.CompletableDeferred<Unit>()
        link.handler = { _, _ -> buildJsonObject { } }
        link.callHandlerForLists = { _, _ ->
            buildJsonObject {
                put("parts", JsonArray(listOf(
                    buildJsonObject { put("items", JsonArray(fixtureModels().take(1).map { Json.encodeToJsonElement(ModelDto.serializer(), it) })); put("total", 2) },
                    buildJsonObject { put("items", JsonArray(fixtureModels().drop(1).map { Json.encodeToJsonElement(ModelDto.serializer(), it) })); put("total", 2) },
                )))
            }
        }
        val controller = com.avek.chat.core.domain.lists.ModelPickerController(
            backgroundScope, com.avek.chat.core.data.remote.RemoteModelRepository(HarnessApi(link)), { 120 },
        )
        controller.opened(); runCurrent()
        val state = controller.state.value
        assertEquals(listOf("alpha", "beta"), state.models.map { it.id })
        assertEquals(false, state.loading)
        gate.complete(Unit)
    }
}
