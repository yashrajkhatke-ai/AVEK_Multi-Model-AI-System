package com.avek.chat.markdown

import com.avek.chat.core.markdown.MarkdownParser
import com.avek.chat.core.markdown.MdBlock
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class MarkdownParserTest {

    @Test
    fun `parses common blocks`() {
        val blocks = MarkdownParser.parse(
            """
            # Title
            Some **bold** text
            continues here.

            - one
            - two

            1. first
            2. second

            > quoted

            ---
            """.trimIndent(),
        )
        assertEquals(MdBlock.Heading(1, "Title"), blocks[0])
        assertEquals(MdBlock.Paragraph("Some **bold** text\ncontinues here."), blocks[1])
        assertTrue(blocks[2] is MdBlock.Bullets)
        assertEquals(1, (blocks[3] as MdBlock.Numbered).start)
        assertEquals(MdBlock.Quote("quoted"), blocks[4])
        assertEquals(MdBlock.Rule, blocks[5])
    }

    @Test
    fun `unclosed fences are treated as streaming code`() {
        val blocks = MarkdownParser.parse("```kotlin\nval a = 1\nval b")
        val code = blocks.single() as MdBlock.Code
        assertEquals("kotlin", code.language)
        assertEquals("val a = 1\nval b", code.code)
        assertFalse(code.closed)
    }

    @Test
    fun `tables pad short rows`() {
        val table = MarkdownParser.parse("| A | B |\n|---|---|\n| 1 |").single() as MdBlock.Table
        assertEquals(listOf("A", "B"), table.header)
        assertEquals(listOf(listOf("1", "")), table.rows)
    }
}
