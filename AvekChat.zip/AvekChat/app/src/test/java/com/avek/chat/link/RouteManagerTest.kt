package com.avek.chat.link

import com.avek.chat.core.link.route.ConnectionState
import com.avek.chat.core.link.route.Route
import com.avek.chat.core.link.route.RouteManager
import com.avek.chat.core.link.rpc.CloseInfo
import com.avek.chat.core.link.rpc.LiveLink
import com.avek.chat.core.link.transport.RawChannel
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.test.TestScope
import kotlinx.coroutines.test.UnconfinedTestDispatcher
import kotlinx.coroutines.test.advanceTimeBy
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.IOException

@OptIn(ExperimentalCoroutinesApi::class)
class RouteManagerTest {

    private class FakeLink(override val serverName: String = "Test PC") : LiveLink {
        private val closed = CompletableDeferred<CloseInfo>()
        var closeCalled = false
        override suspend fun awaitClosed(): CloseInfo = closed.await()
        override fun close(code: Int, reason: String) {
            closeCalled = true
            closed.complete(CloseInfo(code, reason))
        }
        fun drop(info: CloseInfo = CloseInfo(1006, "dropped")) = closed.complete(info)
    }

    /** Scripted route: [openMs] to open the channel, [establishMs] for handshake + ready, then [outcome]. */
    private inner class FakeRoute(
        override val kind: String,
        val openMs: Long = 0,
        val establishMs: Long = 0,
        val fail: Throwable? = null,
        override val label: String = kind,
    ) : Route {
        var startedAt = -1L
        var channel: InMemoryChannel? = null
        val link = FakeLink("PC via $label")
        var establishCalls = 0

        override suspend fun open(): RawChannel {
            startedAt = scheduler().currentTime
            delay(openMs)
            if (fail != null) throw fail
            return InMemoryChannel.pair().first.also { channel = it }
        }
    }

    private lateinit var testScope: TestScope
    private fun scheduler() = testScope.testScheduler

    private fun TestScope.manager(
        routes: List<FakeRoute>,
        onWinner: (LiveLink, Route) -> Unit = { _, _ -> },
        onLost: (CloseInfo) -> Unit = {},
        fatal: (Throwable) -> String? = { null },
        attemptTimeoutMs: Long = 12_000,
    ): RouteManager {
        testScope = this
        return RouteManager(
            scope = backgroundScope,
            routes = { routes },
            establish = { _, route ->
                val fake = route as FakeRoute
                fake.establishCalls++
                delay(fake.establishMs)
                fake.link
            },
            onWinner = onWinner,
            onLost = onLost,
            fatalReason = fatal,
            attemptTimeoutMs = attemptTimeoutMs,
        )
    }

    private fun TestScope.recordStates(manager: RouteManager): List<ConnectionState> {
        val states = mutableListOf<ConnectionState>()
        backgroundScope.launch(UnconfinedTestDispatcher(testScheduler)) { manager.state.collect { states += it } }
        return states
    }

    @Test
    fun `routes start in parallel staggered by 200 ms`() = runTest {
        val routes = listOf(
            FakeRoute("last", fail = IOException("no")),
            FakeRoute("discover", fail = IOException("no")),
            FakeRoute("host", fail = IOException("no")),
        )
        val manager = manager(routes)
        manager.start()
        advanceTimeBy(1)
        runCurrent()
        advanceTimeBy(500)

        assertEquals(listOf(0L, 200L, 400L), routes.map { it.startedAt })
        manager.stop()
    }

    @Test
    fun `the first route to finish handshake and ready wins and the rest are cancelled and closed`() = runTest {
        val slow = FakeRoute("last", openMs = 1_000, establishMs = 500, label = "last 10.0.0.9:7810")
        val fast = FakeRoute("discover", openMs = 100, establishMs = 200, label = "discover")
        val late = FakeRoute("host", openMs = 100, establishMs = 100, label = "host 10.0.0.2:7810")
        var winner: Route? = null
        var winners = 0
        val manager = manager(listOf(slow, fast, late), onWinner = { _, route -> winner = route; winners++ })
        manager.start()
        advanceTimeBy(2_000)

        // fast finishes at 200+100+200 = 500; late at 400+100+100 = 600; slow at 1500.
        assertEquals("discover", winner?.kind)
        assertEquals(1, winners)
        assertEquals(ConnectionState.Connected("discover", "PC via discover"), manager.state.value)
        assertTrue("losing channel is closed", slow.channel?.closedLocally ?: true)
        assertTrue("losing channel is closed", late.channel?.closedLocally ?: true)
        assertFalse("the winner stays open", fast.link.closeCalled)
        assertFalse(late.link.closeCalled && late.establishCalls == 0)
        manager.stop()
    }

    @Test
    fun `a link that wins the race at the same instant as another is closed`() = runTest {
        val a = FakeRoute("last", openMs = 0, establishMs = 300)
        val b = FakeRoute("host", openMs = 0, establishMs = 100) // starts 200 later: also done at 300
        val manager = manager(listOf(a, b))
        manager.start()
        advanceTimeBy(1_000)

        val connected = manager.state.value as ConnectionState.Connected
        val winnerLink = if (connected.routeName == "last") a.link else b.link
        val loserLink = if (connected.routeName == "last") b.link else a.link
        assertFalse(winnerLink.closeCalled)
        assertTrue("the loser's established link must be closed", loserLink.closeCalled || loserLink === winnerLink)
        manager.stop()
    }

    @Test
    fun `when every route fails it waits 1, 2, 4, 8 then 15 seconds repeatedly`() = runTest {
        val manager = manager(listOf(FakeRoute("last", fail = IOException("down")), FakeRoute("host", fail = IOException("down"))))
        val states = recordStates(manager)
        manager.start()
        advanceTimeBy(100_000)

        val waits = states.filterIsInstance<ConnectionState.Connecting>().mapNotNull { it.retryInMs }
        assertEquals(listOf(1_000L, 2_000L, 4_000L, 8_000L, 15_000L, 15_000L, 15_000L), waits.take(7))
        manager.stop()
    }

    @Test
    fun `state goes Disconnected, Connecting, Connected and back to Connecting when the link drops`() = runTest {
        val route = FakeRoute("host", establishMs = 50, label = "host 10.0.0.2:7810")
        val lost = mutableListOf<CloseInfo>()
        val manager = manager(listOf(route), onLost = { lost += it })
        val states = recordStates(manager)
        assertEquals(ConnectionState.Disconnected, manager.state.value)

        manager.start()
        advanceTimeBy(500)
        assertTrue(manager.state.value is ConnectionState.Connected)

        route.link.drop()
        advanceTimeBy(10)
        assertEquals(1, lost.size)
        val reconnecting = manager.state.value as ConnectionState.Connecting
        assertEquals(1_000L, reconnecting.retryInMs)

        // The scripted link object is reused, so it is already "closed"; the manager must keep cycling, not crash.
        assertEquals(listOf("Disconnected", "Connecting", "Connected", "Connecting"), states.map { it::class.simpleName }.take(4))
        manager.stop()
        assertEquals(ConnectionState.Disconnected, manager.state.value)
    }

    @Test
    fun `a fatal handshake failure stops retrying`() = runTest {
        val route = FakeRoute("host", fail = IllegalStateException("revoked"))
        val manager = manager(listOf(route), fatal = { if (it.message == "revoked") "Revoked on the PC" else null })
        manager.start()
        advanceTimeBy(60_000)

        assertEquals(ConnectionState.Failed("Revoked on the PC"), manager.state.value)
        assertEquals("no retries after a fatal failure", 1, route.startedAt.let { if (it >= 0) 1 else 0 })
    }

    @Test
    fun `an auth close (4401) after connecting is fatal`() = runTest {
        val route = FakeRoute("host")
        val manager = manager(listOf(route))
        manager.start()
        advanceTimeBy(100)
        route.link.drop(CloseInfo(4401, "revoked"))
        advanceTimeBy(100)
        assertTrue(manager.state.value is ConnectionState.Failed)
    }

    @Test
    fun `a route that hangs is abandoned after the attempt timeout and the next attempt follows the back-off`() = runTest {
        val hang = FakeRoute("host", openMs = 60_000)
        val manager = manager(listOf(hang), attemptTimeoutMs = 12_000)
        val states = recordStates(manager)
        manager.start()
        advanceTimeBy(12_500)

        val retry = states.filterIsInstance<ConnectionState.Connecting>().lastOrNull { it.retryInMs != null }
        assertEquals(1_000L, retry?.retryInMs)
        manager.stop()
    }

    @Test
    fun `stop closes the live link and returns to Disconnected`() = runTest {
        val route = FakeRoute("host")
        val manager = manager(listOf(route))
        manager.start()
        advanceTimeBy(100)
        assertTrue(manager.state.value is ConnectionState.Connected)

        manager.stop()
        assertTrue(route.link.closeCalled)
        assertEquals(ConnectionState.Disconnected, manager.state.value)
    }

    @Test
    fun `the summary lists the routes being tried`() {
        val state = ConnectionState.Connecting(listOf("last", "discover", "host", "host"), 1)
        assertEquals("last, discover, 2 hosts", state.summary)
        assertEquals("last, host", ConnectionState.Connecting(listOf("last", "host"), 1).summary)
    }
}
