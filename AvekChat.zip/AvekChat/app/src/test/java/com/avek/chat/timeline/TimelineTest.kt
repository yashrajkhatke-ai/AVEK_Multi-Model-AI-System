package com.avek.chat.timeline

import com.avek.chat.core.domain.chat.ReplyPhase
import com.avek.chat.core.domain.chat.StreamingReply
import com.avek.chat.core.domain.chat.TurnFollower
import com.avek.chat.core.domain.context.ContextRepository
import com.avek.chat.core.domain.context.ContextThresholds
import com.avek.chat.core.domain.timeline.BlockKind
import com.avek.chat.core.domain.timeline.CollapseRules
import com.avek.chat.core.domain.timeline.GroupSummary
import com.avek.chat.core.domain.timeline.LayoutItem
import com.avek.chat.core.domain.timeline.RowState
import com.avek.chat.core.domain.timeline.TimelineReducer
import com.avek.chat.core.domain.timeline.TimelineRepository
import com.avek.chat.core.domain.timeline.TurnTimeline
import com.avek.chat.core.domain.trace.TurnKey
import com.avek.chat.core.link.HarnessApi
import com.avek.chat.core.link.wire.BlockDeltaDto
import com.avek.chat.core.link.wire.BlockEndDto
import com.avek.chat.core.link.wire.BlockStartDto
import com.avek.chat.core.link.wire.BlockStateDto
import com.avek.chat.core.link.wire.BlockTitleDto
import com.avek.chat.core.link.wire.ContextDataDto
import com.avek.chat.core.link.wire.EventDecoder
import com.avek.chat.core.link.wire.LinkEvent
import com.avek.chat.core.link.wire.ReadyDto
import com.avek.chat.core.link.wire.TimelineBlockDto
import com.avek.chat.core.link.wire.TimelineDto
import com.avek.chat.core.link.wire.WireEvent
import com.avek.chat.core.link.wire.WireJson
import com.avek.chat.core.model.Message
import com.avek.chat.core.model.MessageStatus
import com.avek.chat.core.model.Role
import com.avek.chat.domain.FakeLink
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.toList
import kotlinx.coroutines.launch
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.longOrNull
import kotlinx.serialization.json.put
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** The timeline of a turn against the recording of the real harness 0.0.8 (`trace-fixture.json`, three turns). */
@OptIn(ExperimentalCoroutinesApi::class)
class TimelineTest {

    private val json = Json { ignoreUnknownKeys = true }
    private val fixture: JsonObject by lazy {
        Json.parseToJsonElement(checkNotNull(javaClass.classLoader.getResourceAsStream("trace-fixture.json")).bufferedReader().readText()).jsonObject
    }

    private fun key(name: String): TurnKey {
        val t = fixture.getValue("turns").jsonObject.getValue(name).jsonObject
        return TurnKey(t.getValue("chatId").jsonPrimitive.content, t.getValue("promptId").jsonPrimitive.content)
    }

    private val events: List<LinkEvent> by lazy {
        fixture.getValue("events").jsonArray.map { it.jsonObject }.filter { it.getValue("ev").jsonPrimitive.content != "_mark" }
            .mapNotNull { e -> EventDecoder.decode(WireEvent(e.getValue("ev").jsonPrimitive.content, e["seq"]?.jsonPrimitive?.longOrNull, e.getValue("data").jsonObject)) }
    }

    private fun read(name: String): List<TimelineBlockDto> =
        fixture.getValue("reads").jsonObject.getValue(name).jsonArray.map { json.decodeFromJsonElement(TimelineBlockDto.serializer(), it) }

    private fun replay(key: TurnKey, list: List<LinkEvent> = events, start: TurnTimeline = TurnTimeline(key)) = list.fold(start) { acc, e -> TimelineReducer.reduce(acc, e) }

    /** The fields both the live stream and `timeline.get` carry. */
    private fun shape(b: com.avek.chat.core.domain.timeline.TimelineBlock) = listOf(b.id, b.parentId, b.kind, b.state, b.title, b.from, b.to, b.text, b.args, b.summary, b.tool, b.agent, b.ms)
    private fun shape(b: TimelineBlockDto) = listOf(b.id, b.parent, b.kind, b.state, b.title, b.from, b.to, b.text.orEmpty(), b.args.orEmpty(), b.summary, b.tool, b.agent, b.ms)

    @Test
    fun `replaying turn A gives the blocks timeline-get returns`() {
        val a = replay(key("A"))
        val expected = read("timelineA")
        assertEquals(expected.map { it.id }, a.order)
        assertEquals(expected.map { shape(it) }, a.order.map { shape(a.blocks.getValue(it)) })
        assertEquals("Weighing the mock options", a.blocks.getValue("b1").title)
        assertEquals("Tool called for Write file", a.blocks.getValue("b2").title)
        assertEquals("Thinking about the result", a.blocks.getValue("b3").title)
        assertFalse(a.live)
    }

    @Test
    fun `turn A's outline equals the replay without texts, and its answer equals assistant text`() {
        val a = replay(key("A"))
        val outline = read("outlineA")
        assertEquals(outline.map { shape(it).take(7) }, a.order.map { shape(a.blocks.getValue(it)).take(7) })
        val turnA = fixture.getValue("reads").jsonObject.getValue("chatGetWithOutline").jsonObject.getValue("items").jsonArray
            .map { it.jsonObject }.first { it.getValue("promptId").jsonPrimitive.content == key("A").promptId }
        assertEquals(turnA.getValue("assistant").jsonObject.getValue("text").jsonPrimitive.content, a.answerText)
        // A saved turn drawn from its outline has headings, no texts until a row is opened.
        val fromOutline = TimelineReducer.outline(TurnTimeline(key("A")), outline)
        assertEquals(a.layout.map { it.key }, fromOutline.layout.map { it.key })
        assertTrue(fromOutline.blocks.getValue("b1").textMissing)
    }

    @Test
    fun `turn B has the tool call that was written inside the text`() {
        val b = replay(key("B"))
        val tool = b.blocks.values.single { it.kind == BlockKind.TOOL }
        assertTrue(tool.args.contains("notes/second.txt"))
        assertEquals("write_file", tool.tool?.name)
        assertEquals("Tool called for Write file", tool.title)
    }

    @Test
    fun `turn C holds the infra tree under its tool`() {
        val c = replay(key("C"))
        val expected = read("timelineC")
        assertEquals(expected.map { shape(it) }, c.order.map { shape(c.blocks.getValue(it)) })
        val tool = c.topLevel.single { it.kind == BlockKind.TOOL }
        val children = c.children(tool.id)
        assertEquals(listOf("note", "agent", "agent", "agent"), children.map { it.kind })
        assertEquals(listOf("lead", "worker", "worker"), children.filter { it.kind == BlockKind.AGENT }.map { it.agent?.role })
        assertTrue(c.children("b6").all { it.kind == BlockKind.ANSWER && it.title == "Output" })
        assertEquals("Research done: 100% covered, 2 sources", c.blocks.getValue("b3").title)
    }

    @Test
    fun `duplicates change nothing`() {
        val k = key("A")
        val once = replay(k)
        assertEquals(once, replay(k, events + events))
        assertEquals(once, replay(k, events.flatMap { listOf(it, it) }))
    }

    @Test
    fun `a missed delta marks the block for reload and the reload continues correctly`() {
        val k = TurnKey("c", "p")
        var t = TimelineReducer.reduce(TurnTimeline(k), LinkEvent.BlockStart(null, BlockStartDto("c", "p", 1, "b1", kind = "thinking", title = "Figuring out what to do", from = 0)))
        t = TimelineReducer.reduce(t, LinkEvent.BlockDelta(null, BlockDeltaDto("c", "p", 2, "b1", "text", "Hello ", 0)))
        t = TimelineReducer.reduce(t, LinkEvent.BlockDelta(null, BlockDeltaDto("c", "p", 3, "b1", "text", "there", 20)))
        assertEquals(setOf("b1"), t.toReload)
        t = TimelineReducer.reduce(t, TimelineDto(listOf(TimelineBlockDto("b1", kind = "thinking", state = "running", title = "Figuring out what to do", t0 = 1, text = "Hello world, and more"))))
        assertTrue(t.toReload.isEmpty())
        t = TimelineReducer.reduce(t, LinkEvent.BlockDelta(null, BlockDeltaDto("c", "p", 4, "b1", "text", " text", 21)))
        assertEquals("Hello world, and more text", t.blocks.getValue("b1").text)
    }

    @Test
    fun `title after end applies, state never moves back, unknown ids are fetched`() {
        val k = TurnKey("c", "p")
        var t = TimelineReducer.reduce(TurnTimeline(k), LinkEvent.BlockStart(null, BlockStartDto("c", "p", 1, "b1", kind = "tool", title = "Tool calling for Web search", state = "writing")))
        t = TimelineReducer.reduce(t, LinkEvent.BlockState(null, BlockStateDto("c", "p", 2, "b1", "running")))
        t = TimelineReducer.reduce(t, LinkEvent.BlockState(null, BlockStateDto("c", "p", 3, "b1", "writing")))
        assertEquals("running", t.blocks.getValue("b1").state)
        t = TimelineReducer.reduce(t, LinkEvent.BlockEnd(null, BlockEndDto("c", "p", 4, "b1", "done", "Tool called for Web search", 10)))
        t = TimelineReducer.reduce(t, LinkEvent.BlockState(null, BlockStateDto("c", "p", 5, "b1", "running")))
        assertEquals("done", t.blocks.getValue("b1").state)
        t = TimelineReducer.reduce(t, LinkEvent.BlockTitle(null, BlockTitleDto("c", "p", 6, "b1", "Tool called for Web search (3 pages)")))
        assertEquals("Tool called for Web search (3 pages)", t.blocks.getValue("b1").title)
        t = TimelineReducer.reduce(t, LinkEvent.BlockDelta(null, BlockDeltaDto("c", "p", 7, "b9", "text", "x", 0)))
        assertEquals(setOf("b9"), t.toReload)
    }

    @Test
    fun `groups and answers are laid out in order, with summaries`() {
        val k = TurnKey("c", "p")
        val kinds = listOf("thinking", "tool", "thinking", "answer", "thinking", "tool", "answer")
        var t = TurnTimeline(k)
        kinds.forEachIndexed { i, kind ->
            t = TimelineReducer.reduce(t, LinkEvent.BlockStart(null, BlockStartDto("c", "p", i + 1L, "b$i", kind = kind)))
            t = TimelineReducer.reduce(t, LinkEvent.BlockEnd(null, BlockEndDto("c", "p", i + 2L, "b$i", ms = 4_000)))
        }
        val layout = t.layout
        assertEquals(listOf(3, -1, 2, -1), layout.map { if (it is LayoutItem.Group) it.blocks.size else -1 })
        assertEquals("Thought for 12 s · 1 tool call", GroupSummary.of(layout[0] as LayoutItem.Group))
        assertEquals("Thought for 8 s · 1 tool call", GroupSummary.of(layout[2] as LayoutItem.Group))
        val quick = LayoutItem.Group(0, listOf(t.blocks.getValue("b0").copy(ms = 300)), true)
        assertEquals("Thought for a moment", GroupSummary.of(quick))
        val two = LayoutItem.Group(0, listOf(t.blocks.getValue("b0").copy(ms = 12_000), t.blocks.getValue("b1"), t.blocks.getValue("b5")), true)
        assertEquals("Thought for 20 s · 2 tool calls", GroupSummary.of(two))
    }

    @Test
    fun `collapse rules`() {
        val open = CollapseRules.onTap(RowState(), ended = false)
        assertTrue(open.expanded)
        assertFalse("a thinking block opened while streaming closes when it ends", CollapseRules.onEnd(BlockKind.THINKING, open).expanded)
        val pinned = CollapseRules.onTap(RowState(), ended = true)
        assertTrue(CollapseRules.onEnd(BlockKind.THINKING, pinned).expanded)
        assertFalse(CollapseRules.onEnd(BlockKind.THINKING, RowState()).expanded)
        listOf(BlockKind.TOOL, BlockKind.AGENT, BlockKind.NOTE).forEach { assertTrue(CollapseRules.onEnd(it, open).expanded) }
        assertTrue("the setting can turn it off", CollapseRules.onEnd(BlockKind.THINKING, open, collapseWhenEnds = false).expanded)
        val running = LayoutItem.Group(1, listOf(com.avek.chat.core.domain.timeline.TimelineBlock("b", null, "thinking", "running", "x")), followedByAnswer = false)
        assertTrue(CollapseRules.groupExpanded(running, turnLive = true, isLastGroup = true, userChoice = null))
        assertFalse(CollapseRules.groupExpanded(running.copy(followedByAnswer = true), turnLive = true, isLastGroup = true, userChoice = null))
        assertFalse("at turn end", CollapseRules.groupExpanded(running, turnLive = false, isLastGroup = true, userChoice = null))
        assertFalse("an earlier group is independent", CollapseRules.groupExpanded(running, turnLive = true, isLastGroup = false, userChoice = null))
        assertTrue(CollapseRules.groupExpanded(running, turnLive = false, isLastGroup = true, userChoice = true))
    }

    @Test
    fun `context thresholds and the circle's sweep`() {
        fun level(f: Float) = ContextThresholds.level(f)
        assertEquals(ContextThresholds.Level.BLUE, level(0.6999f))
        assertEquals(ContextThresholds.Level.YELLOW, level(0.70f))
        assertEquals(ContextThresholds.Level.YELLOW, level(0.8499f))
        assertEquals(ContextThresholds.Level.RED, level(0.85f))
        assertEquals(ContextThresholds.Level.RED, level(1.0f))
        assertEquals(360f, ContextThresholds.sweep(1.3f))
        assertEquals(90f, ContextThresholds.sweep(0.25f))
        assertNull(ContextThresholds.fraction(ContextDataDto(circleTokens = 0, usedTokens = 10)))
        assertEquals(1.25f, ContextThresholds.fraction(ContextDataDto(circleTokens = 100, usedTokens = 125)))
    }

    @Test
    fun `the follower's answer is the joined answer blocks, and the phase follows the open block`() = runTest {
        val k = key("A")
        val flow = MutableSharedFlow<LinkEvent>(extraBufferCapacity = 2048)
        val chats = com.avek.chat.core.data.remote.RemoteChatRepository(HarnessApi(FakeLink { _, _ -> buildJsonObject { } }))
        val user = Message("u", k.chatId, Role.USER, "hi", 0, promptId = k.promptId)
        val assistant = Message("a", k.chatId, Role.ASSISTANT, "", 0, promptId = k.promptId, status = MessageStatus.STREAMING)
        val states = mutableListOf<StreamingReply>()
        backgroundScope.launch { TurnFollower(chats).follow(StreamingReply(user, assistant, ReplyPhase.THINKING, null), flow).collect { states += it } }
        runCurrent()
        events.forEach { flow.emit(it) }
        runCurrent()
        val final = states.last()
        assertEquals(replay(k).answerText, final.message.content)
        assertEquals(ReplyPhase.DONE, final.phase)
        assertTrue(states.any { it.phase == ReplyPhase.THINKING && it.activity?.startsWith("Tool calling for") == true })
        assertTrue(states.any { it.phase == ReplyPhase.ANSWERING })
    }

    @Test
    fun `the repository follows turns, joins late, fetches texts and keeps 8`() = runTest {
        val k = key("A")
        val link = FakeLink { op, args ->
            when (op) {
                "timeline.get" -> WireJson.encodeToJsonElement(TimelineDto.serializer(), TimelineDto(read("timelineA").let { all ->
                    val ids = args["ids"]?.jsonArray?.map { it.jsonPrimitive.content }
                    if (ids == null) all else all.filter { it.id in ids }
                }, live = false))
                else -> buildJsonObject { }
            }
        }
        (link.ready as MutableStateFlow<ReadyDto?>).value = ReadyDto(revision = 2)
        val repo = TimelineRepository(link, HarnessApi(link), backgroundScope)
        repo.start(); runCurrent()
        events.forEach { link.emit(it) }
        runCurrent()
        assertEquals(replay(k).blocks, repo.timeline(k.chatId, k.promptId).value.blocks)
        assertTrue(link.opsCalled("timeline.get").isEmpty())

        // A saved turn from its outline: texts come when a row is opened.
        repo.outline("other", "p000001", read("outlineA"))
        val saved = repo.timeline("other", "p000001")
        assertTrue(saved.value.blocks.getValue("b1").textMissing)
        repo.loadTexts("other", "p000001", listOf("b1")); runCurrent()
        assertEquals(read("timelineA").first().text, saved.value.blocks.getValue("b1").text)

        // Late join: block events of a turn never seen start fetch it first.
        link.emit(LinkEvent.BlockDelta(null, BlockDeltaDto("late", "p1", 1, "b1", "text", "x", 0))); runCurrent()
        assertEquals(2, link.opsCalled("timeline.get").size)

        repeat(10) { repo.timeline("c$it", "p") }
        assertNull(repo.known(k.chatId, k.promptId))
    }

    @Test
    fun `the context repository asks on open, applies its chat's events and shows drops`() = runTest {
        val link = FakeLink { op, _ -> if (op == "context.get") WireJson.encodeToJsonElement(ContextDataDto.serializer(), ContextDataDto(chatId = "c1", circleTokens = 81920, usedTokens = 4000)) else buildJsonObject { } }
        (link.ready as MutableStateFlow<ReadyDto?>).value = ReadyDto(revision = 2)
        val repo = ContextRepository(link, HarnessApi(link), backgroundScope)
        repo.start(); runCurrent()
        repo.show(null, "beta", "Beta 3B", 81920)
        assertEquals(0, repo.current.value?.usedTokens)
        assertEquals(81920, repo.current.value?.circleTokens)
        repo.show("c1", "beta", "Beta 3B", 81920); runCurrent()
        assertEquals(4000, repo.current.value?.usedTokens)
        link.emit(LinkEvent.ChatContext(1, ContextDataDto(chatId = "other", circleTokens = 81920, usedTokens = 70000))); runCurrent()
        assertEquals(4000, repo.current.value?.usedTokens)
        link.emit(LinkEvent.ChatContext(2, ContextDataDto(chatId = "c1", circleTokens = 81920, usedTokens = 2500))); runCurrent()
        assertEquals("a drop (summarised) is shown as is", 2500, repo.current.value?.usedTokens)
        repo.show("c1", "ornith", "Ornith", 81920); runCurrent()
        assertEquals(2, link.opsCalled("context.get").size)
        link.emit(LinkEvent.Refresh); runCurrent()
        assertEquals(3, link.opsCalled("context.get").size)
    }
}
