package com.avek.chat.link

import com.avek.chat.core.link.crypto.HandshakeException
import com.avek.chat.core.link.route.AutoConnect
import com.avek.chat.core.link.route.ConnectionState
import com.avek.chat.core.link.rpc.LiveLink
import com.avek.chat.core.link.store.PairedPc
import com.avek.chat.core.link.transport.RawChannel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.TestScope
import kotlinx.coroutines.test.advanceTimeBy
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class AutoConnectTest {

    private val pc = PairedPc("s_1", "Yash Laptop", ByteArray(65), "Tablet")

    private fun TestScope.loop(
        route: FakeRoute,
        paired: PairedPc? = pc,
        establish: suspend (RawChannel) -> LiveLink = { error("not reached") },
    ) = AutoConnect(
        scope = backgroundScope,
        route = { route },
        pc = { paired },
        establish = establish,
        nowMs = { testScheduler.currentTime },
    )

    @Test
    fun `failures wait 2, 4, 8, then 15 s`() = runTest {
        val route = FakeRoute(backgroundScope, FakeHarnessServer(backgroundScope)).apply { reachable = false }
        val loop = loop(route)
        loop.start()
        val waits = mutableListOf<Long>()
        repeat(6) {
            runCurrent()
            val state = loop.state.value as ConnectionState.Unreachable
            val wait = state.retryAtMs!! - testScheduler.currentTime
            waits += wait
            advanceTimeBy(wait)
            runCurrent()
        }
        assertEquals(listOf(2_000L, 4_000L, 8_000L, 15_000L, 15_000L, 15_000L), waits)
        assertEquals(0L, (loop.state.value as ConnectionState.Unreachable).sinceMs)
        loop.stop()
        assertEquals(ConnectionState.Disconnected, loop.state.value)
    }

    @Test
    fun `a kick tries again at once`() = runTest {
        val route = FakeRoute(backgroundScope, FakeHarnessServer(backgroundScope)).apply { reachable = false }
        val loop = loop(route)
        loop.start()
        runCurrent()
        assertEquals(1, route.reaches)
        loop.kick()
        runCurrent()
        assertEquals(2, route.reaches)
        assertEquals(0L, testScheduler.currentTime)
    }

    @Test
    fun `a PC that is not ours stops the loop with a clear reason`() = runTest {
        val route = FakeRoute(backgroundScope, FakeHarnessServer(backgroundScope))
        val loop = loop(route, establish = { throw HandshakeException.NotOurPc("bad sig") })
        loop.start()
        advanceTimeBy(60_000)
        assertEquals(ConnectionState.Failed("This is not the PC you paired with"), loop.state.value)
        assertEquals(1, route.reaches)
        assertTrue(!loop.isRunning)
    }

    @Test
    fun `a forgotten device stops the loop`() = runTest {
        val route = FakeRoute(backgroundScope, FakeHarnessServer(backgroundScope))
        val loop = loop(route, establish = { throw HandshakeException.Forgotten() })
        loop.start()
        advanceTimeBy(60_000)
        assertEquals(ConnectionState.Forgotten, loop.state.value)
        assertEquals(1, route.reaches)
    }

    @Test
    fun `without a paired PC the loop asks for pairing`() = runTest {
        val route = FakeRoute(backgroundScope, FakeHarnessServer(backgroundScope))
        val loop = loop(route, paired = null)
        loop.start()
        runCurrent()
        assertEquals(ConnectionState.NeedsPairing(), loop.state.value)
        assertEquals(0, route.reaches)
    }
}
