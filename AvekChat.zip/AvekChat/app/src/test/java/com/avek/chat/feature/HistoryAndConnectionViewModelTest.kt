package com.avek.chat.feature

import com.avek.chat.core.common.DeviceInfo
import com.avek.chat.core.data.downloads.DownloadManager
import com.avek.chat.core.data.remote.RemoteChatRepository
import com.avek.chat.core.domain.lists.ListMemoryRegistry
import com.avek.chat.core.domain.repository.SettingsRepository
import com.avek.chat.core.link.HarnessApi
import com.avek.chat.core.link.crypto.Handshake
import com.avek.chat.core.link.discovery.Beacon
import com.avek.chat.core.link.discovery.BeaconSource
import com.avek.chat.core.link.pairing.PairingManager
import com.avek.chat.core.link.route.ConnectionState
import com.avek.chat.core.link.store.PairedPc
import com.avek.chat.core.link.transport.ChannelFactory
import com.avek.chat.core.link.transport.NoWifiBinding
import com.avek.chat.core.link.wire.ChatSummaryDto
import com.avek.chat.core.link.wire.LinkEvent
import com.avek.chat.core.model.settings.ConnectionSettings
import com.avek.chat.core.model.settings.RouteSpec
import com.avek.chat.core.model.settings.UserSettings
import com.avek.chat.domain.FakeLink
import com.avek.chat.domain.MemoryStore
import com.avek.chat.feature.connection.ConnectionViewModel
import com.avek.chat.feature.connection.PairingForm
import com.avek.chat.feature.history.HistoryEvent
import com.avek.chat.feature.history.HistoryFilter
import com.avek.chat.feature.history.HistoryViewModel
import com.avek.chat.link.FakeHarnessServer
import com.avek.chat.link.InMemoryChannel
import com.avek.chat.link.InMemoryPairedPcStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.emptyFlow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.launch
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.TestScope
import kotlinx.coroutines.test.advanceTimeBy
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

private class MemorySettings : SettingsRepository {
    val state = MutableStateFlow(UserSettings())
    override val settings: Flow<UserSettings> = state
    override suspend fun update(transform: (UserSettings) -> UserSettings) {
        state.value = transform(state.value)
    }
}

@OptIn(ExperimentalCoroutinesApi::class)
class HistoryViewModelTest {

    @Before fun setMain() = Dispatchers.setMain(StandardTestDispatcher())

    @After fun resetMain() = Dispatchers.resetMain()

    private fun chat(i: Int, starred: Boolean = false, archived: Boolean = false, title: String = "Chat $i") = buildJsonObject {
        put("chatId", "c$i"); put("title", title); put("createdAt", "2025-01-01T00:00:00Z"); put("updatedAt", "2025-01-01T00:00:00Z")
        put("mode", "auto"); put("turnCount", 1); put("preview", ""); put("starred", starred); put("archived", archived)
    }

    private inner class Rig(scope: TestScope, total: Int = 50) {
        val link = FakeLink()
        val api = HarnessApi(link)
        val settings = MemorySettings()
        val store = MemoryStore()
        val appScope = CoroutineScope(Dispatchers.Main)
        val downloads = DownloadManager(api, store, link, MutableStateFlow(false), appScope)
        val messages = mutableListOf<String>()
        val vm = HistoryViewModel(RemoteChatRepository(api), link, downloads, settings, ListMemoryRegistry())
        val state get() = vm.uiState.value

        init {
            link.handler = { op, args ->
                when (op) {
                    "chats.list" -> {
                        val limit = args["limit"]!!.jsonPrimitive.content.toInt()
                        val start = args["after"]?.jsonPrimitive?.content?.toInt() ?: 0
                        val end = minOf(total, start + limit)
                        buildJsonObject {
                            put("items", JsonArray((start until end).map { chat(it) }))
                            put("total", total)
                            put("next", if (end < total) JsonPrimitive(end.toString()) else JsonPrimitive(null as String?))
                        }
                    }
                    "chat.set" -> buildJsonObject {
                        put("chat", chat(args["chatId"]!!.jsonPrimitive.content.removePrefix("c").toInt(),
                            starred = args["starred"]?.jsonPrimitive?.content == "true", title = args["title"]?.jsonPrimitive?.content ?: "Chat"))
                    }
                    "downloads.set" -> buildJsonObject { put("chatIds", args["chatIds"]!!) }
                    "chat.get" -> buildJsonObject { put("chat", chat(2)); put("items", JsonArray(emptyList())); put("total", 0) }
                    else -> buildJsonObject { }
                }
            }
            scope.backgroundScope.launch { vm.uiState.collect { } }
            scope.backgroundScope.launch { vm.events.collect { if (it is HistoryEvent.Message) messages += it.text } }
            scope.testScheduler.runCurrent()
        }
    }

    @Test
    fun `opening the sidebar asks for 20 chats and offers See all`() = runTest {
        val r = Rig(this)
        r.vm.onSidebarOpened(); runCurrent()
        val request = r.link.opsCalled("chats.list").single()
        assertEquals("20", request["limit"]!!.jsonPrimitive.content)
        assertNull(request["query"])
        assertEquals(20, r.state.conversations.size)
        assertTrue(r.state.list.showSeeAll)
        assertEquals(50, r.state.list.total)
    }

    @Test
    fun `the 13th item prefetches and See all shows the next 40`() = runTest {
        val r = Rig(this, total = 95)
        r.vm.onSidebarOpened(); runCurrent()
        r.vm.onVisibleIndex(11); runCurrent()
        assertEquals(1, r.link.opsCalled("chats.list").size)
        r.vm.onVisibleIndex(12); runCurrent()
        assertEquals(40, r.link.opsCalled("chats.list").last()["limit"]!!.jsonPrimitive.content.toInt())
        assertEquals(20, r.state.conversations.size)
        r.vm.seeAll(); runCurrent()
        assertEquals(60, r.state.conversations.size)
    }

    @Test
    fun `typing searches on the PC after 300 ms, and only the last text counts`() = runTest {
        val r = Rig(this)
        r.vm.onSidebarOpened(); runCurrent()
        r.vm.setQuery("k"); advanceTimeBy(100); r.vm.setQuery("ko"); advanceTimeBy(100); r.vm.setQuery("kot"); runCurrent()
        assertEquals(1, r.link.opsCalled("chats.list").size) // nothing yet
        advanceTimeBy(299); runCurrent()
        assertEquals(1, r.link.opsCalled("chats.list").size)
        advanceTimeBy(2); runCurrent()
        val searches = r.link.opsCalled("chats.list")
        assertEquals(2, searches.size)
        assertEquals("kot", searches.last()["query"]!!.jsonPrimitive.content)
        assertEquals("20", searches.last()["limit"]!!.jsonPrimitive.content)
    }

    @Test
    fun `starred and archived are filters of the same request`() = runTest {
        val r = Rig(this)
        r.vm.onSidebarOpened(); runCurrent()
        r.vm.setFilter(HistoryFilter.STARRED); runCurrent()
        assertEquals("true", r.link.opsCalled("chats.list").last()["starred"]!!.jsonPrimitive.content)
        r.vm.setFilter(HistoryFilter.ARCHIVED); runCurrent()
        val last = r.link.opsCalled("chats.list").last()
        assertEquals("true", last["archived"]!!.jsonPrimitive.content)
        assertNull(last["starred"])
        r.vm.setFilter(HistoryFilter.ALL); runCurrent()
        assertNull(r.link.opsCalled("chats.list").last()["archived"])
    }

    @Test
    fun `chats created, updated and deleted on the PC change the list live`() = runTest {
        val r = Rig(this)
        r.vm.onSidebarOpened(); runCurrent()
        fun dto(i: Int, title: String = "Chat $i", archived: Boolean = false) = ChatSummaryDto("c$i", title, "2025-01-01T00:00:00Z", "2025-01-01T00:00:00Z", null, "auto", 1, "", false, archived)
        r.link.emit(LinkEvent.ChatCreated(1, dto(900, "Brand new"))); runCurrent()
        assertEquals("c900", r.state.conversations.first().id)
        assertEquals(51, r.state.list.total)
        r.link.emit(LinkEvent.ChatUpdated(2, dto(5, "Renamed elsewhere"))); runCurrent()
        assertEquals(listOf("c5", "c900"), r.state.conversations.take(2).map { it.id })
        assertEquals("Renamed elsewhere", r.state.conversations.first().title)
        r.link.emit(LinkEvent.ChatUpdated(3, dto(7, archived = true))); runCurrent() // archived elsewhere: leaves this list
        assertTrue(r.state.conversations.none { it.id == "c7" })
        r.link.emit(LinkEvent.ChatDeleted(4, "c3")); runCurrent()
        assertTrue(r.state.conversations.none { it.id == "c3" })
    }

    @Test
    fun `a reconnect reloads the open list from the first page`() = runTest {
        val r = Rig(this)
        r.vm.onSidebarOpened(); runCurrent()
        r.link.emit(LinkEvent.Refresh); runCurrent()
        assertEquals(2, r.link.opsCalled("chats.list").size)
        // a closed sidebar is not reloaded behind the person's back
        r.vm.onSidebarClosed()
        r.link.emit(LinkEvent.Refresh); runCurrent()
        assertEquals(2, r.link.opsCalled("chats.list").size)
    }

    @Test
    fun `star, rename and delete change the row in place and report`() = runTest {
        val r = Rig(this)
        r.vm.onSidebarOpened(); runCurrent()
        val third = r.state.conversations[3]
        r.vm.toggleStar(third); runCurrent()
        assertTrue(r.state.conversations[3].isStarred)
        assertEquals("c3", r.state.conversations[3].id) // not moved
        r.vm.rename(third, "  Better  "); runCurrent()
        assertEquals("Better", r.state.conversations[3].title)
        r.vm.delete(third); runCurrent()
        assertTrue(r.state.conversations.none { it.id == "c3" })
        assertEquals("Deleted “Chat 3”", r.messages.last())
        assertEquals(1, r.link.opsCalled("chat.delete").size)
    }

    @Test
    fun `archiving removes the row after the PC agrees`() = runTest {
        val r = Rig(this)
        r.vm.onSidebarOpened(); runCurrent()
        r.vm.toggleArchive(r.state.conversations[1]); runCurrent()
        assertEquals("true", r.link.opsCalled("chat.set").single()["archived"]!!.jsonPrimitive.content)
        assertTrue(r.state.conversations.none { it.id == "c1" })
    }

    @Test
    fun `a failed change leaves the list alone and says why`() = runTest {
        val r = Rig(this)
        r.vm.onSidebarOpened(); runCurrent()
        r.link.handler = { _, _ -> throw com.avek.chat.core.link.rpc.RpcException(com.avek.chat.core.link.rpc.RpcException.NOT_CONNECTED, "x") }
        r.vm.toggleArchive(r.state.conversations[1]); runCurrent()
        assertEquals(20, r.state.conversations.size)
        assertEquals("PC not reachable.", r.messages.last())
    }

    @Test
    fun `download and remove download tell the PC the new set`() = runTest {
        val r = Rig(this)
        r.vm.onSidebarOpened(); runCurrent()
        r.vm.toggleDownload(r.state.conversations[2]); runCurrent()
        assertEquals(listOf("c2"), (r.link.opsCalled("downloads.set").last()["chatIds"] as JsonArray).map { it.jsonPrimitive.content })
        assertTrue("c2" in r.state.downloadedIds)
        r.vm.toggleDownload(r.state.conversations[2]); runCurrent()
        assertTrue((r.link.opsCalled("downloads.set").last()["chatIds"] as JsonArray).isEmpty())
        assertFalse("c2" in r.state.downloadedIds)
    }

    @Test
    fun `without the PC the sidebar says so`() = runTest {
        val r = Rig(this)
        r.link.connectionState.value = ConnectionState.Connecting(listOf("last"), 1)
        runCurrent()
        assertTrue(r.state.offline)
    }
}

@OptIn(ExperimentalCoroutinesApi::class)
class ConnectionViewModelTest {

    @Before fun setMain() = Dispatchers.setMain(StandardTestDispatcher())

    @After fun resetMain() = Dispatchers.resetMain()

    private inner class Rig(val scope: TestScope, val beacons: Flow<Beacon> = emptyFlow()) {
        val server = FakeHarnessServer(scope.backgroundScope)
        val store = InMemoryPairedPcStore()
        val link = FakeLink { _, _ -> buildJsonObject { } }
        val settings = MemorySettings()
        val channels = ChannelFactory { target ->
            val (client, serverSide) = InMemoryChannel.pair(target.host, target.port)
            scope.backgroundScope.launch { server.serve(serverSide) }
            client
        }
        val pairing = PairingManager(store, channels, BeaconSource { beacons }, NoWifiBinding, Handshake())
        val vm = ConnectionViewModel(settings, store, pairing, link, HarnessApi(link), object : DeviceInfo { override val model = "Pixel Tablet" })
        val messages = mutableListOf<String>()
        val state get() = vm.uiState.value

        init {
            scope.backgroundScope.launch { vm.uiState.collect { } }
            scope.backgroundScope.launch { vm.messages.collect { messages += it } }
            scope.testScheduler.runCurrent()
        }
    }

    @Test
    fun `the code is uppercased, cleaned and dashed after every four characters`() {
        assertEquals("ABCD", PairingForm.formatCode("abcd"))
        assertEquals("ABCD-E", PairingForm.formatCode("abcde"))
        assertEquals("ABCD-EFGH-JKLM", PairingForm.formatCode("abcd-efgh jklm"))
        assertEquals("ABCD-EFGH-JKLM", PairingForm.formatCode("abcdefghjklmXYZ"))
        assertEquals("A1B2", PairingForm.formatCode("a!1 b@2"))
        assertEquals("", PairingForm.formatCode(""))
    }

    @Test
    fun `pairing needs a full code, a target and a device name`() = runTest {
        val r = Rig(this)
        r.vm.openPairing(); runCurrent()
        assertEquals("Pixel Tablet", r.state.form!!.deviceName)
        assertFalse(r.state.form!!.canPair)
        r.vm.onManualAddress("192.168.43.5"); r.vm.onCode("abcd-efgh-jkl"); runCurrent()
        assertFalse(r.state.form!!.canPair) // 11 characters
        r.vm.onCode("abcd-efgh-jklm"); runCurrent()
        assertTrue(r.state.form!!.canPair)
        r.vm.onDeviceName("  "); runCurrent()
        assertFalse(r.state.form!!.canPair)
    }

    @Test
    fun `a PC announcing itself is listed and chosen when it is the only one`() = runTest {
        val r = Rig(this, beacons = flowOf(Beacon("s_1", "Lab laptop", "192.168.43.5", 7810)))
        r.vm.openPairing(); runCurrent()
        assertEquals(listOf("Lab laptop"), r.state.form!!.discovered.map { it.name })
        assertEquals("s_1", r.state.form!!.selectedServerId)
    }

    @Test
    fun `pairing with the right code stores the PC and starts connecting`() = runTest {
        val r = Rig(this)
        r.vm.openPairing(); runCurrent()
        r.vm.onManualAddress("192.168.43.5:7810"); r.vm.onCode("abcdefghjklm"); runCurrent()
        r.vm.pair(); runCurrent()
        assertEquals("Test PC", r.state.form!!.pairedWith)
        val pc = r.store.pc.value
        assertNotNull(pc)
        assertEquals("Pixel Tablet", pc!!.deviceName)
        assertEquals("192.168.43.5", pc.lastHost)
        assertEquals(1, r.link.connects) // reconnect() = disconnect + connect
        assertEquals("Test PC", r.state.paired!!.serverName)
        r.vm.closePairing(); runCurrent()
        assertNull(r.state.form)
    }

    @Test
    fun `a wrong code says so and nothing is stored`() = runTest {
        val r = Rig(this)
        r.vm.openPairing(); runCurrent()
        r.vm.onManualAddress("192.168.43.5"); r.vm.onCode("ZZZZZZZZZZZZ"); runCurrent()
        r.vm.pair(); runCurrent()
        assertEquals("That code is not right. Check it on the laptop.", r.state.form!!.error)
        assertFalse(r.state.form!!.busy)
        assertNull(r.store.pc.value)
        // typing again clears the message
        r.vm.onCode("ABCDEFGHJKLM"); runCurrent()
        assertNull(r.state.form!!.error)
    }

    @Test
    fun `routes can be added, reordered and removed, but last and discover stay`() = runTest {
        val r = Rig(this)
        assertEquals(listOf(RouteSpec.Last, RouteSpec.Discover), r.state.settings.routes)
        assertFalse(r.vm.addHost("not an address")); runCurrent()
        assertTrue(r.vm.addHost("192.168.43.5")); runCurrent()
        assertFalse(r.vm.addHost("192.168.43.5:7810")); runCurrent()
        assertTrue(r.vm.addHost("10.0.0.2:9000")); runCurrent()
        assertEquals(listOf(RouteSpec.Last, RouteSpec.Discover, RouteSpec.Host("192.168.43.5", 7810), RouteSpec.Host("10.0.0.2", 9000)), r.state.settings.routes)
        assertEquals(2, r.messages.size)
        r.vm.moveRoute(3, -2); runCurrent()
        assertEquals(RouteSpec.Host("10.0.0.2", 9000), r.state.settings.routes[1])
        r.vm.moveRoute(0, -1); runCurrent() // already first
        assertEquals(RouteSpec.Last, r.state.settings.routes[0])
        r.vm.removeRoute(0); runCurrent() // fixed
        assertEquals(RouteSpec.Last, r.state.settings.routes[0])
        r.vm.removeRoute(1); runCurrent()
        assertEquals(listOf(RouteSpec.Last, RouteSpec.Discover, RouteSpec.Host("192.168.43.5", 7810)), r.state.settings.routes)
    }

    @Test
    fun `the switches and the keep-lists number are saved and clamped`() = runTest {
        val r = Rig(this)
        assertFalse(r.state.settings.workInBackground)
        r.vm.setWorkInBackground(true); r.vm.setDemoMode(true); runCurrent()
        assertTrue(r.state.settings.workInBackground)
        assertTrue(r.state.demo)
        assertTrue(r.state.connected)
        r.vm.setKeepListsSeconds(5); runCurrent()
        assertEquals(30, r.state.settings.keepListsSeconds)
        r.vm.setKeepListsSeconds(9_000); runCurrent()
        assertEquals(600, r.state.settings.keepListsSeconds)
        r.vm.setKeepListsSeconds(240); runCurrent()
        assertEquals(240, r.state.settings.keepListsSeconds)
    }

    @Test
    fun `unpair tells the PC, wipes the secret and stops connecting`() = runTest {
        val r = Rig(this)
        r.store.save(PairedPc("d1", ByteArray(32), "s_1", "Lab laptop", "Pixel Tablet"))
        r.link.connectionState.value = ConnectionState.Connected("last", "Lab laptop")
        runCurrent()
        r.vm.unpair(); runCurrent()
        assertEquals(1, r.link.opsCalled("device.unpair").size)
        assertNull(r.store.pc.value)
        assertEquals(1, r.link.disconnects)
        assertEquals(listOf("Unpaired"), r.messages)
    }

    @Test
    fun `unpair works even when the PC cannot be told`() = runTest {
        val r = Rig(this)
        r.store.save(PairedPc("d1", ByteArray(32), "s_1", "Lab laptop", "Pixel Tablet"))
        r.link.connectionState.value = ConnectionState.Connecting(listOf("last"), 1)
        runCurrent()
        r.vm.unpair(); runCurrent()
        assertTrue(r.link.opsCalled("device.unpair").isEmpty())
        assertNull(r.store.pc.value)
    }

    @Test
    fun `the status line reads like the spec says`() = runTest {
        val r = Rig(this)
        r.link.connectionState.value = ConnectionState.Connecting(listOf("last", "discover", "host", "host"), 1)
        runCurrent()
        assertEquals("Trying: last, discover, 2 hosts", r.state.status)
        r.link.connectionState.value = ConnectionState.Connected("host 192.168.43.5:7810", "Lab laptop")
        runCurrent()
        assertEquals("Connected to Lab laptop · host 192.168.43.5:7810", r.state.status)
    }

    @Test
    fun `reconnect is forwarded`() = runTest {
        val r = Rig(this)
        r.vm.reconnect(); runCurrent()
        assertEquals(1, r.link.disconnects)
        assertEquals(1, r.link.connects)
    }
}
