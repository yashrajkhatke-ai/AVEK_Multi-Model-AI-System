package com.avek.chat.feature

import com.avek.chat.core.common.DeviceInfo
import com.avek.chat.core.data.downloads.DownloadManager
import com.avek.chat.core.data.remote.RemoteChatRepository
import com.avek.chat.core.domain.lists.ListMemoryRegistry
import com.avek.chat.core.domain.repository.SettingsRepository
import com.avek.chat.core.link.HarnessApi
import com.avek.chat.core.link.crypto.AvekProtocol
import com.avek.chat.core.link.crypto.PairingHandshake
import com.avek.chat.core.link.PcControl
import com.avek.chat.core.link.RekeyOutcome
import com.avek.chat.core.link.route.FailureReason
import com.avek.chat.core.link.route.NetworkEnvironment
import com.avek.chat.core.link.route.RouteFailure
import com.avek.chat.core.link.route.RouteKind
import com.avek.chat.core.link.route.RouteMode
import com.avek.chat.core.link.store.GrantSecrets
import com.avek.chat.core.link.store.SoftwareSecretVault
import com.avek.chat.core.link.wire.NgrokRouteDto
import com.avek.chat.core.link.wire.RoutesData
import com.avek.chat.core.link.wire.TailscaleRouteDto
import com.avek.chat.core.link.wire.WifiAddressDto
import com.avek.chat.core.link.wire.WifiRoutesDto
import com.avek.chat.feature.connection.PairingUiState
import com.avek.chat.feature.connection.RekeyUi
import com.avek.chat.feature.connection.lastConnectedText
import com.avek.chat.core.link.discovery.FindClient
import com.avek.chat.core.link.store.FilePairedPcStore
import com.avek.chat.core.link.store.SoftwareIdentityVault
import com.avek.chat.core.link.pairing.PairingManager
import com.avek.chat.core.link.route.ConnectionState
import com.avek.chat.core.link.store.PairedPc
import com.avek.chat.core.link.transport.ChannelFactory
import com.avek.chat.core.link.transport.NoWifiBinding
import com.avek.chat.core.link.wire.ChatSummaryDto
import com.avek.chat.core.link.wire.LinkEvent
import com.avek.chat.core.model.settings.ConnectionSettings
import com.avek.chat.core.model.settings.UserSettings
import com.avek.chat.domain.FakeLink
import com.avek.chat.domain.MemoryStore
import com.avek.chat.feature.connection.ConnectionUi
import com.avek.chat.feature.connection.ConnectionViewModel
import com.avek.chat.feature.connection.PairingStep
import com.avek.chat.feature.connection.PairingViewModel
import com.avek.chat.feature.connection.describe
import com.avek.chat.link.FakeKnockListener
import com.avek.chat.link.FakeUdpTransport
import com.avek.chat.feature.history.HistoryEvent
import com.avek.chat.feature.history.HistoryFilter
import com.avek.chat.feature.history.HistoryViewModel
import com.avek.chat.link.FakeHarnessServer
import com.avek.chat.link.InMemoryChannel
import com.avek.chat.link.InMemoryPairedPcStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.emptyFlow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.launch
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.TestScope
import kotlinx.coroutines.test.advanceTimeBy
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

private class MemorySettings : SettingsRepository {
    val state = MutableStateFlow(UserSettings())
    override val settings: Flow<UserSettings> = state
    override suspend fun update(transform: (UserSettings) -> UserSettings) {
        state.value = transform(state.value)
    }
}

@OptIn(ExperimentalCoroutinesApi::class)
class HistoryViewModelTest {

    @Before fun setMain() = Dispatchers.setMain(StandardTestDispatcher())

    @After fun resetMain() = Dispatchers.resetMain()

    private fun chat(i: Int, starred: Boolean = false, archived: Boolean = false, title: String = "Chat $i") = buildJsonObject {
        put("chatId", "c$i"); put("title", title); put("createdAt", "2025-01-01T00:00:00Z"); put("updatedAt", "2025-01-01T00:00:00Z")
        put("mode", "auto"); put("turnCount", 1); put("preview", ""); put("starred", starred); put("archived", archived)
    }

    private inner class Rig(scope: TestScope, total: Int = 50) {
        val link = FakeLink()
        val api = HarnessApi(link)
        val settings = MemorySettings()
        val store = MemoryStore()
        val appScope = CoroutineScope(Dispatchers.Main)
        val downloads = DownloadManager(api, store, link, MutableStateFlow(false), appScope)
        val messages = mutableListOf<String>()
        val vm = HistoryViewModel(RemoteChatRepository(api), link, downloads, settings, ListMemoryRegistry())
        val state get() = vm.uiState.value

        init {
            link.handler = { op, args ->
                when (op) {
                    "chats.list" -> {
                        val limit = args["limit"]!!.jsonPrimitive.content.toInt()
                        val start = args["after"]?.jsonPrimitive?.content?.toInt() ?: 0
                        val end = minOf(total, start + limit)
                        buildJsonObject {
                            put("items", JsonArray((start until end).map { chat(it) }))
                            put("total", total)
                            put("next", if (end < total) JsonPrimitive(end.toString()) else JsonPrimitive(null as String?))
                        }
                    }
                    "chat.set" -> buildJsonObject {
                        put("chat", chat(args["chatId"]!!.jsonPrimitive.content.removePrefix("c").toInt(),
                            starred = args["starred"]?.jsonPrimitive?.content == "true", title = args["title"]?.jsonPrimitive?.content ?: "Chat"))
                    }
                    "downloads.set" -> buildJsonObject { put("chatIds", args["chatIds"]!!) }
                    "chat.get" -> buildJsonObject { put("chat", chat(2)); put("items", JsonArray(emptyList())); put("total", 0) }
                    else -> buildJsonObject { }
                }
            }
            scope.backgroundScope.launch { vm.uiState.collect { } }
            scope.backgroundScope.launch { vm.events.collect { if (it is HistoryEvent.Message) messages += it.text } }
            scope.testScheduler.runCurrent()
        }
    }

    @Test
    fun `opening the sidebar asks for 20 chats and offers See all`() = runTest {
        val r = Rig(this)
        r.vm.onSidebarOpened(); runCurrent()
        val request = r.link.opsCalled("chats.list").single()
        assertEquals("20", request["limit"]!!.jsonPrimitive.content)
        assertNull(request["query"])
        assertEquals(20, r.state.conversations.size)
        assertTrue(r.state.list.showSeeAll)
        assertEquals(50, r.state.list.total)
    }

    @Test
    fun `the 13th item prefetches and See all shows the next 40`() = runTest {
        val r = Rig(this, total = 95)
        r.vm.onSidebarOpened(); runCurrent()
        r.vm.onVisibleIndex(11); runCurrent()
        assertEquals(1, r.link.opsCalled("chats.list").size)
        r.vm.onVisibleIndex(12); runCurrent()
        assertEquals(40, r.link.opsCalled("chats.list").last()["limit"]!!.jsonPrimitive.content.toInt())
        assertEquals(20, r.state.conversations.size)
        r.vm.seeAll(); runCurrent()
        assertEquals(60, r.state.conversations.size)
    }

    @Test
    fun `typing searches on the PC after 300 ms, and only the last text counts`() = runTest {
        val r = Rig(this)
        r.vm.onSidebarOpened(); runCurrent()
        r.vm.setQuery("k"); advanceTimeBy(100); r.vm.setQuery("ko"); advanceTimeBy(100); r.vm.setQuery("kot"); runCurrent()
        assertEquals(1, r.link.opsCalled("chats.list").size) // nothing yet
        advanceTimeBy(299); runCurrent()
        assertEquals(1, r.link.opsCalled("chats.list").size)
        advanceTimeBy(2); runCurrent()
        val searches = r.link.opsCalled("chats.list")
        assertEquals(2, searches.size)
        assertEquals("kot", searches.last()["query"]!!.jsonPrimitive.content)
        assertEquals("20", searches.last()["limit"]!!.jsonPrimitive.content)
    }

    @Test
    fun `starred and archived are filters of the same request`() = runTest {
        val r = Rig(this)
        r.vm.onSidebarOpened(); runCurrent()
        r.vm.setFilter(HistoryFilter.STARRED); runCurrent()
        assertEquals("true", r.link.opsCalled("chats.list").last()["starred"]!!.jsonPrimitive.content)
        r.vm.setFilter(HistoryFilter.ARCHIVED); runCurrent()
        val last = r.link.opsCalled("chats.list").last()
        assertEquals("true", last["archived"]!!.jsonPrimitive.content)
        assertNull(last["starred"])
        r.vm.setFilter(HistoryFilter.ALL); runCurrent()
        assertNull(r.link.opsCalled("chats.list").last()["archived"])
    }

    @Test
    fun `chats created, updated and deleted on the PC change the list live`() = runTest {
        val r = Rig(this)
        r.vm.onSidebarOpened(); runCurrent()
        fun dto(i: Int, title: String = "Chat $i", archived: Boolean = false) = ChatSummaryDto("c$i", title, "2025-01-01T00:00:00Z", "2025-01-01T00:00:00Z", null, "auto", 1, "", false, archived)
        r.link.emit(LinkEvent.ChatCreated(1, dto(900, "Brand new"))); runCurrent()
        assertEquals("c900", r.state.conversations.first().id)
        assertEquals(51, r.state.list.total)
        r.link.emit(LinkEvent.ChatUpdated(2, dto(5, "Renamed elsewhere"))); runCurrent()
        assertEquals(listOf("c5", "c900"), r.state.conversations.take(2).map { it.id })
        assertEquals("Renamed elsewhere", r.state.conversations.first().title)
        r.link.emit(LinkEvent.ChatUpdated(3, dto(7, archived = true))); runCurrent() // archived elsewhere: leaves this list
        assertTrue(r.state.conversations.none { it.id == "c7" })
        r.link.emit(LinkEvent.ChatDeleted(4, "c3")); runCurrent()
        assertTrue(r.state.conversations.none { it.id == "c3" })
    }

    @Test
    fun `a reconnect reloads the open list from the first page`() = runTest {
        val r = Rig(this)
        r.vm.onSidebarOpened(); runCurrent()
        r.link.emit(LinkEvent.Refresh); runCurrent()
        assertEquals(2, r.link.opsCalled("chats.list").size)
        // a closed sidebar is not reloaded behind the person's back
        r.vm.onSidebarClosed()
        r.link.emit(LinkEvent.Refresh); runCurrent()
        assertEquals(2, r.link.opsCalled("chats.list").size)
    }

    @Test
    fun `star, rename and delete change the row in place and report`() = runTest {
        val r = Rig(this)
        r.vm.onSidebarOpened(); runCurrent()
        val third = r.state.conversations[3]
        r.vm.toggleStar(third); runCurrent()
        assertTrue(r.state.conversations[3].isStarred)
        assertEquals("c3", r.state.conversations[3].id) // not moved
        r.vm.rename(third, "  Better  "); runCurrent()
        assertEquals("Better", r.state.conversations[3].title)
        r.vm.delete(third); runCurrent()
        assertTrue(r.state.conversations.none { it.id == "c3" })
        assertEquals("Deleted “Chat 3”", r.messages.last())
        assertEquals(1, r.link.opsCalled("chat.delete").size)
    }

    @Test
    fun `archiving removes the row after the PC agrees`() = runTest {
        val r = Rig(this)
        r.vm.onSidebarOpened(); runCurrent()
        r.vm.toggleArchive(r.state.conversations[1]); runCurrent()
        assertEquals("true", r.link.opsCalled("chat.set").single()["archived"]!!.jsonPrimitive.content)
        assertTrue(r.state.conversations.none { it.id == "c1" })
    }

    @Test
    fun `a failed change leaves the list alone and says why`() = runTest {
        val r = Rig(this)
        r.vm.onSidebarOpened(); runCurrent()
        r.link.handler = { _, _ -> throw com.avek.chat.core.link.rpc.RpcException(com.avek.chat.core.link.rpc.RpcException.NOT_CONNECTED, "x") }
        r.vm.toggleArchive(r.state.conversations[1]); runCurrent()
        assertEquals(20, r.state.conversations.size)
        assertEquals("PC not reachable.", r.messages.last())
    }

    @Test
    fun `download and remove download tell the PC the new set`() = runTest {
        val r = Rig(this)
        r.vm.onSidebarOpened(); runCurrent()
        r.vm.toggleDownload(r.state.conversations[2]); runCurrent()
        assertEquals(listOf("c2"), (r.link.opsCalled("downloads.set").last()["chatIds"] as JsonArray).map { it.jsonPrimitive.content })
        assertTrue("c2" in r.state.downloadedIds)
        r.vm.toggleDownload(r.state.conversations[2]); runCurrent()
        assertTrue((r.link.opsCalled("downloads.set").last()["chatIds"] as JsonArray).isEmpty())
        assertFalse("c2" in r.state.downloadedIds)
    }

    @Test
    fun `without the PC the sidebar says so`() = runTest {
        val r = Rig(this)
        r.link.connectionState.value = ConnectionState.Unreachable("PC", 0L)
        runCurrent()
        assertTrue(r.state.offline)
    }
}

@OptIn(ExperimentalCoroutinesApi::class)
class ConnectionViewModelTest {

    @Before fun setMain() = Dispatchers.setMain(StandardTestDispatcher())

    @After fun resetMain() = Dispatchers.resetMain()

    /** What the real link does for Forget / Replace, recorded. */
    private class FakeControl(val store: InMemoryPairedPcStore) : PcControl {
        var forgets = 0
        var rekeys = 0
        var outcome: RekeyOutcome = RekeyOutcome.Done
        override val currentRoute: RouteKind? = RouteKind.WIFI
        override suspend fun replaceKeys(): RekeyOutcome { rekeys++; return outcome }
        override suspend fun forget() { forgets++; store.clear() }
    }

    private class Env(var installed: Boolean = true) : NetworkEnvironment {
        override val changes = emptyFlow<Unit>()
        override fun tailscaleInstalled() = installed
        override fun vpnActive() = false
    }

    private inner class Rig(val scope: TestScope) {
        val server = FakeHarnessServer(scope.backgroundScope)
        val store = InMemoryPairedPcStore()
        val identity = SoftwareIdentityVault()
        val link = FakeLink { _, _ -> buildJsonObject { } }
        val settings = MemorySettings()
        val listener = FakeKnockListener(server.identity, { server.devices.mapValues { it.value.pub } }, pairingOpenName = "Lab laptop")
        val udp = FakeUdpTransport({ scope.testScheduler.currentTime }, respond = listener::respond)
        val channels = ChannelFactory { target ->
            val (client, serverSide) = InMemoryChannel.pair(target.remote.host, target.remote.port)
            scope.backgroundScope.launch { server.serve(serverSide) }
            client
        }
        val secrets = GrantSecrets(SoftwareSecretVault())
        val pairing = PairingManager(
            store, identity, secrets, channels, FindClient(udp), NoWifiBinding,
            PairingHandshake(kdf = FakeHarnessServer.TEST_KDF, computeDispatcher = StandardTestDispatcher(scope.testScheduler)),
        )
        val control = FakeControl(store)
        val env = Env()
        val vm = ConnectionViewModel(settings, store, link, control, env)
        val messages = mutableListOf<String>()
        val state get() = vm.uiState.value

        init {
            scope.backgroundScope.launch { vm.uiState.collect { } }
            scope.backgroundScope.launch { vm.messages.collect { messages += it } }
            scope.testScheduler.runCurrent()
        }
    }

    private val serverKey = SoftwareIdentityVault().also { it.create(FakeHarnessServer.ALIAS) }
    private val serverPub = serverKey.publicKey(FakeHarnessServer.ALIAS)

    private fun pc(routes: RoutesData? = null) = PairedPc(
        "d_5587348a01", "avek.identity.1", AvekProtocol.serverIdOf(serverPub), "Lab laptop", serverPub, "Pixel Tablet", ByteArray(92), routes = routes,
    )

    @Test
    fun `the switches, the keep-lists number and the route setting are saved`() = runTest {
        val r = Rig(this)
        assertFalse(r.state.settings.workInBackground)
        r.vm.setWorkInBackground(true); r.vm.setDemoMode(true); runCurrent()
        assertTrue(r.state.settings.workInBackground)
        assertTrue(r.state.demo)
        assertTrue(r.state.connected)
        r.vm.setKeepListsSeconds(5); runCurrent()
        assertEquals(30, r.state.settings.keepListsSeconds)
        r.vm.setKeepListsSeconds(9_000); runCurrent()
        assertEquals(600, r.state.settings.keepListsSeconds)
        r.vm.setRouteMode(RouteMode.TailscaleOnly); runCurrent()
        assertEquals(RouteMode.TailscaleOnly, r.state.routeMode)
        assertEquals("TailscaleOnly", r.settings.state.value.connection.routeMode)
    }

    @Test
    fun `the paired PC is shown with its fingerprint, its routes and the route in use`() = runTest {
        val r = Rig(this)
        r.store.save(
            pc(
                RoutesData(
                    wifi = WifiRoutesDto(listOf(WifiAddressDto("Wi-Fi", "192.168.43.5"))),
                    tailscale = TailscaleRouteDto(host = "100.64.1.2", dns = "legion.tail1234.ts.net"),
                    ngrok = NgrokRouteDto("https://my-pc.ngrok-free.dev", "online", null),
                ),
            ),
        )
        r.link.connectionState.value = ConnectionState.Connected("Lab laptop", RouteKind.TAILSCALE, "100.64.1.2:7810")
        runCurrent()
        assertEquals("Lab laptop", r.state.paired!!.serverName)
        assertEquals(AvekProtocol.fingerprintText(serverPub), r.state.paired!!.fingerprint)
        assertEquals("Connected to Lab laptop by Tailscale", r.state.status)
        assertEquals(RouteKind.TAILSCALE, r.state.routeInUse)
        assertEquals(listOf("192.168.43.5 (Wi-Fi)"), r.state.routes.wifiAddresses)
        assertEquals("legion.tail1234.ts.net", r.state.routes.tailscaleName)
        assertTrue(r.state.routes.tailscaleInstalled)
        assertEquals("https://my-pc.ngrok-free.dev", r.state.routes.ngrokUrl)
        assertEquals("online", r.state.routes.ngrokState)
    }

    @Test
    fun `forget goes through the link and says so`() = runTest {
        val r = Rig(this)
        r.store.save(pc())
        r.vm.forget(); runCurrent()
        assertEquals(1, r.control.forgets)
        assertNull(r.store.pc.value)
        assertEquals(listOf("This PC was forgotten"), r.messages)
    }

    @Test
    fun `replacing the keys shows progress and the result`() = runTest {
        val r = Rig(this)
        r.store.save(pc())
        r.vm.replaceKeys(); runCurrent()
        assertEquals(RekeyUi.Done, r.state.rekey)
        r.control.outcome = RekeyOutcome.Failed("The PC refused")
        r.vm.replaceKeys(); runCurrent()
        assertEquals(RekeyUi.Failed("The PC refused"), r.state.rekey)
        assertEquals(2, r.control.rekeys)
    }

    @Test
    fun `the status line reads like the spec says`() {
        assertEquals("Looking for Lab laptop...", describe(ConnectionState.Looking("Lab laptop"), false))
        assertEquals("Waking up your PC...", describe(ConnectionState.WakingPc("Lab laptop"), false))
        assertEquals("Waking up your PC...", describe(ConnectionState.Connected("Lab laptop", RouteKind.WIFI, "x", waking = true), false))
        assertEquals("Connected to Lab laptop by Wi-Fi", describe(ConnectionState.Connected("Lab laptop", RouteKind.WIFI, "10.0.0.2:7810"), false))
        assertEquals("Connected to Lab laptop by ngrok", describe(ConnectionState.Connected("Lab laptop", RouteKind.NGROK, "x"), false))
        assertEquals("PC not reachable - trying again in 8 s", describe(ConnectionState.Unreachable("Lab laptop", 0L, 18_000L), false, nowMs = 10_000L))
        assertEquals("PC not reachable", describe(ConnectionState.Unreachable("Lab laptop", 0L, null), false))
        assertEquals("This PC forgot this device. Pair again.", describe(ConnectionState.Forgotten, false))
        assertEquals("This version pairs differently. Pair with your PC again.", describe(ConnectionState.NeedsPairing(FilePairedPcStore.MIGRATION_NOTICE), false))
        assertEquals("Demo mode: no PC needed", describe(ConnectionState.Forgotten, true))
        assertTrue(ConnectionUi.from(ConnectionState.Forgotten, false).needsPairing)
    }

    @Test
    fun `cannot reach your PC lists every route with a plain reason`() {
        val failures = listOf(
            RouteFailure(RouteKind.WIFI, FailureReason.NotFound, "x"),
            RouteFailure(RouteKind.TAILSCALE, FailureReason.Skipped, "Tailscale is not installed on this phone"),
            RouteFailure(RouteKind.NGROK, FailureReason.Denied, ""),
        )
        val ui = ConnectionUi.from(ConnectionState.Unreachable("Lab laptop", 0L, null, failures, 1_000L), false)
        val lines = ui.unreachable!!.lines
        assertEquals(listOf(RouteKind.WIFI, RouteKind.TAILSCALE, RouteKind.NGROK), lines.map { it.route })
        assertEquals("Your PC did not answer. Is it on and on this network?", lines[0].text)
        assertEquals("Tailscale is not installed on this phone", lines[1].text)
        assertEquals("Your PC does not accept this device on this route.", lines[2].text)
        assertEquals(1_000L, ui.unreachable!!.lastConnectedAt)
        val vpn = ConnectionUi.from(ConnectionState.Unreachable("Lab laptop", 0L, null, listOf(RouteFailure(RouteKind.TAILSCALE, FailureReason.Timeout, "")), null), false, vpnActive = true)
        assertEquals("Tailscale is not available while another VPN is on", vpn.unreachable!!.lines[1].text)
        assertEquals("Last connected 3 hours ago", lastConnectedText(0L, nowMs = 3 * 3_600_000L + 5_000))
        assertEquals("Never connected", lastConnectedText(null))
    }

    @Test
    fun `the migration notice is shown`() = runTest {
        val r = Rig(this)
        r.link.connectionState.value = ConnectionState.NeedsPairing(FilePairedPcStore.MIGRATION_NOTICE)
        runCurrent()
        assertEquals(FilePairedPcStore.MIGRATION_NOTICE, r.state.notice)
    }

    @Test
    fun `reconnect is forwarded`() = runTest {
        val r = Rig(this)
        r.vm.reconnect(); runCurrent()
        assertEquals(1, r.link.disconnects)
        assertEquals(1, r.link.connects)
    }

    // ------------------------------------------------------------------ pairing screen

    private inner class PairRig(val scope: TestScope) {
        val base = Rig(scope)
        val vm = PairingViewModel(base.pairing, base.link, base.settings, object : DeviceInfo { override val model = "Pixel Tablet" })
        val state get() = vm.state.value
    }

    @Test
    fun `pairing finds the PC, needs exactly 12 digits, and stores the PC`() = runTest {
        val r = PairRig(this)
        assertEquals(PairingStep.SEARCHING, r.state.step)
        advanceTimeBy(6_000)
        assertEquals(listOf("Lab laptop"), r.state.found.map { it.name })
        assertEquals("Pixel Tablet", r.state.deviceName)
        assertFalse("no code yet", r.state.canPair)

        r.vm.onCode("1234 5678 901")
        assertEquals(PairingUiState.CODE_HINT, r.state.codeHint)
        assertFalse(r.state.canPair)
        r.vm.onCode("1234-5678-9012")
        assertNull(r.state.codeHint)
        assertTrue(r.state.canPair)

        r.vm.pair(); runCurrent()
        advanceTimeBy(1_000)
        assertEquals(PairingStep.DONE, r.state.step)
        assertEquals("Test PC", r.state.pairedWith)
        assertNotNull(r.base.store.pc.value)
        assertEquals(0, r.state.codeDigits)
        assertTrue(r.base.settings.state.value.connection.onboardingDone)
        assertEquals(1, r.base.link.connects)
        r.vm.stopSearching()
    }

    @Test
    fun `a wrong code shows only the one generic sentence`() = runTest {
        val r = PairRig(this)
        advanceTimeBy(6_000)
        r.vm.onCode("123456789013")
        r.vm.pair(); runCurrent()
        advanceTimeBy(1_000)
        assertEquals(PairingStep.SEARCHING, r.state.step)
        assertEquals("Not paired. Check that the PC's pairing window is open and the code is right.", r.state.error)
        assertNull(r.base.store.pc.value)
        r.vm.stopSearching()
    }

    @Test
    fun `a closed window looks exactly like a wrong code, a busy one says so`() = runTest {
        val r = PairRig(this)
        advanceTimeBy(6_000)
        r.base.server.pairingWindowOpen = false
        r.vm.onCode(FakeHarnessServer.CODE)
        r.vm.pair(); runCurrent(); advanceTimeBy(1_000)
        assertEquals(PairingViewModel.NOT_PAIRED, r.state.error)
        r.base.server.pairingWindowOpen = true
        r.base.server.busy = true
        r.vm.pair(); runCurrent(); advanceTimeBy(1_000)
        assertEquals(PairingViewModel.WINDOW_BUSY, r.state.error)
        r.vm.stopSearching()
    }

    @Test
    fun `letters in the code are rejected and the code is cleared on exit`() = runTest {
        val r = PairRig(this)
        r.vm.onCode("12345678901a")
        assertTrue(r.state.codeInvalid)
        assertFalse(r.state.canPair)
        r.vm.onCode("123456789012")
        r.vm.clearCode()
        assertEquals(0, r.state.codeDigits)
        r.vm.stopSearching()
    }

    @Test
    fun `the Tailscale fallback pairs without find`() = runTest {
        val r = PairRig(this)
        r.vm.stopSearching()
        r.vm.onManualHost(" 10.0.0.2 ")
        r.vm.onCode(FakeHarnessServer.CODE)
        assertTrue(r.state.canPair)
        r.vm.pair(); runCurrent(); advanceTimeBy(1_000)
        assertEquals(PairingStep.DONE, r.state.step)
    }
}
