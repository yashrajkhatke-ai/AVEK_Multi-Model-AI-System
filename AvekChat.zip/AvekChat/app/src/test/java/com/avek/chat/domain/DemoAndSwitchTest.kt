package com.avek.chat.domain

import com.avek.chat.core.common.TimeProvider
import com.avek.chat.core.data.fake.ResponseComposer
import com.avek.chat.core.data.fake.SimulatedInferenceEngine
import com.avek.chat.core.data.link.DemoLinkRepository
import com.avek.chat.core.data.link.SwitchingLinkRepository
import com.avek.chat.core.data.remote.RemoteChatRepository
import com.avek.chat.core.data.remote.RemoteModelRepository
import com.avek.chat.core.domain.chat.ChatOptions
import com.avek.chat.core.domain.chat.GenerateReplyUseCase
import com.avek.chat.core.domain.chat.PromptRequest
import com.avek.chat.core.domain.chat.ReplyPhase
import com.avek.chat.core.domain.chat.StreamingReply
import com.avek.chat.core.domain.chat.TurnFollower
import com.avek.chat.core.domain.repository.ChatListQuery
import com.avek.chat.core.domain.usecase.TaskClassifier
import com.avek.chat.core.domain.usecase.TitleGenerator
import com.avek.chat.core.link.HarnessApi
import com.avek.chat.core.link.LinkProfile
import com.avek.chat.core.link.route.ConnectionState
import com.avek.chat.core.link.wire.LinkEvent
import com.avek.chat.core.model.MessageStatus
import com.avek.chat.core.model.TaskMode
import com.avek.chat.core.model.ThinkingDepth
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.toList
import kotlinx.coroutines.launch
import kotlinx.coroutines.test.advanceTimeBy
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import kotlinx.serialization.json.put
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class DemoAndSwitchTest {

    private fun TestScopeTime(scheduler: kotlinx.coroutines.test.TestCoroutineScheduler) = object : TimeProvider {
        override fun now() = 1_700_000_000_000L + scheduler.currentTime
    }

    private fun kotlinx.coroutines.test.TestScope.demo(): DemoLinkRepository {
        val time = TestScopeTime(testScheduler)
        val composer = ResponseComposer()
        return DemoLinkRepository(SimulatedInferenceEngine(composer, time), composer, TaskClassifier(), TitleGenerator(), time, backgroundScope)
    }

    private fun kotlinx.coroutines.test.TestScope.settle() {
        testScheduler.advanceTimeBy(60_000); testScheduler.runCurrent()
    }

    @Test
    fun `demo mode answers the same operations as the PC`() = runTest {
        val link = demo()
        val api = HarnessApi(link)
        val chats = RemoteChatRepository(api)
        val first = api.defaultModel()
        assertNotNull(first)
        assertEquals(1, first!!.rank)
        val page = chats.list(ChatListQuery(), 20, null)
        assertEquals(20, chats.list(ChatListQuery(), 20, null).items.size)
        assertTrue(page.total > 50)
        // the first page really is limited to what was asked
        assertEquals(5, chats.list(ChatListQuery(), 5, null).items.size)
        val models = RemoteModelRepository(api).allModels().toList()
        assertTrue(models.size >= 5)
        assertEquals(models.map { it.rank }, models.map { it.rank }.sorted())
    }

    @Test
    fun `a demo prompt streams a reply through the same event pipeline and creates the chat`() = runTest {
        val link = demo()
        val api = HarnessApi(link)
        val useCase = GenerateReplyUseCase(api, link, TurnFollower(RemoteChatRepository(api)), TestScopeTime(testScheduler))
        val seen = mutableListOf<StreamingReply>()
        backgroundScope.launch {
            try { useCase(PromptRequest(null, "Explain how a hash map works", ChatOptions(null, TaskMode.AUTO, ThinkingDepth.BALANCED), uiKey = "k")).collect { seen += it } } catch (e: Throwable) { e.printStackTrace(); throw e }
        }
        settle()
        val last = seen.last()
        assertEquals(ReplyPhase.DONE, last.phase)
        assertEquals(MessageStatus.COMPLETE, last.message.status)
        assertTrue(last.message.content.length > 50)
        assertTrue(last.message.thinking?.isNotBlank() == true)
        val chat = RemoteChatRepository(api).open(last.message.conversationId, 12, null)
        assertEquals(2, chat.messages.size)
        assertEquals(last.message.content, chat.messages.last().content)
    }

    @Test
    fun `a risky demo prompt asks first and continues after the answer`() = runTest {
        val link = demo()
        val api = HarnessApi(link)
        val asks = mutableListOf<LinkEvent.AskRequest>()
        backgroundScope.launch { link.events.collect { if (it is LinkEvent.AskRequest) asks += it } }
        val useCase = GenerateReplyUseCase(api, link, TurnFollower(RemoteChatRepository(api)), TestScopeTime(testScheduler))
        val seen = mutableListOf<StreamingReply>()
        backgroundScope.launch {
            useCase(PromptRequest(null, "Please run the install script and delete the old build", ChatOptions(null, TaskMode.AUTO, ThinkingDepth.LIGHT), uiKey = "k")).collect { seen += it }
        }
        settle()
        assertEquals(1, asks.size)
        assertEquals(MessageStatus.WAITING, seen.last().message.status)
        api.askAnswerDecision(asks.single().data.askId, "allow")
        settle()
        assertEquals(MessageStatus.COMPLETE, seen.last().message.status)
    }

    @Test
    fun `demo chat ids carry the demo prefix`() = runTest {
        val link = demo()
        val page = RemoteChatRepository(HarnessApi(link)).list(ChatListQuery(), 5, null)
        assertTrue(page.items.all { it.id.startsWith(com.avek.chat.core.data.downloads.DemoIds.PREFIX) })
    }

    @Test
    fun `the switch sends calls to the active link and raises a refresh when it flips`() = runTest {
        val real = FakeLink { _, _ -> kotlinx.serialization.json.buildJsonObject { put("from", kotlinx.serialization.json.JsonPrimitive("real")) } }
        val other = FakeLink { _, _ -> kotlinx.serialization.json.buildJsonObject { put("from", kotlinx.serialization.json.JsonPrimitive("demo")) } }
        val mode = MutableStateFlow(false)
        val switching = SwitchingLinkRepository(real, other, mode, backgroundScope)
        runCurrent()
        val events = mutableListOf<LinkEvent>()
        backgroundScope.launch { switching.events.collect { events += it } }
        runCurrent()
        switching.connect(); switching.setProfile(LinkProfile.BACKGROUND)
        assertEquals(1, real.connects)
        assertEquals("real", (switching.call("x") as kotlinx.serialization.json.JsonObject)["from"]!!.let { (it as kotlinx.serialization.json.JsonPrimitive).content })

        mode.value = true; runCurrent()
        assertEquals(1, real.disconnects)
        assertEquals(1, other.connects) // wanted stays true across the flip
        assertEquals(LinkProfile.BACKGROUND, other.profile.value)
        assertEquals("demo", (switching.call("x") as kotlinx.serialization.json.JsonObject)["from"]!!.let { (it as kotlinx.serialization.json.JsonPrimitive).content })
        assertTrue(events.any { it is LinkEvent.Refresh })

        // events of the active link flow through, the idle one's do not
        real.emit(LinkEvent.ModelsChanged(1)); other.emit(LinkEvent.ChatDeleted(2, "c")); runCurrent()
        assertTrue(events.any { it is LinkEvent.ChatDeleted })
        assertFalse(events.any { it is LinkEvent.ModelsChanged })
        real.connectionState.value = ConnectionState.NotPaired
        other.connectionState.value = ConnectionState.Connected("demo", "Demo PC")
        runCurrent()
        assertTrue(switching.state.value is ConnectionState.Connected)
    }
}
