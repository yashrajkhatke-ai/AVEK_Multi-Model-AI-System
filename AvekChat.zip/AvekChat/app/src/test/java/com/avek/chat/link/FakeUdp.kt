package com.avek.chat.link

import com.avek.chat.core.link.crypto.AvekProtocol
import com.avek.chat.core.link.crypto.SecureCrypto
import com.avek.chat.core.link.store.IdentityVault
import com.avek.chat.core.link.transport.Datagram
import com.avek.chat.core.link.transport.LocalAddress
import com.avek.chat.core.link.transport.UdpSocket
import com.avek.chat.core.link.transport.UdpTransport
import com.avek.chat.core.link.wire.WireJson
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put

/** A sent datagram with the virtual time it left. */
class Sent(val atMs: Long, val host: String, val port: Int, val data: ByteArray) {
    val json: JsonObject get() = WireJson.parseToJsonElement(data.toString(Charsets.UTF_8)).jsonObject
}

/**
 * An in-memory UDP network: every datagram the app sends is recorded and handed to [respond],
 * whose answers arrive on the socket.
 */
class FakeUdpTransport(
    private val now: () -> Long,
    var local: LocalAddress? = LocalAddress("192.168.43.17", 24),
    var respond: (Sent) -> List<Datagram> = { emptyList() },
) : UdpTransport {
    val sent = mutableListOf<Sent>()
    var opened = 0
    var closed = 0
    /** `viaWifi` of every socket opened, in order (the Tailscale route must not bind to Wi-Fi). */
    val openedViaWifi = mutableListOf<Boolean>()

    override suspend fun open(viaWifi: Boolean): UdpSocket {
        opened++
        openedViaWifi += viaWifi
        val inbox = Channel<Datagram>(Channel.UNLIMITED)
        return object : UdpSocket {
            override suspend fun send(host: String, port: Int, data: ByteArray) {
                val item = Sent(now(), host, port, data)
                sent += item
                respond(item).forEach { inbox.trySend(it) }
            }

            override suspend fun receive(timeoutMs: Long): Datagram? = withTimeoutOrNull(timeoutMs) { inbox.receive() }

            override fun close() {
                closed++
                inbox.close()
            }
        }
    }

    override fun localAddress(): LocalAddress? = local
}

/** The PC's knock listener: answers a signed knock from a known device with a signed `here` (only when [answerHost] matches). */
class FakeKnockListener(
    private val server: IdentityVault,
    private val devices: () -> Map<String, ByteArray>,
    /** Other keys the PC accepts for a device (the announced new key during a rotation). */
    private val alsoKeys: (String) -> List<ByteArray> = { emptyList() },
    val pcHost: String = "192.168.43.5",
    val port: Int = 7810,
    var answerOnlyTo: Set<String>? = null,
    var pairingOpenName: String? = null,
    private val serverAlias: String = FakeHarnessServer.ALIAS,
) {
    val serverId: String get() = AvekProtocol.serverIdOf(server.publicKey(serverAlias))

    fun respond(sent: Sent): List<Datagram> {
        if (answerOnlyTo != null && sent.host !in answerOnlyTo!!) return emptyList()
        val json = sent.json
        val n = json.getValue("n").jsonPrimitive.content
        return when (json.getValue("k").jsonPrimitive.content) {
            "knock" -> {
                val id = json.getValue("id").jsonPrimitive.content
                val pubs = listOfNotNull(devices()[id]) + alsoKeys(id)
                if (pubs.isEmpty()) return emptyList()
                val ts = json.getValue("ts").jsonPrimitive.content.toLong()
                val message = AvekProtocol.knockMessage(id, ts, SecureCrypto.unb64(n))
                val signature = SecureCrypto.unb64(json.getValue("sig").jsonPrimitive.content)
                val ok = pubs.any { SecureCrypto.verify(it, message, signature) }
                if (!ok) return emptyList()
                val sig = server.sign(serverAlias, AvekProtocol.hereMessage(serverId, port, id, SecureCrypto.unb64(n)))
                listOf(datagram(buildJsonObject {
                    put("avek", 4); put("k", "here"); put("sid", serverId); put("port", port); put("n", n); put("sig", SecureCrypto.b64(sig))
                }))
            }
            "find" -> {
                val name = pairingOpenName ?: return emptyList()
                listOf(datagram(buildJsonObject {
                    put("avek", 4); put("k", "open"); put("sid", serverId); put("name", name); put("port", port); put("n", n)
                }))
            }
            else -> emptyList()
        }
    }

    fun datagram(obj: JsonObject) = Datagram(pcHost, 7811, WireJson.encodeToString(JsonObject.serializer(), obj).toByteArray())
}
