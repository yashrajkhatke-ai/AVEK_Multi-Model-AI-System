package com.avek.chat.link

import com.avek.chat.core.link.rpc.ListPart
import com.avek.chat.core.link.rpc.RpcException
import com.avek.chat.core.link.rpc.RpcTimeouts
import com.avek.chat.core.link.wire.EmptyArgs
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.toList
import kotlinx.coroutines.launch
import kotlinx.coroutines.test.advanceTimeBy
import kotlinx.coroutines.test.runTest
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.int
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class RpcTest {

    @Test
    fun `a request gets its reply and ids are unique`() = runTest {
        val link = openTestLink()
        link.server.handlers["models.list"] = { _, _ -> Reply.Ok(obj { put("items", arr()); put("total", 0) }) }

        link.session.rpc.call("ping", EmptyArgs)
        link.session.rpc.call("models.list", obj { put("limit", 1) })

        val ids = link.server.connections.single().requests.map { it.first }
        assertEquals(listOf("ping", "models.list"), ids)
    }

    @Test
    fun `an error reply becomes an RpcException with its code`() = runTest {
        val link = openTestLink()
        link.server.handlers["chat.delete"] = { _, _ -> Reply.Err("not-found", "no such chat") }
        try {
            link.session.rpc.call("chat.delete", obj { put("chatId", "c_x") })
            fail("expected RpcException")
        } catch (e: RpcException) {
            assertEquals("not-found", e.code)
            assertEquals("no such chat", e.message)
        }
    }

    @Test
    fun `an unknown op is answered with unknown-op`() = runTest {
        val link = openTestLink()
        try {
            link.session.rpc.call("nope", EmptyArgs)
            fail("expected RpcException")
        } catch (e: RpcException) {
            assertEquals("unknown-op", e.code)
        }
    }

    @Test
    fun `list replies arrive part by part with more flags, total and next`() = runTest {
        val link = openTestLink()
        link.server.handlers["models.list"] = { _, _ ->
            Reply.Parts(
                listOf(
                    listPart(listOf(obj { put("id", "m1") }), total = 3, next = "c1"),
                    listPart(listOf(obj { put("id", "m2") }), total = 3, next = "c2"),
                    listPart(listOf(obj { put("id", "m3") }), total = 3, next = null),
                ),
            )
        }
        val parts: List<ListPart> = link.session.rpc.callList("models.list", obj { put("limit", "all") }).toList()

        assertEquals(listOf(true, true, false), parts.map { it.more })
        assertEquals(listOf("m1", "m2", "m3"), parts.map { it.items.single().jsonObject["id"]!!.jsonPrimitive.content })
        assertEquals(3, parts.first().total)
        assertEquals(listOf<String?>("c1", "c2", null), parts.map { it.next })
        assertEquals("all", link.server.connections.single().requestsFor("models.list").single()["limit"]!!.jsonPrimitive.content)
    }

    @Test
    fun `integer limit and after are sent as given`() = runTest {
        val link = openTestLink()
        link.server.handlers["chats.list"] = { _, _ -> Reply.Ok(listPart(emptyList(), 0, null)) }
        link.session.rpc.call("chats.list", obj { put("limit", 20); put("after", "cur1") })

        val args = link.server.connections.single().requestsFor("chats.list").single()
        assertEquals(20, args["limit"]!!.jsonPrimitive.int)
        assertEquals("cur1", args["after"]!!.jsonPrimitive.content)
    }

    @Test
    fun `no reply within the default timeout fails after 15 seconds`() = runTest {
        val link = openTestLink()
        link.server.handlers["models.list"] = { _, _ -> Reply.Silence }
        val before = testScheduler.currentTime
        try {
            link.session.rpc.call("models.list", obj { put("limit", 1) })
            fail("expected a timeout")
        } catch (e: RpcException) {
            assertEquals(RpcException.TIMEOUT, e.code)
        }
        assertEquals(15_000L, testScheduler.currentTime - before)
    }

    @Test
    fun `timeouts per operation follow the spec`() {
        assertEquals(15_000L, RpcTimeouts.forOp("chats.list"))
        assertEquals(20_000L, RpcTimeouts.forOp("prompt"))
        assertEquals(60_000L, RpcTimeouts.forOp("attach.end"))
    }

    @Test
    fun `a list that stalls between parts times out after 15 seconds of silence`() = runTest {
        val link = openTestLink()
        link.server.handlers["models.list"] = { _, conn ->
            // one part with more=true, then nothing
            val id = link.server.connections.single().requests.size
            Reply.Parts(listOf(listPart(listOf(obj { put("id", "m1") }), 2, "c1"), listPart(emptyList(), 2, null))).let { Reply.Silence }
        }
        // Manually answer only the first part, flagged as "more", via a raw frame.
        link.server.handlers["models.list"] = { _, conn ->
            conn.sendJson(
                buildJsonObject {
                    put("re", "r1"); put("ok", true); put("more", true)
                    put("data", listPart(listOf(obj { put("id", "m1") }), 2, "c1"))
                },
            )
            Reply.Silence
        }
        val received = mutableListOf<ListPart>()
        val before = testScheduler.currentTime
        try {
            link.session.rpc.callList("models.list", obj { put("limit", "all") }).collect { received += it }
            fail("expected a timeout")
        } catch (e: RpcException) {
            assertEquals(RpcException.TIMEOUT, e.code)
        }
        assertEquals(1, received.size)
        assertEquals(15_000L, testScheduler.currentTime - before)
    }

    @Test
    fun `pending requests fail when the connection closes`() = runTest {
        val link = openTestLink()
        link.server.handlers["models.list"] = { _, conn ->
            conn.close(1001, "going away")
            Reply.Silence
        }
        try {
            link.session.rpc.call("models.list", obj { put("limit", 1) })
            fail("expected connection loss")
        } catch (e: RpcException) {
            assertEquals(RpcException.CONNECTION_LOST, e.code)
        }
        // And requests made afterwards fail at once.
        try {
            link.session.rpc.call("ping", EmptyArgs)
            fail("expected connection loss")
        } catch (e: RpcException) {
            assertEquals(RpcException.CONNECTION_LOST, e.code)
        }
    }

    @Test
    fun `events are delivered in order with their seq`() = runTest {
        val link = openTestLink()
        val connection = link.server.connections.single()
        connection.sendEvent("answer.delta", obj { put("chatId", "c1"); put("promptId", "p1"); put("text", "Hel"); put("offset", 0) })
        connection.sendEvent("answer.delta", obj { put("chatId", "c1"); put("promptId", "p1"); put("text", "lo"); put("offset", 3) })
        link.session.rpc.call("ping", EmptyArgs) // a round trip guarantees the events were read first

        assertEquals(listOf(1L, 2L), link.events.map { it.seq })
        assertEquals(listOf("answer.delta", "answer.delta"), link.events.map { it.ev })
    }

    @Test
    fun `ping is sent every 15 seconds`() = runTest {
        val link = openTestLink()
        advanceTimeBy(31_000)
        val pings = link.server.connections.single().requestsFor("ping").size
        assertEquals(2, pings)
    }

    @Test
    fun `40 seconds of silence closes the session`() = runTest {
        val link = openTestLink()
        link.server.handlers["ping"] = { _, _ -> Reply.Silence }
        advanceTimeBy(46_000)
        val closed = link.session.awaitClosed()
        assertEquals(1006, closed.code)
        assertTrue(closed.reason.contains("40"))
    }

    @Test
    fun `answered pings keep the session alive`() = runTest {
        val link = openTestLink()
        advanceTimeBy(120_000)
        val job = launch { link.session.awaitClosed() }
        advanceTimeBy(1)
        assertTrue(job.isActive)
        job.cancel()
        assertNull(link.events.firstOrNull())
        assertFalse(link.session.ready.isCancelled)
    }
}
