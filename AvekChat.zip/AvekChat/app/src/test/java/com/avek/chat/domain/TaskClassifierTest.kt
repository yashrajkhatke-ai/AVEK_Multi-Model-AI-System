package com.avek.chat.domain

import com.avek.chat.core.domain.usecase.TaskClassifier
import com.avek.chat.core.model.TaskMode
import org.junit.Assert.assertEquals
import org.junit.Test

class TaskClassifierTest {

    private val classifier = TaskClassifier()

    @Test
    fun `code fences route to coding`() {
        assertEquals(TaskMode.CODING, classifier.classify("Why does this crash?\n```kotlin\nval x: String = null\n```"))
    }

    @Test
    fun `research language routes to deep research`() {
        assertEquals(TaskMode.DEEP_RESEARCH, classifier.classify("Research the latest evidence on intermittent fasting with sources"))
    }

    @Test
    fun `arithmetic routes to math`() {
        assertEquals(TaskMode.MATH, classifier.classify("solve 3x + 4 = 19"))
    }

    @Test
    fun `drafting routes to writing`() {
        assertEquals(TaskMode.WRITING, classifier.classify("Draft a cover letter for a design role"))
    }

    @Test
    fun `explanations route to learn`() {
        assertEquals(TaskMode.LEARN, classifier.classify("Explain how photosynthesis works"))
    }

    @Test
    fun `small talk falls back to general`() {
        assertEquals(TaskMode.GENERAL, classifier.classify("hey, how's it going?"))
        assertEquals(TaskMode.GENERAL, classifier.classify("   "))
    }
}
