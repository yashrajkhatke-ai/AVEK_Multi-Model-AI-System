package com.avek.chat.domain

import com.avek.chat.core.domain.lists.ChatListController
import com.avek.chat.core.domain.lists.ListMemoryController
import com.avek.chat.core.domain.lists.ListMemoryRegistry
import com.avek.chat.core.domain.lists.ModelPickerController
import com.avek.chat.core.domain.repository.ModelRepository
import com.avek.chat.core.domain.repository.Page
import com.avek.chat.core.model.ModelKind
import com.avek.chat.core.model.RemoteModel
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.test.advanceTimeBy
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class ListMemoryTest {

    @Test
    fun `the countdown starts when the view closes and clears the pages at zero`() = runTest {
        var dropped = 0
        val memory = ListMemoryController(backgroundScope, { 120 }) { dropped++ }
        memory.inUse()
        advanceTimeBy(1_000_000); runCurrent()
        assertEquals(0, dropped) // never while in use
        memory.idle()
        advanceTimeBy(119_000); runCurrent()
        assertEquals(0, dropped)
        advanceTimeBy(1_001); runCurrent()
        assertEquals(1, dropped)
    }

    @Test
    fun `reopening cancels the countdown and closing again restarts it from the full time`() = runTest {
        var dropped = 0
        val memory = ListMemoryController(backgroundScope, { 120 }) { dropped++ }
        memory.idle()
        advanceTimeBy(100_000); runCurrent()
        memory.inUse()
        advanceTimeBy(500_000); runCurrent()
        assertEquals(0, dropped)
        memory.idle()
        advanceTimeBy(119_000); runCurrent()
        assertEquals(0, dropped) // the earlier 100 s did not count
        advanceTimeBy(1_001); runCurrent()
        assertEquals(1, dropped)
    }

    @Test
    fun `the keep time is clamped to 30 to 600 seconds and read when the countdown starts`() = runTest {
        var dropped = 0
        var seconds = 5
        val memory = ListMemoryController(backgroundScope, { seconds }) { dropped++ }
        memory.idle()
        advanceTimeBy(29_999); runCurrent()
        assertEquals(0, dropped)
        advanceTimeBy(2); runCurrent()
        assertEquals(1, dropped)
        seconds = 9_999
        memory.idle()
        advanceTimeBy(599_000); runCurrent()
        assertEquals(1, dropped)
        advanceTimeBy(1_100); runCurrent()
        assertEquals(2, dropped)
    }

    @Test
    fun `trim clears at once and a pending countdown does not fire twice`() = runTest {
        var dropped = 0
        val memory = ListMemoryController(backgroundScope, { 60 }) { dropped++ }
        memory.idle()
        memory.trim()
        assertEquals(1, dropped)
        advanceTimeBy(1_000_000); runCurrent()
        assertEquals(1, dropped)
    }

    @Test
    fun `the chat list forgets its pages after the countdown and reloads the first 20 on reopen`() = runTest {
        var requests = 0
        val list = ChatListController(backgroundScope, { limit, _ -> requests++; Page((0 until limit).map(::chat), 50, "x") }, { 60 })
        list.opened(); runCurrent()
        assertEquals(20, list.state.value.items.size)
        list.closed()
        advanceTimeBy(59_000); runCurrent()
        list.opened(); runCurrent()
        assertEquals(1, requests) // still in memory: reopening is free
        list.closed()
        advanceTimeBy(60_001); runCurrent()
        assertTrue(list.state.value.items.isEmpty())
        list.opened(); runCurrent()
        assertEquals(2, requests)
    }

    @Test
    fun `the registry trims every closed list at once`() = runTest {
        val registry = ListMemoryRegistry()
        val list = ChatListController(backgroundScope, { limit, _ -> Page((0 until limit).map(::chat), 50, null) }, { 60 }, registry)
        list.opened(); runCurrent()
        assertEquals(20, list.state.value.items.size)
        list.closed()
        registry.trimAll()
        assertTrue(list.state.value.items.isEmpty())
    }

    @Test
    fun `a trim while the sidebar is open starts over with the first page`() = runTest {
        var requests = 0
        val registry = ListMemoryRegistry()
        val list = ChatListController(backgroundScope, { limit, _ -> requests++; Page((0 until limit).map(::chat), 50, "x") }, { 60 }, registry)
        list.opened(); runCurrent()
        list.seeAll(); runCurrent()
        registry.trimAll(); runCurrent()
        assertEquals(20, list.state.value.items.size)
        assertFalse(list.state.value.expanded)
        assertEquals(3, requests)
    }

    private class FakeModels(val gate: CompletableDeferred<Unit>) : ModelRepository {
        var loads = 0
        override suspend fun defaultModel(): RemoteModel? = null
        override fun allModels(): Flow<RemoteModel> = flow {
            loads++
            emit(RemoteModel("a", "Alpha", ModelKind.TEXT, "", 8192, 1))
            gate.await()
            emit(RemoteModel("b", "Beta", ModelKind.VISION, "", 8192, 2))
        }
    }

    @Test
    fun `the model picker fills one model at a time and stays loading until the last part`() = runTest {
        val gate = CompletableDeferred<Unit>()
        val repo = FakeModels(gate)
        val picker = ModelPickerController(backgroundScope, repo, { 120 })
        assertTrue(picker.state.value.models.isEmpty())
        picker.opened(); runCurrent()
        assertEquals(listOf("a"), picker.state.value.models.map { it.id })
        assertTrue(picker.state.value.loading)
        gate.complete(Unit); runCurrent()
        assertEquals(listOf("a", "b"), picker.state.value.models.map { it.id })
        assertFalse(picker.state.value.loading)
        // closing and reopening within the countdown reuses the models
        picker.closed(); advanceTimeBy(10_000); picker.opened(); runCurrent()
        assertEquals(1, repo.loads)
        // after the countdown the next open asks again
        picker.closed(); advanceTimeBy(121_000); runCurrent()
        assertTrue(picker.state.value.models.isEmpty())
        picker.opened(); runCurrent()
        assertEquals(2, repo.loads)
    }
}

private fun chat(i: Int) = com.avek.chat.core.model.Conversation("c$i", "Chat $i", 0, 0, false, false, null, com.avek.chat.core.model.TaskMode.AUTO, "", 1)
