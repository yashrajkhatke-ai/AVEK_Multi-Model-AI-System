package com.avek.chat.link

import com.avek.chat.core.link.crypto.PairingHandshake
import com.avek.chat.core.link.crypto.PairingResult
import com.avek.chat.core.link.crypto.SessionGrant
import com.avek.chat.core.link.crypto.SessionHandshake
import com.avek.chat.core.link.store.DeviceKey
import kotlinx.coroutines.test.StandardTestDispatcher
import com.avek.chat.core.link.rpc.SecureLinkSession
import com.avek.chat.core.link.store.IdentityVault
import com.avek.chat.core.link.store.SoftwareIdentityVault
import com.avek.chat.core.link.wire.WireEvent
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.launch
import kotlinx.coroutines.test.TestScope
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put

/** A paired device + a live secure session against a [FakeHarnessServer]. */
@OptIn(ExperimentalCoroutinesApi::class)
class TestLink(
    val server: FakeHarnessServer,
    val session: SecureLinkSession,
    val events: MutableList<WireEvent>,
    val deviceId: String,
    val identity: IdentityVault,
)

const val TEST_ALIAS = "avek.identity.1"

/** The app's pairing with the test scrypt parameters, computing on the test dispatcher. */
fun TestScope.testPairing(): PairingHandshake =
    PairingHandshake(kdf = FakeHarnessServer.TEST_KDF, computeDispatcher = StandardTestDispatcher(testScheduler))

@OptIn(ExperimentalCoroutinesApi::class)
suspend fun TestScope.openTestLink(
    server: FakeHarnessServer = FakeHarnessServer(backgroundScope),
    pingIntervalMs: Long = 15_000,
    silenceLimitMs: Long = 40_000,
): TestLink {
    val identity = SoftwareIdentityVault().also { it.create(TEST_ALIAS) }
    val pairing = InMemoryChannel.pair()
    backgroundScope.launch { server.serve(pairing.second) }
    val result = testPairing().pair(pairing.first, DeviceKey(identity, TEST_ALIAS), FakeHarnessServer.CODE.toByteArray(), "Tablet")
    val grant = (result as PairingResult.Paired).grant

    val (client, serverSide) = InMemoryChannel.pair()
    backgroundScope.launch { server.serve(serverSide) }
    val keys = SessionHandshake().open(client, SessionGrant(grant.deviceId, DeviceKey(identity, TEST_ALIAS), grant.serverPub, grant.secrets.dk))
    val events = mutableListOf<WireEvent>()
    val session = SecureLinkSession(
        channel = client,
        keys = keys,
        scope = backgroundScope,
        onEvent = { events += it },
        nowMs = { testScheduler.currentTime },
        pingIntervalMs = pingIntervalMs,
        silenceLimitMs = silenceLimitMs,
    )
    session.start()
    session.awaitReady(5_000)
    return TestLink(server, session, events, grant.deviceId, identity)
}

fun obj(build: kotlinx.serialization.json.JsonObjectBuilder.() -> Unit): JsonObject = buildJsonObject(build)

fun arr(vararg items: JsonElement) = JsonArray(items.toList())

fun str(value: String) = JsonPrimitive(value)

fun listPart(items: List<JsonObject>, total: Int, next: String?): JsonObject = buildJsonObject {
    put("items", JsonArray(items))
    put("total", total)
    if (next != null) put("next", next)
}
