package com.avek.chat.link

import com.avek.chat.core.link.crypto.Handshake
import com.avek.chat.core.link.rpc.SecureLinkSession
import com.avek.chat.core.link.wire.WireEvent
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.launch
import kotlinx.coroutines.test.TestScope
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put

/** A paired device + a live secure session against a [FakeHarnessServer]. */
@OptIn(ExperimentalCoroutinesApi::class)
class TestLink(
    val server: FakeHarnessServer,
    val session: SecureLinkSession,
    val events: MutableList<WireEvent>,
    val deviceId: String,
    val secret: ByteArray,
)

@OptIn(ExperimentalCoroutinesApi::class)
suspend fun TestScope.openTestLink(
    server: FakeHarnessServer = FakeHarnessServer(backgroundScope),
    pingIntervalMs: Long = 15_000,
    silenceLimitMs: Long = 40_000,
): TestLink {
    val pairing = InMemoryChannel.pair()
    backgroundScope.launch { server.serve(pairing.second) }
    val grant = Handshake().pair(pairing.first, "ABCDEFGHJKLM", "Tablet")

    val (client, serverSide) = InMemoryChannel.pair()
    backgroundScope.launch { server.serve(serverSide) }
    val keys = Handshake().session(client, grant.deviceId, grant.deviceSecret)
    val events = mutableListOf<WireEvent>()
    val session = SecureLinkSession(
        channel = client,
        keys = keys,
        scope = backgroundScope,
        onEvent = { events += it },
        nowMs = { testScheduler.currentTime },
        pingIntervalMs = pingIntervalMs,
        silenceLimitMs = silenceLimitMs,
    )
    session.start()
    session.awaitReady(5_000)
    return TestLink(server, session, events, grant.deviceId, grant.deviceSecret)
}

fun obj(build: kotlinx.serialization.json.JsonObjectBuilder.() -> Unit): JsonObject = buildJsonObject(build)

fun arr(vararg items: JsonElement) = JsonArray(items.toList())

fun str(value: String) = JsonPrimitive(value)

fun listPart(items: List<JsonObject>, total: Int, next: String?): JsonObject = buildJsonObject {
    put("items", JsonArray(items))
    put("total", total)
    if (next != null) put("next", next)
}
