package com.avek.chat.domain

import com.avek.chat.core.data.downloads.DownloadManager
import com.avek.chat.core.data.downloads.DownloadedChatInfo
import com.avek.chat.core.data.downloads.DownloadedChatStore
import com.avek.chat.core.data.downloads.LocalChatRepository
import com.avek.chat.core.data.remote.ChatSource
import com.avek.chat.core.data.remote.RemoteChatRepository
import com.avek.chat.core.data.remote.toDomain
import com.avek.chat.core.domain.repository.ChatListQuery
import com.avek.chat.core.link.HarnessApi
import com.avek.chat.core.link.route.ConnectionState
import com.avek.chat.core.link.rpc.RpcException
import com.avek.chat.core.link.wire.ChatSummaryDto
import com.avek.chat.core.link.wire.LinkEvent
import com.avek.chat.core.link.wire.AssistantPartDto
import com.avek.chat.core.link.wire.DownloadTurnDto
import com.avek.chat.core.link.wire.ThinkingDto
import com.avek.chat.core.link.wire.TurnViewDto
import com.avek.chat.core.link.wire.UserPartDto
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.test.TestScope
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class MemoryStore : DownloadedChatStore {
    val chats = MutableStateFlow<Map<String, ChatSummaryDto>>(emptyMap())
    val turns = HashMap<String, MutableList<TurnViewDto>>()
    override fun observeInfo() = chats.map { m -> m.values.map { DownloadedChatInfo(it.toDomain(true), 10, 0) } }
    override fun observeIds() = chats.map { it.keys }
    override suspend fun ids() = chats.value.keys
    override suspend fun chat(chatId: String) = chats.value[chatId]?.toDomain(true)?.copy(turnCount = turns[chatId]?.size ?: 0)
    override suspend fun turns(chatId: String) = turns[chatId].orEmpty().toList()
    override suspend fun replace(chat: ChatSummaryDto, turns: List<TurnViewDto>) {
        chats.value = chats.value + (chat.chatId to chat)
        this.turns[chat.chatId] = turns.toMutableList()
    }
    override suspend fun upsertTurn(chatId: String, turn: TurnViewDto) {
        if (chatId !in chats.value) return
        val list = turns.getOrPut(chatId) { mutableListOf() }
        list.removeAll { it.promptId == turn.promptId }
        list += turn
    }
    override suspend fun upsertChat(chat: ChatSummaryDto) {
        if (chat.chatId in chats.value) chats.value = chats.value + (chat.chatId to chat)
    }
    override suspend fun delete(chatId: String) {
        chats.value = chats.value - chatId
        turns.remove(chatId)
    }
}

private fun summary(id: String, updated: String = "2025-01-02T00:00:00Z", turns: Int = 1) =
    ChatSummaryDto(id, "Title $id", "2025-01-01T00:00:00Z", updated, null, "auto", turns, "preview")

private fun turn(id: String, text: String = "hi", created: String = "2025-01-01T00:00:00Z") = TurnViewDto(
    promptId = id, createdAt = created, user = UserPartDto(text), assistant = AssistantPartDto("answer to $text"),
    thinking = ThinkingDto(100, "thought"),
)

@OptIn(ExperimentalCoroutinesApi::class)
class DownloadsTest {

    private fun TestScope.chatGetPart(chat: ChatSummaryDto, turns: List<TurnViewDto>) = buildJsonObject {
        put("chat", com.avek.chat.core.link.wire.WireJson.encodeToJsonElement(ChatSummaryDto.serializer(), chat))
        put("items", JsonArray(turns.map { com.avek.chat.core.link.wire.WireJson.encodeToJsonElement(TurnViewDto.serializer(), it) }))
        put("total", turns.size)
    }

    private class Setup(val link: FakeLink, val store: MemoryStore, val manager: DownloadManager, val demo: MutableStateFlow<Boolean>)

    private fun TestScope.setup(
        pcChats: MutableMap<String, Pair<ChatSummaryDto, List<TurnViewDto>>> = mutableMapOf("c1" to (summary("c1") to listOf(turn("p1")))),
        statusFor: (List<String>) -> List<Triple<String, Boolean, ChatSummaryDto?>> = { ids -> ids.map { Triple(it, it in pcChats, pcChats[it]?.first) } },
        stored: Map<String, Pair<ChatSummaryDto, List<TurnViewDto>>> = emptyMap(),
    ): Setup {
        val store = MemoryStore()
        runBlocking { stored.forEach { (_, v) -> store.replace(v.first, v.second) } }
        val link = FakeLink { op, args ->
            when (op) {
                "downloads.set" -> buildJsonObject { put("chatIds", args["chatIds"]!!) }
                "downloads.status" -> buildJsonObject {
                    put("items", JsonArray(statusFor(args["chatIds"]!!.jsonArray.map { it.jsonPrimitive.content }).map { (id, exists, chat) ->
                        buildJsonObject {
                            put("chatId", id); put("exists", exists)
                            put("updatedAt", chat?.updatedAt ?: ""); put("turnCount", chat?.turnCount ?: 0)
                        }
                    }))
                }
                else -> error(op)
            }
        }
        link.callHandlerForLists = { _, args ->
            val id = args["chatId"]!!.jsonPrimitive.content
            val (chat, turns) = pcChats.getValue(id)
            chatGetPart(chat, turns)
        }
        val demo = MutableStateFlow(false)
        val manager = DownloadManager(HarnessApi(link), store, link, demo, backgroundScope)
        return Setup(link, store, manager, demo)
    }

    @Test
    fun `downloading sends the full id set, fetches every turn with reasoning and tools, and stores it`() = runTest {
        val s = setup()
        s.manager.download("c1")
        assertEquals(listOf("c1"), s.link.opsCalled("downloads.set").last()["chatIds"]!!.jsonArray.map { it.jsonPrimitive.content })
        val args = s.link.opsCalled("chat.get").single()
        assertEquals("all", args["limit"]!!.jsonPrimitive.content)
        assertEquals(setOf("thinking", "tools"), args["include"]!!.jsonArray.map { it.jsonPrimitive.content }.toSet())
        assertEquals("thought", s.store.turns("c1").single().thinking?.text)
        assertTrue("c1" in s.store.ids())
    }

    @Test
    fun `a failed download tells the PC to forget the chat again`() = runTest {
        val s = setup(pcChats = mutableMapOf())
        try { s.manager.download("ghost"); fail() } catch (_: Exception) { }
        assertEquals(emptyList<String>(), s.link.opsCalled("downloads.set").last()["chatIds"]!!.jsonArray.toList())
        assertFalse("ghost" in s.store.ids())
    }

    @Test
    fun `removing deletes the local copy and updates the PC when connected`() = runTest {
        val s = setup(stored = mapOf("c1" to (summary("c1") to listOf(turn("p1")))))
        s.manager.remove("c1")
        assertTrue(s.store.ids().isEmpty())
        assertTrue(s.link.opsCalled("downloads.set").last()["chatIds"]!!.jsonArray.isEmpty())
    }

    @Test
    fun `removing while offline only deletes locally and the next connect repairs the PC`() = runTest {
        val s = setup(stored = mapOf("c1" to (summary("c1") to listOf(turn("p1")))))
        s.link.connectionState.value = ConnectionState.Disconnected
        s.manager.remove("c1")
        assertTrue(s.link.opsCalled("downloads.set").isEmpty())
        s.manager.start(); s.link.connectionState.value = ConnectionState.Connected("r", "PC"); runCurrent()
        assertTrue(s.link.opsCalled("downloads.set").last()["chatIds"]!!.jsonArray.isEmpty())
    }

    @Test
    fun `after connecting the set is re-sent and a chat deleted on the PC is deleted locally`() = runTest {
        val s = setup(
            pcChats = mutableMapOf("c1" to (summary("c1") to listOf(turn("p1")))),
            stored = mapOf("c1" to (summary("c1") to listOf(turn("p1"))), "gone" to (summary("gone") to listOf(turn("p9")))),
        )
        s.link.connectionState.value = ConnectionState.Disconnected
        s.manager.start(); runCurrent()
        s.link.connectionState.value = ConnectionState.Connected("r", "PC"); runCurrent()
        assertEquals(setOf("c1", "gone"), s.link.opsCalled("downloads.set").first()["chatIds"]!!.jsonArray.map { it.jsonPrimitive.content }.toSet())
        assertEquals(setOf("c1"), s.store.ids())
    }

    @Test
    fun `a stale copy is refreshed on connect and a current one is left alone`() = runTest {
        val newer = summary("c1", updated = "2025-02-01T00:00:00Z", turns = 2)
        val s = setup(
            pcChats = mutableMapOf("c1" to (newer to listOf(turn("p1"), turn("p2", "more", "2025-01-03T00:00:00Z")))),
            stored = mapOf("c1" to (summary("c1") to listOf(turn("p1")))),
        )
        s.link.connectionState.value = ConnectionState.Disconnected
        s.manager.start(); runCurrent()
        s.link.connectionState.value = ConnectionState.Connected("r", "PC"); runCurrent()
        assertEquals(2, s.store.turns("c1").size)
        assertEquals(1, s.link.opsCalled("chat.get").size)
    }

    @Test
    fun `live events update the copy, and a deletion on the PC removes it`() = runTest {
        val s = setup(stored = mapOf("c1" to (summary("c1") to listOf(turn("p1")))))
        s.manager.start(); runCurrent()
        s.link.emit(LinkEvent.DownloadTurn(1, DownloadTurnDto("c1", turn("p2", "new", "2025-03-01T00:00:00Z"))))
        s.link.emit(LinkEvent.DownloadTurn(2, DownloadTurnDto("other", turn("p3")))) // not downloaded: ignored
        runCurrent()
        assertEquals(listOf("p1", "p2"), s.store.turns("c1").map { it.promptId })
        assertNull(s.store.chat("other"))
        s.link.emit(LinkEvent.DownloadChat(3, summary("c1").copy(title = "Renamed")))
        runCurrent()
        assertEquals("Renamed", s.store.chat("c1")!!.title)
        s.link.emit(LinkEvent.DownloadDeleted(4, "c1"))
        runCurrent()
        assertTrue(s.store.ids().isEmpty())
    }

    @Test
    fun `demo chats and real chats never mix`() = runTest {
        val s = setup(stored = mapOf(
            "c_demo_1" to (summary("c_demo_1") to listOf(turn("p1"))),
            "c1" to (summary("c1") to listOf(turn("p1"))),
        ))
        s.link.connectionState.value = ConnectionState.Disconnected
        s.manager.start(); runCurrent()
        s.link.connectionState.value = ConnectionState.Connected("r", "PC"); runCurrent()
        // the real PC is told about the real chat only
        assertEquals(listOf("c1"), s.link.opsCalled("downloads.set").first()["chatIds"]!!.jsonArray.map { it.jsonPrimitive.content })
        assertTrue("c_demo_1" in s.store.ids())
    }

    // ------------------------------------------------------------------ ChatSource

    private fun source(s: Setup, connected: () -> Boolean) = ChatSource(
        remote = RemoteChatRepository(HarnessApi(s.link)),
        local = LocalChatRepository(s.store),
        isConnected = connected,
        isDownloaded = { it in s.store.ids() },
    )

    @Test
    fun `offline the list is the downloaded chats and reading works`() = runTest {
        val s = setup(stored = mapOf("c1" to (summary("c1") to listOf(turn("p1", "hello")))))
        val src = source(s) { false }
        val page = src.list(ChatListQuery(), 20, null)
        assertEquals(listOf("c1"), page.items.map { it.id })
        assertTrue(page.items.single().isDownloaded)
        val opened = src.open("c1", 12, null)
        assertEquals(listOf("hello", "answer to hello"), opened.messages.map { it.content })
        assertEquals("thought", opened.messages.last().thinking)
        assertTrue(s.link.calls.isEmpty())
    }

    @Test
    fun `offline search filters the downloaded chats by title`() = runTest {
        val s = setup(stored = mapOf("c1" to (summary("c1") to emptyList()), "c2" to (summary("c2").copy(title = "Pasta") to emptyList())))
        val src = source(s) { false }
        assertEquals(listOf("c2"), src.list(ChatListQuery(text = "pas"), 20, null).items.map { it.id })
    }

    @Test
    fun `offline an undownloaded chat and every change need the PC`() = runTest {
        val s = setup(stored = mapOf("c1" to (summary("c1") to listOf(turn("p1")))))
        val src = source(s) { false }
        for (block in listOf<suspend () -> Unit>(
            { src.open("other", 12, null) },
            { src.delete("c1") },
            { src.rewind("c1", "p1") },
            { src.setChat("c1", title = "x") },
        )) {
            try { block(); fail() } catch (e: RpcException) { assertEquals(RpcException.NOT_CONNECTED, e.code) }
        }
    }

    @Test
    fun `a read that finds the PC unreachable falls back to the copy`() = runTest {
        val s = setup(stored = mapOf("c1" to (summary("c1") to listOf(turn("p1", "cached")))))
        s.link.handler = { _, _ -> throw RpcException(RpcException.CONNECTION_LOST, "lost") }
        val opened = source(s) { true }.open("c1", 12, null)
        assertEquals("cached", opened.messages.first().content)
    }

    @Test
    fun `a protocol error is not hidden by the copy`() = runTest {
        val s = setup(stored = mapOf("c1" to (summary("c1") to listOf(turn("p1")))))
        s.link.handler = { _, _ -> throw RpcException("not-found", "gone") }
        try { source(s) { true }.open("c1", 12, null); fail() } catch (e: RpcException) { assertEquals("not-found", e.code) }
    }
}
