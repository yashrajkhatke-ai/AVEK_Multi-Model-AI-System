package com.avek.chat.link

import com.avek.chat.core.link.crypto.AvekProtocol
import com.avek.chat.core.link.crypto.Handshake
import com.avek.chat.core.link.discovery.FindClient
import com.avek.chat.core.link.discovery.FoundPc
import com.avek.chat.core.link.pairing.PairingManager
import com.avek.chat.core.link.store.FilePairedPcStore
import com.avek.chat.core.link.store.PairedPc
import com.avek.chat.core.link.store.SoftwareIdentityVault
import com.avek.chat.core.link.transport.ChannelFactory
import com.avek.chat.core.link.transport.HostPort
import com.avek.chat.core.link.transport.LocalAddress
import com.avek.chat.core.link.transport.NoWifiBinding
import com.avek.chat.core.link.wire.EventDecoder
import com.avek.chat.core.link.wire.WireCodec
import com.avek.chat.core.link.wire.WireEvent
import com.avek.chat.core.link.wire.WireResponse
import com.avek.chat.core.link.wire.LinkEvent
import com.avek.chat.core.model.settings.ConnectionSettings
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.launch
import kotlinx.coroutines.test.TestScope
import kotlinx.coroutines.test.runTest
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.put
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder

@OptIn(ExperimentalCoroutinesApi::class)
class StoreAndWireTest {

    @get:Rule
    val temp = TemporaryFolder()

    private val serverKey = SoftwareIdentityVault().also { it.create() }
    private val pc = PairedPc(
        AvekProtocol.serverIdOf(serverKey.publicKey()), "Yash Laptop", serverKey.publicKey(), "Tablet", "192.168.43.5", 7810, "e_9", 123,
    )

    // ------------------------------------------------------------------ store

    @Test
    fun `the pinned PC is stored and read back`() {
        val file = temp.newFile("pc.json").also { it.delete() }
        FilePairedPcStore(file).save(pc)
        assertTrue(file.readText().contains("Yash Laptop"))

        val reloaded = FilePairedPcStore(file).pc.value
        assertNotNull(reloaded)
        assertArrayEquals(pc.serverPub, reloaded!!.serverPub)
        assertEquals(pc.serverId, reloaded.serverId)
        assertEquals("e_9", reloaded.epoch)
        assertEquals(123L, reloaded.lastSeq)
        assertEquals("192.168.43.5", reloaded.lastHost)
    }

    @Test
    fun `updates are persisted and clear wipes the file`() {
        val file = temp.newFile("pc2.json").also { it.delete() }
        val store = FilePairedPcStore(file)
        store.save(pc)
        store.update { it.copy(lastSeq = 500, lastHost = "10.0.0.8") }
        assertEquals(500L, FilePairedPcStore(file).pc.value?.lastSeq)

        store.clear()
        assertNull(store.pc.value)
        assertFalse(file.exists())
    }

    @Test
    fun `an old v2 grant is wiped and the person is asked to pair again`() {
        val file = temp.newFile("pc3.json")
        file.writeText(
            """{"deviceId":"d_1","secret":"c2VjcmV0c2VjcmV0c2VjcmV0c2VjcmV0c2VjcmV0MTI=","serverId":"s_1","serverName":"Yash Laptop","deviceName":"Tablet"}""",
        )
        val store = FilePairedPcStore(file)
        assertNull(store.pc.value)
        assertEquals("This version pairs differently. Pair with your PC again.", store.notice.value)
        assertFalse("the old secret is gone", file.exists())
        store.clearNotice()
        assertNull(store.notice.value)
    }

    @Test
    fun `a corrupt file means unpaired, not a crash`() {
        val file = temp.newFile("pc4.json")
        file.writeText("""{"version":3,"serverId":"s_1","serverName":"X","serverPub":"AAAA","deviceName":"T"}""")
        val store = FilePairedPcStore(file)
        assertNull(store.pc.value)
        assertNull(store.notice.value)
        assertFalse(file.exists())
    }

    // ------------------------------------------------------------------ pairing manager

    private fun TestScope.manager(server: FakeHarnessServer, store: InMemoryPairedPcStore, identity: SoftwareIdentityVault, udp: FakeUdpTransport) =
        PairingManager(
            store = store,
            identity = identity,
            channels = ChannelFactory { target ->
                val (c, s) = InMemoryChannel.pair(target.host, target.port)
                backgroundScope.launch { server.serve(s) }
                c
            },
            finder = FindClient(udp),
            binding = NoWifiBinding,
            handshake = Handshake(),
        )

    @Test
    fun `find then pair stores the pinned key with the address that worked`() = runTest {
        val server = FakeHarnessServer(backgroundScope)
        val store = InMemoryPairedPcStore()
        val identity = SoftwareIdentityVault()
        val listener = FakeKnockListener(server.identity, { server.devices }, pairingOpenName = "Test PC")
        val udp = FakeUdpTransport({ testScheduler.currentTime }, respond = listener::respond)
        val manager = manager(server, store, identity, udp)

        val found = manager.find().single()
        assertEquals("Test PC", found.name)
        var digits: String? = null
        val paired = manager.pair(found, "Kitchen tablet", confirm = { digits = it.sas; true }, onAwaitingApproval = {})

        assertEquals(server.lastSas, digits)
        assertEquals("Test PC", paired.serverName)
        assertEquals("Kitchen tablet", store.pc.value?.deviceName)
        assertEquals("192.168.43.5", store.pc.value?.lastHost)
        assertArrayEquals(server.serverPub, store.pc.value?.serverPub)
        assertArrayEquals(identity.publicKey(), server.devices.getValue(AvekProtocol.deviceIdOf(identity.publicKey())))

        manager.forget()
        assertNull(store.pc.value)
        assertFalse("forgetting deletes the device key too", identity.exists())
    }

    @Test
    fun `digits that do not match store nothing`() = runTest {
        val server = FakeHarnessServer(backgroundScope)
        val store = InMemoryPairedPcStore()
        val udp = FakeUdpTransport({ testScheduler.currentTime })
        val manager = manager(server, store, SoftwareIdentityVault(), udp)
        try {
            manager.pair(FoundPc(server.serverId, "Test PC", "10.0.0.2", 7810), "Tablet", confirm = { false }, onAwaitingApproval = {})
            org.junit.Assert.fail("expected a cancellation")
        } catch (_: com.avek.chat.core.link.crypto.HandshakeException.Cancelled) {
        }
        assertNull(store.pc.value)
        assertTrue(server.devices.isEmpty())
    }

    // ------------------------------------------------------------------ small parsers

    @Test
    fun `host and port parsing`() {
        assertEquals(HostPort("192.168.1.5", 7810), HostPort.parse("192.168.1.5"))
        assertEquals(HostPort("192.168.1.5", 8000), HostPort.parse(" 192.168.1.5:8000 "))
        assertNull(HostPort.parse(""))
        assertNull(HostPort.parse("host:abc"))
        assertNull(HostPort.parse("host:70000"))
        assertNull(HostPort.parse("a b"))
        assertEquals("10.0.0.2:7810", HostPort("10.0.0.2", 7810).toString())
    }

    @Test
    fun `subnet broadcast and the 24 sweep list`() {
        val local = LocalAddress("192.168.43.17", 24)
        assertEquals("192.168.43.255", local.broadcast)
        assertEquals(253, local.hostsOf24.size)
        assertFalse(local.hostsOf24.contains("192.168.43.17"))
        assertEquals("10.0.3.255", LocalAddress("10.0.1.9", 22).broadcast)
    }

    // ------------------------------------------------------------------ wire

    @Test
    fun `requests encode with id, op and args`() {
        val text = WireCodec.encodeRequest("r17", "models.list", obj { put("limit", 1) })
        val json = Json.parseToJsonElement(text) as JsonObject
        assertEquals("r17", (json["id"] as kotlinx.serialization.json.JsonPrimitive).content)
        assertEquals("models.list", (json["op"] as kotlinx.serialization.json.JsonPrimitive).content)
        assertEquals("1", ((json["args"] as JsonObject)["limit"] as kotlinx.serialization.json.JsonPrimitive).content)
    }

    @Test
    fun `responses and events are told apart by their first key`() {
        val ok = WireCodec.parse("""{"re":"r1","ok":true,"data":{"x":1},"more":true}""") as WireResponse
        assertTrue(ok.ok && ok.more)
        val err = WireCodec.parse("""{"re":"r2","ok":false,"error":{"code":"busy","message":"turn running"}}""") as WireResponse
        assertEquals("busy", err.error?.code)
        val ev = WireCodec.parse("""{"ev":"answer.delta","seq":412,"data":{"chatId":"c","promptId":"p","text":"x","offset":0}}""") as WireEvent
        assertEquals(412L, ev.seq)
        assertNull(WireCodec.parse("""{"something":"else"}"""))
    }

    @Test
    fun `unknown events and unknown fields are ignored`() {
        assertNull(EventDecoder.decode(WireEvent("future.event", 3, JsonObject(emptyMap()))))
        val decoded = EventDecoder.decode(
            WireEvent("turn.failed", 9, obj { put("chatId", "c"); put("promptId", "p"); put("message", "boom"); put("newField", "ignored") }),
        )
        assertEquals("boom", (decoded as LinkEvent.TurnFailed).data.message)
        // Malformed payloads are dropped, not thrown.
        assertNull(EventDecoder.decode(WireEvent("turn.failed", 9, JsonObject(emptyMap()))))
    }

    @Test
    fun `every event of the spec decodes`() {
        fun decode(ev: String, data: JsonObject) = EventDecoder.decode(WireEvent(ev, 1, data))
        val ids = obj { put("chatId", "c"); put("promptId", "p") }
        assertTrue(decode("turn.started", obj { put("chatId", "c"); put("promptId", "p"); put("modelId", "m"); put("mode", "auto"); put("depth", 2) }) is LinkEvent.TurnStarted)
        assertTrue(decode("thinking.delta", obj { put("chatId", "c"); put("promptId", "p"); put("text", "t"); put("offset", 0) }) is LinkEvent.ThinkingDelta)
        assertTrue(decode("tool.call", obj { put("chatId", "c"); put("promptId", "p"); put("callId", "t1"); put("name", "n"); put("title", "T") }) is LinkEvent.ToolCall)
        assertTrue(decode("tool.result", obj { put("chatId", "c"); put("promptId", "p"); put("callId", "t1"); put("ok", true); put("title", "T") }) is LinkEvent.ToolResult)
        assertTrue(decode("status", obj { put("phase", "load"); put("state", "start"); put("text", "Loading") }) is LinkEvent.Status)
        assertTrue(decode("sources", obj { put("chatId", "c"); put("promptId", "p"); put("sources", arr()) }) is LinkEvent.Sources)
        assertTrue(decode("ask.request", obj { put("askId", "k"); put("summary", "s") }) is LinkEvent.AskRequest)
        assertTrue(decode("ask.resolved", obj { put("askId", "k"); put("by", "Tablet") }) is LinkEvent.AskResolved)
        assertTrue(decode("turn.cancelled", ids) is LinkEvent.TurnCancelled)
        assertTrue(decode("models.changed", JsonObject(emptyMap())) is LinkEvent.ModelsChanged)
        assertTrue(decode("chat.deleted", obj { put("chatId", "c") }) is LinkEvent.ChatDeleted)
        assertTrue(decode("download.deleted", obj { put("chatId", "c") }) is LinkEvent.DownloadDeleted)
        assertTrue(decode("bye", obj { put("reason", "shutdown") }) is LinkEvent.Bye)
        val chat = obj { put("chat", obj { put("chatId", "c"); put("title", "T") }) }
        assertTrue(decode("chat.created", chat) is LinkEvent.ChatCreated)
        assertTrue(decode("chat.updated", chat) is LinkEvent.ChatUpdated)
        assertTrue(decode("download.chat", chat) is LinkEvent.DownloadChat)
        assertTrue(decode("download.turn", obj { put("chatId", "c"); put("turn", obj { put("promptId", "p") }) }) is LinkEvent.DownloadTurn)
        assertTrue(decode("toolcall.delta", obj { put("chatId", "c"); put("promptId", "p"); put("step", 1); put("index", 0); put("text", "{"); put("offset", 0) }) is LinkEvent.ToolCallDelta)
        assertTrue(decode("model.state", obj { put("modelId", "m"); put("state", "loading") }) is LinkEvent.ModelState)
    }

    @Test
    fun `connection settings survive a JSON round trip`() {
        val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }
        val settings = ConnectionSettings(workInBackground = true, keepListsSeconds = 300)
        val decoded = json.decodeFromString(ConnectionSettings.serializer(), json.encodeToString(ConnectionSettings.serializer(), settings))
        assertEquals(settings, decoded)
        // A v2 settings file with routes still loads.
        val old = json.decodeFromString(ConnectionSettings.serializer(), """{"routes":[{"type":"last"}],"workInBackground":true}""")
        assertTrue(old.workInBackground)
        assertEquals(120, ConnectionSettings().keepListsSeconds)
        assertFalse(ConnectionSettings().workInBackground)
    }
}
