package com.avek.chat.link

import com.avek.chat.core.link.crypto.Handshake
import com.avek.chat.core.link.discovery.Beacon
import com.avek.chat.core.link.discovery.BeaconParser
import com.avek.chat.core.link.discovery.BeaconSource
import com.avek.chat.core.link.pairing.PairingManager
import com.avek.chat.core.link.store.FilePairedPcStore
import com.avek.chat.core.link.store.PairedPc
import com.avek.chat.core.link.store.SecretVault
import com.avek.chat.core.link.store.VaultException
import com.avek.chat.core.link.transport.ChannelFactory
import com.avek.chat.core.link.transport.HostPort
import com.avek.chat.core.link.transport.NoWifiBinding
import com.avek.chat.core.link.wire.EventDecoder
import com.avek.chat.core.link.wire.WireCodec
import com.avek.chat.core.link.wire.WireEvent
import com.avek.chat.core.link.wire.WireResponse
import com.avek.chat.core.link.wire.LinkEvent
import com.avek.chat.core.model.settings.ConnectionSettings
import com.avek.chat.core.model.settings.RouteSpec
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.toList
import kotlinx.coroutines.launch
import kotlinx.coroutines.test.runTest
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.put
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder

/** A stand-in vault: reversible and not the identity, so a test can tell the secret was transformed. */
class FakeVault(var broken: Boolean = false) : SecretVault {
    override fun encrypt(plain: ByteArray) = plain.map { (it.toInt() xor 0x5A).toByte() }.toByteArray() + byteArrayOf(0x7F)
    override fun decrypt(cipher: ByteArray): ByteArray {
        if (broken) throw VaultException("key lost")
        return cipher.copyOf(cipher.size - 1).map { (it.toInt() xor 0x5A).toByte() }.toByteArray()
    }
}

@OptIn(ExperimentalCoroutinesApi::class)
class StoreAndWireTest {

    @get:Rule
    val temp = TemporaryFolder()

    private val pc = PairedPc("d_1", ByteArray(32) { it.toByte() }, "s_1", "Yash Laptop", "Tablet", "192.168.43.5", 7810, "e_9", 123)

    // ------------------------------------------------------------------ store

    @Test
    fun `the secret is stored encrypted and read back`() {
        val file = temp.newFile("pc.json").also { it.delete() }
        FilePairedPcStore(file, FakeVault()).save(pc)

        val text = file.readText()
        assertFalse("the secret must not appear in plain base64", text.contains(com.avek.chat.core.link.crypto.SecureCrypto.b64(pc.deviceSecret)))
        assertTrue(text.contains("Yash Laptop"))

        val reloaded = FilePairedPcStore(file, FakeVault()).pc.value
        assertNotNull(reloaded)
        assertArrayEquals(pc.deviceSecret, reloaded!!.deviceSecret)
        assertEquals("e_9", reloaded.epoch)
        assertEquals(123L, reloaded.lastSeq)
        assertEquals("192.168.43.5", reloaded.lastHost)
    }

    @Test
    fun `updates are persisted and clear wipes the file`() {
        val file = temp.newFile("pc2.json").also { it.delete() }
        val store = FilePairedPcStore(file, FakeVault())
        store.save(pc)
        store.update { it.copy(lastSeq = 500, lastHost = "10.0.0.8") }
        assertEquals(500L, FilePairedPcStore(file, FakeVault()).pc.value?.lastSeq)

        store.clear()
        assertNull(store.pc.value)
        assertFalse(file.exists())
    }

    @Test
    fun `a lost vault key means unpaired, not a crash`() {
        val file = temp.newFile("pc3.json").also { it.delete() }
        FilePairedPcStore(file, FakeVault()).save(pc)
        val reopened = FilePairedPcStore(file, FakeVault(broken = true))
        assertNull(reopened.pc.value)
        assertFalse("the unusable file is removed", file.exists())
    }

    // ------------------------------------------------------------------ pairing manager

    @Test
    fun `pairing stores the grant with the address that worked`() = runTest {
        val server = FakeHarnessServer(backgroundScope)
        val store = InMemoryPairedPcStore()
        val manager = PairingManager(
            store = store,
            channels = ChannelFactory { target ->
                val (c, s) = InMemoryChannel.pair(target.host, target.port)
                backgroundScope.launch { server.serve(s) }
                c
            },
            beacons = BeaconSource { flowOf() },
            binding = NoWifiBinding,
            handshake = Handshake(),
        )
        val paired = manager.pair(HostPort("192.168.43.5", 7810), "abcd-efgh-jklm", "Kitchen tablet")

        assertEquals("Test PC", paired.serverName)
        assertEquals("Kitchen tablet", store.pc.value?.deviceName)
        assertEquals("192.168.43.5", store.pc.value?.lastHost)
        assertArrayEquals(server.devices.getValue(paired.deviceId), paired.deviceSecret)

        manager.forget()
        assertNull(store.pc.value)
    }

    @Test
    fun `a wrong pairing code stores nothing`() = runTest {
        val server = FakeHarnessServer(backgroundScope)
        val store = InMemoryPairedPcStore()
        val manager = PairingManager(
            store, ChannelFactory { target ->
                val (c, s) = InMemoryChannel.pair(target.host, target.port)
                backgroundScope.launch { server.serve(s) }
                c
            },
            BeaconSource { flowOf() }, NoWifiBinding, Handshake(),
        )
        try {
            manager.pair(HostPort("10.0.0.2", 7810), "WRNG-CODE-XXXX", "Tablet")
            org.junit.Assert.fail("expected a denial")
        } catch (e: com.avek.chat.core.link.crypto.HandshakeException.Denied) {
            assertEquals("bad-code", e.reason)
        }
        assertNull(store.pc.value)
    }

    @Test
    fun `discovery accumulates PCs by server id`() = runTest {
        val manager = PairingManager(
            InMemoryPairedPcStore(), ChannelFactory { error("unused") },
            BeaconSource { flowOf(Beacon("s_b", "Zeta PC", "10.0.0.3", 7810), Beacon("s_a", "Alpha PC", "10.0.0.2", 7810), Beacon("s_b", "Zeta PC", "10.0.0.4", 7810)) },
            NoWifiBinding, Handshake(),
        )
        val last = manager.discover().toList().last()
        assertEquals(listOf("Alpha PC", "Zeta PC"), last.map { it.name })
        assertEquals("10.0.0.4", last.last().target.host)
    }

    // ------------------------------------------------------------------ small parsers

    @Test
    fun `host and port parsing`() {
        assertEquals(HostPort("192.168.1.5", 7810), HostPort.parse("192.168.1.5"))
        assertEquals(HostPort("192.168.1.5", 8000), HostPort.parse(" 192.168.1.5:8000 "))
        assertNull(HostPort.parse(""))
        assertNull(HostPort.parse("host:abc"))
        assertNull(HostPort.parse("host:70000"))
        assertNull(HostPort.parse("a b"))
        assertEquals("10.0.0.2:7810", HostPort("10.0.0.2", 7810).toString())
    }

    @Test
    fun `beacon parsing accepts the spec's datagram and rejects junk`() {
        val beacon = BeaconParser.parse("""{"avek":2,"serverId":"s_9f3c1a","name":"Yash Laptop","port":7810}""", "192.168.43.5")
        assertEquals(Beacon("s_9f3c1a", "Yash Laptop", "192.168.43.5", 7810), beacon)
        assertNull(BeaconParser.parse("not json", "1.1.1.1"))
        assertNull(BeaconParser.parse("""{"serverId":"x","port":1}""", "1.1.1.1"))
        assertNull(BeaconParser.parse("""{"avek":2,"serverId":"x","port":99999}""", "1.1.1.1"))
    }

    // ------------------------------------------------------------------ wire

    @Test
    fun `requests encode with id, op and args`() {
        val text = WireCodec.encodeRequest("r17", "models.list", obj { put("limit", 1) })
        val json = Json.parseToJsonElement(text) as JsonObject
        assertEquals("r17", (json["id"] as kotlinx.serialization.json.JsonPrimitive).content)
        assertEquals("models.list", (json["op"] as kotlinx.serialization.json.JsonPrimitive).content)
        assertEquals("1", ((json["args"] as JsonObject)["limit"] as kotlinx.serialization.json.JsonPrimitive).content)
    }

    @Test
    fun `responses and events are told apart by their first key`() {
        val ok = WireCodec.parse("""{"re":"r1","ok":true,"data":{"x":1},"more":true}""") as WireResponse
        assertTrue(ok.ok && ok.more)
        val err = WireCodec.parse("""{"re":"r2","ok":false,"error":{"code":"busy","message":"turn running"}}""") as WireResponse
        assertEquals("busy", err.error?.code)
        val ev = WireCodec.parse("""{"ev":"answer.delta","seq":412,"data":{"chatId":"c","promptId":"p","text":"x","offset":0}}""") as WireEvent
        assertEquals(412L, ev.seq)
        assertNull(WireCodec.parse("""{"something":"else"}"""))
    }

    @Test
    fun `unknown events and unknown fields are ignored`() {
        assertNull(EventDecoder.decode(WireEvent("future.event", 3, JsonObject(emptyMap()))))
        val decoded = EventDecoder.decode(
            WireEvent("turn.failed", 9, obj { put("chatId", "c"); put("promptId", "p"); put("message", "boom"); put("newField", "ignored") }),
        )
        assertEquals("boom", (decoded as LinkEvent.TurnFailed).data.message)
        // Malformed payloads are dropped, not thrown.
        assertNull(EventDecoder.decode(WireEvent("turn.failed", 9, JsonObject(emptyMap()))))
    }

    @Test
    fun `every event of the spec decodes`() {
        fun decode(ev: String, data: JsonObject) = EventDecoder.decode(WireEvent(ev, 1, data))
        val ids = obj { put("chatId", "c"); put("promptId", "p") }
        assertTrue(decode("turn.started", obj { put("chatId", "c"); put("promptId", "p"); put("modelId", "m"); put("mode", "auto"); put("depth", 2) }) is LinkEvent.TurnStarted)
        assertTrue(decode("thinking.delta", obj { put("chatId", "c"); put("promptId", "p"); put("text", "t"); put("offset", 0) }) is LinkEvent.ThinkingDelta)
        assertTrue(decode("tool.call", obj { put("chatId", "c"); put("promptId", "p"); put("callId", "t1"); put("name", "n"); put("title", "T") }) is LinkEvent.ToolCall)
        assertTrue(decode("tool.result", obj { put("chatId", "c"); put("promptId", "p"); put("callId", "t1"); put("ok", true); put("title", "T") }) is LinkEvent.ToolResult)
        assertTrue(decode("status", obj { put("phase", "load"); put("state", "start"); put("text", "Loading") }) is LinkEvent.Status)
        assertTrue(decode("sources", obj { put("chatId", "c"); put("promptId", "p"); put("sources", arr()) }) is LinkEvent.Sources)
        assertTrue(decode("ask.request", obj { put("askId", "k"); put("summary", "s") }) is LinkEvent.AskRequest)
        assertTrue(decode("ask.resolved", obj { put("askId", "k"); put("by", "Tablet") }) is LinkEvent.AskResolved)
        assertTrue(decode("turn.cancelled", ids) is LinkEvent.TurnCancelled)
        assertTrue(decode("models.changed", JsonObject(emptyMap())) is LinkEvent.ModelsChanged)
        assertTrue(decode("chat.deleted", obj { put("chatId", "c") }) is LinkEvent.ChatDeleted)
        assertTrue(decode("download.deleted", obj { put("chatId", "c") }) is LinkEvent.DownloadDeleted)
        assertTrue(decode("bye", obj { put("reason", "shutdown") }) is LinkEvent.Bye)
        val chat = obj { put("chat", obj { put("chatId", "c"); put("title", "T") }) }
        assertTrue(decode("chat.created", chat) is LinkEvent.ChatCreated)
        assertTrue(decode("chat.updated", chat) is LinkEvent.ChatUpdated)
        assertTrue(decode("download.chat", chat) is LinkEvent.DownloadChat)
        assertTrue(decode("download.turn", obj { put("chatId", "c"); put("turn", obj { put("promptId", "p") }) }) is LinkEvent.DownloadTurn)
    }

    @Test
    fun `route settings survive a JSON round trip including fixed items and hosts`() {
        val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }
        val settings = ConnectionSettings(
            routes = listOf(RouteSpec.Host("10.0.0.2", 7810), RouteSpec.Last, RouteSpec.Discover, RouteSpec.Host("192.168.1.9", 8000)),
            workInBackground = true,
            keepListsSeconds = 300,
        )
        val decoded = json.decodeFromString(ConnectionSettings.serializer(), json.encodeToString(ConnectionSettings.serializer(), settings))
        assertEquals(settings, decoded)
        assertEquals(listOf(RouteSpec.Last, RouteSpec.Discover), ConnectionSettings().routes)
        assertEquals(120, ConnectionSettings().keepListsSeconds)
        assertFalse(ConnectionSettings().workInBackground)
    }
}
