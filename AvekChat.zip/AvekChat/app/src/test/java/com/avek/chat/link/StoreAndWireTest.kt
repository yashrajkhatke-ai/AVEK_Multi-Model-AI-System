package com.avek.chat.link

import com.avek.chat.core.link.crypto.AvekProtocol
import com.avek.chat.core.link.crypto.PairingResult
import com.avek.chat.core.link.crypto.SecureCrypto
import com.avek.chat.core.link.pairing.PairTarget
import com.avek.chat.core.link.store.DeviceSecrets
import com.avek.chat.core.link.store.GrantSecrets
import com.avek.chat.core.link.store.PendingRekey
import com.avek.chat.core.link.store.SoftwareSecretVault
import com.avek.chat.core.link.transport.ChannelTarget
import com.avek.chat.core.link.wire.NgrokRouteDto
import com.avek.chat.core.link.wire.RoutesData
import com.avek.chat.core.link.wire.TailscaleRouteDto
import com.avek.chat.core.link.discovery.FindClient
import com.avek.chat.core.link.discovery.FoundPc
import com.avek.chat.core.link.pairing.PairingManager
import com.avek.chat.core.link.store.FilePairedPcStore
import com.avek.chat.core.link.store.PairedPc
import com.avek.chat.core.link.store.SoftwareIdentityVault
import com.avek.chat.core.link.transport.ChannelFactory
import com.avek.chat.core.link.transport.HostPort
import com.avek.chat.core.link.transport.LocalAddress
import com.avek.chat.core.link.transport.NoWifiBinding
import com.avek.chat.core.link.wire.EventDecoder
import com.avek.chat.core.link.wire.WireCodec
import com.avek.chat.core.link.wire.WireEvent
import com.avek.chat.core.link.wire.WireResponse
import com.avek.chat.core.link.wire.LinkEvent
import com.avek.chat.core.model.settings.ConnectionSettings
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.launch
import kotlinx.coroutines.test.TestScope
import kotlinx.coroutines.test.runTest
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.put
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder

@OptIn(ExperimentalCoroutinesApi::class)
class StoreAndWireTest {

    @get:Rule
    val temp = TemporaryFolder()

    private val serverKey = SoftwareIdentityVault().also { it.create(FakeHarnessServer.ALIAS) }
    private val serverPub = serverKey.publicKey(FakeHarnessServer.ALIAS)
    private val vault = SoftwareSecretVault()
    private val sealed = GrantSecrets(vault).seal(DeviceSecrets(ByteArray(32) { 1 }, ByteArray(32) { 2 }))
    private val pc = PairedPc(
        deviceId = "d_5587348a01",
        identityAlias = "avek.identity.1",
        serverId = AvekProtocol.serverIdOf(serverPub),
        serverName = "Yash Laptop",
        serverPub = serverPub,
        deviceName = "Tablet",
        sealedSecrets = sealed,
        routes = RoutesData(tailscale = TailscaleRouteDto(host = "100.64.1.2", dns = "legion.tail1234.ts.net")),
        lastWifiHost = "192.168.43.5",
        epoch = "e_9",
        lastSeq = 123,
    )

    // ------------------------------------------------------------------ store

    @Test
    fun `the grant is stored and read back with its secrets sealed`() {
        val file = temp.newFile("pc.json").also { it.delete() }
        FilePairedPcStore(file, vault).save(pc)
        val text = file.readText()
        assertTrue(text.contains("Yash Laptop"))
        assertFalse("routes are sealed", text.contains("100.64.1.2"))
        assertFalse("routes are sealed", text.contains("legion"))

        val reloaded = FilePairedPcStore(file, vault).pc.value
        assertNotNull(reloaded)
        assertArrayEquals(pc.serverPub, reloaded!!.serverPub)
        assertEquals(pc.deviceId, reloaded.deviceId)
        assertEquals(pc.identityAlias, reloaded.identityAlias)
        assertEquals("e_9", reloaded.epoch)
        assertEquals(123L, reloaded.lastSeq)
        assertEquals("192.168.43.5", reloaded.lastWifiHost)
        assertEquals("100.64.1.2", reloaded.routes?.tailscale?.host)
        val secrets = GrantSecrets(vault).open(reloaded.sealedSecrets)
        assertArrayEquals(ByteArray(32) { 1 }, secrets.dk)
        assertArrayEquals(ByteArray(32) { 2 }, secrets.rk)
        assertEquals("DeviceSecrets(***)", secrets.toString())
    }

    @Test
    fun `a pending key replacement survives a restart`() {
        val file = temp.newFile("pc5.json").also { it.delete() }
        FilePairedPcStore(file, vault).save(pc.copy(pendingRekey = PendingRekey("avek.identity.2", sealed, 42L)))
        val pending = FilePairedPcStore(file, vault).pc.value!!.pendingRekey!!
        assertEquals("avek.identity.2", pending.alias)
        assertEquals(42L, pending.deadlineMs)
        assertArrayEquals(sealed, pending.sealedSecrets)
    }

    @Test
    fun `updates are persisted and clear wipes the file`() {
        val file = temp.newFile("pc2.json").also { it.delete() }
        val store = FilePairedPcStore(file, vault)
        store.save(pc)
        store.update { it.copy(lastSeq = 500, lastWifiHost = "10.0.0.8") }
        assertEquals(500L, FilePairedPcStore(file, vault).pc.value?.lastSeq)
        store.clear()
        assertNull(store.pc.value)
        assertFalse(file.exists())
    }

    @Test
    fun `a v3 grant is wiped with its Keystore key and the person is asked to pair again`() {
        val file = temp.newFile("pc3.json")
        file.writeText(
            """{"version":3,"serverId":"s_1","serverName":"Yash Laptop","serverPub":"${SecureCrypto.b64(serverPub)}","deviceName":"Tablet","lastHost":"192.168.43.5"}""",
        )
        var keystoreWiped = 0
        val store = FilePairedPcStore(file, vault) { keystoreWiped++ }
        assertNull(store.pc.value)
        assertEquals("This version pairs differently. Pair with your PC again.", store.notice.value)
        assertFalse("the old grant is gone", file.exists())
        assertEquals(1, keystoreWiped)
        store.clearNotice()
        assertNull(store.notice.value)
    }

    @Test
    fun `a corrupt file means unpaired, not a crash`() {
        val file = temp.newFile("pc4.json")
        file.writeText("""{"version":4,"deviceId":"d","identityAlias":"a","serverId":"s_1","serverName":"X","serverPub":"AAAA","deviceName":"T","sealedSecrets":"AA=="}""")
        val store = FilePairedPcStore(file, vault)
        assertNull(store.pc.value)
        assertNull(store.notice.value)
        assertFalse(file.exists())
    }

    @Test
    fun `routes the vault can no longer open are dropped, the grant stays`() {
        val file = temp.newFile("pc6.json").also { it.delete() }
        FilePairedPcStore(file, vault).save(pc)
        val other = SoftwareSecretVault()
        val reloaded = FilePairedPcStore(file, other).pc.value
        assertNotNull(reloaded)
        assertNull(reloaded!!.routes)
    }

    // ------------------------------------------------------------------ pairing manager

    private fun TestScope.manager(server: FakeHarnessServer, store: InMemoryPairedPcStore, identity: SoftwareIdentityVault, udp: FakeUdpTransport, targets: MutableList<ChannelTarget> = mutableListOf()) =
        PairingManager(
            store = store,
            identity = identity,
            secrets = GrantSecrets(vault),
            channels = ChannelFactory { target ->
                targets += target
                val (c, s) = InMemoryChannel.pair(target.remote.host, target.remote.port)
                backgroundScope.launch { server.serve(s) }
                c
            },
            finder = FindClient(udp),
            binding = NoWifiBinding,
            handshake = testPairing(),
        )

    @Test
    fun `find then pair with the code stores the grant with dk and rk sealed`() = runTest {
        val server = FakeHarnessServer(backgroundScope)
        val store = InMemoryPairedPcStore()
        val identity = SoftwareIdentityVault()
        val listener = FakeKnockListener(server.identity, { server.devices.mapValues { it.value.pub } }, pairingOpenName = "Test PC")
        val udp = FakeUdpTransport({ testScheduler.currentTime }, respond = listener::respond)
        val manager = manager(server, store, identity, udp)

        val found = manager.find().single()
        assertEquals("Test PC", found.name)
        val code = "1234 5678 9012".toCharArray()
        val result = manager.pair(PairTarget.Found(found), code, "Kitchen tablet")
        assertTrue(result is PairingResult.Paired)
        val stored = store.pc.value!!
        assertEquals("Kitchen tablet", stored.deviceName)
        assertEquals("192.168.43.5", stored.lastWifiHost)
        assertEquals("avek.identity.1", stored.identityAlias)
        assertArrayEquals(server.serverPub, stored.serverPub)
        val device = server.devices.getValue(stored.deviceId)
        assertArrayEquals(identity.publicKey("avek.identity.1"), device.pub)
        val secrets = GrantSecrets(vault).open(stored.sealedSecrets)
        assertArrayEquals(device.dk, secrets.dk)
        assertArrayEquals(device.rk, secrets.rk)
    }

    @Test
    fun `a wrong code stores nothing and leaves no key behind`() = runTest {
        val server = FakeHarnessServer(backgroundScope)
        val store = InMemoryPairedPcStore()
        val identity = SoftwareIdentityVault()
        val manager = manager(server, store, identity, FakeUdpTransport({ testScheduler.currentTime }))
        val result = manager.pair(PairTarget.Found(FoundPc(server.serverId, "Test PC", "10.0.0.2", 7810)), "123456789013".toCharArray(), "Tablet")
        assertEquals(PairingResult.NotPaired, result)
        assertNull(store.pc.value)
        assertTrue(server.devices.isEmpty())
        assertTrue(identity.aliases().isEmpty())
    }

    @Test
    fun `the Tailscale fallback pairs with ws to port 7810 on the default network`() = runTest {
        val server = FakeHarnessServer(backgroundScope)
        val targets = mutableListOf<ChannelTarget>()
        val store = InMemoryPairedPcStore()
        val manager = manager(server, store, SoftwareIdentityVault(), FakeUdpTransport({ testScheduler.currentTime }), targets)
        val result = manager.pair(PairTarget.Manual("legion.tail1234.ts.net"), FakeHarnessServer.CODE.toCharArray(), "Tablet")
        assertTrue(result is PairingResult.Paired)
        assertEquals("ws://legion.tail1234.ts.net:7810/ui", targets.single().url)
        assertFalse(targets.single().viaWifi)
        assertNull(store.pc.value!!.lastWifiHost)
    }

    @Test
    fun `a PC that cannot be reached is NoRoute`() = runTest {
        val manager = PairingManager(
            InMemoryPairedPcStore(), SoftwareIdentityVault(), GrantSecrets(vault),
            ChannelFactory { throw java.io.IOException("refused") },
            FindClient(FakeUdpTransport({ 0 })), NoWifiBinding, testPairing(),
        )
        assertEquals(PairingResult.NoRoute, manager.pair(PairTarget.Manual("10.9.9.9"), FakeHarnessServer.CODE.toCharArray(), "Tablet"))
    }

    // ------------------------------------------------------------------ parsers

    @Test
    fun `routes data gives the ngrok host for wss`() {
        assertEquals("my-pc.ngrok-free.dev", RoutesData(ngrok = NgrokRouteDto(url = "https://my-pc.ngrok-free.dev")).ngrokHost)
        assertEquals("my-pc.ngrok-free.dev", RoutesData(ngrok = NgrokRouteDto(url = "https://my-pc.ngrok-free.dev/")).ngrokHost)
        assertNull(RoutesData(ngrok = NgrokRouteDto(url = "")).ngrokHost)
        assertNull(RoutesData().ngrokHost)
    }

    // ------------------------------------------------------------------ small parsers

    @Test
    fun `host and port parsing`() {
        assertEquals(HostPort("192.168.1.5", 7810), HostPort.parse("192.168.1.5"))
        assertEquals(HostPort("192.168.1.5", 8000), HostPort.parse(" 192.168.1.5:8000 "))
        assertNull(HostPort.parse(""))
        assertNull(HostPort.parse("host:abc"))
        assertNull(HostPort.parse("host:70000"))
        assertNull(HostPort.parse("a b"))
        assertEquals("10.0.0.2:7810", HostPort("10.0.0.2", 7810).toString())
    }

    @Test
    fun `subnet broadcast and the 24 sweep list`() {
        val local = LocalAddress("192.168.43.17", 24)
        assertEquals("192.168.43.255", local.broadcast)
        assertEquals(253, local.hostsOf24.size)
        assertFalse(local.hostsOf24.contains("192.168.43.17"))
        assertEquals("10.0.3.255", LocalAddress("10.0.1.9", 22).broadcast)
    }

    // ------------------------------------------------------------------ wire

    @Test
    fun `requests encode with id, op and args`() {
        val text = WireCodec.encodeRequest("r17", "models.list", obj { put("limit", 1) })
        val json = Json.parseToJsonElement(text) as JsonObject
        assertEquals("r17", (json["id"] as kotlinx.serialization.json.JsonPrimitive).content)
        assertEquals("models.list", (json["op"] as kotlinx.serialization.json.JsonPrimitive).content)
        assertEquals("1", ((json["args"] as JsonObject)["limit"] as kotlinx.serialization.json.JsonPrimitive).content)
    }

    @Test
    fun `responses and events are told apart by their first key`() {
        val ok = WireCodec.parse("""{"re":"r1","ok":true,"data":{"x":1},"more":true}""") as WireResponse
        assertTrue(ok.ok && ok.more)
        val err = WireCodec.parse("""{"re":"r2","ok":false,"error":{"code":"busy","message":"turn running"}}""") as WireResponse
        assertEquals("busy", err.error?.code)
        val ev = WireCodec.parse("""{"ev":"answer.delta","seq":412,"data":{"chatId":"c","promptId":"p","text":"x","offset":0}}""") as WireEvent
        assertEquals(412L, ev.seq)
        assertNull(WireCodec.parse("""{"something":"else"}"""))
    }

    @Test
    fun `unknown events and unknown fields are ignored`() {
        assertNull(EventDecoder.decode(WireEvent("future.event", 3, JsonObject(emptyMap()))))
        val decoded = EventDecoder.decode(
            WireEvent("turn.failed", 9, obj { put("chatId", "c"); put("promptId", "p"); put("message", "boom"); put("newField", "ignored") }),
        )
        assertEquals("boom", (decoded as LinkEvent.TurnFailed).data.message)
        // Malformed payloads are dropped, not thrown.
        assertNull(EventDecoder.decode(WireEvent("turn.failed", 9, JsonObject(emptyMap()))))
    }

    @Test
    fun `every event of the spec decodes`() {
        fun decode(ev: String, data: JsonObject) = EventDecoder.decode(WireEvent(ev, 1, data))
        val ids = obj { put("chatId", "c"); put("promptId", "p") }
        assertTrue(decode("turn.started", obj { put("chatId", "c"); put("promptId", "p"); put("modelId", "m"); put("mode", "auto"); put("depth", 2) }) is LinkEvent.TurnStarted)
        assertTrue(decode("thinking.delta", obj { put("chatId", "c"); put("promptId", "p"); put("text", "t"); put("offset", 0) }) is LinkEvent.ThinkingDelta)
        assertTrue(decode("tool.call", obj { put("chatId", "c"); put("promptId", "p"); put("callId", "t1"); put("name", "n"); put("title", "T") }) is LinkEvent.ToolCall)
        assertTrue(decode("tool.result", obj { put("chatId", "c"); put("promptId", "p"); put("callId", "t1"); put("ok", true); put("title", "T") }) is LinkEvent.ToolResult)
        assertTrue(decode("status", obj { put("phase", "load"); put("state", "start"); put("text", "Loading") }) is LinkEvent.Status)
        assertTrue(decode("sources", obj { put("chatId", "c"); put("promptId", "p"); put("sources", arr()) }) is LinkEvent.Sources)
        assertTrue(decode("ask.request", obj { put("askId", "k"); put("summary", "s") }) is LinkEvent.AskRequest)
        assertTrue(decode("ask.resolved", obj { put("askId", "k"); put("by", "Tablet") }) is LinkEvent.AskResolved)
        assertTrue(decode("turn.cancelled", ids) is LinkEvent.TurnCancelled)
        assertTrue(decode("models.changed", JsonObject(emptyMap())) is LinkEvent.ModelsChanged)
        assertTrue(decode("chat.deleted", obj { put("chatId", "c") }) is LinkEvent.ChatDeleted)
        assertTrue(decode("download.deleted", obj { put("chatId", "c") }) is LinkEvent.DownloadDeleted)
        assertTrue(decode("bye", obj { put("reason", "shutdown") }) is LinkEvent.Bye)
        val chat = obj { put("chat", obj { put("chatId", "c"); put("title", "T") }) }
        assertTrue(decode("chat.created", chat) is LinkEvent.ChatCreated)
        assertTrue(decode("chat.updated", chat) is LinkEvent.ChatUpdated)
        assertTrue(decode("download.chat", chat) is LinkEvent.DownloadChat)
        assertTrue(decode("download.turn", obj { put("chatId", "c"); put("turn", obj { put("promptId", "p") }) }) is LinkEvent.DownloadTurn)
        assertTrue(decode("toolcall.delta", obj { put("chatId", "c"); put("promptId", "p"); put("step", 1); put("index", 0); put("text", "{"); put("offset", 0) }) is LinkEvent.ToolCallDelta)
        assertTrue(decode("model.state", obj { put("modelId", "m"); put("state", "loading") }) is LinkEvent.ModelState)
        assertTrue(decode("routes.changed", obj { put("wifi", obj { put("port", 7810) }) }) is LinkEvent.RoutesChanged)
        assertTrue(decode("profiles.changed", obj { put("modelId", "m"); put("activeId", "fast"); put("change", "applied") }) is LinkEvent.ProfilesChanged)
    }

    @Test
    fun `connection settings survive a JSON round trip`() {
        val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }
        val settings = ConnectionSettings(workInBackground = true, keepListsSeconds = 300)
        val decoded = json.decodeFromString(ConnectionSettings.serializer(), json.encodeToString(ConnectionSettings.serializer(), settings))
        assertEquals(settings, decoded)
        // A v2 settings file with routes still loads.
        val old = json.decodeFromString(ConnectionSettings.serializer(), """{"routes":[{"type":"last"}],"workInBackground":true}""")
        assertTrue(old.workInBackground)
        assertEquals(120, ConnectionSettings().keepListsSeconds)
        assertFalse(ConnectionSettings().workInBackground)
    }
}
