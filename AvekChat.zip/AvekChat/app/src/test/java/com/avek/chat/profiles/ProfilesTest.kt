package com.avek.chat.profiles

import com.avek.chat.core.link.HarnessApi
import com.avek.chat.core.link.route.ConnectionState
import com.avek.chat.core.link.route.RouteInfoSync
import com.avek.chat.core.link.route.RouteKind
import com.avek.chat.core.link.rpc.RpcException
import com.avek.chat.core.link.store.PairedPc
import com.avek.chat.core.link.wire.HardwareData
import com.avek.chat.core.link.wire.HardwareGpuDto
import com.avek.chat.core.link.wire.LinkEvent
import com.avek.chat.core.link.wire.ModelStateDto
import com.avek.chat.core.link.wire.ProfilesChangedDto
import com.avek.chat.core.link.wire.RoutesData
import com.avek.chat.core.link.wire.TailscaleRouteDto
import com.avek.chat.core.link.wire.WireJson
import com.avek.chat.domain.FakeLink
import com.avek.chat.feature.chat.profiles.LayerPlan
import com.avek.chat.feature.chat.profiles.Layers
import com.avek.chat.feature.chat.profiles.LoadProfilesViewModel
import com.avek.chat.feature.chat.profiles.ProfileMemory
import com.avek.chat.feature.chat.profiles.ProfilesPhase
import com.avek.chat.feature.chat.profiles.hardwareSummary
import com.avek.chat.link.InMemoryPairedPcStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.TestScope
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class LayerPlanTest {

    @Test
    fun `of clamps and gives the rest to the CPU`() {
        assertEquals(Layers(38, 27, 0), LayerPlan.of(65, 38, 27))
        assertEquals(Layers(65, 0, 0), LayerPlan.of(65, 99, 10))
        assertEquals(Layers(0, 0, 65), LayerPlan.of(65, -3, -1))
        assertEquals(Layers(40, 25, 0), LayerPlan.of(65, 40, 40))
        assertEquals(65, LayerPlan.of(65, 12, 7).total)
    }

    @Test
    fun `RTX up takes from the CPU first and then pushes the iGPU down, never negative`() {
        val start = Layers(20, 20, 25)
        assertEquals(Layers(45, 20, 0), LayerPlan.withRtx(start, 65, 45))
        assertEquals(Layers(55, 10, 0), LayerPlan.withRtx(start, 65, 55))
        assertEquals(Layers(65, 0, 0), LayerPlan.withRtx(start, 65, 80))
        assertEquals(Layers(0, 20, 45), LayerPlan.withRtx(start, 65, -5))
    }

    @Test
    fun `iGPU up takes from the CPU first and then pushes the RTX down`() {
        val start = Layers(30, 10, 25)
        assertEquals(Layers(30, 35, 0), LayerPlan.withIgpu(start, 65, 35))
        assertEquals(Layers(20, 45, 0), LayerPlan.withIgpu(start, 65, 45))
    }

    @Test
    fun `presets follow the hardware`() {
        val all = LayerPlan.presets(65, hasRtx = true, hasIgpu = true)
        assertEquals(listOf("All on RTX", "RTX + iGPU", "RTX + CPU", "All on CPU"), all.map { it.name })
        assertEquals(Layers(65, 0, 0), all[0].layers)
        assertEquals(Layers(39, 26, 0), all[1].layers)
        assertEquals(Layers(39, 0, 26), all[2].layers)
        assertEquals(Layers(0, 0, 65), all[3].layers)
        assertEquals(listOf("All on RTX", "RTX + CPU", "All on CPU"), LayerPlan.presets(65, hasRtx = true, hasIgpu = false).map { it.name })
        assertEquals(listOf("All on CPU"), LayerPlan.presets(65, hasRtx = false, hasIgpu = true).map { it.name })
    }

    @Test
    fun `summary, description and context`() {
        assertEquals("RTX 38 · iGPU 27 · CPU 0 layers · 75K context", LayerPlan.summary(Layers(38, 27, 0), 75_000))
        assertEquals("RTX 38 layers, iGPU 27, CPU 0", LayerPlan.description(Layers(38, 27, 0)))
        assertEquals("32K", LayerPlan.contextK(32_768))
        assertEquals(32_768, LayerPlan.snapContext(32_900, 4096, 524_288))
        assertEquals(4096, LayerPlan.snapContext(10, 4096, 524_288))
        assertEquals(524_288, LayerPlan.snapContext(9_000_000, 4096, 524_288))
    }

    @Test
    fun `hardware summary hides an absent processor`() {
        val hw = HardwareData(rtx = HardwareGpuDto("0", "RTX 5060", 8192, 7066), igpu = HardwareGpuDto("1", "Radeon 780M"), cpu = com.avek.chat.core.link.wire.CpuDto(16, 16384, 7168))
        assertEquals("RTX 5060 · 6.9 GB free  |  Radeon 780M (uses system memory)  |  RAM 7.0 GB free", hardwareSummary(hw))
        assertEquals("RAM 7.0 GB free", hardwareSummary(hw.copy(rtx = null, igpu = null)))
    }
}

class RouteInfoSyncTest {
    @Test
    fun `routes-get is stored and routes-changed applied`() = kotlinx.coroutines.runBlocking {
        val store = InMemoryPairedPcStore(PairedPc("d", "a", "s", "PC", ByteArray(65), "T", ByteArray(92)))
        val sync = RouteInfoSync(store)
        sync.refresh { RoutesData(tailscale = TailscaleRouteDto(host = "100.64.1.2")) }
        assertEquals("100.64.1.2", store.pc.value!!.routes!!.tailscale!!.host)
        sync.apply(RoutesData())
        assertNull(store.pc.value!!.routes!!.tailscale)
    }
}

@OptIn(ExperimentalCoroutinesApi::class)
class LoadProfilesViewModelTest {

    @Before fun setMain() = Dispatchers.setMain(StandardTestDispatcher())

    @After fun resetMain() = Dispatchers.resetMain()

    private val profilesJson = """
        {"modelId":"qwen3.8-27b","layersTotal":65,"activeId":"fast",
         "hardware":{"rtx":{"id":"0","name":"RTX 5060","totalMb":8192,"freeMb":6900},"igpu":{"id":"1","name":"Radeon 780M","totalMb":0,"freeMb":0},"cpu":{"threads":16,"ramTotalMb":16384,"ramFreeMb":7000}},
         "limits":{"minContext":4096,"maxContext":524288,"maxSlots":8,"cacheTypes":["f16","q8_0","q4_0"]},
         "profiles":[
          {"id":"fast","modelId":"qwen3.8-27b","name":"Fast","builtin":true,"layers":{"rtx":38,"igpu":27,"cpu":0},"contextTokens":75000,"slots":2,"cacheType":"q4_0","active":true,
           "measured":{"decodeTps":12.4},"estimate":{"verdict":"fits","notes":["RTX: about 6.7 GB needed, 6.9 GB free."]},"problems":[]},
          {"id":"big","modelId":"qwen3.8-27b","name":"Huge","builtin":true,"layers":{"rtx":65,"igpu":0,"cpu":0},"contextTokens":262144,"slots":1,"cacheType":"f16",
           "estimate":{"verdict":"too-big","notes":["Too big"]},"problems":[]},
          {"id":"npu","modelId":"qwen3.8-27b","name":"Needs NPU","builtin":true,"layers":{"rtx":0,"igpu":0,"cpu":65},"contextTokens":4096,"slots":1,
           "estimate":{"verdict":"unknown","notes":[]},"problems":["This PC has no such processor."]}
         ]}
    """.trimIndent()

    private inner class Rig(val scope: TestScope) {
        val link = FakeLink()
        val memory = ProfileMemory({ scope.testScheduler.currentTime }, 120_000)
        var applyError: RpcException? = null
        var reloading = true
        var saveError: RpcException? = null
        val vm = LoadProfilesViewModel(HarnessApi(link), link, memory)
        val state get() = vm.state.value

        init {
            link.handler = { op, args -> handle(op, args) }
        }

        private fun handle(op: String, args: JsonObject): JsonElement = when (op) {
            "profiles.list" -> WireJson.parseToJsonElement(profilesJson)
            "hardware.get" -> WireJson.parseToJsonElement(profilesJson).jsonObject.getValue("hardware")
            "profile.apply" -> {
                applyError?.let { throw it }
                WireJson.parseToJsonElement("""{"modelId":"qwen3.8-27b","activeId":"${args.getValue("id").jsonPrimitive.content}","reloading":$reloading}""")
            }
            "profile.save" -> {
                saveError?.let { throw it }
                val name = args.getValue("name").jsonPrimitive.content
                WireJson.parseToJsonElement(
                    """{"profile":{"id":"own1","modelId":"qwen3.8-27b","name":"$name","builtin":false,"layers":${args.getValue("layers")},"contextTokens":${args.getValue("contextTokens")},"slots":2,"cacheType":"q4_0",
                       "estimate":{"verdict":"tight","notes":["System memory is tight."]},"problems":[]}}""",
                )
            }
            "profile.delete" -> JsonObject(emptyMap())
            else -> error("unexpected $op")
        }
    }

    @Test
    fun `nothing is fetched until the sheet opens, then the list and the hardware arrive`() = runTest {
        val r = Rig(this)
        runCurrent()
        assertTrue(r.link.calls.isEmpty())
        r.vm.open("qwen3.8-27b", "Qwen 27B")
        runCurrent()
        assertEquals(ProfilesPhase.Ready, r.state.phase)
        assertEquals(3, r.state.data!!.profiles.size)
        assertEquals("RTX 5060", r.state.hardware!!.rtx!!.name)
        assertEquals(setOf("profiles.list", "hardware.get"), r.link.calls.map { it.first }.toSet())
        assertEquals("Fast", r.memory.summary("qwen3.8-27b")!!.name)
        assertEquals("RTX 38 · iGPU 27 · CPU 0 layers · 75K context", r.memory.summary("qwen3.8-27b")!!.line)
    }

    @Test
    fun `use applies and shows Reloading until model-state says ready`() = runTest {
        val r = Rig(this)
        r.vm.open("qwen3.8-27b", "Qwen 27B"); runCurrent()
        val fast = r.state.data!!.profiles.first()
        r.vm.use(fast); runCurrent()
        val phase = r.state.phase as ProfilesPhase.Applying
        assertEquals("Reloading Qwen 27B with Fast...", phase.text)
        r.link.emit(LinkEvent.ModelState(1, ModelStateDto("qwen3.8-27b", "loading", reason = "profile"))); runCurrent()
        assertTrue(r.state.phase is ProfilesPhase.Applying)
        r.link.emit(LinkEvent.ModelState(2, ModelStateDto("qwen3.8-27b", "ready", reason = "profile"))); runCurrent()
        assertEquals(ProfilesPhase.Ready, r.state.phase)
    }

    @Test
    fun `busy shows the spec's sentence`() = runTest {
        val r = Rig(this)
        r.vm.open("qwen3.8-27b", "Qwen 27B"); runCurrent()
        r.applyError = RpcException("busy", "busy")
        r.vm.use(r.state.data!!.profiles.first()); runCurrent()
        assertEquals("The model is answering. Try again when it has finished.", r.state.message)
        assertEquals(ProfilesPhase.Ready, r.state.phase)
    }

    @Test
    fun `too big asks first, problems disable use`() = runTest {
        val r = Rig(this)
        r.vm.open("qwen3.8-27b", "Qwen 27B"); runCurrent()
        val (_, big, npu) = r.state.data!!.profiles
        r.vm.use(big); runCurrent()
        assertEquals("big", r.state.confirmTooBig)
        assertTrue(r.link.opsCalled("profile.apply").isEmpty())
        r.vm.use(big, force = true); runCurrent()
        assertEquals(1, r.link.opsCalled("profile.apply").size)
        r.reloading = false
        r.vm.use(npu); runCurrent()
        assertEquals("a profile with problems is never applied", 1, r.link.opsCalled("profile.apply").size)
    }

    @Test
    fun `save sends the draft and shows the PC's estimate at once`() = runTest {
        val r = Rig(this)
        r.vm.open("qwen3.8-27b", "Qwen 27B"); runCurrent()
        r.vm.copy(r.state.data!!.profiles.first())
        val draft = (r.state.phase as ProfilesPhase.Editing).draft
        assertEquals("Copy of Fast", draft.name)
        assertNull("a copy has no id", draft.id)
        r.vm.setRtx(50)
        val moved = (r.state.phase as ProfilesPhase.Editing).draft.layers
        assertEquals(Layers(50, 15, 0), moved)
        r.vm.setName("")
        assertFalse((r.state.phase as ProfilesPhase.Editing).draft.canSave)
        r.vm.setName("Mine")
        r.vm.save(); runCurrent()
        assertEquals(ProfilesPhase.Ready, r.state.phase)
        val saved = r.state.data!!.profiles.last()
        assertEquals("Mine", saved.name)
        assertEquals("tight", saved.estimate!!.verdict)
        val sent = r.link.opsCalled("profile.save").single()
        assertFalse(sent.containsKey("id"))
        assertEquals("50", sent.getValue("layers").jsonObject.getValue("rtx").jsonPrimitive.content)
    }

    @Test
    fun `a save error stays in the editor`() = runTest {
        val r = Rig(this)
        r.vm.open("qwen3.8-27b", "Qwen 27B"); runCurrent()
        r.vm.newProfile()
        r.vm.setName("X")
        r.saveError = RpcException("conflict", "You already have 24 profiles of your own for this model.")
        r.vm.save(); runCurrent()
        val draft = (r.state.phase as ProfilesPhase.Editing).draft
        assertEquals("You already have 24 profiles of your own for this model.", draft.error)
        assertFalse(draft.saving)
    }

    @Test
    fun `delete removes an own profile`() = runTest {
        val r = Rig(this)
        r.vm.open("qwen3.8-27b", "Qwen 27B"); runCurrent()
        r.vm.newProfile(); r.vm.setName("Mine"); r.vm.save(); runCurrent()
        val own = r.state.data!!.profiles.last()
        r.vm.delete(own); runCurrent()
        assertEquals(1, r.link.opsCalled("profile.delete").size)
    }

    @Test
    fun `profiles-changed from another device refetches`() = runTest {
        val r = Rig(this)
        r.vm.open("qwen3.8-27b", "Qwen 27B"); runCurrent()
        val before = r.link.opsCalled("profiles.list").size
        r.link.emit(LinkEvent.ProfilesChanged(5, ProfilesChangedDto("qwen3.8-27b", "big", "applied"))); runCurrent()
        assertEquals(before + 1, r.link.opsCalled("profiles.list").size)
        r.link.emit(LinkEvent.ProfilesChanged(6, ProfilesChangedDto("other-model", "x", "applied"))); runCurrent()
        assertEquals(before + 1, r.link.opsCalled("profiles.list").size)
    }

    @Test
    fun `a dropped connection keeps the last list and says Not connected`() = runTest {
        val r = Rig(this)
        r.vm.open("qwen3.8-27b", "Qwen 27B"); runCurrent()
        r.link.connectionState.value = ConnectionState.Unreachable("PC", 0L)
        runCurrent()
        assertFalse(r.state.connected)
        assertEquals(3, r.state.data!!.profiles.size)
        r.link.connectionState.value = ConnectionState.Connected("PC", RouteKind.WIFI, "x")
        runCurrent()
        assertTrue(r.state.connected)
    }

    @Test
    fun `the remembered summary expires after 120 s and follows applied changes`() = runTest {
        val r = Rig(this)
        r.vm.open("qwen3.8-27b", "Qwen 27B"); runCurrent()
        r.memory.onChanged(ProfilesChangedDto("qwen3.8-27b", "big", "applied"))
        assertEquals("Huge", r.memory.summary("qwen3.8-27b")!!.name)
        testScheduler.advanceTimeBy(121_000)
        assertNull(r.memory.summary("qwen3.8-27b"))
    }
}
