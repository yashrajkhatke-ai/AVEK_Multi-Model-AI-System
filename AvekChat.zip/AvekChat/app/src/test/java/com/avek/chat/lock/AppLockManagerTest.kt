package com.avek.chat.lock

import com.avek.chat.core.data.lock.FileLockStore
import com.avek.chat.core.domain.lock.AppLockManager
import com.avek.chat.core.domain.lock.LockClock
import com.avek.chat.core.domain.lock.LockCounter
import com.avek.chat.core.domain.lock.LockState
import com.avek.chat.core.domain.lock.LockStore
import com.avek.chat.core.domain.lock.PasswordCheck
import com.avek.chat.core.domain.lock.PasswordRecord
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.TestScope
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder

class FakeLockClock(var elapsed: Long = 1_000, var boot: Int = 1) : LockClock {
    override fun elapsedRealtime() = elapsed
    override fun bootCount() = boot
}

class MemoryLockStore : LockStore {
    var password: PasswordRecord? = null
    var counter: LockCounter? = null
    var counterBroken = false
    var passwordBroken = false
    override fun readPassword(): PasswordRecord? = if (passwordBroken) throw IllegalStateException("damaged") else password
    override fun writePassword(record: PasswordRecord) { password = record }
    override fun readCounter(): LockCounter? = if (counterBroken) throw IllegalStateException("damaged") else counter
    override fun writeCounter(counter: LockCounter) { counterBroken = false; this.counter = counter }
    override fun clear() { password = null; counter = null }
}

@OptIn(ExperimentalCoroutinesApi::class)
class AppLockManagerTest {

    @get:Rule
    val temp = TemporaryFolder()

    private val logs = mutableListOf<String>()

    private fun TestScope.manager(store: LockStore = MemoryLockStore(), clock: FakeLockClock = FakeLockClock(), iterations: Int = 1_000) =
        AppLockManager(store, clock, iterations = iterations, compute = StandardTestDispatcher(testScheduler), log = { logs += it })

    private fun pw(text: String) = text.toCharArray()

    @Test
    fun `password rules - at least 8 characters, entered twice the same`() = runTest {
        val lock = manager()
        assertEquals(LockState.NoPassword, lock.state.value)
        assertEquals("The password needs at least 8 characters.", lock.createPassword(pw("short"), pw("short")))
        assertEquals("The two passwords are not the same.", lock.createPassword(pw("long enough"), pw("long enougH")))
        assertEquals(LockState.NoPassword, lock.state.value)
        assertNull(lock.createPassword(pw("long enough"), pw("long enough")))
        assertEquals(LockState.Unlocked, lock.state.value)
    }

    @Test
    fun `the hash is PBKDF2-HMAC-SHA256 with a 16-byte salt and 32-byte result, never the password`() = runTest {
        val store = MemoryLockStore()
        val lock = manager(store)
        val first = pw("correct horse")
        val second = pw("correct horse")
        lock.createPassword(first, second)
        assertTrue("the arrays are wiped", first.all { it == '\u0000' } && second.all { it == '\u0000' })
        val record = store.password!!
        assertEquals(16, record.salt.size)
        assertEquals(32, record.hash.size)
        assertEquals(1_000, record.iterations)
        assertArrayEquals(AppLockManager.pbkdf2(pw("correct horse"), record.salt, 1_000), record.hash)
        assertFalse(String(record.hash, Charsets.ISO_8859_1).contains("correct"))
        assertEquals("PasswordRecord(***)", record.toString())
    }

    @Test
    fun `the production setting is 600,000 iterations`() {
        assertEquals(600_000, AppLockManager.ITERATIONS)
    }

    @Test
    fun `unlocking needs the phone check and then the right password`() = runTest {
        val store = MemoryLockStore()
        manager(store).createPassword(pw("correct horse"), pw("correct horse"))
        val lock = manager(store)
        assertEquals(LockState.Locked(biometricPassed = false), lock.state.value)
        lock.onBiometricPassed()
        assertEquals(LockState.Locked(biometricPassed = true), lock.state.value)
        assertEquals(PasswordCheck.Wrong(9), lock.checkPassword(pw("wrong horse")))
        assertEquals(PasswordCheck.Correct, lock.checkPassword(pw("correct horse")))
        assertEquals(LockState.Unlocked, lock.state.value)
        assertEquals(0, store.counter!!.failures)
    }

    @Test
    fun `ten wrong in a row lock for 10 minutes, doubling at the next lockout`() = runTest {
        val store = MemoryLockStore()
        val clock = FakeLockClock()
        manager(store, clock).createPassword(pw("correct horse"), pw("correct horse"))
        val lock = manager(store, clock)
        lock.onBiometricPassed()
        repeat(9) { assertTrue(lock.checkPassword(pw("nope nope")) is PasswordCheck.Wrong) }
        assertEquals(PasswordCheck.LockedOut(600_000), lock.checkPassword(pw("nope nope")))
        // Even the right password is refused while locked out.
        assertTrue(lock.checkPassword(pw("correct horse")) is PasswordCheck.LockedOut)
        clock.elapsed += 599_000
        assertEquals(1_000L, lock.lockoutRemainingMs())
        clock.elapsed += 1_000
        assertEquals(0L, lock.lockoutRemainingMs())

        repeat(9) { lock.checkPassword(pw("nope nope")) }
        assertEquals("doubled", PasswordCheck.LockedOut(1_200_000), lock.checkPassword(pw("nope nope")))
        clock.elapsed += 1_200_000
        assertEquals(PasswordCheck.Correct, lock.checkPassword(pw("correct horse")))
    }

    @Test
    fun `a reboot cannot shorten a lockout`() = runTest {
        val store = MemoryLockStore()
        val clock = FakeLockClock(elapsed = 5_000_000)
        manager(store, clock).createPassword(pw("correct horse"), pw("correct horse"))
        val lock = manager(store, clock)
        repeat(10) { lock.checkPassword(pw("nope nope")) }
        clock.elapsed += 300_000
        // Reboot: the elapsed clock starts again from a small number, the boot count goes up.
        clock.boot = 2
        clock.elapsed = 10_000
        val after = manager(store, clock)
        assertEquals("the lockout starts again in full", 600_000L, after.lockoutRemainingMs())
    }

    @Test
    fun `an unreadable counter counts as locked for 10 minutes, never as a reset`() = runTest {
        val store = MemoryLockStore()
        val clock = FakeLockClock()
        manager(store, clock).createPassword(pw("correct horse"), pw("correct horse"))
        store.counterBroken = true
        val lock = manager(store, clock)
        lock.onBiometricPassed()
        assertTrue(lock.checkPassword(pw("correct horse")) is PasswordCheck.LockedOut)
        assertEquals(600_000L, lock.lockoutRemainingMs())
    }

    @Test
    fun `an unreadable password record is Broken and only starting over helps`() = runTest {
        val store = MemoryLockStore().apply { passwordBroken = true }
        val lock = manager(store)
        assertEquals(LockState.Broken, lock.state.value)
        store.passwordBroken = false
        lock.reset()
        assertEquals(LockState.NoPassword, lock.state.value)
        assertNull(store.password)
    }

    @Test
    fun `the grace period - none locks on every return, 5 minutes lets a quick return through`() = runTest {
        val store = MemoryLockStore()
        val clock = FakeLockClock()
        val lock = manager(store, clock)
        lock.createPassword(pw("correct horse"), pw("correct horse"))
        lock.onBackground(); clock.elapsed += 1_000; lock.onForeground(graceMinutes = 0)
        assertEquals(LockState.Locked(false), lock.state.value)

        lock.onBiometricPassed(); lock.checkPassword(pw("correct horse"))
        lock.onBackground(); clock.elapsed += 4 * 60_000; lock.onForeground(graceMinutes = 5)
        assertEquals(LockState.Unlocked, lock.state.value)
        lock.onBackground(); clock.elapsed += 5 * 60_000; lock.onForeground(graceMinutes = 5)
        assertEquals(LockState.Locked(false), lock.state.value)
    }

    @Test
    fun `changing the password asks for the old one first`() = runTest {
        val lock = manager()
        lock.createPassword(pw("correct horse"), pw("correct horse"))
        assertEquals("The current password is not right.", lock.changePassword(pw("wrong horse"), pw("new password"), pw("new password")))
        assertNull(lock.changePassword(pw("correct horse"), pw("new password"), pw("new password")))
        lock.onBackground(); lock.onForeground(0); lock.onBiometricPassed()
        assertEquals(PasswordCheck.Correct, lock.checkPassword(pw("new password")))
    }

    @Test
    fun `no secret ever reaches the log`() = runTest {
        val lock = manager()
        lock.createPassword(pw("correct horse"), pw("correct horse"))
        lock.onBackground(); lock.onForeground(0); lock.onBiometricPassed()
        lock.checkPassword(pw("wrong horse"))
        lock.checkPassword(pw("correct horse"))
        assertTrue(logs.isNotEmpty())
        assertTrue(logs.none { "horse" in it })
    }

    @Test
    fun `the file store keeps the hash and the counter, and a damaged file reads as unreadable`() = runTest {
        val dir = temp.newFolder("lock")
        val store = FileLockStore(dir)
        val lock = manager(store)
        lock.createPassword(pw("correct horse"), pw("correct horse"))
        assertNotNull(FileLockStore(dir).readPassword())
        assertFalse(java.io.File(dir, "password.json").readText().contains("horse"))
        java.io.File(dir, "counter.json").writeText("{broken")
        val reopened = manager(FileLockStore(dir))
        reopened.onBiometricPassed()
        assertTrue(reopened.checkPassword(pw("correct horse")) is PasswordCheck.LockedOut)
    }
}
