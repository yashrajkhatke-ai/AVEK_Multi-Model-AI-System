package com.avek.chat.domain

import com.avek.chat.core.domain.repository.ConversationRepository
import com.avek.chat.core.model.Conversation
import com.avek.chat.core.model.Feedback
import com.avek.chat.core.model.Message
import com.avek.chat.core.model.MessageStatus
import com.avek.chat.core.model.TaskMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.map

/** In-memory [ConversationRepository] for fast, deterministic tests. */
class FakeConversationRepository : ConversationRepository {
    val conversations = MutableStateFlow<Map<String, Conversation>>(emptyMap())
    val messages = MutableStateFlow<Map<String, Message>>(emptyMap())
    private var nextId = 0

    private fun sorted(id: String) = messages.value.values.filter { it.conversationId == id }.sortedBy { it.createdAt }

    override fun observeConversations(): Flow<List<Conversation>> = conversations.map { it.values.filter { c -> !c.isArchived } }
    override fun observeArchived(): Flow<List<Conversation>> = conversations.map { it.values.filter { c -> c.isArchived } }
    override fun search(query: String): Flow<List<Conversation>> = conversations.map { it.values.filter { c -> c.title.contains(query, true) } }
    override fun observeConversation(id: String): Flow<Conversation?> = conversations.map { it[id] }
    override fun observeMessages(conversationId: String): Flow<List<Message>> = messages.map { sorted(conversationId) }
    override suspend fun getConversation(id: String) = conversations.value[id]
    override suspend fun getMessages(conversationId: String) = sorted(conversationId)

    override suspend fun createConversation(title: String, modelId: String, taskMode: TaskMode): Conversation {
        val c = Conversation("c${nextId++}", title, 0, 0, false, false, modelId, taskMode, "", 0)
        conversations.value += c.id to c
        return c
    }

    override suspend fun upsertMessage(message: Message) {
        messages.value += message.id to message
    }

    override suspend fun deleteMessagesFrom(conversationId: String, fromCreatedAt: Long) {
        messages.value = messages.value.filterValues { it.conversationId != conversationId || it.createdAt < fromCreatedAt }
    }

    override suspend fun setFeedback(messageId: String, feedback: Feedback) {
        messages.value[messageId]?.let { messages.value += messageId to it.copy(feedback = feedback) }
    }

    override suspend fun refreshSummary(conversationId: String, modelId: String, taskMode: TaskMode) {
        conversations.value[conversationId]?.let {
            conversations.value += conversationId to it.copy(messageCount = sorted(conversationId).size, preview = sorted(conversationId).last().content.take(40))
        }
    }

    override suspend fun rename(id: String, title: String) = update(id) { it.copy(title = title) }
    override suspend fun setStarred(id: String, starred: Boolean) = update(id) { it.copy(isStarred = starred) }
    override suspend fun setArchived(id: String, archived: Boolean) = update(id) { it.copy(isArchived = archived) }
    override suspend fun delete(id: String) {
        conversations.value -= id
        messages.value = messages.value.filterValues { it.conversationId != id }
    }
    override suspend fun deleteAll() {
        conversations.value = emptyMap()
        messages.value = emptyMap()
    }
    override suspend fun recoverInterruptedReplies() {
        messages.value = messages.value.mapValues { (_, m) -> if (m.status == MessageStatus.STREAMING) m.copy(status = MessageStatus.STOPPED) else m }
    }
    override suspend fun insertAll(conversations: List<Conversation>, messages: List<Message>) {
        this.conversations.value += conversations.associateBy { it.id }
        this.messages.value += messages.associateBy { it.id }
    }

    private fun update(id: String, transform: (Conversation) -> Conversation) {
        conversations.value[id]?.let { conversations.value += id to transform(it) }
    }
}
