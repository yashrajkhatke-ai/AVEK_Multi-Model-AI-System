package com.avek.chat.domain

import com.avek.chat.core.common.TimeProvider
import com.avek.chat.core.domain.usecase.HistoryGrouper
import com.avek.chat.core.model.Conversation
import com.avek.chat.core.model.TaskMode
import org.junit.Assert.assertEquals
import org.junit.Test
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.ZoneOffset

class HistoryGrouperTest {

    private val zone = ZoneOffset.UTC
    private val now = LocalDateTime.of(2026, 6, 15, 12, 0).toInstant(zone).toEpochMilli()
    private val grouper = HistoryGrouper(
        object : TimeProvider {
            override fun now() = now
            override fun zone(): ZoneId = zone
        },
    )

    private fun conversation(id: String, daysAgo: Long, starred: Boolean = false) = Conversation(
        id = id,
        title = id,
        createdAt = now - daysAgo * DAY,
        updatedAt = now - daysAgo * DAY,
        isStarred = starred,
        isArchived = false,
        modelId = "m",
        taskMode = TaskMode.GENERAL,
        preview = "",
        messageCount = 2,
    )

    @Test
    fun `buckets by relative date with starred pinned first`() {
        val sections = grouper.group(
            listOf(
                conversation("today", 0),
                conversation("yesterday", 1),
                conversation("week", 4),
                conversation("month", 20),
                conversation("older", 90),
                conversation("star", 200, starred = true),
            ),
        )
        assertEquals(
            listOf("Starred", "Today", "Yesterday", "Previous 7 days", "Previous 30 days"),
            sections.take(5).map { it.label },
        )
        assertEquals(listOf("star"), sections.first().conversations.map { it.id })
        assertEquals(6, sections.size)
    }

    @Test
    fun `starred stays in its date bucket when not pinned`() {
        val sections = grouper.group(listOf(conversation("star", 0, starred = true)), pinStarred = false)
        assertEquals(listOf("Today"), sections.map { it.label })
    }

    private companion object {
        const val DAY = 86_400_000L
    }
}
