package com.avek.chat.link

import com.avek.chat.core.link.crypto.FrameOpener
import com.avek.chat.core.link.crypto.FrameSealer
import com.avek.chat.core.link.crypto.HandshakeMath
import com.avek.chat.core.link.crypto.KeySource
import com.avek.chat.core.link.crypto.SecureCrypto
import com.avek.chat.core.link.crypto.SystemKeySource
import com.avek.chat.core.link.transport.HostPort
import com.avek.chat.core.link.transport.RawChannel
import com.avek.chat.core.link.transport.RawMessage
import com.avek.chat.core.link.wire.WireJson
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.channels.ReceiveChannel
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put

/** Two connected in-memory channels (client side, server side). Closing one ends both, like a WebSocket. */
class InMemoryChannel(
    override val remote: HostPort,
    private val inbox: Channel<RawMessage>,
    private val peerInbox: Channel<RawMessage>,
) : RawChannel {
    @Volatile
    var closedLocally = false
        private set
    val sentTexts = mutableListOf<String>()
    val sentBinaries = mutableListOf<ByteArray>()

    override val incoming: ReceiveChannel<RawMessage> get() = inbox

    override suspend fun sendText(text: String) {
        check(!closedLocally) { "channel closed" }
        sentTexts += text
        peerInbox.trySend(RawMessage.Text(text))
    }

    override suspend fun sendBinary(bytes: ByteArray) {
        check(!closedLocally) { "channel closed" }
        sentBinaries += bytes
        peerInbox.trySend(RawMessage.Binary(bytes))
    }

    override fun close(code: Int, reason: String) {
        if (closedLocally) return
        closedLocally = true
        peerInbox.trySend(RawMessage.Closed(code, reason))
        peerInbox.close()
        inbox.trySend(RawMessage.Closed(code, reason))
        inbox.close()
    }

    companion object {
        fun pair(host: String = "10.0.0.2", port: Int = 7810): Pair<InMemoryChannel, InMemoryChannel> {
            val toServer = Channel<RawMessage>(Channel.UNLIMITED)
            val toClient = Channel<RawMessage>(Channel.UNLIMITED)
            val client = InMemoryChannel(HostPort(host, port), toClient, toServer)
            val server = InMemoryChannel(HostPort(host, port), toServer, toClient)
            return client to server
        }
    }
}

/** What a request handler of [FakeHarnessServer] answers. */
sealed interface Reply {
    data class Ok(val data: JsonObject = JsonObject(emptyMap())) : Reply
    data class Parts(val parts: List<JsonObject>) : Reply
    data class Err(val code: String, val message: String = "") : Reply
    /** Never answer (to test timeouts). */
    data object Silence : Reply
}

/** One live secure connection, from the server's side. */
class FakeServerConnection(
    private val channel: InMemoryChannel,
    private val sealer: FrameSealer,
    val opener: FrameOpener,
    val deviceId: String,
) {
    val requests = mutableListOf<Pair<String, JsonObject>>()
    private var nextSeq = 1L

    suspend fun sendJson(obj: JsonObject) {
        channel.sendBinary(sealer.seal(WireJson.encodeToString(JsonObject.serializer(), obj).toByteArray()))
    }

    suspend fun sendEvent(ev: String, data: JsonObject, seq: Long? = nextSeq++) {
        sendJson(
            buildJsonObject {
                put("ev", ev)
                if (seq != null) put("seq", seq)
                put("data", data)
            },
        )
    }

    suspend fun sendRawText(text: String) = channel.sendText(text)

    fun close(code: Int = 1000, reason: String = "") = channel.close(code, reason)

    fun requestsFor(op: String): List<JsonObject> = requests.filter { it.first == op }.map { it.second }
}

/**
 * The server half of UI-WIRE, for tests: pairing, session handshake, `ready`, request handling and
 * pushed events, all over [InMemoryChannel]s. Misbehaviour switches let tests provoke failures.
 */
class FakeHarnessServer(
    private val scope: CoroutineScope,
    private val keys: KeySource = SystemKeySource(),
    val serverId: String = "s_test0001",
    val serverName: String = "Test PC",
    var epoch: String = "e_1",
) {
    val devices = mutableMapOf<String, ByteArray>()
    var pairingCode: String? = "ABCDEFGHJKLM"
    var corruptServerMac = false
    var corruptGrant = false
    var staySilentInHandshake = false
    var pairAttempts = 0
    var pendingAsks: List<JsonObject> = emptyList()
    val connections = mutableListOf<FakeServerConnection>()
    val handlers = mutableMapOf<String, suspend (JsonObject, FakeServerConnection) -> Reply>()
    var onProofReceived: (() -> Unit)? = null
    var sawSessionProof = false

    /** Close with 4401 right after the client's proof, as the PC does for a wrong or revoked secret. */
    var rejectProof = false

    /** How many session handshakes (`hello`) the server has seen. */
    var sessionHellos = 0

    private var deviceCounter = 0

    /** Handles one accepted connection from its first message. */
    suspend fun serve(channel: InMemoryChannel) {
        if (staySilentInHandshake) return
        val first = (channel.incoming.receive() as? RawMessage.Text)?.text ?: return channel.close(4400, "bad handshake")
        val hello = WireJson.parseToJsonElement(first).jsonObject
        when (hello.string("t")) {
            "pair.hello" -> servePairing(channel, hello)
            "hello" -> serveSession(channel, hello)
            else -> channel.close(4400, "bad handshake")
        }
    }

    // ------------------------------------------------------------------ pairing

    private suspend fun servePairing(channel: InMemoryChannel, hello: JsonObject) {
        val code = pairingCode
        if (code == null) {
            channel.sendText(json("t" to "pair.denied", "reason" to "no-code"))
            return channel.close(4401, "no code")
        }
        val clientEpk = SecureCrypto.unb64(hello.string("epk")!!)
        val clientNonce = SecureCrypto.unb64(hello.string("nonce")!!)
        val pair = keys.newKeyPair()
        val serverNonce = keys.randomBytes(16)
        channel.sendText(
            json(
                "t" to "pair.hello.ok", "epk" to SecureCrypto.b64(pair.publicRaw), "nonce" to SecureCrypto.b64(serverNonce),
                "serverId" to serverId, "serverName" to serverName,
            ),
        )
        val shared = SecureCrypto.ecdh(pair.privateKey, clientEpk)
        val derived = HandshakeMath.pair(shared, HandshakeMath.normalizeCode(code), clientEpk, pair.publicRaw, clientNonce, serverNonce)

        val proof = WireJson.parseToJsonElement((channel.incoming.receive() as RawMessage.Text).text).jsonObject
        pairAttempts++
        if (!SecureCrypto.constantTimeEquals(SecureCrypto.unb64(proof.string("mac")!!), derived.clientMac)) {
            channel.sendText(json("t" to "pair.denied", "reason" to "bad-code"))
            return channel.close(4401, "bad code")
        }
        val deviceId = "d_new${++deviceCounter}"
        val secret = keys.randomBytes(32)
        devices[deviceId] = secret
        val grant = """{"deviceId":"$deviceId","deviceSecret":"${SecureCrypto.b64(secret)}","serverId":"$serverId","serverName":"$serverName"}"""
        val iv = keys.randomBytes(12)
        val sealed = SecureCrypto.aesGcmSeal(derived.encKey, iv, derived.transcript, grant.toByteArray())
        val serverMac = if (corruptServerMac) derived.serverMac.copyOf().also { it[0] = (it[0] + 1).toByte() } else derived.serverMac
        val data = if (corruptGrant) sealed.copyOf().also { it[0] = (it[0] + 1).toByte() } else sealed
        channel.sendText(
            json("t" to "pair.done", "mac" to SecureCrypto.b64(serverMac), "iv" to SecureCrypto.b64(iv), "data" to SecureCrypto.b64(data)),
        )
        channel.close(4000, "paired")
    }

    // ------------------------------------------------------------------ session

    private suspend fun serveSession(channel: InMemoryChannel, hello: JsonObject) {
        sessionHellos++
        val deviceId = hello.string("deviceId")!!
        val secret = devices[deviceId]
        if (secret == null) {
            channel.sendText(json("t" to "hello.denied", "reason" to "unknown-device"))
            return channel.close(4401, "unknown device")
        }
        val clientEpk = SecureCrypto.unb64(hello.string("epk")!!)
        val clientNonce = SecureCrypto.unb64(hello.string("nonce")!!)
        val pair = keys.newKeyPair()
        val serverNonce = keys.randomBytes(16)
        val shared = SecureCrypto.ecdh(pair.privateKey, clientEpk)
        val derived = HandshakeMath.session(deviceId, secret, shared, clientEpk, pair.publicRaw, clientNonce, serverNonce)
        val serverMac = if (corruptServerMac) derived.serverMac.copyOf().also { it[0] = (it[0] + 1).toByte() } else derived.serverMac
        channel.sendText(
            json("t" to "hello.ok", "epk" to SecureCrypto.b64(pair.publicRaw), "nonce" to SecureCrypto.b64(serverNonce), "mac" to SecureCrypto.b64(serverMac)),
        )
        val proofMessage = channel.incoming.receive()
        if (proofMessage !is RawMessage.Text) return
        sawSessionProof = true
        onProofReceived?.invoke()
        val proof = WireJson.parseToJsonElement(proofMessage.text).jsonObject
        if (rejectProof || !SecureCrypto.constantTimeEquals(SecureCrypto.unb64(proof.string("mac")!!), derived.clientMac)) {
            return channel.close(4401, "wrong secret")
        }

        val connection = FakeServerConnection(channel, FrameSealer(derived.serverToClient), FrameOpener(derived.clientToServer), deviceId)
        connections += connection
        connection.sendEvent("ready", readyData(deviceId), seq = null)
        for (message in channel.incoming) {
            when (message) {
                is RawMessage.Binary -> {
                    val request = try {
                        WireJson.parseToJsonElement(connection.opener.open(message.bytes).toString(Charsets.UTF_8)).jsonObject
                    } catch (e: Exception) {
                        return channel.close(4400, "bad frame")
                    }
                    handle(connection, request)
                }
                is RawMessage.Text -> return channel.close(4400, "text in phase 2")
                is RawMessage.Closed -> return
            }
        }
    }

    private suspend fun handle(connection: FakeServerConnection, request: JsonObject) {
        val id = request.string("id") ?: return
        val op = request.string("op") ?: return
        val args = (request["args"] as? JsonObject) ?: JsonObject(emptyMap())
        connection.requests += op to args
        val reply = handlers[op]?.invoke(args, connection) ?: defaultReply(op, args)
        when (reply) {
            is Reply.Ok -> connection.sendJson(buildJsonObject { put("re", id); put("ok", true); put("data", reply.data) })
            is Reply.Parts -> reply.parts.forEachIndexed { index, part ->
                connection.sendJson(
                    buildJsonObject {
                        put("re", id); put("ok", true); put("data", part)
                        if (index < reply.parts.lastIndex) put("more", true)
                    },
                )
            }
            is Reply.Err -> connection.sendJson(
                buildJsonObject {
                    put("re", id); put("ok", false)
                    put("error", buildJsonObject { put("code", reply.code); put("message", reply.message) })
                },
            )
            Reply.Silence -> Unit
        }
    }

    private fun defaultReply(op: String, args: JsonObject): Reply = when (op) {
        "ping" -> Reply.Ok(buildJsonObject { put("t", "now") })
        "subscribe" -> Reply.Ok(buildJsonObject { put("topics", args["topics"] ?: JsonArray(emptyList())) })
        "resume" -> Reply.Ok(buildJsonObject { put("replayed", 0) })
        else -> Reply.Err("unknown-op", op)
    }

    private fun readyData(deviceId: String) = buildJsonObject {
        put("server", buildJsonObject { put("id", serverId); put("name", serverName); put("version", "test") })
        put("protocol", 2)
        put("now", "2026-10-02T12:00:00.000Z")
        put("epoch", epoch)
        put("limits", buildJsonObject {
            put("maxFrameBytes", 1048576); put("attachChunkBytes", 262144); put("maxAttachmentBytes", 52428800); put("maxListPart", 100)
        })
        put("resumeHoldSec", 150)
        put("device", buildJsonObject { put("id", deviceId); put("name", "Test device") })
        put("runningTurns", JsonArray(emptyList()))
        put("pendingAsks", JsonArray(pendingAsks))
    }

    private fun json(vararg pairs: Pair<String, String>): String =
        WireJson.encodeToString(JsonObject.serializer(), buildJsonObject { pairs.forEach { (k, v) -> put(k, v) } })

    private fun JsonObject.string(key: String): String? = (this[key] as? JsonPrimitive)?.contentOrNull

    /** Registers a paired device so session handshakes succeed. */
    fun addDevice(deviceId: String, secret: ByteArray) {
        devices[deviceId] = secret
    }
}
