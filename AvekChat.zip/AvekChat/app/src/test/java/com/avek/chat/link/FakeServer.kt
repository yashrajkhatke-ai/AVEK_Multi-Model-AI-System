package com.avek.chat.link

import com.avek.chat.core.link.crypto.FrameOpener
import com.avek.chat.core.link.crypto.Frames
import com.avek.chat.core.link.crypto.KdfParams
import com.avek.chat.core.link.crypto.FrameSealer
import com.avek.chat.core.link.crypto.AvekProtocol
import com.avek.chat.core.link.crypto.KeySource
import com.avek.chat.core.link.crypto.SecureCrypto
import com.avek.chat.core.link.crypto.SystemKeySource
import com.avek.chat.core.link.store.IdentityVault
import com.avek.chat.core.link.store.SoftwareIdentityVault
import com.avek.chat.core.link.transport.HostPort
import com.avek.chat.core.link.transport.RawChannel
import com.avek.chat.core.link.transport.RawMessage
import com.avek.chat.core.link.wire.WireJson
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.channels.ReceiveChannel
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put

/** Two connected in-memory channels (client side, server side). Closing one ends both, like a WebSocket. */
class InMemoryChannel(
    override val remote: HostPort,
    private val inbox: Channel<RawMessage>,
    private val peerInbox: Channel<RawMessage>,
) : RawChannel {
    @Volatile
    var closedLocally = false
        private set
    val sentTexts = mutableListOf<String>()
    val sentBinaries = mutableListOf<ByteArray>()

    override val incoming: ReceiveChannel<RawMessage> get() = inbox

    override suspend fun sendText(text: String) {
        check(!closedLocally) { "channel closed" }
        sentTexts += text
        peerInbox.trySend(RawMessage.Text(text))
    }

    override suspend fun sendBinary(bytes: ByteArray) {
        check(!closedLocally) { "channel closed" }
        sentBinaries += bytes
        peerInbox.trySend(RawMessage.Binary(bytes))
    }

    override fun close(code: Int, reason: String) {
        if (closedLocally) return
        closedLocally = true
        peerInbox.trySend(RawMessage.Closed(code, reason))
        peerInbox.close()
        inbox.trySend(RawMessage.Closed(code, reason))
        inbox.close()
    }

    companion object {
        fun pair(host: String = "10.0.0.2", port: Int = 7810): Pair<InMemoryChannel, InMemoryChannel> {
            val toServer = Channel<RawMessage>(Channel.UNLIMITED)
            val toClient = Channel<RawMessage>(Channel.UNLIMITED)
            val client = InMemoryChannel(HostPort(host, port), toClient, toServer)
            val server = InMemoryChannel(HostPort(host, port), toServer, toClient)
            return client to server
        }
    }
}

/** What a request handler of [FakeHarnessServer] answers. */
sealed interface Reply {
    data class Ok(val data: JsonObject = JsonObject(emptyMap())) : Reply
    data class Parts(val parts: List<JsonObject>) : Reply
    data class Err(val code: String, val message: String = "") : Reply
    /** Never answer (to test timeouts). */
    data object Silence : Reply
}

/** One live secure connection, from the server's side. */
class FakeServerConnection(
    private val channel: InMemoryChannel,
    private val sealer: FrameSealer,
    val opener: FrameOpener,
    val deviceId: String,
) {
    val requests = mutableListOf<Pair<String, JsonObject>>()
    private var nextSeq = 1L

    suspend fun sendJson(obj: JsonObject) {
        channel.sendBinary(sealer.seal(WireJson.encodeToString(JsonObject.serializer(), obj).toByteArray()))
    }

    suspend fun sendEvent(ev: String, data: JsonObject, seq: Long? = nextSeq++) {
        sendJson(
            buildJsonObject {
                put("ev", ev)
                if (seq != null) put("seq", seq)
                put("data", data)
            },
        )
    }

    suspend fun sendRawText(text: String) = channel.sendText(text)

    /** Sends the [back]-th last binary frame again, unchanged (a replay, or a reordering when back > 0). */
    suspend fun replayFrame(back: Int = 0) = channel.sendBinary(channel.sentBinaries[channel.sentBinaries.lastIndex - back])

    fun close(code: Int = 1000, reason: String = "") = channel.close(code, reason)

    fun requestsFor(op: String): List<JsonObject> = requests.filter { it.first == op }.map { it.second }
}

/** What the fake PC stores per paired device (UI-WIRE v4 section 3): the key, `dk`, `rk`, and a pending rotation. */
class FakeDevice(
    var pub: ByteArray,
    var dk: ByteArray,
    var rk: ByteArray,
    var nextPub: ByteArray? = null,
    var nextDk: ByteArray? = null,
    var nextRk: ByteArray? = null,
)

/**
 * The PC half of UI-WIRE v4, for tests: two-secret pairing (code key by scrypt, the box), the session
 * handshake with `dk` and `slot:"next"`, `waking`, `ready`, `device.rekey`, `routes.get`, request
 * handling and pushed events, all over [InMemoryChannel]s. Misbehaviour switches let tests provoke failures.
 */
class FakeHarnessServer(
    private val scope: CoroutineScope,
    private val keys: KeySource = SystemKeySource(),
    val identity: IdentityVault = SoftwareIdentityVault().also { it.create(ALIAS) },
    val serverName: String = "Test PC",
    var epoch: String = "e_1",
    /** The 12 digits the PC tool showed (the PC keeps only the scrypt of it). */
    var code: String = CODE,
    /** Tests use a small scrypt; the app is built with the same parameters ([TEST_KDF]). */
    val kdf: KdfParams = TEST_KDF,
) {
    val serverPub: ByteArray get() = identity.publicKey(ALIAS)
    val serverId: String get() = AvekProtocol.serverIdOf(serverPub)

    /** deviceId -> what the PC stores when a pairing succeeds. */
    val devices = mutableMapOf<String, FakeDevice>()
    var pairingWindowOpen = true
    var busy = false
    var corruptBoxSig = false
    var corruptBoxMac = false
    var wrongBoxServerId = false
    var wrongBoxDeviceId = false
    /** Sends kdf parameters weaker than the spec's (a fake PC trying to make the code cheap to guess). */
    var weakKdf = false
    var corruptSessionSig = false
    var corruptSessionMac = false
    /** Signs the session with a different key (another PC claiming to be ours). */
    var impostor: IdentityVault? = null
    var staySilentInHandshake = false
    var pairAttempts = 0
    var pendingAsks: List<JsonObject> = emptyList()
    var modelStates: List<JsonObject> = emptyList()
    /** Sends the event `waking` before `ready` (the heavy part was asleep). */
    var wakingBeforeReady = false
    /** What `routes.get` answers. */
    var routes: JsonObject = buildJsonObject {
        put("wifi", buildJsonObject {
            put("addresses", JsonArray(listOf(buildJsonObject { put("interface", "Wi-Fi"); put("address", "10.0.0.2") })))
            put("port", 7810); put("knockPort", 7811)
        })
        put("updatedAt", "2026-10-07T10:00:00.000Z")
    }
    val connections = mutableListOf<FakeServerConnection>()
    val handlers = mutableMapOf<String, suspend (JsonObject, FakeServerConnection) -> Reply>()
    var onProofReceived: (() -> Unit)? = null
    var sawSessionProof = false
    /** The `slot` of every session `hello`, in order (null when absent). */
    val helloSlots = mutableListOf<String?>()

    /** Close with 4401 right after the client's proof, as the PC does for a forgotten device. */
    var rejectProof = false

    /** How many session handshakes (`hello`) the server has seen. */
    var sessionHellos = 0

    /** Handles one accepted connection from its first message. */
    suspend fun serve(channel: InMemoryChannel) {
        if (staySilentInHandshake) return
        val first = (channel.incoming.receive() as? RawMessage.Text)?.text ?: return channel.close(4400, "bad handshake")
        val hello = WireJson.parseToJsonElement(first).jsonObject
        when (hello.string("t")) {
            "pair.hello" -> servePairing(channel, hello)
            "hello" -> serveSession(channel, hello)
            else -> channel.close(4400, "bad handshake")
        }
    }

    // ------------------------------------------------------------------ pairing (section 3)

    private suspend fun servePairing(channel: InMemoryChannel, hello: JsonObject) {
        if (busy) return channel.close(4409, "")
        if (!pairingWindowOpen) return channel.close(4401, "")
        if (hello.int("v") != AvekProtocol.VERSION) return channel.close(4400, "")
        pairAttempts++
        val devPub = SecureCrypto.unb64(hello.string("devPub")!!)
        val clientEpk = SecureCrypto.unb64(hello.string("epk")!!)
        val clientNonce = SecureCrypto.unb64(hello.string("nonce")!!)
        val eph = keys.newKeyPair()
        val serverNonce = keys.randomBytes(16)
        val salt = keys.randomBytes(16)
        val sentKdf = if (weakKdf) KdfParams(1024, 1, 1) else kdf
        channel.sendText(
            WireJson.encodeToString(
                JsonObject.serializer(),
                buildJsonObject {
                    put("t", "pair.hello.ok"); put("srvPub", SecureCrypto.b64(serverPub)); put("epk", SecureCrypto.b64(eph.publicRaw))
                    put("nonce", SecureCrypto.b64(serverNonce)); put("serverId", serverId); put("serverName", serverName)
                    put("salt", SecureCrypto.b64(salt))
                    put("kdf", buildJsonObject { put("N", sentKdf.n); put("r", sentKdf.r); put("p", sentKdf.p) })
                },
            ),
        )
        val proofMsg = channel.incoming.receive()
        if (proofMsg !is RawMessage.Text) return
        val proof = WireJson.parseToJsonElement(proofMsg.text).jsonObject
        if (proof.string("t") != "pair.proof") return channel.close(4400, "")
        val codeKey = AvekProtocol.scrypt(code.toByteArray(), salt, kdf.n, kdf.r, kdf.p)
        val shared = SecureCrypto.ecdh(eph.privateKey, clientEpk)
        val transcript = AvekProtocol.pairTranscript(serverPub, devPub, clientEpk, eph.publicRaw, clientNonce, serverNonce, salt)
        val sigOk = SecureCrypto.verify(devPub, AvekProtocol.pairClientMessage(transcript), SecureCrypto.unb64(proof.string("sig")!!))
        val macOk = SecureCrypto.constantTimeEquals(SecureCrypto.unb64(proof.string("mac")!!), AvekProtocol.pairClientMac(codeKey, transcript))
        if (!sigOk || !macOk || !pairingWindowOpen) {
            channel.sendText("""{"t":"pair.denied"}""")
            return channel.close(4401, "")
        }
        val deviceId = AvekProtocol.deviceIdOf(devPub)
        val dk = keys.randomBytes(32)
        val rk = keys.randomBytes(32)
        devices[deviceId] = FakeDevice(devPub, dk, rk)
        val sig = identity.sign(ALIAS, AvekProtocol.pairServerMessage(transcript)).let { if (corruptBoxSig) damage(it) else it }
        val mac = AvekProtocol.pairServerMac(codeKey, transcript).let { if (corruptBoxMac) damage(it) else it }
        val content = buildJsonObject {
            put("deviceId", if (wrongBoxDeviceId) "d_0000000000" else deviceId)
            put("serverId", if (wrongBoxServerId) "s_00000000" else serverId)
            put("dk", SecureCrypto.b64(dk)); put("rk", SecureCrypto.b64(rk))
            put("sig", SecureCrypto.b64(sig)); put("mac", SecureCrypto.b64(mac))
        }
        val boxKey = AvekProtocol.pairBoxKey(shared, codeKey, transcript)
        channel.sendBinary(Frames.seal(boxKey, 0, WireJson.encodeToString(JsonObject.serializer(), content).toByteArray()))
        channel.close(4000, "")
    }

    // ------------------------------------------------------------------ session (section 4)

    private suspend fun serveSession(channel: InMemoryChannel, hello: JsonObject) {
        sessionHellos++
        val slot = hello.string("slot")
        helloSlots += slot
        val deviceId = hello.string("deviceId")!!
        val device = devices[deviceId] ?: return channel.close(4401, "")
        val next = slot == "next"
        val devPub = (if (next) device.nextPub else device.pub) ?: return channel.close(4401, "")
        val dk = (if (next) device.nextDk else device.dk) ?: return channel.close(4401, "")
        val clientEpk = SecureCrypto.unb64(hello.string("epk")!!)
        val clientNonce = SecureCrypto.unb64(hello.string("nonce")!!)
        val pair = keys.newKeyPair()
        val serverNonce = keys.randomBytes(16)
        val shared = SecureCrypto.ecdh(pair.privateKey, clientEpk)
        val signer = impostor ?: identity
        val signerPub = signer.publicKey(ALIAS)
        val derived = AvekProtocol.sessionKeys(shared, signerPub, devPub, clientEpk, pair.publicRaw, clientNonce, serverNonce, dk)
        val sig = signer.sign(ALIAS, derived.serverMessage).let { if (corruptSessionSig) damage(it) else it }
        val mac = if (corruptSessionMac) damage(derived.serverMac) else derived.serverMac
        channel.sendText(
            json(
                "t" to "hello.ok", "epk" to SecureCrypto.b64(pair.publicRaw), "nonce" to SecureCrypto.b64(serverNonce),
                "sig" to SecureCrypto.b64(sig), "mac" to SecureCrypto.b64(mac),
            ),
        )
        val proofMessage = channel.incoming.receive()
        if (proofMessage !is RawMessage.Text) return
        sawSessionProof = true
        onProofReceived?.invoke()
        val proof = WireJson.parseToJsonElement(proofMessage.text).jsonObject
        val sigOk = SecureCrypto.verify(devPub, derived.clientMessage, SecureCrypto.unb64(proof.string("sig")!!))
        val macOk = SecureCrypto.constantTimeEquals(SecureCrypto.unb64(proof.string("mac")!!), derived.clientMac)
        if (rejectProof || !sigOk || !macOk) return channel.close(4401, "")
        if (next) {
            // Section 4.1 step 5: the new key and secrets replace the old ones.
            device.pub = device.nextPub!!
            device.dk = device.nextDk!!
            device.rk = device.nextRk!!
            device.nextPub = null; device.nextDk = null; device.nextRk = null
        }

        val connection = FakeServerConnection(channel, FrameSealer(derived.serverToClient), FrameOpener(derived.clientToServer), deviceId)
        connections += connection
        if (wakingBeforeReady) connection.sendEvent("waking", buildJsonObject { put("phase", "core"); put("since", "now") }, seq = null)
        connection.sendEvent("ready", readyData(deviceId), seq = null)
        for (message in channel.incoming) {
            when (message) {
                is RawMessage.Binary -> {
                    val request = try {
                        WireJson.parseToJsonElement(connection.opener.open(message.bytes).toString(Charsets.UTF_8)).jsonObject
                    } catch (e: Exception) {
                        return channel.close(4400, "bad frame")
                    }
                    handle(connection, request)
                }
                is RawMessage.Text -> return channel.close(4400, "text in phase 2")
                is RawMessage.Closed -> return
            }
        }
    }

    private suspend fun handle(connection: FakeServerConnection, request: JsonObject) {
        val id = request.string("id") ?: return
        val op = request.string("op") ?: return
        val args = (request["args"] as? JsonObject) ?: JsonObject(emptyMap())
        connection.requests += op to args
        val reply = handlers[op]?.invoke(args, connection) ?: defaultReply(op, args, connection)
        when (reply) {
            is Reply.Ok -> connection.sendJson(buildJsonObject { put("re", id); put("ok", true); put("data", reply.data) })
            is Reply.Parts -> reply.parts.forEachIndexed { index, part ->
                connection.sendJson(
                    buildJsonObject {
                        put("re", id); put("ok", true); put("data", part)
                        if (index < reply.parts.lastIndex) put("more", true)
                    },
                )
            }
            is Reply.Err -> connection.sendJson(
                buildJsonObject {
                    put("re", id); put("ok", false)
                    put("error", buildJsonObject { put("code", reply.code); put("message", reply.message) })
                },
            )
            Reply.Silence -> Unit
        }
    }

    private fun defaultReply(op: String, args: JsonObject, connection: FakeServerConnection): Reply = when (op) {
        "ping" -> Reply.Ok(buildJsonObject { put("t", "now") })
        "subscribe" -> Reply.Ok(buildJsonObject { put("topics", args["topics"] ?: JsonArray(emptyList())) })
        "resume" -> Reply.Ok(buildJsonObject { put("replayed", 0) })
        "routes.get" -> Reply.Ok(routes)
        "device.rekey" -> rekey(args, connection)
        "device.unpair" -> {
            devices.remove(connection.deviceId)
            Reply.Ok()
        }
        else -> Reply.Err("unknown-op", op)
    }

    /** Section 4.1: both signatures over `rekeyMessage`, then fresh `dk`/`rk` for the announced key. */
    private fun rekey(args: JsonObject, connection: FakeServerConnection): Reply {
        val device = devices[connection.deviceId] ?: return Reply.Err("denied")
        val newPub = SecureCrypto.unb64(args.string("newPub") ?: return Reply.Err("bad-request"))
        if (!SecureCrypto.isValidPublicKey(newPub) || newPub.contentEquals(device.pub)) return Reply.Err("bad-request")
        val message = AvekProtocol.rekeyMessage(connection.deviceId, newPub)
        val oldOk = SecureCrypto.verify(device.pub, message, SecureCrypto.unb64(args.string("sig")!!))
        val newOk = SecureCrypto.verify(newPub, message, SecureCrypto.unb64(args.string("sigNew")!!))
        if (!oldOk || !newOk) return Reply.Err("denied")
        device.nextPub = newPub
        device.nextDk = keys.randomBytes(32)
        device.nextRk = keys.randomBytes(32)
        return Reply.Ok(buildJsonObject {
            put("dk", SecureCrypto.b64(device.nextDk!!)); put("rk", SecureCrypto.b64(device.nextRk!!)); put("graceSec", 600)
        })
    }

    private fun readyData(deviceId: String) = buildJsonObject {
        put("server", buildJsonObject { put("id", serverId); put("name", serverName); put("version", "test") })
        put("protocol", 4)
        put("revision", 2)
        put("route", "wifi")
        put("now", "2026-10-02T12:00:00.000Z")
        put("epoch", epoch)
        put("limits", buildJsonObject {
            put("maxFrameBytes", 1048576); put("attachChunkBytes", 262144); put("maxAttachmentBytes", 52428800); put("maxListPart", 100)
        })
        put("resumeHoldSec", 150)
        put("device", buildJsonObject { put("id", deviceId); put("name", "Test device") })
        put("runningTurns", JsonArray(emptyList()))
        put("pendingAsks", JsonArray(pendingAsks))
        put("modelStates", JsonArray(modelStates))
    }

    private fun damage(bytes: ByteArray): ByteArray = bytes.copyOf().also { it[it.size / 2] = (it[it.size / 2].toInt() xor 0x01).toByte() }

    private fun json(vararg pairs: Pair<String, String>): String =
        WireJson.encodeToString(JsonObject.serializer(), buildJsonObject { pairs.forEach { (k, v) -> put(k, v) } })

    private fun JsonObject.string(key: String): String? = (this[key] as? JsonPrimitive)?.contentOrNull
    private fun JsonObject.int(key: String): Int? = (this[key] as? JsonPrimitive)?.contentOrNull?.toIntOrNull()

    /** Registers a paired device (as a finished pairing would) so session handshakes succeed. Returns its secrets. */
    fun addDevice(devicePub: ByteArray, dk: ByteArray = keys.randomBytes(32), rk: ByteArray = keys.randomBytes(32)): FakeDevice =
        FakeDevice(devicePub, dk, rk).also { devices[AvekProtocol.deviceIdOf(devicePub)] = it }

    companion object {
        const val ALIAS = "server"
        const val CODE = "123456789012"
        val TEST_KDF = KdfParams(1024, 8, 1)
    }
}
