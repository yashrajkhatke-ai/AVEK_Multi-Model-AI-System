package com.avek.chat.link

import com.avek.chat.core.link.crypto.AvekProtocol
import com.avek.chat.core.link.crypto.SecureCrypto
import com.avek.chat.core.link.discovery.FindClient
import com.avek.chat.core.link.discovery.KnockAnswer
import com.avek.chat.core.link.discovery.KnockClient
import com.avek.chat.core.link.discovery.KnockTargets
import com.avek.chat.core.link.store.PairedPc
import com.avek.chat.core.link.store.DeviceKey
import com.avek.chat.core.link.wire.RoutesData
import com.avek.chat.core.link.wire.WifiRoutesDto
import com.avek.chat.core.link.store.SoftwareIdentityVault
import com.avek.chat.core.link.transport.Datagram
import com.avek.chat.core.link.transport.LocalAddress
import com.avek.chat.core.link.wire.WireJson
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.TestScope
import kotlinx.coroutines.test.runTest
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class KnockFindTest {

    private val server = SoftwareIdentityVault().also { it.create(FakeHarnessServer.ALIAS) }
    private val serverPub = server.publicKey(FakeHarnessServer.ALIAS)
    private val vault = SoftwareIdentityVault().also { it.create(TEST_ALIAS) }
    private val device = DeviceKey(vault, TEST_ALIAS)
    private val deviceId = AvekProtocol.deviceIdOf(device.publicKey())
    private val pc = PairedPc(
        deviceId, TEST_ALIAS, AvekProtocol.serverIdOf(serverPub), "Yash Laptop", serverPub, "Tablet", ByteArray(92),
        lastWifiHost = "192.168.43.5",
    )

    private fun TestScope.setup(listener: FakeKnockListener = FakeKnockListener(server, { mapOf(deviceId to device.publicKey()) })): Pair<FakeUdpTransport, FakeKnockListener> {
        val udp = FakeUdpTransport({ testScheduler.currentTime })
        udp.respond = listener::respond
        return udp to listener
    }

    @Test
    fun `a knock is signed and the first datagrams go to the last host and both broadcasts`() = runTest {
        val (udp, _) = setup()
        val answer = KnockClient(udp, { 1_800_000_000_000 }).knockWifi(pc, device)
        assertEquals(KnockAnswer("192.168.43.5", 7810), answer)
        val first = udp.sent.filter { it.atMs == 0L }.map { it.host }
        assertEquals(listOf("192.168.43.5", "255.255.255.255", "192.168.43.255"), first)
        val knock = udp.sent.first().json
        assertEquals("knock", knock.getValue("k").jsonPrimitive.content)
        assertEquals(deviceId, knock.getValue("id").jsonPrimitive.content)
        val ok = SecureCrypto.verify(
            device.publicKey(),
            AvekProtocol.knockMessage(deviceId, 1_800_000_000_000, SecureCrypto.unb64(knock.getValue("n").jsonPrimitive.content)),
            SecureCrypto.unb64(knock.getValue("sig").jsonPrimitive.content),
        )
        assertTrue(ok)
        assertTrue(udp.sent.all { it.port == KnockTargets.PORT })
        assertEquals(udp.opened, udp.closed)
    }

    @Test
    fun `repeats go out at 0, 1 and 3 s with fresh nonces, and the sweep starts at 1_5 s in spaced batches`() = runTest {
        val (udp, listener) = setup()
        listener.answerOnlyTo = emptySet() // nobody answers
        val answer = KnockClient(udp).knockWifi(pc, device)
        assertNull(answer)

        val direct = setOf("192.168.43.5", "255.255.255.255", "192.168.43.255")
        val repeats = udp.sent.filter { it.host == "255.255.255.255" }
        assertEquals(listOf(0L, 1_000L, 3_000L), repeats.map { it.atMs })
        assertEquals(3, repeats.map { it.json.getValue("n").jsonPrimitive.content }.toSet().size)

        val sweep = udp.sent.filter { it.host !in direct }
        assertEquals(253 - 1, sweep.size) // x.1..x.254 without itself (.17) and the last host (.5)
        assertEquals(1_500L, sweep.first().atMs)
        val batches = sweep.groupBy { it.atMs }
        assertTrue(batches.values.all { it.size <= 32 })
        val times = batches.keys.sorted()
        assertTrue(times.zipWithNext().all { (a, b) -> b - a >= 150 })
    }

    @Test
    fun `a PC that only answers the sweep is still found`() = runTest {
        val (udp, listener) = setup()
        listener.answerOnlyTo = setOf("192.168.43.5")
        val moved = pc.copy(lastWifiHost = "10.9.9.9")
        udp.local = LocalAddress("192.168.43.17", 24)
        val answer = KnockClient(udp).knockWifi(moved, device)
        assertEquals("192.168.43.5", answer?.host)
        assertTrue(testScheduler.currentTime >= 1_500)
    }

    @Test
    fun `answers with a wrong sid, an unknown nonce, a bad signature or a bad port are ignored`() {
        val nonce = ByteArray(16) { 9 }
        val n = SecureCrypto.b64(nonce)
        fun here(sid: String = pc.serverId, port: Int = 7810, nn: String = n, signer: SoftwareIdentityVault = server, signedPort: Int = port, avek: Int = 4): Datagram {
            val sig = signer.sign(FakeHarnessServer.ALIAS, AvekProtocol.hereMessage(sid, signedPort, deviceId, SecureCrypto.unb64(nn)))
            val json = buildJsonObject { put("avek", avek); put("k", "here"); put("sid", sid); put("port", port); put("n", nn); put("sig", SecureCrypto.b64(sig)) }
            return Datagram("192.168.43.5", 7811, WireJson.encodeToString(JsonObject.serializer(), json).toByteArray())
        }
        val nonces = setOf(n)
        assertNotNull(KnockClient.accept(here(), nonces, pc))
        assertNull(KnockClient.accept(here(sid = "s_other"), nonces, pc))
        assertNull(KnockClient.accept(here(), setOf("other"), pc))
        assertNull(KnockClient.accept(here(signer = SoftwareIdentityVault().also { it.create(FakeHarnessServer.ALIAS) }), nonces, pc))
        assertNull(KnockClient.accept(here(port = 9999, signedPort = 7810), nonces, pc))
        assertNull(KnockClient.accept(here(avek = 3), nonces, pc))
        assertNull(KnockClient.accept(Datagram("1.1.1.1", 7811, "junk".toByteArray()), nonces, pc))
    }

    @Test
    fun `the knock of the Wi-Fi route goes to the knock port of routes-get and uses the stored device id`() = runTest {
        val (udp, _) = setup()
        val routed = pc.copy(routes = RoutesData(wifi = WifiRoutesDto(emptyList(), 7810, 7811)))
        KnockClient(udp).knockWifi(routed, device)
        assertTrue(udp.sent.all { it.port == 7811 })
        assertEquals(listOf(true), udp.openedViaWifi)
    }

    @Test
    fun `the Tailscale route sends one unicast datagram on the default network`() = runTest {
        val listener = FakeKnockListener(server, { mapOf(deviceId to device.publicKey()) }, pcHost = "100.64.1.2")
        val (udp, _) = setup(listener)
        val answer = KnockClient(udp).knockTailscale(pc, device, "100.64.1.2", 7811)
        assertEquals(KnockAnswer("100.64.1.2", 7810), answer)
        assertEquals(1, udp.sent.size)
        assertEquals("100.64.1.2", udp.sent.single().host)
        assertEquals(7811, udp.sent.single().port)
        assertEquals("not bound to Wi-Fi", listOf(false), udp.openedViaWifi)
        assertEquals(udp.opened, udp.closed)
    }

    @Test
    fun `a Tailscale knock nobody answers gives up after its wait`() = runTest {
        val listener = FakeKnockListener(server, { emptyMap() })
        val (udp, _) = setup(listener)
        assertNull(KnockClient(udp).knockTailscale(pc, device, "100.64.1.2", 7811))
        assertEquals(1, udp.sent.size)
        assertEquals(KnockClient.TAILSCALE_WAIT_MS, testScheduler.currentTime)
    }

    @Test
    fun `a knock signed with a key the PC does not know gets no answer`() = runTest {
        val (udp, _) = setup()
        val stranger = SoftwareIdentityVault().also { it.create("x") }
        assertNull(KnockClient(udp).knockWifi(pc.copy(lastWifiHost = null), DeviceKey(stranger, "x")))
    }

    @Test
    fun `find lists PCs whose pairing window is open, once each`() = runTest {
        val (udp, listener) = setup()
        listener.pairingOpenName = "Yash Laptop"
        val found = FindClient(udp).find()
        assertEquals(1, found.size)
        assertEquals("Yash Laptop", found.single().name)
        assertEquals(pc.serverId, found.single().serverId)
        assertEquals("192.168.43.5", found.single().host)
        assertEquals("find", udp.sent.first().json.getValue("k").jsonPrimitive.content)
    }

    @Test
    fun `find with no window open finds nothing`() = runTest {
        val (udp, _) = setup()
        assertTrue(FindClient(udp).find().isEmpty())
    }
}
