package com.avek.chat.theme

import com.avek.chat.core.designsystem.theme.ColorMath
import com.avek.chat.core.designsystem.theme.ThemeCatalog
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ThemeCatalogTest {

    @Test
    fun `generated space has the advertised size and unique ids`() {
        val ids = ThemeCatalog.generatedIds()
        assertEquals(ThemeCatalog.generatedCount, ids.size)
        assertEquals(ids.size, ids.toSet().size)
    }

    @Test
    fun `every theme keeps body text readable in both modes`() {
        val all = ThemeCatalog.presets.map { it.id } + ThemeCatalog.generatedIds()
        all.forEach { id ->
            val theme = ThemeCatalog.resolve(id)
            listOf(theme.light, theme.dark).forEach { colors ->
                val ratio = ColorMath.contrast(colors.textPrimary, colors.chatBackground)
                assertTrue("$id (${if (colors.isDark) "dark" else "light"}) contrast $ratio", ratio >= 7f)
                assertTrue("$id user bubble text", ColorMath.contrast(colors.userText, colors.userBubble) >= 4.5f)
            }
        }
    }

    @Test
    fun `unknown ids fall back to the default theme`() {
        assertEquals(ThemeCatalog.DEFAULT_ID, ThemeCatalog.resolve("gen:999.0.0.0").id)
    }

    @Test
    fun `hex round trips`() {
        val color = ColorMath.parseHex("#C96442")!!
        assertEquals("#C96442", ColorMath.toHex(color))
        assertEquals("#AABBCC", ColorMath.toHex(ColorMath.parseHex("abc")!!))
    }
}
