package com.avek.chat.link

import com.avek.chat.core.link.crypto.AvekProtocol
import com.avek.chat.core.link.crypto.SecureCrypto
import com.avek.chat.core.link.route.AutoConnect
import com.avek.chat.core.link.route.ConnectionState
import com.avek.chat.core.link.route.FailureReason
import com.avek.chat.core.link.route.Fatal
import com.avek.chat.core.link.route.NetworkEnvironment
import com.avek.chat.core.link.route.NgrokRouteAttempt
import com.avek.chat.core.link.route.RaceResult
import com.avek.chat.core.link.route.RouteAttempt
import com.avek.chat.core.link.route.RouteCredentials
import com.avek.chat.core.link.route.RouteFailedException
import com.avek.chat.core.link.route.RouteKind
import com.avek.chat.core.link.route.RouteMode
import com.avek.chat.core.link.route.RouteRacer
import com.avek.chat.core.link.route.TailscaleRouteAttempt
import com.avek.chat.core.link.rpc.CloseInfo
import com.avek.chat.core.link.rpc.LiveLink
import com.avek.chat.core.link.store.DeviceKey
import com.avek.chat.core.link.store.PairedPc
import com.avek.chat.core.link.store.SoftwareIdentityVault
import com.avek.chat.core.link.transport.ChannelFactory
import com.avek.chat.core.link.transport.ChannelTarget
import com.avek.chat.core.link.wire.NgrokRouteDto
import com.avek.chat.core.link.wire.RoutesData
import com.avek.chat.core.link.wire.TailscaleRouteDto
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.emptyFlow
import kotlinx.coroutines.test.TestScope
import kotlinx.coroutines.test.advanceTimeBy
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** A fake connection: records whether it was closed (no open sockets after a race). */
class FakeConn(val name: String) : LiveLink {
    var closed = false
    private val done = CompletableDeferred<CloseInfo>()
    override val serverName: String = name
    override suspend fun awaitClosed(): CloseInfo = done.await()
    override fun close(code: Int, reason: String) {
        closed = true
        done.complete(CloseInfo(code, reason))
    }
}

/** A scripted route: succeeds or fails after [afterMs]; counts starts and cancellations. */
class ScriptedAttempt(
    override val kind: RouteKind,
    private val afterMs: Long,
    private val failWith: RouteFailedException? = null,
    private val skip: String? = null,
    private val hang: Boolean = false,
) : RouteAttempt<LiveLink> {
    var started = 0
    var startedAt = -1L
    var cancelled = false
    var clock: () -> Long = { 0 }
    val made = mutableListOf<FakeConn>()

    override fun skipReason(): String? = skip

    override suspend fun connect(): LiveLink {
        started++
        startedAt = clock()
        try {
            if (hang) awaitCancellation()
            delay(afterMs)
            failWith?.let { throw it }
            return FakeConn(kind.wire).also { made += it }
        } catch (e: CancellationException) {
            cancelled = true
            throw e
        }
    }
}

@OptIn(ExperimentalCoroutinesApi::class)
class RouteRacerTest {

    private fun TestScope.attempts(vararg list: ScriptedAttempt): List<ScriptedAttempt> =
        list.toList().onEach { a -> a.clock = { testScheduler.currentTime } }

    private suspend fun TestScope.race(mode: RouteMode, list: List<ScriptedAttempt>): RaceResult<LiveLink> =
        RouteRacer().race(mode, list) { it.close() }

    private fun notFound() = RouteFailedException(FailureReason.NotFound, "no answer")

    @Test
    fun `Wi-Fi wins before 3 s and ngrok never starts`() = runTest {
        val (wifi, ts, ngrok) = attempts(
            ScriptedAttempt(RouteKind.WIFI, 1_200),
            ScriptedAttempt(RouteKind.TAILSCALE, 2_500),
            ScriptedAttempt(RouteKind.NGROK, 100),
        )
        val result = race(RouteMode.Auto, listOf(wifi, ts, ngrok)) as RaceResult.Winner
        assertEquals(RouteKind.WIFI, result.route)
        assertEquals(1_200L, testScheduler.currentTime)
        assertEquals(0, ngrok.started)
        assertTrue("the loser is cancelled", ts.cancelled)
        assertEquals(0L, wifi.startedAt)
        assertEquals(0L, ts.startedAt)
    }

    @Test
    fun `Tailscale can win`() = runTest {
        val (wifi, ts, ngrok) = attempts(
            ScriptedAttempt(RouteKind.WIFI, 0, hang = true),
            ScriptedAttempt(RouteKind.TAILSCALE, 800),
            ScriptedAttempt(RouteKind.NGROK, 100),
        )
        val result = race(RouteMode.Auto, listOf(wifi, ts, ngrok)) as RaceResult.Winner
        assertEquals(RouteKind.TAILSCALE, result.route)
        assertTrue(wifi.cancelled)
        assertEquals(0, ngrok.started)
    }

    @Test
    fun `both fail early, then ngrok starts at once and wins`() = runTest {
        val (wifi, ts, ngrok) = attempts(
            ScriptedAttempt(RouteKind.WIFI, 500, notFound()),
            ScriptedAttempt(RouteKind.TAILSCALE, 700, RouteFailedException(FailureReason.Refused, "refused")),
            ScriptedAttempt(RouteKind.NGROK, 400),
        )
        val result = race(RouteMode.Auto, listOf(wifi, ts, ngrok)) as RaceResult.Winner
        assertEquals(RouteKind.NGROK, result.route)
        assertEquals("started when both earlier routes had failed", 700L, ngrok.startedAt)
        assertEquals(listOf(FailureReason.NotFound, FailureReason.Refused), result.failures.map { it.reason })
    }

    @Test
    fun `ngrok starts at 3 s when nothing has finished yet`() = runTest {
        val (wifi, ts, ngrok) = attempts(
            ScriptedAttempt(RouteKind.WIFI, 0, hang = true),
            ScriptedAttempt(RouteKind.TAILSCALE, 0, hang = true),
            ScriptedAttempt(RouteKind.NGROK, 1_000),
        )
        val result = race(RouteMode.Auto, listOf(wifi, ts, ngrok)) as RaceResult.Winner
        assertEquals(RouteKind.NGROK, result.route)
        assertEquals(3_000L, ngrok.startedAt)
        assertTrue(wifi.cancelled && ts.cancelled)
    }

    @Test
    fun `ngrok never starts when something connected at 2_9 s`() = runTest {
        val (wifi, ts, ngrok) = attempts(
            ScriptedAttempt(RouteKind.WIFI, 2_900),
            ScriptedAttempt(RouteKind.TAILSCALE, 0, hang = true),
            ScriptedAttempt(RouteKind.NGROK, 10),
        )
        val result = race(RouteMode.Auto, listOf(wifi, ts, ngrok)) as RaceResult.Winner
        assertEquals(RouteKind.WIFI, result.route)
        advanceTimeBy(10_000)
        assertEquals(0, ngrok.started)
    }

    @Test
    fun `all fail gives one failure per route with the right reasons`() = runTest {
        val (wifi, ts, ngrok) = attempts(
            ScriptedAttempt(RouteKind.WIFI, 1_000, notFound()),
            ScriptedAttempt(RouteKind.TAILSCALE, 0, skip = "Tailscale is not installed on this phone"),
            ScriptedAttempt(RouteKind.NGROK, 500, RouteFailedException(FailureReason.Denied, "denied")),
        )
        val result = race(RouteMode.Auto, listOf(wifi, ts, ngrok)) as RaceResult.AllFailed
        assertEquals(listOf(RouteKind.WIFI, RouteKind.TAILSCALE, RouteKind.NGROK), result.failures.map { it.route })
        assertEquals(listOf(FailureReason.NotFound, FailureReason.Skipped, FailureReason.Denied), result.failures.map { it.reason })
        assertEquals("Tailscale is not installed on this phone", result.failures[1].message)
        assertEquals(0, ts.started)
    }

    @Test
    fun `a route that is not set up is skipped silently`() = runTest {
        val (wifi) = attempts(ScriptedAttempt(RouteKind.WIFI, 100, notFound()))
        val result = race(RouteMode.Auto, listOf(wifi)) as RaceResult.AllFailed
        assertEquals(listOf(FailureReason.NotFound, FailureReason.Skipped, FailureReason.Skipped), result.failures.map { it.reason })
    }

    @Test
    fun `restricted modes try only their route and immediately`() = runTest {
        for (mode in listOf(RouteMode.WifiOnly, RouteMode.TailscaleOnly, RouteMode.NgrokOnly)) {
            val list = attempts(
                ScriptedAttempt(RouteKind.WIFI, 100),
                ScriptedAttempt(RouteKind.TAILSCALE, 100),
                ScriptedAttempt(RouteKind.NGROK, 100),
            )
            val start = testScheduler.currentTime
            val result = race(mode, list) as RaceResult.Winner
            assertEquals(mode.only, result.route)
            list.forEach { a ->
                if (a.kind == mode.only) assertEquals(start, a.startedAt) else assertEquals(0, a.started)
            }
        }
    }

    @Test
    fun `the overall limit is 20 s and running routes time out`() = runTest {
        val (wifi, ts, ngrok) = attempts(
            ScriptedAttempt(RouteKind.WIFI, 0, hang = true),
            ScriptedAttempt(RouteKind.TAILSCALE, 0, hang = true),
            ScriptedAttempt(RouteKind.NGROK, 0, hang = true),
        )
        val result = race(RouteMode.Auto, listOf(wifi, ts, ngrok)) as RaceResult.AllFailed
        assertEquals(20_000L, testScheduler.currentTime)
        assertEquals(List(3) { FailureReason.Timeout }, result.failures.map { it.reason })
        assertTrue(wifi.cancelled && ts.cancelled && ngrok.cancelled)
    }

    @Test
    fun `a late second winner is closed, so nothing stays open`() = runTest {
        val (wifi, ts) = attempts(
            ScriptedAttempt(RouteKind.WIFI, 1_000),
            ScriptedAttempt(RouteKind.TAILSCALE, 1_000),
        )
        val result = race(RouteMode.Auto, listOf(wifi, ts)) as RaceResult.Winner
        val all = wifi.made + ts.made
        val winner = result.connection as FakeConn
        assertTrue(all.filter { it !== winner }.all { it.closed })
        assertFalse(winner.closed)
    }

    // ------------------------------------------------------------------ the real attempts

    private val vault = SoftwareIdentityVault().also { it.create(TEST_ALIAS) }
    private val pc = PairedPc("d_5587348a01", TEST_ALIAS, "s_7e80118c", "PC", ByteArray(65), "Tablet", ByteArray(92))
    private fun credentials() = RouteCredentials(pc.deviceId, DeviceKey(vault, TEST_ALIAS), ByteArray(32), ByteArray(32) { 5 }, slotNext = false)

    private class Env(private val installed: Boolean) : NetworkEnvironment {
        override val changes = emptyFlow<Unit>()
        override fun tailscaleInstalled() = installed
        override fun vpnActive() = false
    }

    @Test
    fun `Tailscale is skipped without a stored host or without the app`() {
        val noHost = TailscaleRouteAttempt<LiveLink>(pc, credentials(), KnockClientStub.client, { error("no") }, Env(true)) { _, _, _ -> error("no") }
        assertEquals("Not set up", noHost.skipReason())
        val withHost = pc.copy(routes = RoutesData(tailscale = TailscaleRouteDto(host = "100.64.1.2")))
        val notInstalled = TailscaleRouteAttempt<LiveLink>(withHost, credentials(), KnockClientStub.client, { error("no") }, Env(false)) { _, _, _ -> error("no") }
        assertEquals("Tailscale is not installed on this phone", notInstalled.skipReason())
        val ready = TailscaleRouteAttempt<LiveLink>(withHost, credentials(), KnockClientStub.client, { error("no") }, Env(true)) { _, _, _ -> error("no") }
        assertEquals(null, ready.skipReason())
    }

    @Test
    fun `the ngrok route opens wss with a fresh route proof every attempt`() = runTest {
        val routed = pc.copy(routes = RoutesData(ngrok = NgrokRouteDto(url = "https://my-pc.ngrok-free.dev", state = "online")))
        val targets = mutableListOf<ChannelTarget>()
        val factory = ChannelFactory { target ->
            targets += target
            throw com.avek.chat.core.link.transport.ChannelOpenException(404, null)
        }
        var n = 0
        val attempt = NgrokRouteAttempt<LiveLink>(routed, credentials(), factory, { _, _, _ -> error("no") }, nowMs = { 1_800_000_000_000 }, randomBytes = { size -> ByteArray(size) { (n + it).toByte() }.also { n++ } })
        repeat(2) {
            val failure = runCatching { attempt.connect() }.exceptionOrNull() as RouteFailedException
            assertEquals("an empty 404 from the tunnel door is denied", FailureReason.Denied, failure.reason)
        }
        assertEquals("wss://my-pc.ngrok-free.dev/ui", targets.first().url)
        assertEquals("1", targets.first().headers["ngrok-skip-browser-warning"])
        val headers = targets.map { it.headers.getValue("Authorization") }
        assertNotEquals("a fresh nonce every attempt", headers[0], headers[1])
        val expected = AvekProtocol.routeHeader(ByteArray(32) { 5 }, pc.deviceId, 1_800_000_000_000, ByteArray(16) { it.toByte() })
        assertEquals(expected, headers[0])
        assertFalse(targets.first().viaWifi)
        assertTrue(SecureCrypto.b64(ByteArray(1)).isNotEmpty())
    }

    @Test
    fun `ngrok is skipped when no url is stored`() {
        val attempt = NgrokRouteAttempt<LiveLink>(pc, credentials(), { error("no") }, { _, _, _ -> error("no") })
        assertEquals("Not set up", attempt.skipReason())
    }

    // ------------------------------------------------------------------ the loop

    private fun TestScope.loop(attempts: () -> List<RouteAttempt<LiveLink>>, paired: PairedPc? = pc) = AutoConnect(
        scope = backgroundScope,
        pc = { paired },
        mode = { RouteMode.Auto },
        candidates = { listOf(credentials()) },
        attempts = { _, _ -> attempts() },
        describe = { "test" },
        nowMs = { testScheduler.currentTime },
    )

    @Test
    fun `failures wait 2, 4, 8, then 15 s and remember the reasons`() = runTest {
        val loop = loop({ listOf(ScriptedAttempt(RouteKind.WIFI, 0, notFound())) })
        loop.start()
        val waits = mutableListOf<Long>()
        repeat(6) {
            runCurrent()
            val state = loop.state.value as ConnectionState.Unreachable
            assertEquals(3, state.failures.size)
            val wait = state.retryAtMs!! - testScheduler.currentTime
            waits += wait
            advanceTimeBy(wait)
            runCurrent()
        }
        assertEquals(listOf(2_000L, 4_000L, 8_000L, 15_000L, 15_000L, 15_000L), waits)
        loop.stop()
        assertEquals(ConnectionState.Disconnected, loop.state.value)
    }

    @Test
    fun `a kick tries again at once`() = runTest {
        var tries = 0
        val loop = loop({ tries++; listOf(ScriptedAttempt(RouteKind.WIFI, 0, notFound())) })
        loop.start()
        runCurrent()
        val before = tries
        loop.kick()
        runCurrent()
        assertEquals(before + 1, tries)
        loop.stop()
    }

    @Test
    fun `a 4401 after a valid knock stops the loop as Forgotten`() = runTest {
        var tries = 0
        val loop = loop({ tries++; listOf(ScriptedAttempt(RouteKind.WIFI, 0, RouteFailedException(FailureReason.Denied, "forgot", Fatal.Forgotten))) })
        loop.start()
        advanceTimeBy(60_000)
        assertEquals(ConnectionState.Forgotten, loop.state.value)
        assertEquals(1, tries)
    }

    @Test
    fun `a PC that does not prove the pinned key is not retried in a loop`() = runTest {
        var tries = 0
        val loop = loop({ tries++; listOf(ScriptedAttempt(RouteKind.WIFI, 0, RouteFailedException(FailureReason.Denied, "not ours", Fatal.NotOurPc))) })
        loop.start()
        advanceTimeBy(60_000)
        assertTrue(loop.state.value is ConnectionState.Failed)
        assertEquals(1, tries)
    }

    @Test
    fun `a winner is Connected with its route`() = runTest {
        val loop = loop({ listOf(ScriptedAttempt(RouteKind.TAILSCALE, 10)) })
        loop.start()
        advanceTimeBy(100)
        val state = loop.state.value as ConnectionState.Connected
        assertEquals(RouteKind.TAILSCALE, state.route)
        loop.stop()
    }
}

/** A knock client that is never used (the skip checks do not knock). */
object KnockClientStub {
    val client = com.avek.chat.core.link.discovery.KnockClient(FakeUdpTransport({ 0 }))
}
