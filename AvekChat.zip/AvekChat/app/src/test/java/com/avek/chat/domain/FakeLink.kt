package com.avek.chat.domain

import com.avek.chat.core.link.LinkProfile
import com.avek.chat.core.link.LinkRepository
import com.avek.chat.core.link.route.ConnectionState
import com.avek.chat.core.link.rpc.ListPart
import com.avek.chat.core.link.wire.LinkEvent
import com.avek.chat.core.link.wire.ReadyDto
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flow
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.jsonObject

/** A scripted [LinkRepository]: every request goes to [handler], events are pushed with [emit]. */
class FakeLink(
    var handler: suspend (op: String, args: JsonObject) -> JsonElement = { op, _ -> error("unexpected $op") },
) : LinkRepository {
    /** When set, list requests are answered by this instead of [handler]. */
    var callHandlerForLists: (suspend (op: String, args: JsonObject) -> JsonElement)? = null

    val calls = mutableListOf<Pair<String, JsonObject>>()
    val connectionState = MutableStateFlow<ConnectionState>(ConnectionState.Connected("test", com.avek.chat.core.link.route.RouteKind.WIFI, "Test PC"))
    private val eventFlow = MutableSharedFlow<LinkEvent>(extraBufferCapacity = 256)
    override val state: StateFlow<ConnectionState> get() = connectionState
    override val events: SharedFlow<LinkEvent> get() = eventFlow
    override val ready: StateFlow<ReadyDto?> = MutableStateFlow(ReadyDto())
    override val profile = MutableStateFlow(LinkProfile.FOREGROUND)

    var connects = 0
    var disconnects = 0
    override fun connect() { connects++ }
    override fun disconnect() { disconnects++ }
    override fun setProfile(profile: LinkProfile) { this.profile.value = profile }

    var traceIsWanted = false
    override fun setTraceWanted(wanted: Boolean) { traceIsWanted = wanted }

    suspend fun emit(event: LinkEvent) = eventFlow.emit(event)

    override suspend fun call(op: String, args: JsonObject, timeoutMs: Long): JsonElement {
        calls += op to args
        return handler(op, args)
    }

    /** Each element the handler returns for the op is one part. */
    override fun callList(op: String, args: JsonObject, timeoutMs: Long): Flow<ListPart> = flow {
        calls += op to args
        val data = (callHandlerForLists ?: handler)(op, args).jsonObject
        val parts = (data["parts"] as? JsonArray)?.map { it.jsonObject } ?: listOf(data)
        for ((i, part) in parts.withIndex()) {
            emit(ListPart(emptyList(), null, null, more = i < parts.size - 1, raw = part))
        }
    }

    fun opsCalled(op: String) = calls.filter { it.first == op }.map { it.second }
}
