package com.avek.chat.domain

import com.avek.chat.core.data.remote.assistantMessageId
import com.avek.chat.core.data.remote.parseInstant
import com.avek.chat.core.data.remote.toDomain
import com.avek.chat.core.data.remote.toMessages
import com.avek.chat.core.link.LinkLifecycleController
import com.avek.chat.core.link.LinkProfile
import com.avek.chat.core.link.store.PairedPc
import com.avek.chat.core.link.wire.AssistantPartDto
import com.avek.chat.core.link.wire.AttachmentInfoDto
import com.avek.chat.core.link.wire.ChatSummaryDto
import com.avek.chat.core.link.wire.ModelDto
import com.avek.chat.core.link.wire.ThinkingDto
import com.avek.chat.core.link.wire.ToolDto
import com.avek.chat.core.link.wire.TurnViewDto
import com.avek.chat.core.link.wire.UserPartDto
import com.avek.chat.core.model.Feedback
import com.avek.chat.core.model.MessageStatus
import com.avek.chat.core.model.ModelKind
import com.avek.chat.core.model.RemoteModel
import com.avek.chat.core.model.TaskMode
import com.avek.chat.core.model.settings.ConnectionSettings
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.test.advanceTimeBy
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class LifecycleTest {

    private class Rig(scope: kotlinx.coroutines.CoroutineScope, paired: Boolean = true, settings: ConnectionSettings = ConnectionSettings()) {
        val visible = MutableStateFlow(true)
        val settings = MutableStateFlow(settings)
        val pc = MutableStateFlow(if (paired) PairedPc("s", "PC", ByteArray(65), "Phone") else null)
        val link = FakeLink()
        val background = mutableListOf<Boolean>()
        val controller = LinkLifecycleController(scope, visible, this.settings, pc, link, { background += it }, graceMs = 30_000)
    }

    @Test
    fun `visible means connected with every topic`() = runTest {
        val rig = Rig(backgroundScope).also { it.controller.start() }
        runCurrent()
        assertEquals(1, rig.link.connects)
        assertEquals(LinkProfile.FOREGROUND, rig.link.profile.value)
        assertEquals(7, rig.link.profile.value.topics.size)
    }

    @Test
    fun `off screen without background work closes the link after 30 seconds, and coming back cancels it`() = runTest {
        val rig = Rig(backgroundScope).also { it.controller.start() }
        runCurrent()
        rig.visible.value = false; runCurrent()
        advanceTimeBy(29_000); runCurrent()
        assertEquals(0, rig.link.disconnects)
        rig.visible.value = true; runCurrent()
        advanceTimeBy(60_000); runCurrent()
        assertEquals(0, rig.link.disconnects)
        rig.visible.value = false; runCurrent()
        advanceTimeBy(30_001); runCurrent()
        assertEquals(1, rig.link.disconnects)
    }

    @Test
    fun `off screen with background work keeps the link on the small profile and runs the service`() = runTest {
        val rig = Rig(backgroundScope, settings = ConnectionSettings(workInBackground = true)).also { it.controller.start() }
        runCurrent()
        rig.visible.value = false; runCurrent()
        advanceTimeBy(600_000); runCurrent()
        assertEquals(0, rig.link.disconnects)
        assertEquals(LinkProfile.BACKGROUND, rig.link.profile.value)
        assertEquals(listOf("ask", "turn", "downloads"), rig.link.profile.value.topics)
        assertTrue(rig.background.last())
        rig.visible.value = true; runCurrent()
        assertEquals(LinkProfile.FOREGROUND, rig.link.profile.value)
    }

    @Test
    fun `turning background work off stops the service`() = runTest {
        val rig = Rig(backgroundScope, settings = ConnectionSettings(workInBackground = true)).also { it.controller.start() }
        runCurrent()
        assertTrue(rig.background.last())
        rig.settings.value = ConnectionSettings(workInBackground = false); runCurrent()
        assertFalse(rig.background.last())
    }

    @Test
    fun `an unpaired app or demo mode never connects`() = runTest {
        val unpaired = Rig(backgroundScope, paired = false).also { it.controller.start() }
        val demo = Rig(backgroundScope, settings = ConnectionSettings(demoMode = true, workInBackground = true)).also { it.controller.start() }
        runCurrent()
        assertEquals(0, unpaired.link.connects)
        assertEquals(0, demo.link.connects)
        assertFalse(demo.background.last())
    }
}

class MapperTest {

    @Test
    fun `timestamps parse and bad ones become zero`() {
        assertEquals(1_735_689_600_000L, parseInstant("2025-01-01T00:00:00Z"))
        assertEquals(1_735_689_600_123L, parseInstant("2025-01-01T00:00:00.123Z"))
        assertEquals(0L, parseInstant(""))
        assertEquals(0L, parseInstant("yesterday"))
    }

    @Test
    fun `a turn becomes a user and an assistant message sharing the prompt id`() {
        val turn = TurnViewDto(
            promptId = "p7", createdAt = "2025-01-01T00:00:00Z", status = "completed", modelId = "m", mode = "coding", depth = 3,
            user = UserPartDto("hi", listOf(AttachmentInfoDto("a.png", "image/png", 5))),
            assistant = AssistantPartDto("hello"),
            thinking = ThinkingDto(1200),
            tools = listOf(ToolDto("t1", "read_file", true, "Read x")),
            feedback = "up",
        )
        val pair = turn.toMessages("c1")
        assertEquals("p7:u", pair.user.id)
        assertEquals(assistantMessageId("p7"), pair.assistant.id)
        assertEquals("p7", pair.assistant.promptId)
        assertEquals("a.png", pair.user.attachments.single().name)
        assertTrue(pair.assistant.hasThinking)
        assertNull(pair.assistant.thinking) // lazy: not loaded
        assertEquals(1200L, pair.assistant.thinkingDurationMs)
        assertEquals(TaskMode.CODING, pair.assistant.requestedTask)
        assertEquals(3, pair.assistant.depth.level)
        assertEquals(Feedback.POSITIVE, pair.assistant.feedback)
        assertEquals("Read x", pair.assistant.tools.single().title)
        assertTrue(pair.user.createdAt < pair.assistant.createdAt)
    }

    @Test
    fun `statuses map and unknown modes fall back to auto`() {
        fun status(s: String) = TurnViewDto("p", status = s, mode = "zzz").toMessages("c").assistant
        assertEquals(MessageStatus.STREAMING, status("in-progress").status)
        assertEquals(MessageStatus.WAITING, status("waiting").status)
        assertEquals(MessageStatus.STOPPED, status("cancelled").status)
        assertEquals(MessageStatus.ERROR, status("failed").status)
        assertEquals(MessageStatus.COMPLETE, status("completed").status)
        assertEquals(TaskMode.AUTO, status("completed").requestedTask)
    }

    @Test
    fun `chat summaries and models map`() {
        val chat = ChatSummaryDto("c1", "", "2025-01-01T00:00:00Z", "2025-01-02T00:00:00Z", "m", "research", 4, "p", starred = true).toDomain(isDownloaded = true)
        assertEquals("New chat", chat.title)
        assertEquals(TaskMode.DEEP_RESEARCH, chat.taskMode)
        assertTrue(chat.isStarred && chat.isDownloaded)
        val vision = ModelDto(
            "m", "Mira", "vision", 2, tagline = "Sees images", intelligence = 9, speed = 3, contextTokens = 81_920,
            capabilities = listOf(com.avek.chat.core.link.wire.CapabilityDto("vision", "Vision"), com.avek.chat.core.link.wire.CapabilityDto("", "")),
            state = "ready", sizeBytes = 5_000_000_000,
        ).toDomain()
        assertEquals(ModelKind.VISION, vision.kind)
        assertTrue(vision.isVision)
        assertEquals("Sees images", vision.tagline)
        assertEquals("meters are clamped to 1..5", 5, vision.intelligence)
        assertEquals(listOf("Vision"), vision.capabilities.map { it.label })
        assertEquals(com.avek.chat.core.model.ModelLoadState.READY, vision.state)
        assertEquals(com.avek.chat.core.model.ModelLoadState.UNKNOWN, com.avek.chat.core.model.ModelLoadState.fromWire("weird"))
        assertEquals("Mira", vision.name)
        assertEquals("m", ModelDto("m").toDomain().name)
    }
}
