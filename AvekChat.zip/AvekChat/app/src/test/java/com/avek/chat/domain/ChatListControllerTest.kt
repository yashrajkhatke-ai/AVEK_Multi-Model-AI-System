package com.avek.chat.domain

import com.avek.chat.core.domain.lists.ChatListController
import com.avek.chat.core.domain.lists.ListMemoryRegistry
import com.avek.chat.core.domain.repository.Page
import com.avek.chat.core.model.Conversation
import com.avek.chat.core.model.TaskMode
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.TestScope
import kotlinx.coroutines.test.advanceTimeBy
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

private fun chat(i: Int) = Conversation("c$i", "Chat $i", 0, 0, false, false, null, TaskMode.AUTO, "", 1)

/** 95 chats on a fake PC; records every request so the paging rules can be checked exactly. */
@OptIn(ExperimentalCoroutinesApi::class)
private class FakePc(val total: Int = 95) {
    val requests = mutableListOf<Pair<Int, String?>>()
    var gate: CompletableDeferred<Unit>? = null

    suspend fun fetch(limit: Int, after: String?): Page<Conversation> {
        requests += limit to after
        gate?.await()
        val start = after?.toInt() ?: 0
        val end = minOf(total, start + limit)
        return Page((start until end).map(::chat), total, if (end < total) end.toString() else null)
    }
}

@OptIn(ExperimentalCoroutinesApi::class)
class ChatListControllerTest {

    private fun TestScope.controller(pc: FakePc, registry: ListMemoryRegistry? = null) =
        ChatListController(backgroundScope, pc::fetch, { 120 }, registry)

    @Test
    fun `opening requests exactly 20 and offers See all when more exist`() = runTest {
        val pc = FakePc()
        val list = controller(pc)
        list.opened(); runCurrent()
        assertEquals(listOf(20 to null), pc.requests)
        val state = list.state.value
        assertEquals(20, state.items.size)
        assertEquals(95, state.total)
        assertTrue(state.showSeeAll)
    }

    @Test
    fun `no See all when everything fits in the first page`() = runTest {
        val pc = FakePc(total = 20)
        val list = controller(pc)
        list.opened(); runCurrent()
        assertFalse(list.state.value.showSeeAll)
        list.onVisibleIndex(19); runCurrent()
        assertEquals(1, pc.requests.size)
    }

    @Test
    fun `items 21 plus are not requested before item 13 is visible`() = runTest {
        val pc = FakePc()
        val list = controller(pc)
        list.opened(); runCurrent()
        for (i in 0..11) list.onVisibleIndex(i)
        runCurrent()
        assertEquals(1, pc.requests.size)
        list.onVisibleIndex(12) // the 13th item
        runCurrent()
        assertEquals(listOf(20 to null, 40 to "20"), pc.requests)
        // once per page: scrolling further does not repeat the prefetch
        list.onVisibleIndex(13); list.onVisibleIndex(19); runCurrent()
        assertEquals(2, pc.requests.size)
        // the prefetched page is held back until See all
        assertEquals(20, list.state.value.items.size)
    }

    @Test
    fun `See all shows the prefetched 40 at once`() = runTest {
        val pc = FakePc()
        val list = controller(pc)
        list.opened(); runCurrent()
        list.onVisibleIndex(12); runCurrent()
        list.seeAll(); runCurrent()
        val state = list.state.value
        assertEquals(60, state.items.size)
        assertTrue(state.expanded)
        assertTrue(state.hasMore)
        assertFalse(state.showSeeAll)
        assertEquals(2, pc.requests.size) // no extra request
    }

    @Test
    fun `See all before the prefetch finished waits for it instead of asking twice`() = runTest {
        val pc = FakePc()
        val list = controller(pc)
        list.opened(); runCurrent()
        pc.gate = CompletableDeferred()
        list.onVisibleIndex(12); runCurrent()
        list.seeAll(); runCurrent()
        assertTrue(list.state.value.loadingMore)
        assertEquals(20, list.state.value.items.size)
        pc.gate!!.complete(Unit); runCurrent()
        assertEquals(60, list.state.value.items.size)
        assertFalse(list.state.value.loadingMore)
        assertEquals(2, pc.requests.size)
    }

    @Test
    fun `See all without a prefetch loads the next 40`() = runTest {
        val pc = FakePc()
        val list = controller(pc)
        list.opened(); runCurrent()
        list.seeAll(); runCurrent()
        assertEquals(listOf(20 to null, 40 to "20"), pc.requests)
        assertEquals(60, list.state.value.items.size)
    }

    @Test
    fun `after See all one of the last 8 items visible prefetches the next 40 once`() = runTest {
        val pc = FakePc()
        val list = controller(pc)
        list.opened(); runCurrent()
        list.seeAll(); runCurrent() // 60 loaded
        list.onVisibleIndex(30); runCurrent()
        assertEquals(2, pc.requests.size) // far from the end: nothing
        list.onVisibleIndex(52); runCurrent() // the 53rd = 8th from the end (60-8)
        assertEquals(3, pc.requests.size)
        assertEquals(40 to "60", pc.requests.last())
        assertEquals(95, list.state.value.items.size)
        list.onVisibleIndex(59); list.onVisibleIndex(94); runCurrent()
        assertEquals(3, pc.requests.size) // next is null: done
        assertFalse(list.state.value.hasMore)
    }

    @Test
    fun `an item outside the last 8 never triggers the prefetch`() = runTest {
        val pc = FakePc()
        val list = controller(pc)
        list.opened(); runCurrent()
        list.seeAll(); runCurrent()
        list.onVisibleIndex(51); runCurrent()
        assertEquals(2, pc.requests.size)
    }

    @Test
    fun `a failed prefetch can be retried and does not break the list`() = runTest {
        var fail = true
        val pc = FakePc()
        val list = ChatListController(backgroundScope, { limit, after -> if (after != null && fail) error("boom") else pc.fetch(limit, after) }, { 120 })
        list.opened(); runCurrent()
        list.onVisibleIndex(12); runCurrent()
        assertEquals(20, list.state.value.items.size)
        fail = false
        list.onVisibleIndex(13); runCurrent() // allowed again
        list.seeAll(); runCurrent()
        assertEquals(60, list.state.value.items.size)
    }

    @Test
    fun `live updates move a chat to the top and removals shrink the total`() = runTest {
        val pc = FakePc()
        val list = controller(pc)
        list.opened(); runCurrent()
        list.upsert(chat(5).copy(title = "Renamed"), insertIfMissing = false)
        assertEquals(listOf("c5", "c0", "c1"), list.state.value.items.take(3).map { it.id })
        list.upsert(chat(500), insertIfMissing = true)
        assertEquals("c500", list.state.value.items.first().id)
        assertEquals(96, list.state.value.total)
        list.remove("c500")
        assertEquals(95, list.state.value.total)
    }

    @Test
    fun `update replaces a chat in place`() = runTest {
        val list = controller(FakePc())
        list.opened(); runCurrent()
        list.update(chat(3).copy(title = "Starred now", isStarred = true))
        assertEquals(listOf("c2", "c3", "c4"), list.state.value.items.subList(2, 5).map { it.id })
        assertTrue(list.state.value.items[3].isStarred)
    }

    @Test
    fun `refresh starts again from the first 20`() = runTest {
        val pc = FakePc()
        val list = controller(pc)
        list.opened(); runCurrent()
        list.seeAll(); runCurrent()
        list.refresh(); runCurrent()
        assertEquals(20, list.state.value.items.size)
        assertFalse(list.state.value.expanded)
    }
}
