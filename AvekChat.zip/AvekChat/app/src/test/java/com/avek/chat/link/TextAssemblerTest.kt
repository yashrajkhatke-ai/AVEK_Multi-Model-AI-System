package com.avek.chat.link

import com.avek.chat.core.link.rpc.TextAssembler
import com.avek.chat.core.link.rpc.TextAssembler.Outcome
import org.junit.Assert.assertEquals
import org.junit.Test

class TextAssemblerTest {

    private val key = "p1:answer"

    @Test
    fun `contiguous deltas append`() {
        val assembler = TextAssembler()
        assertEquals(Outcome.Appended("Hel"), assembler.apply(key, 0, "Hel"))
        assertEquals(Outcome.Appended("lo"), assembler.apply(key, 3, "lo"))
        assertEquals("Hello", assembler.text(key))
    }

    @Test
    fun `an overlapping delta appends only the new part`() {
        val assembler = TextAssembler()
        assembler.apply(key, 0, "Hello")
        // The server re-sends from offset 3 (e.g. after a resume): "lo" is a duplicate, " world" is new.
        assertEquals(Outcome.Appended(" world"), assembler.apply(key, 3, "lo world"))
        assertEquals("Hello world", assembler.text(key))
    }

    @Test
    fun `a fully duplicated delta changes nothing`() {
        val assembler = TextAssembler()
        assembler.apply(key, 0, "Hello")
        assertEquals(Outcome.Duplicate, assembler.apply(key, 0, "Hello"))
        assertEquals(Outcome.Duplicate, assembler.apply(key, 1, "ell"))
        assertEquals("Hello", assembler.text(key))
    }

    @Test
    fun `a gap is ignored and signals a reload`() {
        val assembler = TextAssembler()
        assembler.apply(key, 0, "Hello")
        assertEquals(Outcome.Reload, assembler.apply(key, 9, "later"))
        assertEquals("Hello", assembler.text(key))
        // After the reload the caller resets and streaming continues from the fresh text.
        assembler.reset(key, "Hello, world")
        assertEquals(Outcome.Appended("!"), assembler.apply(key, 12, "!"))
    }

    @Test
    fun `offsets count UTF-16 code units so surrogate pairs take two`() {
        val assembler = TextAssembler()
        val face = "😀" // one emoji = 2 UTF-16 units
        assertEquals(2, face.length)
        assembler.apply(key, 0, "a${face}b") // length 4
        assertEquals(4, assembler.length(key))

        // Next delta starts at offset 4 (not 3, which would count code points).
        assertEquals(Outcome.Appended("c"), assembler.apply(key, 4, "c"))
        // A duplicate that begins after the pair: offset 3 covers only "b".
        assertEquals(Outcome.Appended("d"), assembler.apply(key, 3, "bcd"))
        assertEquals("a${face}bcd", assembler.text(key))
    }

    @Test
    fun `a delta that splits a surrogate pair still assembles correctly`() {
        val assembler = TextAssembler()
        val face = "😀"
        assembler.apply(key, 0, face.substring(0, 1)) // high surrogate only
        assembler.apply(key, 1, face.substring(1) + "!")
        assertEquals("$face!", assembler.text(key))
    }

    @Test
    fun `thinking and answer are tracked independently per turn`() {
        val assembler = TextAssembler()
        assembler.apply("p1:thinking", 0, "hmm")
        assembler.apply("p1:answer", 0, "Yes")
        assembler.apply("p2:answer", 0, "No")
        assertEquals("hmm", assembler.text("p1:thinking"))
        assertEquals("Yes", assembler.text("p1:answer"))
        assertEquals("No", assembler.text("p2:answer"))
        assertEquals(0, assembler.length("unknown"))
    }

    @Test
    fun `reset seeds the text so streaming continues after a late join`() {
        val assembler = TextAssembler()
        assembler.reset(key, "Already 18 chars...")
        val length = assembler.length(key)
        assertEquals(Outcome.Appended("more"), assembler.apply(key, length, "more"))
    }
}
