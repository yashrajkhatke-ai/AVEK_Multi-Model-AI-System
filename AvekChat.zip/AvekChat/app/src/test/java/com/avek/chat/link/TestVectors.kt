package com.avek.chat.link

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive

/** The reference values produced by the harness (resource `test-vectors.json`). */
object TestVectors {
    val root: JsonObject by lazy {
        val stream = checkNotNull(TestVectors::class.java.classLoader.getResourceAsStream("test-vectors.json")) {
            "test-vectors.json is missing from the test resources"
        }
        Json.parseToJsonElement(stream.bufferedReader().readText()).jsonObject
    }

    fun obj(vararg path: String): JsonObject = path.fold(root) { acc, key -> acc.getValue(key).jsonObject }

    fun string(vararg path: String): String {
        val parent = path.dropLast(1).fold(root) { acc, key -> acc.getValue(key).jsonObject }
        return parent.getValue(path.last()).jsonPrimitive.content
    }
}
