package com.avek.chat.link

import com.avek.chat.core.link.DefaultLinkRepository
import com.avek.chat.core.link.LinkProfile
import com.avek.chat.core.link.crypto.Handshake
import com.avek.chat.core.link.discovery.BeaconSource
import com.avek.chat.core.link.route.ConnectionState
import com.avek.chat.core.link.route.RouteFactory
import com.avek.chat.core.link.rpc.RpcException
import com.avek.chat.core.link.store.PairedPc
import com.avek.chat.core.link.store.PairedPcStore
import com.avek.chat.core.link.transport.ChannelFactory
import com.avek.chat.core.link.transport.NoWifiBinding
import com.avek.chat.core.link.wire.LinkEvent
import com.avek.chat.core.model.settings.RouteSpec
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.emptyFlow
import kotlinx.coroutines.flow.toList
import kotlinx.coroutines.launch
import kotlinx.coroutines.test.TestScope
import kotlinx.coroutines.test.UnconfinedTestDispatcher
import kotlinx.coroutines.test.advanceTimeBy
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class InMemoryPairedPcStore(initial: PairedPc? = null) : PairedPcStore {
    private val state = MutableStateFlow(initial)
    override val pc: StateFlow<PairedPc?> = state
    override fun save(pc: PairedPc) { state.value = pc }
    override fun update(transform: (PairedPc) -> PairedPc) { state.value = state.value?.let(transform) }
    override fun clear() { state.value = null }
}

@OptIn(ExperimentalCoroutinesApi::class)
class LinkRepositoryTest {

    private class Fixture(
        val scope: TestScope,
        val server: FakeHarnessServer,
        val store: InMemoryPairedPcStore,
        val repo: DefaultLinkRepository,
        val events: MutableList<LinkEvent>,
        val serverEpochHolder: FakeHarnessServer = server,
    ) {
        val subscribes get() = server.connections.flatMap { it.requestsFor("subscribe") }
        fun topics(args: kotlinx.serialization.json.JsonObject) = args["topics"]!!.jsonArray.map { it.jsonPrimitive.content }
    }

    private suspend fun TestScope.fixture(
        paired: Boolean = true,
        configure: FakeHarnessServer.() -> Unit = {},
        specs: List<RouteSpec> = listOf(RouteSpec.Host("10.0.0.2", 7810)),
    ): Fixture {
        val server = FakeHarnessServer(backgroundScope).apply(configure)
        // Pair once (the PC remembers the device), then hand the credentials to the store.
        val (client, serverSide) = InMemoryChannel.pair()
        backgroundScope.launch { server.serve(serverSide) }
        val grant = Handshake().pair(client, "ABCDEFGHJKLM", "Tablet")
        val store = InMemoryPairedPcStore(
            if (paired) PairedPc(grant.deviceId, grant.deviceSecret, grant.serverId, grant.serverName, "Tablet") else null,
        )
        val channels = ChannelFactory { target ->
            val (c, s) = InMemoryChannel.pair(target.host, target.port)
            backgroundScope.launch { server.serve(s) }
            c
        }
        val repo = DefaultLinkRepository(
            store = store,
            routeSpecs = { specs },
            routeFactory = RouteFactory(channels, BeaconSource { emptyFlow() }),
            binding = NoWifiBinding,
            handshake = Handshake(),
            scope = backgroundScope,
            nowMs = { testScheduler.currentTime },
            attemptTimeoutMs = 5_000,
        )
        val events = mutableListOf<LinkEvent>()
        backgroundScope.launch(UnconfinedTestDispatcher(testScheduler)) { repo.events.collect { events += it } }
        return Fixture(this, server, store, repo, events)
    }

    @Test
    fun `connect reaches Connected, subscribes to all six topics and announces a refresh`() = runTest {
        val f = fixture()
        assertEquals(ConnectionState.Disconnected, f.repo.state.value)

        f.repo.connect()
        advanceTimeBy(2_000)

        val state = f.repo.state.value as ConnectionState.Connected
        assertEquals("Test PC", state.serverName)
        assertEquals("host 10.0.0.2:7810", state.routeName)
        assertEquals("e_1", f.repo.ready.value?.epoch)
        assertEquals(1, f.subscribes.size)
        assertEquals(listOf("stream", "turn", "ask", "chats", "models", "downloads"), f.topics(f.subscribes.single()))
        assertTrue(f.events.contains(LinkEvent.Refresh))
    }

    @Test
    fun `without a pairing the state is NotPaired`() = runTest {
        val f = fixture(paired = false)
        f.repo.connect()
        advanceTimeBy(1_000)
        assertEquals(ConnectionState.NotPaired, f.repo.state.value)
        assertTrue(f.server.connections.isEmpty())
    }

    @Test
    fun `the background profile subscribes to ask, turn and downloads only`() = runTest {
        val f = fixture()
        f.repo.connect()
        advanceTimeBy(2_000)

        f.repo.setProfile(LinkProfile.BACKGROUND)
        advanceTimeBy(500)
        assertEquals(listOf("ask", "turn", "downloads"), f.topics(f.subscribes.last()))

        f.repo.setProfile(LinkProfile.FOREGROUND)
        advanceTimeBy(500)
        assertEquals(LinkProfile.FOREGROUND.topics, f.topics(f.subscribes.last()))
        assertEquals("a subscribe REPLACES the set, so every profile change sends one", 3, f.subscribes.size)
    }

    @Test
    fun `a profile chosen before connecting is used for the first subscribe`() = runTest {
        val f = fixture()
        f.repo.setProfile(LinkProfile.BACKGROUND)
        f.repo.connect()
        advanceTimeBy(2_000)
        assertEquals(listOf("ask", "turn", "downloads"), f.topics(f.subscribes.single()))
    }

    @Test
    fun `after a reconnect the app subscribes again with the profile in effect`() = runTest {
        val f = fixture()
        f.repo.connect()
        advanceTimeBy(2_000)
        f.repo.setProfile(LinkProfile.BACKGROUND)
        advanceTimeBy(500)
        val firstConnection = f.server.connections.single()

        firstConnection.close(1006, "wifi dropped")
        advanceTimeBy(500)
        assertTrue("reconnecting", f.repo.state.value is ConnectionState.Connecting)
        advanceTimeBy(3_000)

        assertTrue(f.repo.state.value is ConnectionState.Connected)
        assertEquals(2, f.server.connections.size)
        val secondSubscribes = f.server.connections.last().requestsFor("subscribe")
        assertEquals(1, secondSubscribes.size)
        assertEquals(listOf("ask", "turn", "downloads"), f.topics(secondSubscribes.single()))
    }

    @Test
    fun `a reconnect to the same harness resumes after subscribing, with the highest seq seen`() = runTest {
        val f = fixture()
        f.repo.connect()
        advanceTimeBy(2_000)
        val first = f.server.connections.single()
        first.sendEvent("answer.delta", obj { put("chatId", "c1"); put("promptId", "p1"); put("text", "Hi"); put("offset", 0) }, seq = 41)
        first.sendEvent("answer.delta", obj { put("chatId", "c1"); put("promptId", "p1"); put("text", "!"); put("offset", 2) }, seq = 42)
        advanceTimeBy(100)
        assertEquals(2, f.events.filterIsInstance<LinkEvent.AnswerDelta>().size)

        first.close(1006, "dropped")
        advanceTimeBy(4_000)

        val second = f.server.connections.last()
        assertEquals(listOf("subscribe", "resume"), second.requests.map { it.first }.filter { it == "subscribe" || it == "resume" })
        val resume = second.requestsFor("resume").single()
        assertEquals("e_1", resume["epoch"]!!.jsonPrimitive.content)
        assertEquals("42", resume["lastSeq"]!!.jsonPrimitive.content)
    }

    @Test
    fun `a restarted harness (new epoch) is not resumed`() = runTest {
        val f = fixture()
        f.repo.connect()
        advanceTimeBy(2_000)
        f.server.connections.single().sendEvent("status", obj { put("phase", "p"); put("state", "start"); put("text", "t") }, seq = 7)
        advanceTimeBy(100)

        f.server.epoch = "e_2"
        f.server.connections.single().close(1006, "harness restarted")
        advanceTimeBy(4_000)

        val second = f.server.connections.last()
        assertTrue(second.requestsFor("resume").isEmpty())
        assertEquals("e_2", f.store.pc.value?.epoch)
        assertEquals(0L, f.store.pc.value?.lastSeq)
    }

    @Test
    fun `pending asks from ready are delivered as ask requests`() = runTest {
        val f = fixture(configure = {
            pendingAsks = listOf(obj { put("askId", "k_1"); put("kind", "approval"); put("summary", "Run npm install?") })
        })
        f.repo.connect()
        advanceTimeBy(2_000)
        val ask = f.events.filterIsInstance<LinkEvent.AskRequest>().single()
        assertEquals("k_1", ask.data.askId)
        assertEquals("Run npm install?", ask.data.summary)
    }

    @Test
    fun `the last host and port are remembered after connecting`() = runTest {
        val f = fixture()
        f.repo.connect()
        advanceTimeBy(2_000)
        assertEquals("10.0.0.2", f.store.pc.value?.lastHost)
        assertEquals(7810, f.store.pc.value?.lastPort)
    }

    @Test
    fun `server events are decoded and published`() = runTest {
        val f = fixture()
        f.repo.connect()
        advanceTimeBy(2_000)
        f.server.connections.single().sendEvent("turn.completed", obj {
            put("chatId", "c1"); put("promptId", "p1"); put("stopReason", "end"); put("durationMs", 1200); put("thinkingMs", 300)
            put("title", "Trip plan"); put("preview", "Day 1: ...")
        })
        advanceTimeBy(100)
        val completed = f.events.filterIsInstance<LinkEvent.TurnCompleted>().single()
        assertEquals("Trip plan", completed.data.title)
        assertEquals(1L, completed.seq)
    }

    @Test
    fun `call and callList pass through to the server and fail when not connected`() = runTest {
        val f = fixture()
        try {
            f.repo.call("ping")
            fail("not connected")
        } catch (e: RpcException) {
            assertEquals(RpcException.NOT_CONNECTED, e.code)
        }
        f.repo.connect()
        advanceTimeBy(2_000)
        f.server.handlers["chats.list"] = { _, _ -> Reply.Parts(listOf(listPart(listOf(obj { put("chatId", "c1") }), 1, null))) }
        val parts = f.repo.callList("chats.list", obj { put("limit", 20) }).toList()
        assertEquals(1, parts.single().items.size)
        assertNotNull(f.repo.call("ping"))
    }

    @Test
    fun `disconnect closes the link and stops reconnecting`() = runTest {
        val f = fixture()
        f.repo.connect()
        advanceTimeBy(2_000)
        f.repo.disconnect()
        advanceTimeBy(60_000)

        assertEquals(ConnectionState.Disconnected, f.repo.state.value)
        assertEquals("no new connection after disconnect", 1, f.server.connections.size)
        assertNull(f.repo.ready.value)
        try {
            f.repo.call("ping")
            fail("not connected")
        } catch (e: RpcException) {
            assertEquals(RpcException.NOT_CONNECTED, e.code)
        }
    }

    @Test
    fun `a bye with reason revoked is fatal`() = runTest {
        val f = fixture()
        f.repo.connect()
        advanceTimeBy(2_000)
        f.server.connections.single().sendEvent("bye", obj { put("reason", "revoked") }, seq = null)
        advanceTimeBy(5_000)
        assertTrue(f.repo.state.value is ConnectionState.Failed)
        assertEquals(1, f.server.connections.size)
    }

    @Test
    fun `a device the PC rejects after the proof (4401) fails fatally without retrying`() = runTest {
        val f = fixture(configure = { rejectProof = true })
        f.repo.connect()
        advanceTimeBy(30_000)
        assertTrue(f.repo.state.value is ConnectionState.Failed)
        assertEquals("one attempt only", 1, f.server.sessionHellos)
    }

    @Test
    fun `a server that cannot prove the secret is treated as not our PC and retried with back-off`() = runTest {
        val f = fixture()
        f.server.corruptServerMac = true
        f.repo.connect()
        advanceTimeBy(10_000)
        val state = f.repo.state.value
        assertTrue("still trying, not failed: $state", state is ConnectionState.Connecting)
        assertFalse(f.server.sawSessionProof)
    }
}
