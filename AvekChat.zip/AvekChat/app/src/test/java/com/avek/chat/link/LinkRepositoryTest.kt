package com.avek.chat.link

import com.avek.chat.core.link.DefaultLinkRepository
import com.avek.chat.core.link.LinkProfile
import com.avek.chat.core.link.RekeyOutcome
import com.avek.chat.core.link.crypto.PairingResult
import com.avek.chat.core.link.crypto.SessionHandshake
import com.avek.chat.core.link.discovery.KnockClient
import com.avek.chat.core.link.discovery.KnockSchedule
import com.avek.chat.core.link.route.ConnectionState
import com.avek.chat.core.link.route.NoNetworkEnvironment
import com.avek.chat.core.link.route.RouteKind
import com.avek.chat.core.link.route.RouteMode
import com.avek.chat.core.link.rpc.RpcException
import com.avek.chat.core.link.store.DeviceKey
import com.avek.chat.core.link.store.FilePairedPcStore
import com.avek.chat.core.link.store.GrantSecrets
import com.avek.chat.core.link.store.PairedPc
import com.avek.chat.core.link.store.PairedPcStore
import com.avek.chat.core.link.store.PendingRekey
import com.avek.chat.core.link.store.SoftwareIdentityVault
import com.avek.chat.core.link.store.SoftwareSecretVault
import com.avek.chat.core.link.transport.ChannelFactory
import com.avek.chat.core.link.transport.NoWifiBinding
import com.avek.chat.core.link.wire.LinkEvent
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.toList
import kotlinx.coroutines.launch
import kotlinx.coroutines.test.TestScope
import kotlinx.coroutines.test.UnconfinedTestDispatcher
import kotlinx.coroutines.test.advanceTimeBy
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class InMemoryPairedPcStore(initial: PairedPc? = null, initialNotice: String? = null) : PairedPcStore {
    private val state = MutableStateFlow(initial)
    private val _notice = MutableStateFlow(initialNotice)
    override val pc: StateFlow<PairedPc?> = state
    override val notice: StateFlow<String?> = _notice
    override fun save(pc: PairedPc) { state.value = pc; _notice.value = null }
    override fun update(transform: (PairedPc) -> PairedPc) { state.value = state.value?.let(transform) }
    override fun clear() { state.value = null }
    override fun clearNotice() { _notice.value = null }
}

/** Pairs [alias] of [identity] with [server] (the PC remembers the device) and returns what the app would store. */
suspend fun TestScope.pairWith(
    server: FakeHarnessServer,
    identity: SoftwareIdentityVault = SoftwareIdentityVault(),
    secrets: SoftwareSecretVault = SoftwareSecretVault(),
    alias: String = TEST_ALIAS,
): PairedPc {
    identity.create(alias)
    val (client, serverSide) = InMemoryChannel.pair()
    backgroundScope.launch { server.serve(serverSide) }
    val grant = (testPairing().pair(client, DeviceKey(identity, alias), FakeHarnessServer.CODE.toByteArray(), "Tablet") as PairingResult.Paired).grant
    return PairedPc(grant.deviceId, alias, grant.serverId, grant.serverName, grant.serverPub, "Tablet", GrantSecrets(secrets).seal(grant.secrets))
}

/** The Wi-Fi route of the tests: a knock answered by the fake PC's listener and a channel straight to the fake PC. */
class TestNetwork(scope: TestScope, val server: FakeHarnessServer) {
    var reachable = true
    var opens = 0
    val listener = FakeKnockListener(
        server.identity,
        { server.devices.mapValues { it.value.pub } },
        alsoKeys = { id -> listOfNotNull(server.devices[id]?.nextPub) },
        pcHost = "10.0.0.2",
    )
    val udp = FakeUdpTransport({ scope.testScheduler.currentTime }, local = null, respond = { sent -> if (reachable) listener.respond(sent) else emptyList() })
    val knock = KnockClient(udp, { 1_800_000_000_000 }, schedule = KnockSchedule(repeatsAtMs = listOf(0L), finalWaitMs = 200))
    val channels = ChannelFactory { target ->
        opens++
        val (c, s) = InMemoryChannel.pair(target.remote.host, target.remote.port)
        scope.backgroundScope.launch { server.serve(s) }
        c
    }
}

@OptIn(ExperimentalCoroutinesApi::class)
class LinkRepositoryTest {

    private class Fixture(
        val scope: TestScope,
        val server: FakeHarnessServer,
        val store: InMemoryPairedPcStore,
        val identity: SoftwareIdentityVault,
        val vault: SoftwareSecretVault,
        val repo: DefaultLinkRepository,
        val events: MutableList<LinkEvent>,
        val net: TestNetwork,
    ) {
        val subscribes get() = server.connections.flatMap { it.requestsFor("subscribe") }
        fun topics(args: kotlinx.serialization.json.JsonObject) = args["topics"]!!.jsonArray.map { it.jsonPrimitive.content }
    }

    private fun TestScope.repoFor(
        store: PairedPcStore,
        identity: SoftwareIdentityVault,
        vault: SoftwareSecretVault,
        net: TestNetwork,
        mode: RouteMode = RouteMode.Auto,
    ) = DefaultLinkRepository(
        store = store,
        identity = identity,
        vault = vault,
        knock = net.knock,
        channels = net.channels,
        environment = NoNetworkEnvironment,
        binding = NoWifiBinding,
        handshake = SessionHandshake(),
        routeMode = MutableStateFlow(mode),
        scope = backgroundScope,
        nowMs = { 1_800_000_000_000 + testScheduler.currentTime },
    )

    private suspend fun TestScope.fixture(
        paired: Boolean = true,
        configure: FakeHarnessServer.() -> Unit = {},
    ): Fixture {
        val server = FakeHarnessServer(backgroundScope).apply(configure)
        val identity = SoftwareIdentityVault()
        val vault = SoftwareSecretVault()
        val pc = pairWith(server, identity, vault)
        val store = InMemoryPairedPcStore(if (paired) pc else null)
        val net = TestNetwork(this, server)
        val repo = repoFor(store, identity, vault, net)
        val events = mutableListOf<LinkEvent>()
        backgroundScope.launch(UnconfinedTestDispatcher(testScheduler)) { repo.events.collect { events += it } }
        return Fixture(this, server, store, identity, vault, repo, events, net)
    }

    @Test
    fun `connect races the routes, reaches Connected by Wi-Fi, asks routes-get, then subscribes`() = runTest {
        val f = fixture()
        assertEquals(ConnectionState.Disconnected, f.repo.state.value)
        f.repo.connect()
        advanceTimeBy(2_000)

        val state = f.repo.state.value as ConnectionState.Connected
        assertEquals("Test PC", state.pcName)
        assertEquals(RouteKind.WIFI, state.route)
        assertEquals("10.0.0.2:7810", state.address)
        assertEquals(RouteKind.WIFI, f.repo.currentRoute)
        val ops = f.server.connections.single().requests.map { it.first }
        assertEquals(listOf("routes.get", "subscribe"), ops.take(2))
        assertEquals(listOf("stream", "turn", "ask", "chats", "models", "downloads", "timeline", "routes"), f.topics(f.subscribes.single()))
        assertTrue(f.events.contains(LinkEvent.Refresh))
        assertEquals("10.0.0.2", f.store.pc.value?.routes?.wifi?.addresses?.single()?.address)
        assertNotNull(f.store.pc.value?.lastConnectedAt)
    }

    @Test
    fun `routes-changed updates the stored routes`() = runTest {
        val f = fixture()
        f.repo.connect()
        advanceTimeBy(2_000)
        f.server.connections.single().sendEvent("routes.changed", obj {
            put("wifi", obj { put("addresses", JsonArray(emptyList())); put("port", 7810); put("knockPort", 7811) })
            put("tailscale", obj { put("host", "100.64.1.2"); put("dns", "legion.tail1234.ts.net"); put("port", 7810); put("knockPort", 7811) })
            put("ngrok", obj { put("url", "https://my-pc.ngrok-free.dev"); put("state", "online") })
        })
        advanceTimeBy(100)
        val routes = f.store.pc.value!!.routes!!
        assertEquals("100.64.1.2", routes.tailscale!!.host)
        assertEquals("my-pc.ngrok-free.dev", routes.ngrokHost)
        assertTrue(f.events.any { it is LinkEvent.RoutesChanged })
    }

    @Test
    fun `waking before ready shows as WakingPc and ends Connected`() = runTest {
        val f = fixture(configure = { wakingBeforeReady = true })
        val seen = mutableListOf<ConnectionState>()
        backgroundScope.launch(UnconfinedTestDispatcher(testScheduler)) { f.repo.state.collect { seen += it } }
        f.repo.connect()
        advanceTimeBy(2_000)
        assertTrue(f.repo.state.value is ConnectionState.Connected)
        assertFalse((f.repo.state.value as ConnectionState.Connected).waking)
    }

    @Test
    fun `waking after ready marks the connection as waking until the answer comes`() = runTest {
        val f = fixture()
        f.server.handlers["models.list"] = { _, connection ->
            connection.sendEvent("waking", obj { put("phase", "core") }, seq = null)
            Reply.Silence
        }
        f.repo.connect()
        advanceTimeBy(2_000)
        backgroundScope.launch { runCatching { f.repo.call("models.list", obj { put("limit", 1) }) } }
        advanceTimeBy(100)
        assertTrue((f.repo.state.value as ConnectionState.Connected).waking)
        // No reply for 20 s: still waiting (requests do not time out before 30 s while waking).
        advanceTimeBy(20_000)
        assertTrue((f.repo.state.value as ConnectionState.Connected).waking)
    }

    @Test
    fun `without a pairing the state is NeedsPairing`() = runTest {
        val f = fixture(paired = false)
        f.repo.connect()
        advanceTimeBy(1_000)
        assertEquals(ConnectionState.NeedsPairing(null), f.repo.state.value)
        assertTrue(f.server.connections.isEmpty())
    }

    @Test
    fun `an unreachable PC shows a failure per route, backs off, and a kick tries at once`() = runTest {
        val f = fixture()
        f.net.reachable = false
        f.repo.connect()
        advanceTimeBy(3_000)
        val state = f.repo.state.value as ConnectionState.Unreachable
        assertEquals(3, state.failures.size)
        assertEquals("not-found on Wi-Fi", com.avek.chat.core.link.route.FailureReason.NotFound, state.failures[0].reason)
        assertEquals(com.avek.chat.core.link.route.FailureReason.Skipped, state.failures[1].reason)
        assertEquals(com.avek.chat.core.link.route.FailureReason.Skipped, state.failures[2].reason)

        f.net.reachable = true
        f.repo.connect() // the app came back on screen: try now
        advanceTimeBy(1_000)
        assertTrue(f.repo.state.value is ConnectionState.Connected)
    }

    @Test
    fun `the background profile subscribes to ask, turn and downloads only`() = runTest {
        val f = fixture()
        f.repo.connect()
        advanceTimeBy(2_000)
        f.repo.setProfile(LinkProfile.BACKGROUND)
        advanceTimeBy(500)
        assertEquals(listOf("ask", "turn", "downloads"), f.topics(f.subscribes.last()))
        f.repo.setProfile(LinkProfile.FOREGROUND)
        advanceTimeBy(500)
        assertEquals(LinkProfile.FOREGROUND.topics, f.topics(f.subscribes.last()))
    }

    @Test
    fun `a reconnect to the same harness resumes before subscribing, with the highest seq seen`() = runTest {
        val f = fixture()
        f.repo.connect()
        advanceTimeBy(2_000)
        val first = f.server.connections.single()
        first.sendEvent("answer.delta", obj { put("chatId", "c1"); put("promptId", "p1"); put("text", "Hi"); put("offset", 0) }, seq = 41)
        first.sendEvent("answer.delta", obj { put("chatId", "c1"); put("promptId", "p1"); put("text", "!"); put("offset", 2) }, seq = 42)
        advanceTimeBy(100)
        first.close(1006, "dropped")
        advanceTimeBy(4_000)

        val second = f.server.connections.last()
        assertEquals(listOf("routes.get", "resume", "subscribe"), second.requests.map { it.first }.filter { it in setOf("routes.get", "resume", "subscribe") })
        val resume = second.requestsFor("resume").single()
        assertEquals("e_1", resume["epoch"]!!.jsonPrimitive.content)
        assertEquals("42", resume["lastSeq"]!!.jsonPrimitive.content)
    }

    @Test
    fun `pending asks from ready are delivered as ask requests`() = runTest {
        val f = fixture(configure = {
            pendingAsks = listOf(obj { put("askId", "k_1"); put("kind", "approval"); put("summary", "Run npm install?") })
        })
        f.repo.connect()
        advanceTimeBy(2_000)
        assertEquals("k_1", f.events.filterIsInstance<LinkEvent.AskRequest>().single().data.askId)
    }

    @Test
    fun `the last Wi-Fi host is remembered after connecting`() = runTest {
        val f = fixture()
        f.repo.connect()
        advanceTimeBy(2_000)
        assertEquals("10.0.0.2", f.store.pc.value?.lastWifiHost)
        assertEquals(7810, f.store.pc.value?.lastWifiPort)
    }

    @Test
    fun `call and callList pass through to the server and fail when not connected`() = runTest {
        val f = fixture()
        try {
            f.repo.call("ping")
            fail("not connected")
        } catch (e: RpcException) {
            assertEquals(RpcException.NOT_CONNECTED, e.code)
        }
        f.repo.connect()
        advanceTimeBy(2_000)
        f.server.handlers["chats.list"] = { _, _ -> Reply.Parts(listOf(listPart(listOf(obj { put("chatId", "c1") }), 1, null))) }
        val parts = f.repo.callList("chats.list", obj { put("limit", 20) }).toList()
        assertEquals(1, parts.single().items.size)
        assertNotNull(f.repo.call("ping"))
    }

    @Test
    fun `disconnect closes the link and stops reconnecting`() = runTest {
        val f = fixture()
        f.repo.connect()
        advanceTimeBy(2_000)
        f.repo.disconnect()
        advanceTimeBy(60_000)
        assertEquals(ConnectionState.Disconnected, f.repo.state.value)
        assertEquals(1, f.server.connections.size)
        assertNull(f.repo.ready.value)
    }

    @Test
    fun `a bye with reason revoked means the PC forgot this device`() = runTest {
        val f = fixture()
        f.repo.connect()
        advanceTimeBy(2_000)
        f.server.connections.single().sendEvent("bye", obj { put("reason", "revoked") }, seq = null)
        advanceTimeBy(5_000)
        assertEquals(ConnectionState.Forgotten, f.repo.state.value)
    }

    @Test
    fun `a 4401 after the proof is Forgotten without retrying, and the grant is kept`() = runTest {
        val f = fixture(configure = { rejectProof = true })
        f.repo.connect()
        advanceTimeBy(30_000)
        assertEquals(ConnectionState.Forgotten, f.repo.state.value)
        assertEquals("one attempt only", 1, f.server.sessionHellos)
        assertNotNull("kept until the person confirms", f.store.pc.value)
    }

    @Test
    fun `a PC that cannot prove the pinned key is not ours and is not retried`() = runTest {
        val f = fixture()
        f.server.impostor = SoftwareIdentityVault().also { it.create(FakeHarnessServer.ALIAS) }
        f.repo.connect()
        advanceTimeBy(30_000)
        assertEquals(ConnectionState.Failed("This is not the PC you paired with."), f.repo.state.value)
        assertEquals(1, f.server.sessionHellos)
        assertFalse(f.server.sawSessionProof)
    }

    @Test
    fun `reconnect clears a stopped state and tries again`() = runTest {
        val f = fixture(configure = { rejectProof = true })
        f.repo.connect()
        advanceTimeBy(5_000)
        assertEquals(ConnectionState.Forgotten, f.repo.state.value)
        f.server.rejectProof = false
        f.repo.reconnect()
        advanceTimeBy(2_000)
        assertTrue(f.repo.state.value is ConnectionState.Connected)
    }

    @Test
    fun `a wiped v3 pairing shows its notice while pairing is needed`() = runTest {
        val f = fixture(paired = false)
        val store = InMemoryPairedPcStore(null, FilePairedPcStore.MIGRATION_NOTICE)
        val repo = repoFor(store, SoftwareIdentityVault(), SoftwareSecretVault(), f.net)
        runCurrent()
        assertEquals(ConnectionState.NeedsPairing(FilePairedPcStore.MIGRATION_NOTICE), repo.state.value)
    }

    @Test
    fun `forget tells the PC and deletes the keys, the sealed secrets and the stored PC`() = runTest {
        val f = fixture()
        f.repo.connect()
        advanceTimeBy(2_000)
        f.repo.forget()
        advanceTimeBy(100)
        assertNull(f.store.pc.value)
        assertTrue(f.identity.aliases().isEmpty())
        assertTrue(f.server.devices.isEmpty())
        assertEquals(ConnectionState.NeedsPairing(null), f.repo.state.value)
    }

    // ------------------------------------------------------------------ key replacement (section 4.1)

    @Test
    fun `replacing the keys connects with slot next, then deletes the old key and secrets`() = runTest {
        val f = fixture()
        f.repo.connect()
        advanceTimeBy(2_000)
        val before = f.store.pc.value!!
        val outcome = run {
            var result: RekeyOutcome? = null
            backgroundScope.launch { result = f.repo.replaceKeys() }
            advanceTimeBy(5_000)
            result
        }
        assertEquals(RekeyOutcome.Done, outcome)
        val after = f.store.pc.value!!
        assertEquals("the device id never changes", before.deviceId, after.deviceId)
        assertEquals("avek.identity.2", after.identityAlias)
        assertNull(after.pendingRekey)
        assertFalse("old key deleted", f.identity.exists(TEST_ALIAS))
        assertEquals(listOf("avek.identity.2"), f.identity.aliases())
        assertTrue(f.server.helloSlots.contains("next"))
        assertArrayEquals(f.identity.publicKey("avek.identity.2"), f.server.devices.getValue(after.deviceId).pub)
        assertFalse("new secrets", before.sealedSecrets.contentEquals(after.sealedSecrets))
        assertTrue(f.repo.state.value is ConnectionState.Connected)
    }

    /** A rotation interrupted after [step]: the stored state at that moment, opened by a fresh app instance. */
    private suspend fun TestScope.interrupted(step: Int, deadlinePassed: Boolean = false): Fixture {
        val f = fixture()
        // Steps 1-3 by hand: the new key, device.rekey on the PC, the answer.
        f.repo.connect()
        advanceTimeBy(2_000)
        val pc = f.store.pc.value!!
        f.identity.create("avek.identity.2")
        val newPub = f.identity.publicKey("avek.identity.2")
        val device = f.server.devices.getValue(pc.deviceId)
        device.nextPub = newPub
        device.nextDk = ByteArray(32) { 3 }
        device.nextRk = ByteArray(32) { 4 }
        val sealed = GrantSecrets(f.vault).seal(com.avek.chat.core.link.store.DeviceSecrets(device.nextDk!!.copyOf(), device.nextRk!!.copyOf()))
        f.repo.disconnect()
        advanceTimeBy(100)
        val now = 1_800_000_000_000 + testScheduler.currentTime
        if (step >= 3) {
            f.store.update { it.copy(pendingRekey = PendingRekey("avek.identity.2", sealed, if (deadlinePassed) now - 1 else now + 600_000)) }
        }
        if (step >= 5) {
            // The PC promoted the new key (ready arrived), but the app died before storing that.
            device.pub = device.nextPub!!; device.dk = device.nextDk!!; device.rk = device.nextRk!!
            device.nextPub = null; device.nextDk = null; device.nextRk = null
        }
        val repo = repoFor(f.store, f.identity, f.vault, f.net)
        return Fixture(this, f.server, f.store, f.identity, f.vault, repo, mutableListOf(), f.net)
    }

    @Test
    fun `a crash after step 3 (stored, not reconnected) finishes the replacement on the next start`() = runTest {
        val f = interrupted(step = 3)
        f.repo.connect()
        advanceTimeBy(3_000)
        assertTrue(f.repo.state.value is ConnectionState.Connected)
        assertEquals("avek.identity.2", f.store.pc.value!!.identityAlias)
        assertNull(f.store.pc.value!!.pendingRekey)
        assertEquals(listOf("avek.identity.2"), f.identity.aliases())
    }

    @Test
    fun `a crash after step 5 (the PC promoted, the app did not) still ends on the new key`() = runTest {
        val f = interrupted(step = 5)
        f.repo.connect()
        advanceTimeBy(6_000)
        assertTrue(f.repo.state.value is ConnectionState.Connected)
        assertEquals("avek.identity.2", f.store.pc.value!!.identityAlias)
        assertNull(f.store.pc.value!!.pendingRekey)
        assertFalse(f.identity.exists(TEST_ALIAS))
    }

    @Test
    fun `a crash before the answer was stored (step 2) keeps the old key and cleans up the new one`() = runTest {
        val f = interrupted(step = 2)
        assertFalse("the orphan key is deleted at start", f.identity.exists("avek.identity.2"))
        f.repo.connect()
        advanceTimeBy(3_000)
        assertTrue(f.repo.state.value is ConnectionState.Connected)
        assertEquals(TEST_ALIAS, f.store.pc.value!!.identityAlias)
    }

    @Test
    fun `after the grace the old key is used and the pending one is dropped`() = runTest {
        val f = interrupted(step = 3, deadlinePassed = true)
        // The PC's grace also ended: it no longer accepts the announced key.
        f.server.devices.values.forEach { it.nextPub = null; it.nextDk = null; it.nextRk = null }
        f.repo.connect()
        advanceTimeBy(3_000)
        assertTrue(f.repo.state.value is ConnectionState.Connected)
        assertEquals(TEST_ALIAS, f.store.pc.value!!.identityAlias)
        assertNull(f.store.pc.value!!.pendingRekey)
        assertFalse(f.identity.exists("avek.identity.2"))
    }
}
