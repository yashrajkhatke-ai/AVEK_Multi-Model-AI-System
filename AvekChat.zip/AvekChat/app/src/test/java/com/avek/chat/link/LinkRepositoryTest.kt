package com.avek.chat.link

import com.avek.chat.core.link.DefaultLinkRepository
import com.avek.chat.core.link.LinkProfile
import com.avek.chat.core.link.crypto.Handshake
import com.avek.chat.core.link.route.ConnectionState
import com.avek.chat.core.link.route.Reached
import com.avek.chat.core.link.route.Route
import com.avek.chat.core.link.rpc.RpcException
import com.avek.chat.core.link.store.FilePairedPcStore
import com.avek.chat.core.link.store.PairedPc
import com.avek.chat.core.link.store.PairedPcStore
import com.avek.chat.core.link.store.SoftwareIdentityVault
import com.avek.chat.core.link.transport.NoWifiBinding
import com.avek.chat.core.link.wire.LinkEvent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.toList
import kotlinx.coroutines.launch
import kotlinx.coroutines.test.TestScope
import kotlinx.coroutines.test.UnconfinedTestDispatcher
import kotlinx.coroutines.test.advanceTimeBy
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class InMemoryPairedPcStore(initial: PairedPc? = null, initialNotice: String? = null) : PairedPcStore {
    private val state = MutableStateFlow(initial)
    private val _notice = MutableStateFlow(initialNotice)
    override val pc: StateFlow<PairedPc?> = state
    override val notice: StateFlow<String?> = _notice
    override fun save(pc: PairedPc) { state.value = pc; _notice.value = null }
    override fun update(transform: (PairedPc) -> PairedPc) { state.value = state.value?.let(transform) }
    override fun clear() { state.value = null }
    override fun clearNotice() { _notice.value = null }
}

/** A route straight to the fake PC (the knock is tested separately); [reachable] = false makes it not answer. */
class FakeRoute(private val scope: CoroutineScope, private val server: FakeHarnessServer) : Route {
    override val kind = "test"
    var reachable = true
    var reaches = 0

    override suspend fun reach(pc: PairedPc): Reached? {
        reaches++
        if (!reachable) return null
        val (c, s) = InMemoryChannel.pair("10.0.0.2", 7810)
        scope.launch { server.serve(s) }
        return Reached(c, "10.0.0.2:7810")
    }
}

/** Pairs a fresh identity with [server] (the PC remembers the device) and returns what the app would store. */
suspend fun TestScope.pairWith(server: FakeHarnessServer, identity: SoftwareIdentityVault = SoftwareIdentityVault()): PairedPc {
    val (client, serverSide) = InMemoryChannel.pair()
    backgroundScope.launch { server.serve(serverSide) }
    val paired = Handshake().pair(client, identity, "Tablet", confirm = { true })
    return PairedPc(paired.serverId, paired.serverName, paired.serverPub, "Tablet")
}

@OptIn(ExperimentalCoroutinesApi::class)
class LinkRepositoryTest {

    private class Fixture(
        val scope: TestScope,
        val server: FakeHarnessServer,
        val store: InMemoryPairedPcStore,
        val repo: DefaultLinkRepository,
        val events: MutableList<LinkEvent>,
        val route: FakeRoute,
    ) {
        val subscribes get() = server.connections.flatMap { it.requestsFor("subscribe") }
        fun topics(args: kotlinx.serialization.json.JsonObject) = args["topics"]!!.jsonArray.map { it.jsonPrimitive.content }
    }

    private suspend fun TestScope.fixture(
        paired: Boolean = true,
        configure: FakeHarnessServer.() -> Unit = {},
    ): Fixture {
        val server = FakeHarnessServer(backgroundScope).apply(configure)
        val identity = SoftwareIdentityVault()
        val pc = pairWith(server, identity)
        val store = InMemoryPairedPcStore(if (paired) pc else null)
        val route = FakeRoute(backgroundScope, server)
        val repo = DefaultLinkRepository(
            store = store,
            identity = identity,
            route = route,
            binding = NoWifiBinding,
            handshake = Handshake(),
            scope = backgroundScope,
            nowMs = { testScheduler.currentTime },
            attemptTimeoutMs = 5_000,
        )
        val events = mutableListOf<LinkEvent>()
        backgroundScope.launch(UnconfinedTestDispatcher(testScheduler)) { repo.events.collect { events += it } }
        return Fixture(this, server, store, repo, events, route)
    }

    @Test
    fun `connect reaches Connected, subscribes to the seven topics and announces a refresh`() = runTest {
        val f = fixture()
        assertEquals(ConnectionState.Disconnected, f.repo.state.value)

        f.repo.connect()
        advanceTimeBy(2_000)

        val state = f.repo.state.value as ConnectionState.Connected
        assertEquals("Test PC", state.pcName)
        assertEquals("10.0.0.2:7810", state.address)
        assertEquals("e_1", f.repo.ready.value?.epoch)
        assertEquals(1, f.subscribes.size)
        assertEquals(listOf("stream", "turn", "ask", "chats", "models", "downloads", "timeline"), f.topics(f.subscribes.single()))
        assertTrue(f.events.contains(LinkEvent.Refresh))
    }

    @Test
    fun `wanting the trace adds the seventh topic and dropping it removes it again`() = runTest {
        val f = fixture()
        f.repo.connect()
        advanceTimeBy(2_000)
        f.repo.setTraceWanted(true)
        advanceTimeBy(500)
        assertEquals(LinkProfile.FOREGROUND.topics + "trace", f.topics(f.subscribes.last()))
        f.repo.setTraceWanted(false)
        advanceTimeBy(500)
        assertEquals(LinkProfile.FOREGROUND.topics, f.topics(f.subscribes.last()))
    }

    @Test
    fun `without a pairing the state is NeedsPairing`() = runTest {
        val f = fixture(paired = false)
        f.repo.connect()
        advanceTimeBy(1_000)
        assertEquals(ConnectionState.NeedsPairing(null), f.repo.state.value)
        assertTrue(f.server.connections.isEmpty())
    }

    @Test
    fun `an unreachable PC is retried with back-off and a kick cuts the wait short`() = runTest {
        val f = fixture()
        f.route.reachable = false
        f.repo.connect()
        runCurrent()
        val state = f.repo.state.value as ConnectionState.Unreachable
        assertEquals(2_000L, state.retryAtMs!! - testScheduler.currentTime)
        assertEquals(1, f.route.reaches)
        advanceTimeBy(2_000)
        runCurrent()
        assertEquals(2, f.route.reaches)
        assertEquals(4_000L, (f.repo.state.value as ConnectionState.Unreachable).retryAtMs!! - testScheduler.currentTime)

        f.route.reachable = true
        f.repo.connect() // the app came back on screen: try now, not in 4 s
        runCurrent()
        advanceTimeBy(100)
        assertTrue(f.repo.state.value is ConnectionState.Connected)
    }

    @Test
    fun `the background profile subscribes to ask, turn and downloads only`() = runTest {
        val f = fixture()
        f.repo.connect()
        advanceTimeBy(2_000)

        f.repo.setProfile(LinkProfile.BACKGROUND)
        advanceTimeBy(500)
        assertEquals(listOf("ask", "turn", "downloads"), f.topics(f.subscribes.last()))

        f.repo.setProfile(LinkProfile.FOREGROUND)
        advanceTimeBy(500)
        assertEquals(LinkProfile.FOREGROUND.topics, f.topics(f.subscribes.last()))
        assertEquals("a subscribe REPLACES the set, so every profile change sends one", 3, f.subscribes.size)
    }

    @Test
    fun `a profile chosen before connecting is used for the first subscribe`() = runTest {
        val f = fixture()
        f.repo.setProfile(LinkProfile.BACKGROUND)
        f.repo.connect()
        advanceTimeBy(2_000)
        assertEquals(listOf("ask", "turn", "downloads"), f.topics(f.subscribes.single()))
    }

    @Test
    fun `after a reconnect the app subscribes again with the profile in effect`() = runTest {
        val f = fixture()
        f.repo.connect()
        advanceTimeBy(2_000)
        f.repo.setProfile(LinkProfile.BACKGROUND)
        advanceTimeBy(500)
        val firstConnection = f.server.connections.single()

        firstConnection.close(1006, "wifi dropped")
        advanceTimeBy(3_000)

        assertTrue(f.repo.state.value is ConnectionState.Connected)
        assertEquals(2, f.server.connections.size)
        val secondSubscribes = f.server.connections.last().requestsFor("subscribe")
        assertEquals(1, secondSubscribes.size)
        assertEquals(listOf("ask", "turn", "downloads"), f.topics(secondSubscribes.single()))
    }

    @Test
    fun `a reconnect to the same harness resumes before subscribing, with the highest seq seen`() = runTest {
        val f = fixture()
        f.repo.connect()
        advanceTimeBy(2_000)
        val first = f.server.connections.single()
        first.sendEvent("answer.delta", obj { put("chatId", "c1"); put("promptId", "p1"); put("text", "Hi"); put("offset", 0) }, seq = 41)
        first.sendEvent("answer.delta", obj { put("chatId", "c1"); put("promptId", "p1"); put("text", "!"); put("offset", 2) }, seq = 42)
        advanceTimeBy(100)
        assertEquals(2, f.events.filterIsInstance<LinkEvent.AnswerDelta>().size)

        first.close(1006, "dropped")
        advanceTimeBy(4_000)

        val second = f.server.connections.last()
        assertEquals(listOf("resume", "subscribe"), second.requests.map { it.first }.filter { it == "subscribe" || it == "resume" })
        val resume = second.requestsFor("resume").single()
        assertEquals("e_1", resume["epoch"]!!.jsonPrimitive.content)
        assertEquals("42", resume["lastSeq"]!!.jsonPrimitive.content)
    }

    @Test
    fun `a restarted harness (new epoch) is not resumed`() = runTest {
        val f = fixture()
        f.repo.connect()
        advanceTimeBy(2_000)
        f.server.connections.single().sendEvent("status", obj { put("phase", "p"); put("state", "start"); put("text", "t") }, seq = 7)
        advanceTimeBy(100)

        f.server.epoch = "e_2"
        f.server.connections.single().close(1006, "harness restarted")
        advanceTimeBy(4_000)

        val second = f.server.connections.last()
        assertTrue(second.requestsFor("resume").isEmpty())
        assertEquals("e_2", f.store.pc.value?.epoch)
        assertEquals(0L, f.store.pc.value?.lastSeq)
    }

    @Test
    fun `pending asks from ready are delivered as ask requests`() = runTest {
        val f = fixture(configure = {
            pendingAsks = listOf(obj { put("askId", "k_1"); put("kind", "approval"); put("summary", "Run npm install?") })
        })
        f.repo.connect()
        advanceTimeBy(2_000)
        val ask = f.events.filterIsInstance<LinkEvent.AskRequest>().single()
        assertEquals("k_1", ask.data.askId)
        assertEquals("Run npm install?", ask.data.summary)
    }

    @Test
    fun `the last host and port are remembered after connecting`() = runTest {
        val f = fixture()
        f.repo.connect()
        advanceTimeBy(2_000)
        assertEquals("10.0.0.2", f.store.pc.value?.lastHost)
        assertEquals(7810, f.store.pc.value?.lastPort)
    }

    @Test
    fun `server events are decoded and published`() = runTest {
        val f = fixture()
        f.repo.connect()
        advanceTimeBy(2_000)
        f.server.connections.single().sendEvent("turn.completed", obj {
            put("chatId", "c1"); put("promptId", "p1"); put("stopReason", "end"); put("durationMs", 1200); put("thinkingMs", 300)
            put("title", "Trip plan"); put("preview", "Day 1: ...")
        })
        advanceTimeBy(100)
        val completed = f.events.filterIsInstance<LinkEvent.TurnCompleted>().single()
        assertEquals("Trip plan", completed.data.title)
        assertEquals(1L, completed.seq)
    }

    @Test
    fun `call and callList pass through to the server and fail when not connected`() = runTest {
        val f = fixture()
        try {
            f.repo.call("ping")
            fail("not connected")
        } catch (e: RpcException) {
            assertEquals(RpcException.NOT_CONNECTED, e.code)
        }
        f.repo.connect()
        advanceTimeBy(2_000)
        f.server.handlers["chats.list"] = { _, _ -> Reply.Parts(listOf(listPart(listOf(obj { put("chatId", "c1") }), 1, null))) }
        val parts = f.repo.callList("chats.list", obj { put("limit", 20) }).toList()
        assertEquals(1, parts.single().items.size)
        assertNotNull(f.repo.call("ping"))
    }

    @Test
    fun `disconnect closes the link and stops reconnecting`() = runTest {
        val f = fixture()
        f.repo.connect()
        advanceTimeBy(2_000)
        f.repo.disconnect()
        advanceTimeBy(60_000)

        assertEquals(ConnectionState.Disconnected, f.repo.state.value)
        assertEquals("no new connection after disconnect", 1, f.server.connections.size)
        assertNull(f.repo.ready.value)
        try {
            f.repo.call("ping")
            fail("not connected")
        } catch (e: RpcException) {
            assertEquals(RpcException.NOT_CONNECTED, e.code)
        }
    }

    @Test
    fun `a bye with reason revoked means the PC forgot this device`() = runTest {
        val f = fixture()
        f.repo.connect()
        advanceTimeBy(2_000)
        f.server.connections.single().sendEvent("bye", obj { put("reason", "revoked") }, seq = null)
        advanceTimeBy(5_000)
        assertEquals(ConnectionState.Forgotten, f.repo.state.value)
        assertEquals(1, f.server.connections.size)
    }

    @Test
    fun `a device the PC rejects after the proof (4401) is Forgotten without retrying`() = runTest {
        val f = fixture(configure = { rejectProof = true })
        f.repo.connect()
        advanceTimeBy(30_000)
        assertEquals(ConnectionState.Forgotten, f.repo.state.value)
        assertEquals("one attempt only", 1, f.server.sessionHellos)
    }

    @Test
    fun `a PC that cannot prove the pinned key is not ours and is not retried`() = runTest {
        val f = fixture()
        f.server.impostor = SoftwareIdentityVault().also { it.create() }
        f.repo.connect()
        advanceTimeBy(30_000)
        assertEquals(ConnectionState.Failed("This is not the PC you paired with"), f.repo.state.value)
        assertEquals(1, f.server.sessionHellos)
        assertFalse(f.server.sawSessionProof)
    }

    @Test
    fun `reconnect clears a stopped state and tries again`() = runTest {
        val f = fixture(configure = { rejectProof = true })
        f.repo.connect()
        advanceTimeBy(5_000)
        assertEquals(ConnectionState.Forgotten, f.repo.state.value)
        f.server.rejectProof = false
        f.repo.reconnect()
        advanceTimeBy(2_000)
        assertTrue(f.repo.state.value is ConnectionState.Connected)
    }

    @Test
    fun `a wiped v2 pairing shows its notice while pairing is needed`() = runTest {
        val f = fixture(paired = false)
        val store = InMemoryPairedPcStore(null, FilePairedPcStore.MIGRATION_NOTICE)
        val repo = DefaultLinkRepository(store, SoftwareIdentityVault(), f.route, NoWifiBinding, Handshake(), backgroundScope, { testScheduler.currentTime })
        runCurrent()
        assertEquals(ConnectionState.NeedsPairing(FilePairedPcStore.MIGRATION_NOTICE), repo.state.value)
    }
}
