package com.avek.chat.link

import com.avek.chat.core.link.crypto.AvekProtocol
import com.avek.chat.core.link.crypto.FrameException
import com.avek.chat.core.link.crypto.FrameOpener
import com.avek.chat.core.link.crypto.FrameSealer
import com.avek.chat.core.link.crypto.Frames
import com.avek.chat.core.link.crypto.SecureCrypto
import com.avek.chat.core.link.store.SoftwareIdentityVault
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

/** Reproduces EVERY value of the harness's v4 `test-vectors.json` (AVEK-SEC/4). */
class CryptoVectorsTest {

    private fun hex(vararg path: String) = SecureCrypto.unhex(TestVectors.string(*path))
    private fun b64(vararg path: String) = SecureCrypto.unb64(TestVectors.string(*path))

    private val devicePub = b64("identities", "devicePublic")
    private val serverPub = b64("identities", "serverPublic")
    private val clientEpk = b64("ephemeral", "clientPublic")
    private val serverEpk = b64("ephemeral", "serverPublic")
    private val clientNonce = b64("nonces", "client")
    private val serverNonce = b64("nonces", "server")
    private val shared = hex("ephemeral", "sharedHex")
    private val codeKey = hex("scrypt", "codeKeyHex")
    private val salt = hex("pairing", "saltCHex")

    /** A valid signature verifies with the key; the damaged one does not. */
    private fun checkSigns(publicRaw: ByteArray, message: ByteArray, vararg path: String) {
        assertTrue("${path.joinToString(".")} must verify", SecureCrypto.verify(publicRaw, message, b64(*path, "signature")))
        assertFalse("${path.joinToString(".")} damaged must fail", SecureCrypto.verify(publicRaw, message, b64(*path, "damagedSignature")))
    }

    private fun pairTranscript() = AvekProtocol.pairTranscript(serverPub, devicePub, clientEpk, serverEpk, clientNonce, serverNonce, salt)

    private fun session(dk: ByteArray = hex("session", "dkHex")) =
        AvekProtocol.sessionKeys(shared, serverPub, devicePub, clientEpk, serverEpk, clientNonce, serverNonce, dk)

    // ------------------------------------------------------------------ HKDF

    @Test
    fun `hkdf reproduces RFC 5869 test case 1`() {
        val okm = SecureCrypto.hkdf(hex("hkdf", "ikmHex"), hex("hkdf", "saltHex"), hex("hkdf", "infoHex"), 42)
        assertEquals(TestVectors.string("hkdf", "okmHex"), SecureCrypto.hex(okm))
        assertEquals(TestVectors.string("hkdf", "rfc5869TestCase1OkmHex"), SecureCrypto.hex(okm))
    }

    // ------------------------------------------------------------------ scrypt and the code

    @Test
    fun `scrypt of the key and the code match (N=131072, r=8, p=1)`() {
        val keyScrypt = AvekProtocol.scrypt(TestVectors.string("scrypt", "key").toByteArray(), hex("scrypt", "saltKHex"))
        assertEquals(TestVectors.string("scrypt", "keyScryptHex"), SecureCrypto.hex(keyScrypt))
        assertEquals(TestVectors.string("scrypt", "keyCheckHex"), SecureCrypto.hex(AvekProtocol.keyCheck(keyScrypt)))
        val code = AvekProtocol.scryptCode(TestVectors.string("scrypt", "code").toByteArray(), hex("scrypt", "saltCHex"))
        assertEquals(TestVectors.string("scrypt", "codeKeyHex"), SecureCrypto.hex(code))
        assertEquals(AvekProtocol.SCRYPT_N, TestVectors.string("scrypt", "N").toInt())
        assertEquals(AvekProtocol.SCRYPT_R, TestVectors.string("scrypt", "r").toInt())
        assertEquals(AvekProtocol.SCRYPT_P, TestVectors.string("scrypt", "p").toInt())
    }

    @Test
    fun `code inputs normalise exactly like the vectors`() {
        val inputs = TestVectors.obj("scrypt", "codeInputs")
        assertTrue(inputs.size >= 6)
        for ((input, expected) in inputs) {
            val want = if (expected is kotlinx.serialization.json.JsonNull) null else expected.jsonPrimitive.content
            assertEquals("normalizeCode(\"$input\")", want, AvekProtocol.normalizeCode(input))
            val digits = AvekProtocol.normalizeCodeDigits(input.toCharArray())
            assertEquals(want, digits?.toString(Charsets.US_ASCII))
        }
        assertNull(AvekProtocol.normalizeCode("1234 5678 901O"))
    }

    // ------------------------------------------------------------------ identities

    @Test
    fun `identity keys, ids and fingerprints match`() {
        val devicePrivate = SecureCrypto.privateKeyFromScalar(hex("identities", "devicePrivateHex"))
        val serverPrivate = SecureCrypto.privateKeyFromScalar(hex("identities", "serverPrivateHex"))
        assertArrayEquals(devicePub, SecureCrypto.publicKeyOf(devicePrivate))
        assertArrayEquals(serverPub, SecureCrypto.publicKeyOf(serverPrivate))
        assertEquals(TestVectors.string("identities", "deviceId"), AvekProtocol.deviceIdOf(devicePub))
        assertEquals(TestVectors.string("identities", "serverId"), AvekProtocol.serverIdOf(serverPub))
        assertEquals(TestVectors.string("identities", "deviceFingerprintHex"), SecureCrypto.hex(AvekProtocol.fingerprint(devicePub)))
        assertEquals(TestVectors.string("identities", "deviceFingerprintText"), AvekProtocol.fingerprintText(devicePub))
    }

    @Test
    fun `device signature vector verifies and the damaged one fails`() {
        checkSigns(devicePub, hex("identities", "deviceSigns", "messageHex"), "identities", "deviceSigns")
    }

    @Test
    fun `the vault signs with the vector key and the signature verifies`() {
        val vault = SoftwareIdentityVault(mapOf("avek.identity.1" to hex("identities", "devicePrivateHex")))
        assertArrayEquals(devicePub, vault.publicKey("avek.identity.1"))
        val message = hex("identities", "deviceSigns", "messageHex")
        assertTrue(SecureCrypto.verify(devicePub, message, vault.sign("avek.identity.1", message)))
        assertFalse(SecureCrypto.verify(serverPub, message, vault.sign("avek.identity.1", message)))
        assertEquals("avek.identity.2", vault.nextAlias())
    }

    @Test
    fun `invalid public keys are refused`() {
        assertTrue(SecureCrypto.isValidPublicKey(devicePub))
        assertFalse(SecureCrypto.isValidPublicKey(devicePub.copyOf(64)))
        assertFalse(SecureCrypto.isValidPublicKey(devicePub.copyOf().also { it[0] = 2 }))
        assertFalse(SecureCrypto.isValidPublicKey(devicePub.copyOf().also { it[64] = (it[64] + 1).toByte() })) // off the curve
        assertFalse(SecureCrypto.verify(devicePub.copyOf(10), byteArrayOf(1), byteArrayOf(2)))
    }

    @Test
    fun `both sides derive the vector's shared secret`() {
        val client = SecureCrypto.privateKeyFromScalar(hex("ephemeral", "clientPrivateHex"))
        val server = SecureCrypto.privateKeyFromScalar(hex("ephemeral", "serverPrivateHex"))
        assertArrayEquals(clientEpk, SecureCrypto.publicKeyOf(client))
        assertArrayEquals(serverEpk, SecureCrypto.publicKeyOf(server))
        assertArrayEquals(shared, SecureCrypto.ecdh(client, serverEpk))
        assertArrayEquals(shared, SecureCrypto.ecdh(server, clientEpk))
    }

    // ------------------------------------------------------------------ pairing

    @Test
    fun `pairing transcript, messages, MACs and box key match`() {
        val transcript = pairTranscript()
        assertEquals(TestVectors.string("pairing", "transcriptHex"), SecureCrypto.hex(transcript))
        assertEquals(TestVectors.string("pairing", "clientMessageHex"), SecureCrypto.hex(AvekProtocol.pairClientMessage(transcript)))
        assertEquals(TestVectors.string("pairing", "serverMessageHex"), SecureCrypto.hex(AvekProtocol.pairServerMessage(transcript)))
        assertEquals(TestVectors.string("pairing", "clientMacHex"), SecureCrypto.hex(AvekProtocol.pairClientMac(codeKey, transcript)))
        assertEquals(TestVectors.string("pairing", "serverMacHex"), SecureCrypto.hex(AvekProtocol.pairServerMac(codeKey, transcript)))
        assertEquals(TestVectors.string("pairing", "boxKeyHex"), SecureCrypto.hex(AvekProtocol.pairBoxKey(shared, codeKey, transcript)))
        checkSigns(devicePub, AvekProtocol.pairClientMessage(transcript), "pairing", "clientSigns")
        checkSigns(serverPub, AvekProtocol.pairServerMessage(transcript), "pairing", "serverSigns")
    }

    @Test
    fun `the box frame opens to the vector plaintext and its content verifies`() {
        val transcript = pairTranscript()
        val boxKey = AvekProtocol.pairBoxKey(shared, codeKey, transcript)
        val plain = AvekProtocol.openBox(boxKey, b64("pairing", "boxFrame")).toString(Charsets.UTF_8)
        assertEquals(TestVectors.string("pairing", "boxPlaintext"), plain)
        val box = Json.parseToJsonElement(plain).jsonObject
        assertEquals(AvekProtocol.deviceIdOf(devicePub), box.getValue("deviceId").jsonPrimitive.content)
        assertEquals(AvekProtocol.serverIdOf(serverPub), box.getValue("serverId").jsonPrimitive.content)
        assertEquals(TestVectors.string("deviceKeys", "dkHex"), SecureCrypto.hex(SecureCrypto.unb64(box.getValue("dk").jsonPrimitive.content)))
        assertEquals(TestVectors.string("deviceKeys", "rkHex"), SecureCrypto.hex(SecureCrypto.unb64(box.getValue("rk").jsonPrimitive.content)))
        assertTrue(SecureCrypto.verify(serverPub, AvekProtocol.pairServerMessage(transcript), SecureCrypto.unb64(box.getValue("sig").jsonPrimitive.content)))
        assertEquals(TestVectors.string("pairing", "serverMacHex"), SecureCrypto.hex(SecureCrypto.unb64(box.getValue("mac").jsonPrimitive.content)))
    }

    @Test
    fun `the box does not open with a wrong code`() {
        val transcript = pairTranscript()
        val wrongCode = AvekProtocol.scryptCode("123456789013".toByteArray(), salt, 1024)
        try {
            AvekProtocol.openBox(AvekProtocol.pairBoxKey(shared, wrongCode, transcript), b64("pairing", "boxFrame"))
            fail("A wrong code must not open the box")
        } catch (_: FrameException) {
        }
    }

    // ------------------------------------------------------------------ session

    @Test
    fun `session transcript, messages, MACs and directional keys match`() {
        val keys = session()
        assertEquals(TestVectors.string("session", "transcriptHex"), SecureCrypto.hex(keys.transcript))
        assertEquals(TestVectors.string("session", "serverMessageHex"), SecureCrypto.hex(keys.serverMessage))
        assertEquals(TestVectors.string("session", "clientMessageHex"), SecureCrypto.hex(keys.clientMessage))
        assertEquals(TestVectors.string("session", "serverMac"), SecureCrypto.b64(keys.serverMac))
        assertEquals(TestVectors.string("session", "clientMac"), SecureCrypto.b64(keys.clientMac))
        assertEquals(TestVectors.string("session", "c2sKeyHex"), SecureCrypto.hex(keys.clientToServer))
        assertEquals(TestVectors.string("session", "s2cKeyHex"), SecureCrypto.hex(keys.serverToClient))
        checkSigns(serverPub, keys.serverMessage, "session", "serverSigns")
        checkSigns(devicePub, keys.clientMessage, "session", "clientSigns")
    }

    @Test
    fun `another dk gives other keys`() {
        val keys = session()
        val other = session(ByteArray(32) { (it * 7 + 3).toByte() })
        assertNotEquals(SecureCrypto.b64(keys.clientMac), SecureCrypto.b64(other.clientMac))
        assertNotEquals(SecureCrypto.hex(keys.clientToServer), SecureCrypto.hex(other.clientToServer))
        // The vector's own "another dk" values differ from ours too.
        assertNotEquals(TestVectors.string("session", "withAnotherDk", "clientMac"), SecureCrypto.b64(keys.clientMac))
        assertNotEquals(TestVectors.string("session", "withAnotherDk", "c2sKeyHex"), SecureCrypto.hex(keys.clientToServer))
    }

    @Test
    fun `sample frames open and re-seal with the explicit counter`() {
        val keys = session()
        val c2s = b64("session", "clientToServerFrame0", "frame")
        val (c0, p0) = Frames.open(keys.clientToServer, c2s)
        assertEquals(0L, c0)
        assertEquals(TestVectors.string("session", "clientToServerFrame0", "plaintext"), p0.toString(Charsets.UTF_8))
        assertArrayEquals(c2s, Frames.seal(keys.clientToServer, 0, p0))
        val s2c = b64("session", "serverToClientFrame1", "frame")
        val (c1, p1) = Frames.open(keys.serverToClient, s2c)
        assertEquals(1L, c1)
        assertEquals(TestVectors.string("session", "serverToClientFrame1", "plaintext"), p1.toString(Charsets.UTF_8))
        assertArrayEquals(s2c, Frames.seal(keys.serverToClient, 1, p1))
    }

    @Test
    fun `the opener accepts the vector frame and then rejects a replay of it`() {
        val keys = session()
        val frame = b64("session", "serverToClientFrame1", "frame")
        val opener = FrameOpener(keys.serverToClient)
        opener.open(frame)
        try {
            opener.open(frame)
            fail("A replayed frame must be rejected")
        } catch (_: FrameException) {
        }
    }

    // ------------------------------------------------------------------ rekey, route proof, knock

    @Test
    fun `rekey message matches and both signatures verify`() {
        val newPub = b64("rekey", "newPublic")
        val message = AvekProtocol.rekeyMessage(TestVectors.string("rekey", "deviceId"), newPub)
        assertEquals(TestVectors.string("rekey", "messageHex"), SecureCrypto.hex(message))
        checkSigns(devicePub, message, "rekey", "oldKeySigns")
        checkSigns(newPub, message, "rekey", "newKeySigns")
    }

    @Test
    fun `route proof header matches byte for byte`() {
        val header = AvekProtocol.routeHeader(
            hex("routeProof", "rkHex"),
            TestVectors.string("routeProof", "deviceId"),
            TestVectors.string("routeProof", "ts").toLong(),
            b64("routeProof", "nonce"),
        )
        assertEquals(TestVectors.string("routeProof", "header"), header)
        val parts = header.removePrefix("AVEK ").split('.')
        assertEquals(22, parts[2].length)
        assertEquals(43, parts[3].length)
    }

    @Test
    fun `knock and here messages and signatures match`() {
        val nonce = b64("knock", "nonce")
        val knock = AvekProtocol.knockMessage(TestVectors.string("knock", "deviceId"), TestVectors.string("knock", "ts").toLong(), nonce)
        assertEquals(TestVectors.string("knock", "messageHex"), SecureCrypto.hex(knock))
        checkSigns(devicePub, knock, "knock", "deviceSigns")
        val here = AvekProtocol.hereMessage(
            TestVectors.string("knock", "serverId"),
            TestVectors.string("knock", "port").toInt(),
            TestVectors.string("knock", "deviceId"),
            nonce,
        )
        assertEquals(TestVectors.string("knock", "hereMessageHex"), SecureCrypto.hex(here))
        checkSigns(serverPub, here, "knock", "serverSigns")
    }

    // ------------------------------------------------------------------ frame rules

    private val key = ByteArray(32) { it.toByte() }

    @Test
    fun `sealer counters start at 0 and increase by exactly 1`() {
        val sealer = FrameSealer(key)
        val counters = (0 until 5).map { Frames.readCounter(sealer.seal("x".toByteArray())) }
        assertEquals(listOf(0L, 1L, 2L, 3L, 4L), counters)
    }

    @Test
    fun `opener rejects equal, lower and tampered frames`() {
        val frames = (0 until 4).map { Frames.seal(key, it.toLong(), "m$it".toByteArray()) }
        val opener = FrameOpener(key)
        assertEquals("m0", opener.open(frames[0]).toString(Charsets.UTF_8))
        assertEquals("m2", opener.open(frames[2]).toString(Charsets.UTF_8)) // gaps are fine: only "strictly greater" is required

        for (rejected in listOf(frames[2], frames[1], frames[0])) {
            try {
                opener.open(rejected)
                fail("Counter not strictly greater must be rejected")
            } catch (_: FrameException) {
            }
        }
        val tampered = frames[3].copyOf().also { it[it.size - 1] = (it[it.size - 1] + 1).toByte() }
        try {
            opener.open(tampered)
            fail("A bad tag must be rejected")
        } catch (_: FrameException) {
        }
        // The rejected frames did not move the window: the genuine next frame still opens.
        assertEquals("m3", opener.open(frames[3]).toString(Charsets.UTF_8))
        assertTrue(true)
    }

    @Test
    fun `a frame cannot be opened with a changed counter`() {
        val frame = Frames.seal(key, 7, "hello".toByteArray())
        val forged = frame.copyOf().also { it[7] = 8 } // counter 7 -> 8 changes the nonce, so the tag fails
        try {
            Frames.open(key, forged)
            fail("expected FrameException")
        } catch (_: FrameException) {
        }
    }

    @Test
    fun `too short frames are rejected`() {
        try {
            Frames.open(key, ByteArray(10))
            fail("expected FrameException")
        } catch (_: FrameException) {
        }
    }
}
