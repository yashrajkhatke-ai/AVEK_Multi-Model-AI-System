package com.avek.chat.link

import com.avek.chat.core.link.crypto.AvekProtocol
import com.avek.chat.core.link.crypto.FrameException
import com.avek.chat.core.link.crypto.FrameOpener
import com.avek.chat.core.link.crypto.FrameSealer
import com.avek.chat.core.link.crypto.Frames
import com.avek.chat.core.link.crypto.SecureCrypto
import com.avek.chat.core.link.store.SoftwareIdentityVault
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

/** Reproduces EVERY value of the harness's v3 `test-vectors.json` (AVEK-SEC/2). */
class CryptoVectorsTest {

    private fun hex(vararg path: String) = SecureCrypto.unhex(TestVectors.string(*path))
    private fun b64(vararg path: String) = SecureCrypto.unb64(TestVectors.string(*path))

    private val devicePub = b64("identities", "devicePublic")
    private val serverPub = b64("identities", "serverPublic")
    private val clientEpk = b64("ephemeral", "clientPublic")
    private val serverEpk = b64("ephemeral", "serverPublic")
    private val clientNonce = b64("nonces", "client")
    private val serverNonce = b64("nonces", "server")
    private val shared = hex("ephemeral", "sharedHex")

    /** A valid signature verifies with the key; the damaged one does not. */
    private fun checkSigns(publicRaw: ByteArray, message: ByteArray, vararg path: String) {
        assertTrue("${path.joinToString(".")} must verify", SecureCrypto.verify(publicRaw, message, b64(*path, "signature")))
        assertFalse("${path.joinToString(".")} damaged must fail", SecureCrypto.verify(publicRaw, message, b64(*path, "damagedSignature")))
    }

    // ------------------------------------------------------------------ HKDF

    @Test
    fun `hkdf reproduces RFC 5869 test case 1`() {
        val okm = SecureCrypto.hkdf(hex("hkdf", "ikmHex"), hex("hkdf", "saltHex"), hex("hkdf", "infoHex"), 42)
        assertEquals(TestVectors.string("hkdf", "okmHex"), SecureCrypto.hex(okm))
        assertEquals(TestVectors.string("hkdf", "rfc5869TestCase1OkmHex"), SecureCrypto.hex(okm))
    }

    // ------------------------------------------------------------------ identities

    @Test
    fun `identity keys, ids and fingerprints match`() {
        val devicePrivate = SecureCrypto.privateKeyFromScalar(hex("identities", "devicePrivateHex"))
        val serverPrivate = SecureCrypto.privateKeyFromScalar(hex("identities", "serverPrivateHex"))
        assertArrayEquals(devicePub, SecureCrypto.publicKeyOf(devicePrivate))
        assertArrayEquals(serverPub, SecureCrypto.publicKeyOf(serverPrivate))
        assertEquals(TestVectors.string("identities", "deviceId"), AvekProtocol.deviceIdOf(devicePub))
        assertEquals(TestVectors.string("identities", "serverId"), AvekProtocol.serverIdOf(serverPub))
        assertEquals(TestVectors.string("identities", "deviceFingerprintHex"), SecureCrypto.hex(AvekProtocol.fingerprint(devicePub)))
        assertEquals(TestVectors.string("identities", "deviceFingerprintText"), AvekProtocol.fingerprintText(devicePub))
    }

    @Test
    fun `device signature vector verifies and the damaged one fails`() {
        checkSigns(devicePub, hex("identities", "deviceSigns", "messageHex"), "identities", "deviceSigns")
    }

    @Test
    fun `the vault signs with the vector key and the signature verifies`() {
        val vault = SoftwareIdentityVault(hex("identities", "devicePrivateHex"))
        assertArrayEquals(devicePub, vault.publicKey())
        val message = hex("identities", "deviceSigns", "messageHex")
        assertTrue(SecureCrypto.verify(devicePub, message, vault.sign(message)))
        assertFalse(SecureCrypto.verify(serverPub, message, vault.sign(message)))
    }

    @Test
    fun `invalid public keys are refused`() {
        assertTrue(SecureCrypto.isValidPublicKey(devicePub))
        assertFalse(SecureCrypto.isValidPublicKey(devicePub.copyOf(64)))
        assertFalse(SecureCrypto.isValidPublicKey(devicePub.copyOf().also { it[0] = 2 }))
        assertFalse(SecureCrypto.isValidPublicKey(devicePub.copyOf().also { it[64] = (it[64] + 1).toByte() })) // off the curve
        assertFalse(SecureCrypto.verify(devicePub.copyOf(10), byteArrayOf(1), byteArrayOf(2)))
    }

    // ------------------------------------------------------------------ ECDH

    @Test
    fun `both sides derive the vector's shared secret`() {
        val clientPrivate = SecureCrypto.privateKeyFromScalar(hex("ephemeral", "clientPrivateHex"))
        val serverPrivate = SecureCrypto.privateKeyFromScalar(hex("ephemeral", "serverPrivateHex"))
        assertArrayEquals(clientEpk, SecureCrypto.publicKeyOf(clientPrivate))
        assertArrayEquals(serverEpk, SecureCrypto.publicKeyOf(serverPrivate))
        assertEquals(TestVectors.string("ephemeral", "sharedHex"), SecureCrypto.hex(SecureCrypto.ecdh(clientPrivate, serverEpk)))
        assertEquals(TestVectors.string("ephemeral", "sharedHex"), SecureCrypto.hex(SecureCrypto.ecdh(serverPrivate, clientEpk)))
    }

    @Test
    fun `public keys round trip as 65 byte uncompressed points`() {
        val key = SecureCrypto.decodePublicKey(clientEpk)
        assertArrayEquals(clientEpk, SecureCrypto.encodePublicKey(key as java.security.interfaces.ECPublicKey))
        assertEquals(65, SecureCrypto.generateKeyPair().publicRaw.size)
    }

    // ------------------------------------------------------------------ pairing

    @Test
    fun `pairing commit, transcript, digits and messages match`() {
        val commit = AvekProtocol.pairCommit(
            TestVectors.string("pairing", "name"), TestVectors.string("pairing", "platform"), devicePub, clientNonce,
        )
        assertEquals(TestVectors.string("pairing", "commitHex"), SecureCrypto.hex(commit))
        val transcript = AvekProtocol.pairTranscript(commit, serverPub, serverNonce, devicePub, clientNonce)
        assertEquals(TestVectors.string("pairing", "transcriptHex"), SecureCrypto.hex(transcript))
        val sas = AvekProtocol.pairSas(transcript)
        assertEquals(TestVectors.string("pairing", "sas"), sas)
        assertEquals(TestVectors.string("pairing", "sasFormatted"), AvekProtocol.formatSas(sas))
        assertEquals(TestVectors.string("pairing", "clientMessageHex"), SecureCrypto.hex(AvekProtocol.pairClientMessage(transcript)))
        assertEquals(TestVectors.string("pairing", "serverMessageHex"), SecureCrypto.hex(AvekProtocol.pairServerMessage(transcript)))
        checkSigns(devicePub, AvekProtocol.pairClientMessage(transcript), "pairing", "clientSigns")
        checkSigns(serverPub, AvekProtocol.pairServerMessage(transcript), "pairing", "serverSigns")
    }

    @Test
    fun `a different name changes the commit and the digits`() {
        val a = AvekProtocol.pairCommit("Tablet Test", "android", devicePub, clientNonce)
        val b = AvekProtocol.pairCommit("Tablet Tesu", "android", devicePub, clientNonce)
        assertFalse(a.contentEquals(b))
        val sasA = AvekProtocol.pairSas(AvekProtocol.pairTranscript(a, serverPub, serverNonce, devicePub, clientNonce))
        assertEquals(6, sasA.length)
    }

    // ------------------------------------------------------------------ session

    private fun sessionDerivation() = AvekProtocol.sessionKeys(shared, serverPub, devicePub, clientEpk, serverEpk, clientNonce, serverNonce)

    @Test
    fun `session transcript, messages, MACs and directional keys match`() {
        val derived = sessionDerivation()
        assertEquals(TestVectors.string("session", "transcriptHex"), SecureCrypto.hex(derived.transcript))
        assertEquals(TestVectors.string("session", "serverMessageHex"), SecureCrypto.hex(derived.serverMessage))
        assertEquals(TestVectors.string("session", "clientMessageHex"), SecureCrypto.hex(derived.clientMessage))
        assertEquals(TestVectors.string("session", "clientMac"), SecureCrypto.b64(derived.clientMac))
        assertEquals(TestVectors.string("session", "serverMac"), SecureCrypto.b64(derived.serverMac))
        assertEquals(TestVectors.string("session", "c2sKeyHex"), SecureCrypto.hex(derived.clientToServer))
        assertEquals(TestVectors.string("session", "s2cKeyHex"), SecureCrypto.hex(derived.serverToClient))
        checkSigns(serverPub, derived.serverMessage, "session", "serverSigns")
        checkSigns(devicePub, derived.clientMessage, "session", "clientSigns")
    }

    @Test
    fun `sample frames open and re-seal with the explicit counter`() {
        val derived = sessionDerivation()

        val c2sFrame = b64("session", "clientToServerFrame0", "frame")
        val (c2sCounter, c2sPlain) = Frames.open(derived.clientToServer, c2sFrame)
        assertEquals(0L, c2sCounter)
        assertEquals(TestVectors.string("session", "clientToServerFrame0", "plaintext"), c2sPlain.toString(Charsets.UTF_8))
        assertArrayEquals(c2sFrame, Frames.seal(derived.clientToServer, 0, c2sPlain))

        val s2cFrame = b64("session", "serverToClientFrame1", "frame")
        val (s2cCounter, s2cPlain) = Frames.open(derived.serverToClient, s2cFrame)
        assertEquals(1L, s2cCounter)
        assertEquals(TestVectors.string("session", "serverToClientFrame1", "plaintext"), s2cPlain.toString(Charsets.UTF_8))
        assertArrayEquals(s2cFrame, Frames.seal(derived.serverToClient, 1, s2cPlain))
    }

    @Test
    fun `the opener accepts the vector frame and then rejects a replay of it`() {
        val derived = sessionDerivation()
        val frame = b64("session", "serverToClientFrame1", "frame")
        val opener = FrameOpener(derived.serverToClient)
        assertEquals(TestVectors.string("session", "serverToClientFrame1", "plaintext"), opener.open(frame).toString(Charsets.UTF_8))
        try {
            opener.open(frame)
            fail("A replayed frame must be rejected")
        } catch (_: FrameException) {
            // expected
        }
    }

    // ------------------------------------------------------------------ knock

    @Test
    fun `knock and here messages and signatures match`() {
        val deviceId = TestVectors.string("knock", "deviceId")
        val ts = TestVectors.string("knock", "ts").toLong()
        val nonce = b64("knock", "nonce")
        val knock = AvekProtocol.knockMessage(deviceId, ts, nonce)
        assertEquals(TestVectors.string("knock", "messageHex"), SecureCrypto.hex(knock))
        checkSigns(devicePub, knock, "knock", "deviceSigns")

        val here = AvekProtocol.hereMessage(
            TestVectors.string("knock", "serverId"), TestVectors.string("knock", "port").toInt(), deviceId, nonce,
        )
        assertEquals(TestVectors.string("knock", "hereMessageHex"), SecureCrypto.hex(here))
        checkSigns(serverPub, here, "knock", "serverSigns")
    }

    // ------------------------------------------------------------------ frame rules

    private val key = ByteArray(32) { it.toByte() }

    @Test
    fun `sealer counters start at 0 and increase by exactly 1`() {
        val sealer = FrameSealer(key)
        val counters = (0 until 5).map { Frames.readCounter(sealer.seal("x".toByteArray())) }
        assertEquals(listOf(0L, 1L, 2L, 3L, 4L), counters)
    }

    @Test
    fun `opener rejects equal, lower and tampered frames`() {
        val frames = (0 until 4).map { Frames.seal(key, it.toLong(), "m$it".toByteArray()) }
        val opener = FrameOpener(key)
        assertEquals("m0", opener.open(frames[0]).toString(Charsets.UTF_8))
        assertEquals("m2", opener.open(frames[2]).toString(Charsets.UTF_8)) // gaps are fine: only "strictly greater" is required

        for (rejected in listOf(frames[2], frames[1], frames[0])) {
            try {
                opener.open(rejected)
                fail("Counter not strictly greater must be rejected")
            } catch (_: FrameException) {
            }
        }
        val tampered = frames[3].copyOf().also { it[it.size - 1] = (it[it.size - 1] + 1).toByte() }
        try {
            opener.open(tampered)
            fail("A bad tag must be rejected")
        } catch (_: FrameException) {
        }
        // The rejected frames did not move the window: the genuine next frame still opens.
        assertEquals("m3", opener.open(frames[3]).toString(Charsets.UTF_8))
        assertTrue(true)
    }

    @Test
    fun `a frame cannot be opened with a changed counter`() {
        val frame = Frames.seal(key, 7, "hello".toByteArray())
        val forged = frame.copyOf().also { it[7] = 8 } // counter 7 -> 8 changes the nonce, so the tag fails
        try {
            Frames.open(key, forged)
            fail("expected FrameException")
        } catch (_: FrameException) {
        }
    }

    @Test
    fun `too short frames are rejected`() {
        try {
            Frames.open(key, ByteArray(10))
            fail("expected FrameException")
        } catch (_: FrameException) {
        }
    }
}
