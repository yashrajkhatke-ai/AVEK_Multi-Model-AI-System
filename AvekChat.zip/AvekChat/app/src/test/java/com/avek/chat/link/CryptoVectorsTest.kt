package com.avek.chat.link

import com.avek.chat.core.link.crypto.FrameException
import com.avek.chat.core.link.crypto.FrameOpener
import com.avek.chat.core.link.crypto.FrameSealer
import com.avek.chat.core.link.crypto.Frames
import com.avek.chat.core.link.crypto.HandshakeMath
import com.avek.chat.core.link.crypto.SecureCrypto
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

/** Reproduces EVERY value of the harness's `test-vectors.json`. */
class CryptoVectorsTest {

    private fun hex(vararg path: String) = SecureCrypto.unhex(TestVectors.string(*path))
    private fun b64(vararg path: String) = SecureCrypto.unb64(TestVectors.string(*path))

    private val clientPublic = b64("keys", "clientPublic")
    private val serverPublic = b64("keys", "serverPublic")
    private val clientNonce = b64("nonces", "client")
    private val serverNonce = b64("nonces", "server")
    private val shared = hex("keys", "sharedHex")

    // ------------------------------------------------------------------ HKDF

    @Test
    fun `hkdf reproduces RFC 5869 test case 1`() {
        val okm = SecureCrypto.hkdf(hex("hkdf", "ikmHex"), hex("hkdf", "saltHex"), hex("hkdf", "infoHex"), 42)
        assertEquals(TestVectors.string("hkdf", "okmHex"), SecureCrypto.hex(okm))
        assertEquals(TestVectors.string("hkdf", "rfc5869TestCase1OkmHex"), SecureCrypto.hex(okm))
    }

    // ------------------------------------------------------------------ ECDH

    @Test
    fun `both sides derive the vector's shared secret`() {
        val clientPrivate = SecureCrypto.privateKeyFromScalar(hex("keys", "clientPrivateHex"))
        val serverPrivate = SecureCrypto.privateKeyFromScalar(hex("keys", "serverPrivateHex"))
        assertEquals(TestVectors.string("keys", "sharedHex"), SecureCrypto.hex(SecureCrypto.ecdh(clientPrivate, serverPublic)))
        assertEquals(TestVectors.string("keys", "sharedHex"), SecureCrypto.hex(SecureCrypto.ecdh(serverPrivate, clientPublic)))
    }

    @Test
    fun `public keys round trip as 65 byte uncompressed points`() {
        val key = SecureCrypto.decodePublicKey(clientPublic)
        val encoded = SecureCrypto.encodePublicKey(key as java.security.interfaces.ECPublicKey)
        assertArrayEquals(clientPublic, encoded)
        assertEquals(65, SecureCrypto.generateKeyPair().publicRaw.size)
    }

    // ------------------------------------------------------------------ pairing

    @Test
    fun `pairing transcript, MACs and encKey match`() {
        val code = TestVectors.string("pairing", "code")
        assertEquals(TestVectors.string("pairing", "normalizedCode"), HandshakeMath.normalizeCode(code))
        assertEquals("ABCDEFGHJKLM", HandshakeMath.normalizeCode("abcd efgh-jklm"))

        val derived = HandshakeMath.pair(shared, HandshakeMath.normalizeCode(code), clientPublic, serverPublic, clientNonce, serverNonce)
        assertEquals(TestVectors.string("pairing", "transcriptHex"), SecureCrypto.hex(derived.transcript))
        assertEquals(TestVectors.string("pairing", "clientMac"), SecureCrypto.b64(derived.clientMac))
        assertEquals(TestVectors.string("pairing", "serverMac"), SecureCrypto.b64(derived.serverMac))
        assertEquals(TestVectors.string("pairing", "encKeyHex"), SecureCrypto.hex(derived.encKey))
    }

    @Test
    fun `sealed grant decrypts and re-encrypts with the fixed IV`() {
        val derived = HandshakeMath.pair(shared, "ABCDEFGHJKLM", clientPublic, serverPublic, clientNonce, serverNonce)
        val iv = b64("pairing", "iv")
        val sealed = b64("pairing", "sealedGrant")
        val plaintext = TestVectors.string("pairing", "grantPlaintext")

        assertEquals(plaintext, SecureCrypto.aesGcmOpen(derived.encKey, iv, derived.transcript, sealed).toString(Charsets.UTF_8))
        assertArrayEquals(sealed, SecureCrypto.aesGcmSeal(derived.encKey, iv, derived.transcript, plaintext.toByteArray()))
    }

    @Test
    fun `a different code produces different pairing MACs`() {
        val good = HandshakeMath.pair(shared, "ABCDEFGHJKLM", clientPublic, serverPublic, clientNonce, serverNonce)
        val bad = HandshakeMath.pair(shared, "ABCDEFGHJKLN", clientPublic, serverPublic, clientNonce, serverNonce)
        assertFalse(SecureCrypto.constantTimeEquals(good.clientMac, bad.clientMac))
    }

    // ------------------------------------------------------------------ session

    private fun sessionDerivation() = HandshakeMath.session(
        deviceId = TestVectors.string("session", "deviceId"),
        deviceSecret = b64("session", "deviceSecret"),
        shared = shared,
        clientEpk = clientPublic,
        serverEpk = serverPublic,
        clientNonce = clientNonce,
        serverNonce = serverNonce,
    )

    @Test
    fun `session transcript, MACs and directional keys match`() {
        val derived = sessionDerivation()
        assertEquals(TestVectors.string("session", "transcriptHex"), SecureCrypto.hex(derived.transcript))
        assertEquals(TestVectors.string("session", "clientMac"), SecureCrypto.b64(derived.clientMac))
        assertEquals(TestVectors.string("session", "serverMac"), SecureCrypto.b64(derived.serverMac))
        assertEquals(TestVectors.string("session", "c2sKeyHex"), SecureCrypto.hex(derived.clientToServer))
        assertEquals(TestVectors.string("session", "s2cKeyHex"), SecureCrypto.hex(derived.serverToClient))
    }

    @Test
    fun `sample frames open and re-seal with the explicit counter`() {
        val derived = sessionDerivation()

        val c2sFrame = b64("session", "clientToServerFrame0", "frame")
        val (c2sCounter, c2sPlain) = Frames.open(derived.clientToServer, c2sFrame)
        assertEquals(0L, c2sCounter)
        assertEquals(TestVectors.string("session", "clientToServerFrame0", "plaintext"), c2sPlain.toString(Charsets.UTF_8))
        assertArrayEquals(c2sFrame, Frames.seal(derived.clientToServer, 0, c2sPlain))

        val s2cFrame = b64("session", "serverToClientFrame1", "frame")
        val (s2cCounter, s2cPlain) = Frames.open(derived.serverToClient, s2cFrame)
        assertEquals(1L, s2cCounter)
        assertEquals(TestVectors.string("session", "serverToClientFrame1", "plaintext"), s2cPlain.toString(Charsets.UTF_8))
        assertArrayEquals(s2cFrame, Frames.seal(derived.serverToClient, 1, s2cPlain))
    }

    @Test
    fun `the opener accepts the vector frame and then rejects a replay of it`() {
        val derived = sessionDerivation()
        val frame = b64("session", "serverToClientFrame1", "frame")
        val opener = FrameOpener(derived.serverToClient)
        assertEquals(TestVectors.string("session", "serverToClientFrame1", "plaintext"), opener.open(frame).toString(Charsets.UTF_8))
        try {
            opener.open(frame)
            fail("A replayed frame must be rejected")
        } catch (_: FrameException) {
            // expected
        }
    }

    // ------------------------------------------------------------------ frame rules

    private val key = ByteArray(32) { it.toByte() }

    @Test
    fun `sealer counters start at 0 and increase by exactly 1`() {
        val sealer = FrameSealer(key)
        val counters = (0 until 5).map { Frames.readCounter(sealer.seal("x".toByteArray())) }
        assertEquals(listOf(0L, 1L, 2L, 3L, 4L), counters)
    }

    @Test
    fun `opener rejects equal, lower and tampered frames`() {
        val frames = (0 until 4).map { Frames.seal(key, it.toLong(), "m$it".toByteArray()) }
        val opener = FrameOpener(key)
        assertEquals("m0", opener.open(frames[0]).toString(Charsets.UTF_8))
        assertEquals("m2", opener.open(frames[2]).toString(Charsets.UTF_8)) // gaps are fine: only "strictly greater" is required

        for (rejected in listOf(frames[2], frames[1], frames[0])) {
            try {
                opener.open(rejected)
                fail("Counter not strictly greater must be rejected")
            } catch (_: FrameException) {
            }
        }
        val tampered = frames[3].copyOf().also { it[it.size - 1] = (it[it.size - 1] + 1).toByte() }
        try {
            opener.open(tampered)
            fail("A bad tag must be rejected")
        } catch (_: FrameException) {
        }
        // The rejected frames did not move the window: the genuine next frame still opens.
        assertEquals("m3", opener.open(frames[3]).toString(Charsets.UTF_8))
        assertTrue(true)
    }

    @Test
    fun `a frame cannot be opened with a changed counter`() {
        val frame = Frames.seal(key, 7, "hello".toByteArray())
        val forged = frame.copyOf().also { it[7] = 8 } // counter 7 -> 8 changes the nonce, so the tag fails
        try {
            Frames.open(key, forged)
            fail("expected FrameException")
        } catch (_: FrameException) {
        }
    }

    @Test
    fun `too short frames are rejected`() {
        try {
            Frames.open(key, ByteArray(10))
            fail("expected FrameException")
        } catch (_: FrameException) {
        }
    }
}
