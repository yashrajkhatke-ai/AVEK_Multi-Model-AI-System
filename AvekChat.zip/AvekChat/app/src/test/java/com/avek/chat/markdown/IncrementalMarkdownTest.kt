package com.avek.chat.markdown

import com.avek.chat.core.markdown.IncrementalMarkdown
import com.avek.chat.core.markdown.MarkdownParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class IncrementalMarkdownTest {

    private val sample = """
        # Plan for the trip

        Day one is **busy**: we land at 9
        and drive north.

        - pack the *charger*
        - book the car
          - with insurance

        1. Museum
        2. Lunch at `the harbour`

        > A quote that
        > spans lines

        ```kotlin
        fun main() {
            println("hi")

            // a blank line inside a fence must not end it
        }
        ```

        | Day | Place |
        |-----|-------|
        | 1 | Oslo |
        | 2 | Bergen |

        ---

        Final words.
    """.trimIndent()

    @Test
    fun `incremental parsing equals a full parse for every prefix, token by token`() {
        val parser = IncrementalMarkdown()
        for (end in 0..sample.length) {
            val prefix = sample.substring(0, end)
            assertEquals("prefix of length $end", MarkdownParser.parse(prefix), parser.update(prefix))
        }
    }

    @Test
    fun `a fresh parser on any prefix also equals a full parse`() {
        for (end in 0..sample.length step 7) {
            val prefix = sample.substring(0, end)
            assertEquals(MarkdownParser.parse(prefix), IncrementalMarkdown().update(prefix))
        }
    }

    @Test
    fun `completed blocks are kept, not parsed again`() {
        val parser = IncrementalMarkdown()
        parser.update(sample)
        assertTrue(parser.settledCount >= 6)
        val first = parser.update(sample + "\n\nMore")
        assertEquals(MarkdownParser.parse(sample + "\n\nMore"), first)
    }

    @Test
    fun `a text that is replaced (reload) starts over`() {
        val parser = IncrementalMarkdown()
        parser.update(sample)
        assertEquals(MarkdownParser.parse("Other\n\ntext"), parser.update("Other\n\ntext"))
        assertEquals(MarkdownParser.parse("a\r\n\r\nb"), parser.update("a\r\n\r\nb"))
    }
}
