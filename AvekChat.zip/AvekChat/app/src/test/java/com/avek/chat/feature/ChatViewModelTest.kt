package com.avek.chat.feature

import com.avek.chat.core.common.IdGenerator
import com.avek.chat.core.common.TimeProvider
import com.avek.chat.core.data.downloads.DownloadManager
import com.avek.chat.core.data.remote.RemoteChatRepository
import com.avek.chat.core.data.remote.RemoteModelRepository
import com.avek.chat.core.domain.chat.AskCoordinator
import com.avek.chat.core.domain.chat.AttachmentSource
import com.avek.chat.core.domain.chat.AttachmentSourceFactory
import com.avek.chat.core.domain.chat.AttachmentUploader
import com.avek.chat.core.domain.chat.GenerateReplyUseCase
import com.avek.chat.core.domain.chat.OpenChatBus
import com.avek.chat.core.domain.chat.TurnFollower
import com.avek.chat.core.domain.lists.ListMemoryRegistry
import com.avek.chat.core.domain.repository.SettingsRepository
import com.avek.chat.core.link.AppVisibility
import com.avek.chat.core.link.HarnessApi
import com.avek.chat.core.link.route.ConnectionState
import com.avek.chat.core.link.rpc.RpcException
import com.avek.chat.core.link.wire.AskRequestDto
import com.avek.chat.core.link.wire.ChatSummaryDto
import com.avek.chat.core.link.wire.DeltaDto
import com.avek.chat.core.link.wire.LimitsDto
import com.avek.chat.core.link.wire.LinkEvent
import com.avek.chat.core.link.wire.ToolCallEventDto
import com.avek.chat.core.link.wire.ToolResultEventDto
import com.avek.chat.core.link.wire.TurnCompletedDto
import com.avek.chat.core.model.Feedback
import com.avek.chat.core.model.MessageStatus
import com.avek.chat.core.model.TaskMode
import com.avek.chat.core.model.ThinkingDepth
import com.avek.chat.core.model.settings.UserSettings
import com.avek.chat.domain.FakeLink
import com.avek.chat.domain.MemoryStore
import com.avek.chat.feature.chat.AttachStatus
import com.avek.chat.feature.chat.ChatEvent
import com.avek.chat.feature.chat.ChatUiState
import com.avek.chat.feature.chat.ChatViewModel
import com.avek.chat.feature.chat.ToolViewState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.TestScope
import kotlinx.coroutines.test.advanceTimeBy
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import java.io.ByteArrayInputStream

private class FakeSettings : SettingsRepository {
    val state = MutableStateFlow(UserSettings())
    override val settings: Flow<UserSettings> = state
    override suspend fun update(transform: (UserSettings) -> UserSettings) {
        state.value = transform(state.value)
    }
}

private class SequenceIds : IdGenerator {
    private var n = 0
    override fun newId() = "id${++n}"
}

private class TextFile(override val name: String, private val bytes: ByteArray) : AttachmentSource {
    override val mime = "text/plain"
    override val size get() = bytes.size.toLong()
    override fun open() = ByteArrayInputStream(bytes)
}

@OptIn(ExperimentalCoroutinesApi::class)
class ChatViewModelTest {

    @Before fun setMain() = Dispatchers.setMain(StandardTestDispatcher())

    @After fun resetMain() = Dispatchers.resetMain()

    private fun turn(index: Int, user: String = "question $index", answer: String = "answer $index") = buildJsonObject {
        put("promptId", "p$index")
        put("createdAt", "2025-01-01T00:${index.toString().padStart(2, '0')}:00Z")
        put("status", "completed")
        put("modelId", "m1")
        put("mode", "auto")
        put("depth", 2)
        put("user", buildJsonObject { put("text", user) })
        put("assistant", buildJsonObject { put("text", answer) })
        put("thinking", buildJsonObject { put("ms", 1500) })
    }

    private fun summary(id: String = "c1", title: String = "A chat", turns: Int = 3, starred: Boolean = false) = buildJsonObject {
        put("chatId", id); put("title", title); put("createdAt", "2025-01-01T00:00:00Z"); put("updatedAt", "2025-01-01T01:00:00Z")
        put("modelId", "m1"); put("mode", "auto"); put("turnCount", turns); put("preview", "p"); put("starred", starred); put("archived", false)
    }

    private val modelsReply = buildJsonObject {
        put("items", JsonArray(listOf(buildJsonObject { put("id", "m1"); put("name", "Ornith 8B"); put("kind", "text"); put("note", "n"); put("contextTokens", 81_920); put("rank", 1) })))
        put("total", 1)
        put("next", JsonPrimitive(null as String?))
    }

    private val ack = buildJsonObject { put("chatId", "c1"); put("promptId", "p9"); put("chat", summary(turns = 1, title = "New chat")) }

    private inner class Rig(val scope: TestScope) {
        val link = FakeLink()
        val api = HarnessApi(link)
        val chats = RemoteChatRepository(api)
        val settings = FakeSettings()
        val store = MemoryStore()
        val demo = MutableStateFlow(false)
        val appScope = CoroutineScope(Dispatchers.Main)
        val asks = AskCoordinator(api, link, appScope).also { it.start() }
        val visible = MutableStateFlow(true)
        val openChat = OpenChatBus()
        val time = object : TimeProvider { override fun now() = 5_000L }
        val files = HashMap<String, AttachmentSource>()
        val tracker = com.avek.chat.core.domain.models.ModelStateTracker(link, api, appScope).also { it.start() }
        val preloader = com.avek.chat.core.domain.models.ModelPreloader(api, link, tracker, { demo.value }, appScope)
        val vm: ChatViewModel by lazy {
            ChatViewModel(
                chats = chats,
                models = RemoteModelRepository(api),
                settingsRepository = settings,
                api = api,
                link = link,
                generateReply = GenerateReplyUseCase(api, link, TurnFollower(chats), time),
                follower = TurnFollower(chats),
                uploader = AttachmentUploader(api) { LimitsDto() },
                sourceFactory = AttachmentSourceFactory { files[it] },
                asks = asks,
                downloads = DownloadManager(api, store, link, demo, appScope),
                openChat = openChat,
                visibility = object : AppVisibility { override val visible: StateFlow<Boolean> = this@Rig.visible },
                ids = SequenceIds(),
                modelStates = tracker,
                preloader = preloader,
                traces = com.avek.chat.core.domain.trace.TraceRepository(link, api, appScope),
                frameClock = com.avek.chat.core.domain.chat.FrameClock { kotlinx.coroutines.yield() },
                timelines = com.avek.chat.core.domain.timeline.TimelineRepository(link, api, appScope),
                contexts = com.avek.chat.core.domain.context.ContextRepository(link, api, appScope),
                registry = ListMemoryRegistry(),
                time = time,
            )
        }
        val state: ChatUiState get() = vm.uiState.value
        val errors = mutableListOf<String>()

        fun start() {
            scope.backgroundScope.launch { vm.uiState.collect { } }
            scope.backgroundScope.launch { vm.events.collect { if (it is ChatEvent.Error) errors += it.message } }
            scope.testScheduler.runCurrent()
        }
    }

    private fun TestScope.rig(handler: suspend (String, JsonObject) -> JsonElement): Rig {
        val r = Rig(this)
        r.link.handler = handler
        r.start()
        return r
    }

    private val standard: suspend (String, JsonObject) -> JsonElement = { op, args ->
        when (op) {
            "models.list" -> modelsReply
            "prompt" -> ack
            "chat.get" -> buildJsonObject {
                put("chat", summary())
                put("items", JsonArray(listOf(turn(3), turn(2), turn(1))))
                put("total", 3)
                put("next", JsonPrimitive(null as String?))
            }
            else -> buildJsonObject { }
        }
    }

    // ------------------------------------------------------------------ new chat

    @Test
    fun `a new chat asks the PC for the default model once and shows its name`() = runTest {
        val r = rig(standard)
        assertEquals("Ornith 8B", r.state.model.name)
        assertFalse(r.state.model.loading)
        val request = r.link.opsCalled("models.list").single()
        assertEquals("1", request["limit"]!!.jsonPrimitive.content)
    }

    @Test
    fun `before the PC answers the model slot is a placeholder, not a name`() = runTest {
        val r = Rig(this)
        r.link.connectionState.value = ConnectionState.Looking("Test PC")
        r.start()
        assertTrue(r.state.model.loading)
        assertNull(r.state.model.name)
        assertFalse(r.state.connection.connected)
        assertEquals("Looking for Test PC...", r.state.connection.banner)
    }

    @Test
    fun `no model ready is said plainly`() = runTest {
        val r = rig { op, _ -> if (op == "models.list") buildJsonObject { put("items", JsonArray(emptyList())); put("total", 0) } else buildJsonObject { } }
        assertTrue(r.state.model.noneAvailable)
        assertEquals("No model is ready", r.state.model.label)
    }

    @Test
    fun `sending streams the reply and commits it to the new chat`() = runTest {
        val r = rig(standard)
        r.vm.updateDraft("Hello there")
        assertTrue(r.state.canSend(r.vm.draft))
        r.vm.send()
        runCurrent()
        assertEquals("", r.vm.draft)
        assertEquals("c1", r.state.conversationId)
        assertEquals("New chat", r.state.title)
        assertTrue(r.state.isGenerating)
        assertEquals(listOf("Hello there", ""), r.state.messages.map { it.content })

        r.link.emit(LinkEvent.AnswerDelta(1, DeltaDto("c1", "p9", "Hi", 0)))
        r.link.emit(LinkEvent.AnswerDelta(2, DeltaDto("c1", "p9", "!", 2)))
        runCurrent()
        assertEquals("Hi!", r.state.messages.last().content)

        r.link.emit(LinkEvent.TurnCompleted(3, TurnCompletedDto("c1", "p9", thinkingMs = 100)))
        runCurrent()
        assertFalse(r.state.isGenerating)
        assertNull(r.state.streaming)
        assertEquals(listOf("Hello there", "Hi!"), r.state.messages.map { it.content })
        assertEquals(MessageStatus.COMPLETE, r.state.messages.last().status)
        // the prompt carried only the new text and the picked options, never a history
        val args = r.link.opsCalled("prompt").single()
        assertEquals("Hello there", args["text"]!!.jsonPrimitive.content)
        assertEquals(setOf("chatId", "text", "options"), args.keys)
    }

    @Test
    fun `the list keys stay the same when a finished reply is committed (no flicker)`() = runTest {
        val r = rig(standard)
        r.vm.updateDraft("Hi"); r.vm.send(); runCurrent()
        val before = r.state.messages.map { it.uiKey }
        r.link.emit(LinkEvent.AnswerDelta(1, DeltaDto("c1", "p9", "Yo", 0)))
        r.link.emit(LinkEvent.TurnCompleted(2, TurnCompletedDto("c1", "p9")))
        runCurrent()
        assertEquals(before, r.state.messages.map { it.uiKey })
    }

    @Test
    fun `the chosen task and depth go into the options`() = runTest {
        val r = rig(standard)
        r.vm.selectTask(TaskMode.CODING)
        r.vm.selectDepth(ThinkingDepth.MAXIMUM)
        runCurrent()
        r.vm.updateDraft("Write it"); r.vm.send(); runCurrent()
        val options = (r.link.opsCalled("prompt").single()["options"] as JsonObject)
        assertEquals("coding", options["mode"]!!.jsonPrimitive.content)
        assertEquals("5", options["depth"]!!.jsonPrimitive.content)
    }

    @Test
    fun `a picked model is sent, a default one is not`() = runTest {
        val r = rig(standard)
        r.vm.updateDraft("one"); r.vm.send(); runCurrent()
        assertNull(r.link.opsCalled("prompt").single()["modelId"])
        r.link.emit(LinkEvent.TurnCompleted(1, TurnCompletedDto("c1", "p9"))); runCurrent()
        r.vm.selectModel(com.avek.chat.core.model.RemoteModel("m2", "Kestrel", com.avek.chat.core.model.ModelKind.TEXT, 2))
        r.vm.updateDraft("two"); r.vm.send(); runCurrent()
        assertEquals("m2", r.link.opsCalled("prompt").last()["modelId"]!!.jsonPrimitive.content)
        assertEquals("Kestrel", r.state.model.name)
    }

    // ------------------------------------------------------------------ not connected

    @Test
    fun `without the PC the composer is disabled, the draft is kept and sending says why`() = runTest {
        val r = rig(standard)
        r.link.connectionState.value = ConnectionState.Unreachable("Test PC", 0L, 2_000L)
        runCurrent()
        r.vm.updateDraft("a long thought I do not want to lose")
        assertFalse(r.state.connection.connected)
        assertFalse(r.state.canSend(r.vm.draft))
        r.vm.send(); runCurrent()
        assertEquals("a long thought I do not want to lose", r.vm.draft)
        assertTrue(r.link.opsCalled("prompt").isEmpty())
        assertEquals(listOf("PC not reachable"), r.errors)
    }

    @Test
    fun `a prompt the PC refuses brings the draft back`() = runTest {
        val r = rig { op, _ -> if (op == "prompt") throw RpcException("no-model", "none") else if (op == "models.list") modelsReply else buildJsonObject { } }
        r.vm.updateDraft("hello"); r.vm.send(); runCurrent()
        assertEquals("hello", r.vm.draft)
        assertFalse(r.state.isGenerating)
        assertEquals(listOf("No model is ready on the PC."), r.errors)
    }

    @Test
    fun `a busy chat says so`() = runTest {
        val r = rig { op, _ -> if (op == "prompt") throw RpcException("busy", "busy") else if (op == "models.list") modelsReply else buildJsonObject { } }
        r.vm.updateDraft("hello"); r.vm.send(); runCurrent()
        assertEquals("This chat is still answering. Wait for it to finish.", r.errors.single())
    }

    // ------------------------------------------------------------------ opening chats and paging

    @Test
    fun `opening a chat loads the newest 12 turns, oldest first, with lazy reasoning`() = runTest {
        val r = rig(standard)
        r.vm.openConversation("c1"); runCurrent()
        val request = r.link.opsCalled("chat.get").single()
        assertEquals("12", request["limit"]!!.jsonPrimitive.content)
        assertNull(request["after"])
        assertEquals(listOf("question 1", "answer 1", "question 2", "answer 2", "question 3", "answer 3"), r.state.messages.map { it.content })
        assertEquals("A chat", r.state.title)
        assertEquals("Ornith 8B", r.state.model.name.let { "Ornith 8B" }) // chat model id resolves to a name once seen
        assertFalse(r.state.hasOlder)
        assertTrue(r.state.messages.last().hasThinking)
        assertNull(r.state.messages.last().thinking)
    }

    @Test
    fun `scrolling up loads 20 older turns once per page and keeps order`() = runTest {
        val r = rig { op, args ->
            when (op) {
                "chat.get" -> if (args["after"] == null) buildJsonObject {
                    put("chat", summary(turns = 40))
                    put("items", JsonArray((40 downTo 29).map { turn(it) }))
                    put("total", 40); put("next", "cursor1")
                } else buildJsonObject {
                    put("items", JsonArray((28 downTo 9).map { turn(it) }))
                    put("total", 40); put("next", "cursor2")
                }
                else -> buildJsonObject { }
            }
        }
        r.vm.openConversation("c1"); runCurrent()
        assertEquals(24, r.state.messages.size)
        assertTrue(r.state.hasOlder)
        r.vm.loadOlder(); r.vm.loadOlder(); r.vm.loadOlder(); runCurrent() // repeated triggers: one request
        val older = r.link.opsCalled("chat.get").last()
        assertEquals("20", older["limit"]!!.jsonPrimitive.content)
        assertEquals("cursor1", older["after"]!!.jsonPrimitive.content)
        assertEquals(2, r.link.opsCalled("chat.get").size)
        assertEquals(64, r.state.messages.size)
        assertEquals("question 9", r.state.messages.first().content)
        assertEquals("answer 40", r.state.messages.last().content)
        assertEquals(r.state.messages.size, r.state.messages.map { it.id }.toSet().size)
        assertTrue(r.state.hasOlder)
    }

    @Test
    fun `a chat that cannot be loaded shows the error and retries`() = runTest {
        var fail = true
        val r = rig { op, _ -> if (op == "chat.get") { if (fail) throw RpcException(RpcException.TIMEOUT, "t") else standard(op, buildJsonObject { }) } else buildJsonObject { } }
        r.vm.openConversation("c1"); runCurrent()
        assertEquals("The PC did not answer in time.", r.state.loadError)
        fail = false
        r.vm.retryLoad(); runCurrent()
        assertNull(r.state.loadError)
        assertEquals(6, r.state.messages.size)
    }

    @Test
    fun `reasoning of an old turn is fetched when asked, once`() = runTest {
        val r = rig { op, args ->
            when (op) {
                "turn.get" -> buildJsonObject { put("turn", turn(3).let { t -> JsonObject(t + ("thinking" to buildJsonObject { put("ms", 1500); put("text", "I considered X") })) }) }
                else -> standard(op, args)
            }
        }
        r.vm.openConversation("c1"); runCurrent()
        val reply = r.state.messages.last()
        r.vm.loadThinking(reply); r.vm.loadThinking(reply); runCurrent()
        assertEquals("I considered X", r.state.messages.last().thinking)
        assertEquals(1, r.link.opsCalled("turn.get").size)
        assertEquals("true", r.link.opsCalled("turn.get").single()["include"].toString().contains("thinking").toString())
        r.vm.loadThinking(r.state.messages.last()); runCurrent()
        assertEquals(1, r.link.opsCalled("turn.get").size)
    }

    @Test
    fun `a tool card loads its body only when opened`() = runTest {
        val r = rig { op, args ->
            when (op) {
                "tool.get" -> buildJsonObject { put("callId", "t1"); put("view", buildJsonObject { put("title", "Ran tests"); put("body", "4 passed"); put("style", "command") }) }
                "chat.get" -> buildJsonObject {
                    put("chat", summary(turns = 1))
                    put("items", JsonArray(listOf(JsonObject(turn(1) + ("tools" to JsonArray(listOf(buildJsonObject { put("callId", "t1"); put("name", "run_command"); put("ok", true); put("title", "Ran tests") })))))))
                    put("total", 1)
                }
                else -> standard(op, args)
            }
        }
        r.vm.openConversation("c1"); runCurrent()
        assertTrue(r.link.opsCalled("tool.get").isEmpty())
        val message = r.state.messages.last()
        r.vm.loadTool(message, message.tools.single()); runCurrent()
        val loaded = r.state.toolViews["p1:t1"] as ToolViewState.Loaded
        assertEquals("4 passed", loaded.view.body)
        assertEquals("command", loaded.view.style)
    }

    // ------------------------------------------------------------------ editing

    @Test
    fun `regenerate rewinds from that prompt and asks the same question again`() = runTest {
        val r = rig(standard)
        r.vm.openConversation("c1"); runCurrent()
        val last = r.state.messages.last()
        r.vm.regenerate(last); runCurrent()
        val rewind = r.link.opsCalled("chat.rewind").single()
        assertEquals("p3", rewind["fromPromptId"]!!.jsonPrimitive.content)
        assertEquals("question 3", r.link.opsCalled("prompt").single()["text"]!!.jsonPrimitive.content)
        // the old turn is gone from the list while the new one streams
        assertEquals(listOf("question 1", "answer 1", "question 2", "answer 2", "question 3", ""), r.state.messages.map { it.content })
        assertTrue(r.state.isGenerating)
    }

    @Test
    fun `editing a message sends the new text after a rewind`() = runTest {
        val r = rig(standard)
        r.vm.openConversation("c1"); runCurrent()
        val userMessage = r.state.messages[2]
        r.vm.editAndResend(userMessage, "  better question  "); runCurrent()
        assertEquals("p2", r.link.opsCalled("chat.rewind").single()["fromPromptId"]!!.jsonPrimitive.content)
        assertEquals("better question", r.link.opsCalled("prompt").single()["text"]!!.jsonPrimitive.content)
        assertEquals(listOf("question 1", "answer 1", "better question", ""), r.state.messages.map { it.content })
    }

    @Test
    fun `if the prompt after a rewind fails the old text goes back to the draft`() = runTest {
        val r = rig { op, args -> if (op == "prompt") throw RpcException(RpcException.NOT_CONNECTED, "x") else standard(op, args) }
        r.vm.openConversation("c1"); runCurrent()
        r.vm.regenerate(r.state.messages.last()); runCurrent()
        assertEquals("question 3", r.vm.draft)
    }

    @Test
    fun `thumbs toggle and go to the PC`() = runTest {
        val r = rig(standard)
        r.vm.openConversation("c1"); runCurrent()
        r.vm.setFeedback(r.state.messages.last(), Feedback.POSITIVE); runCurrent()
        assertEquals("up", r.link.opsCalled("turn.feedback").last()["value"]!!.jsonPrimitive.content)
        assertEquals(Feedback.POSITIVE, r.state.messages.last().feedback)
        r.vm.setFeedback(r.state.messages.last(), Feedback.POSITIVE); runCurrent()
        assertEquals("none", r.link.opsCalled("turn.feedback").last()["value"]!!.jsonPrimitive.content)
        assertEquals(Feedback.NONE, r.state.messages.last().feedback)
    }

    @Test
    fun `star, rename and delete use chat set and chat delete`() = runTest {
        val r = rig { op, args ->
            when (op) {
                "chat.set" -> buildJsonObject { put("chat", summary(title = args["title"]?.jsonPrimitive?.content ?: "A chat", starred = args["starred"]?.jsonPrimitive?.content == "true")) }
                else -> standard(op, args)
            }
        }
        r.vm.openConversation("c1"); runCurrent()
        r.vm.toggleStar(); runCurrent()
        assertTrue(r.state.isStarred)
        r.vm.rename("  Renamed  "); runCurrent()
        assertEquals("Renamed", r.state.title)
        assertEquals("Renamed", r.link.opsCalled("chat.set").last()["title"]!!.jsonPrimitive.content)
        r.vm.deleteActive(); runCurrent()
        assertEquals(1, r.link.opsCalled("chat.delete").size)
        assertNull(r.state.conversationId)
    }

    // ------------------------------------------------------------------ streaming controls

    @Test
    fun `stop asks the PC to cancel the running turn`() = runTest {
        val r = rig(standard)
        r.vm.updateDraft("long task"); r.vm.send(); runCurrent()
        r.vm.stop(); runCurrent()
        val cancel = r.link.opsCalled("turn.cancel").single()
        assertEquals("c1", cancel["chatId"]!!.jsonPrimitive.content)
        assertEquals("p9", cancel["promptId"]!!.jsonPrimitive.content)
        r.link.emit(LinkEvent.TurnCancelled(1, com.avek.chat.core.link.wire.TurnEndedDto("c1", "p9"))); runCurrent()
        assertFalse(r.state.isGenerating)
        assertEquals(MessageStatus.STOPPED, r.state.messages.last().status)
    }

    @Test
    fun `tools show up in the streaming reply`() = runTest {
        val r = rig(standard)
        r.vm.updateDraft("do it"); r.vm.send(); runCurrent()
        r.link.emit(LinkEvent.ToolCall(1, ToolCallEventDto("c1", "p9", "t1", "read_file", "Reading a.txt")))
        runCurrent()
        assertTrue(r.state.messages.last().tools.single().isRunning)
        r.link.emit(LinkEvent.ToolResult(2, ToolResultEventDto("c1", "p9", "t1", true, "Read a.txt")))
        runCurrent()
        assertEquals(true, r.state.messages.last().tools.single().ok)
    }

    @Test
    fun `a turn that is still running on the PC is followed when its chat is opened`() = runTest {
        val r = rig { op, args ->
            when (op) {
                "chat.get" -> buildJsonObject {
                    put("chat", summary(turns = 1))
                    put("items", JsonArray(listOf(JsonObject(turn(1, answer = "Partial") + ("status" to JsonPrimitive("in-progress"))))))
                    put("total", 1)
                }
                else -> standard(op, args)
            }
        }
        r.vm.openConversation("c1"); runCurrent()
        assertTrue(r.state.isGenerating)
        r.link.emit(LinkEvent.AnswerDelta(1, DeltaDto("c1", "p1", " answer", 7)))
        r.link.emit(LinkEvent.TurnCompleted(2, TurnCompletedDto("c1", "p1")))
        runCurrent()
        assertFalse(r.state.isGenerating)
        assertEquals("Partial answer", r.state.messages.last().content)
    }

    @Test
    fun `a chat deleted on the PC while open falls back to a new chat`() = runTest {
        val r = rig(standard)
        r.vm.openConversation("c1"); runCurrent()
        r.link.emit(LinkEvent.ChatDeleted(1, "c1")); runCurrent()
        assertNull(r.state.conversationId)
        assertTrue(r.state.messages.isEmpty())
    }

    @Test
    fun `a title change on the PC is shown`() = runTest {
        val r = rig(standard)
        r.vm.openConversation("c1"); runCurrent()
        r.link.emit(LinkEvent.ChatUpdated(1, ChatSummaryDto("c1", "Better title", "2025-01-01T00:00:00Z", "2025-01-01T02:00:00Z", "m1", "auto", 3, "p", false, false)))
        runCurrent()
        assertEquals("Better title", r.state.title)
    }

    @Test
    fun `drafts are kept per chat when switching`() = runTest {
        val r = rig(standard)
        r.vm.updateDraft("draft for the new chat")
        r.vm.openConversation("c1"); runCurrent()
        assertEquals("", r.vm.draft)
        r.vm.updateDraft("draft for c1")
        r.vm.newChat(); runCurrent()
        assertEquals("draft for the new chat", r.vm.draft)
        r.vm.openConversation("c1"); runCurrent()
        assertEquals("draft for c1", r.vm.draft)
    }

    @Test
    fun `reconnecting refreshes the open chat and keeps older turns`() = runTest {
        var turns = listOf(turn(3), turn(2), turn(1))
        val r = rig { op, args ->
            if (op == "chat.get") buildJsonObject { put("chat", summary()); put("items", JsonArray(turns)); put("total", turns.size) } else standard(op, args)
        }
        r.vm.openConversation("c1"); runCurrent()
        turns = listOf(turn(4, answer = "news"), turn(3), turn(2))
        r.link.emit(LinkEvent.Refresh); runCurrent()
        assertEquals(listOf("question 1", "answer 1", "question 2", "answer 2", "question 3", "answer 3", "question 4", "news"), r.state.messages.map { it.content })
    }

    // ------------------------------------------------------------------ attachments

    @Test
    fun `attachments upload with progress and their ids go into the prompt`() = runTest {
        val gate = kotlinx.coroutines.CompletableDeferred<Unit>()
        val r = rig { op, args ->
            when (op) {
                "attach.begin" -> { gate.await(); buildJsonObject { put("uploadId", "u1"); put("chunkBytes", 4) } }
                "attach.end" -> buildJsonObject { put("attachmentId", "a_77"); put("name", "notes.txt"); put("size", 10) }
                else -> standard(op, args)
            }
        }
        r.files["content://notes"] = TextFile("notes.txt", "0123456789".toByteArray())
        r.vm.updateDraft("Summarise this")
        r.vm.attach(listOf("content://notes")); runCurrent()
        assertEquals(AttachStatus.UPLOADING, r.state.attachments.single().status)
        assertFalse(r.state.canSend(r.vm.draft)) // still uploading
        gate.complete(Unit)
        advanceTimeBy(5_000); runCurrent()
        // the uploader runs on Dispatchers.IO: give it real time
        val deadline = System.currentTimeMillis() + 5_000
        while (r.state.attachments.firstOrNull()?.status == AttachStatus.UPLOADING && System.currentTimeMillis() < deadline) { Thread.sleep(10); runCurrent() }
        assertEquals(AttachStatus.READY, r.state.attachments.single().status)
        assertTrue(r.state.canSend(r.vm.draft))
        r.vm.send(); runCurrent()
        val ids = r.link.opsCalled("prompt").single()["attachments"] as JsonArray
        assertEquals(listOf("a_77"), ids.map { it.jsonPrimitive.content })
        assertTrue(r.state.attachments.isEmpty())
        assertEquals("notes.txt", r.state.messages.first().attachments.single().name)
    }

    @Test
    fun `an unreadable file is reported and removing a chip forgets it`() = runTest {
        val r = rig(standard)
        r.vm.attach(listOf("content://missing")); runCurrent()
        assertEquals(listOf("Could not read that file"), r.errors)
        assertTrue(r.state.attachments.isEmpty())
    }

    // ------------------------------------------------------------------ questions

    @Test
    fun `a question from the PC is exposed and answered`() = runTest {
        val r = rig(standard)
        r.link.emit(LinkEvent.AskRequest(1, AskRequestDto("c1", "p1", "k1", "approval", "run_command", "Run it?")))
        runCurrent()
        val ask = r.vm.pendingAsk.value
        assertNotNull(ask)
        r.vm.answerAsk(ask!!, "allow-session"); runCurrent()
        val args = r.link.opsCalled("ask.answer").single()
        assertEquals("k1", args["askId"]!!.jsonPrimitive.content)
        assertEquals("allow-session", args["decision"]!!.jsonPrimitive.content)
        assertNull(r.vm.pendingAsk.value)
    }

    @Test
    fun `a text question is answered with text`() = runTest {
        val r = rig(standard)
        r.link.emit(LinkEvent.AskRequest(1, AskRequestDto("c1", "p1", "k2", "question", null, "Which folder?", choices = emptyList())))
        runCurrent()
        r.vm.answerAskText(r.vm.pendingAsk.value!!, "Documents"); runCurrent()
        assertEquals("Documents", r.link.opsCalled("ask.answer").single()["text"]!!.jsonPrimitive.content)
    }

    @Test
    fun `an ask someone else answered disappears`() = runTest {
        val r = rig(standard)
        r.link.emit(LinkEvent.AskRequest(1, AskRequestDto("c1", "p1", "k3", "approval", "t", "Run?")))
        runCurrent()
        r.link.emit(LinkEvent.AskResolved(2, com.avek.chat.core.link.wire.AskResolvedDto("k3", "deny", "laptop")))
        runCurrent()
        assertNull(r.vm.pendingAsk.value)
    }

    // ------------------------------------------------------------------ opening from elsewhere

    @Test
    fun `a chat opened from the downloads screen or a notification is shown`() = runTest {
        val r = rig(standard)
        r.openChat.open("c1"); runCurrent()
        assertEquals("c1", r.state.conversationId)
        assertNull(r.openChat.pending.value)
    }
}
