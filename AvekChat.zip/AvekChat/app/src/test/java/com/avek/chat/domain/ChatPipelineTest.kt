package com.avek.chat.domain

import com.avek.chat.core.common.AppDispatchers
import com.avek.chat.core.common.TimeProvider
import com.avek.chat.core.data.fake.ResponseComposer
import com.avek.chat.core.data.fake.SimulatedInferenceEngine
import com.avek.chat.core.data.repository.StaticModelRepository
import com.avek.chat.core.domain.usecase.ChatOptions
import com.avek.chat.core.domain.usecase.GenerateReplyUseCase
import com.avek.chat.core.domain.usecase.ReplyPhase
import com.avek.chat.core.domain.usecase.SendMessageUseCase
import com.avek.chat.core.domain.usecase.TaskClassifier
import com.avek.chat.core.domain.usecase.TitleGenerator
import com.avek.chat.core.model.MessageStatus
import com.avek.chat.core.model.Role
import com.avek.chat.core.model.TaskMode
import com.avek.chat.core.model.ThinkingDepth
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.toList
import kotlinx.coroutines.launch
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.TestScope
import kotlinx.coroutines.test.advanceTimeBy
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.concurrent.atomic.AtomicInteger

class ChatPipelineTest {

    private val dispatcher = StandardTestDispatcher()
    private val scope = TestScope(dispatcher)
    private val repository = FakeConversationRepository()
    private val models = StaticModelRepository()
    private val counter = AtomicInteger()
    private val ids = { "id-${counter.incrementAndGet()}" }
    private val time = object : TimeProvider {
        override fun now(): Long = scope.testScheduler.currentTime
    }
    private val dispatchers = object : AppDispatchers {
        override val io: CoroutineDispatcher = dispatcher
        override val default: CoroutineDispatcher = dispatcher
        override val main: CoroutineDispatcher = dispatcher
    }
    private val send = SendMessageUseCase(repository, TitleGenerator(), ids, time)
    private val generate = GenerateReplyUseCase(
        repository,
        models,
        SimulatedInferenceEngine(ResponseComposer(), time),
        TaskClassifier(),
        ids,
        time,
        dispatchers,
    )

    @Test
    fun `auto mode routes, thinks, then answers and persists a complete reply`() = scope.runTest {
        val options = ChatOptions("avek-atlas", TaskMode.AUTO, ThinkingDepth.DEEP)
        val id = send(null, "Write a Kotlin function to debounce search input", options, autoTitle = true)

        val snapshots = generate(id, options).toList()

        assertTrue(snapshots.any { it.phase == ReplyPhase.THINKING && it.activity != null })
        assertEquals(ReplyPhase.DONE, snapshots.last().phase)
        val messages = repository.getMessages(id)
        assertEquals(listOf(Role.USER, Role.ASSISTANT), messages.map { it.role })
        val reply = messages.last()
        assertEquals(MessageStatus.COMPLETE, reply.status)
        assertEquals(TaskMode.CODING, reply.resolvedTask)
        assertTrue(reply.content.contains("```kotlin"))
        assertTrue(reply.thinking!!.isNotBlank())
        assertTrue(reply.thinkingDurationMs > 0)
        assertEquals("Write a Kotlin function to debounce search", repository.getConversation(id)!!.title)
    }

    @Test
    fun `instant depth skips thinking and depth is clamped to the model`() = scope.runTest {
        val flash = ChatOptions("avek-flash", TaskMode.GENERAL, ThinkingDepth.MAXIMUM)
        val id = send(null, "Hello there", flash, autoTitle = true)
        val reply = generate(id, flash).toList().last().message
        assertEquals(ThinkingDepth.LIGHT, reply.depth)

        val instant = flash.copy(depth = ThinkingDepth.INSTANT)
        send(id, "And again", instant, autoTitle = true)
        val second = generate(id, instant).toList().last().message
        assertNull(second.thinking)
    }

    @Test
    fun `deep research collects sources`() = scope.runTest {
        val options = ChatOptions("avek-sage", TaskMode.DEEP_RESEARCH, ThinkingDepth.DEEP)
        val id = send(null, "Research coral reef restoration", options, autoTitle = true)
        val reply = generate(id, options).toList().last().message
        assertEquals(4 + ThinkingDepth.DEEP.level * 2, reply.sources.size)
    }

    @Test
    fun `stopping mid-stream persists a stopped partial reply`() = scope.runTest {
        val options = ChatOptions("avek-nova", TaskMode.WRITING, ThinkingDepth.BALANCED)
        val id = send(null, "Draft a short welcome note", options, autoTitle = true)

        val job = launch { generate(id, options).collect {} }
        advanceTimeBy(3_000)
        job.cancel()
        job.join()

        val reply = repository.getMessages(id).last()
        assertEquals(Role.ASSISTANT, reply.role)
        assertEquals(MessageStatus.STOPPED, reply.status)
        assertNotNull(reply.thinking)
    }

    @Test
    fun `observed conversation reflects the new title`() = scope.runTest {
        val id = send(null, "Please explain black holes", ChatOptions("avek-nova", TaskMode.LEARN, ThinkingDepth.INSTANT), autoTitle = true)
        assertEquals("Explain black holes", repository.observeConversation(id).first()!!.title)
    }
}
