package com.avek.chat.domain

import com.avek.chat.core.common.TimeProvider
import com.avek.chat.core.data.remote.RemoteChatRepository
import com.avek.chat.core.domain.chat.ChatOptions
import com.avek.chat.core.domain.chat.GenerateReplyUseCase
import com.avek.chat.core.domain.chat.PromptRequest
import com.avek.chat.core.domain.chat.ReplyPhase
import com.avek.chat.core.domain.chat.StreamingReply
import com.avek.chat.core.domain.chat.TurnFollower
import com.avek.chat.core.link.HarnessApi
import com.avek.chat.core.link.rpc.RpcException
import com.avek.chat.core.link.wire.AskRequestDto
import com.avek.chat.core.link.wire.AskResolvedDto
import com.avek.chat.core.link.wire.DeltaDto
import com.avek.chat.core.link.wire.LinkEvent
import com.avek.chat.core.link.wire.SourceDto
import com.avek.chat.core.link.wire.SourcesEventDto
import com.avek.chat.core.link.wire.StatusDto
import com.avek.chat.core.link.wire.ToolCallEventDto
import com.avek.chat.core.link.wire.ToolResultEventDto
import com.avek.chat.core.link.wire.TurnCompletedDto
import com.avek.chat.core.link.wire.TurnEndedDto
import com.avek.chat.core.link.wire.TurnFailedDto
import com.avek.chat.core.link.wire.TurnStartedDto
import com.avek.chat.core.model.MessageStatus
import com.avek.chat.core.model.TaskMode
import com.avek.chat.core.model.ThinkingDepth
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.launch
import kotlinx.coroutines.test.TestScope
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * The reply pipeline against a scripted PC: prompt acknowledgement, event-driven streaming,
 * offsets, reloads after a gap, tools, asks and the three ways a turn can end.
 */
@OptIn(ExperimentalCoroutinesApi::class)
class ReplyFlowTest {

    private val time = object : TimeProvider { override fun now() = 1_000L }

    private class Fixture(val link: FakeLink, val useCase: GenerateReplyUseCase)

    private fun fixture(handler: suspend (String, JsonObject) -> kotlinx.serialization.json.JsonElement): Fixture {
        val link = FakeLink(handler)
        val api = HarnessApi(link)
        val follower = TurnFollower(RemoteChatRepository(api))
        return Fixture(link, GenerateReplyUseCase(api, link, follower, time))
    }

    private val ack = buildJsonObject {
        put("chatId", "c1")
        put("promptId", "p1")
        put("chat", buildJsonObject { put("chatId", "c1"); put("title", "New chat") })
    }

    private fun request(depth: ThinkingDepth = ThinkingDepth.BALANCED, chatId: String? = null) = PromptRequest(
        chatId = chatId,
        text = "Hello",
        options = ChatOptions(modelId = null, task = TaskMode.AUTO, depth = depth),
        uiKey = "ui1",
    )

    private fun TestScope.collect(f: Fixture, req: PromptRequest = request()): MutableList<StreamingReply> {
        val seen = mutableListOf<StreamingReply>()
        backgroundScope.launch { f.useCase(req).collect { seen += it } }
        runCurrent()
        return seen
    }

    @Test
    fun `prompt carries only the new text and options and omits model and attachments when unset`() = runTest {
        val f = fixture { _, _ -> ack }
        collect(f)
        val args = f.link.opsCalled("prompt").single()
        assertEquals("Hello", args["text"]!!.jsonPrimitive.content)
        assertTrue(args["chatId"] is JsonNull)
        assertNull(args["modelId"])
        assertNull(args["attachments"])
        val options = args["options"]!!.jsonObject
        assertEquals(2, options["depth"]!!.jsonPrimitive.content.toInt())
        assertEquals("auto", options["mode"]!!.jsonPrimitive.content)
        assertTrue("no history is ever sent", args.keys == setOf("chatId", "text", "options"))
    }

    @Test
    fun `an existing chat id, model and attachment ids are sent as given`() = runTest {
        val f = fixture { _, _ -> ack }
        collect(f, request(chatId = "c1").copy(options = ChatOptions("m1", TaskMode.CODING, ThinkingDepth.DEEP), attachmentIds = listOf("a1", "a2")))
        val args = f.link.opsCalled("prompt").single()
        assertEquals("c1", args["chatId"]!!.jsonPrimitive.content)
        assertEquals("m1", args["modelId"]!!.jsonPrimitive.content)
        assertEquals("coding", args["options"]!!.jsonObject["mode"]!!.jsonPrimitive.content)
        assertEquals(listOf("a1", "a2"), (args["attachments"] as JsonArray).map { it.jsonPrimitive.content })
    }

    @Test
    fun `the first snapshot shows the user message and an empty streaming reply`() = runTest {
        val f = fixture { _, _ -> ack }
        val seen = collect(f)
        val first = seen.first()
        assertEquals("Hello", first.user.content)
        assertEquals("ui1", first.user.uiKey)
        assertEquals("p1:u", first.user.id)
        assertEquals("", first.message.content)
        assertEquals(MessageStatus.STREAMING, first.message.status)
        assertEquals(ReplyPhase.THINKING, first.phase)
        assertEquals("c1", first.chat?.id)
    }

    @Test
    fun `an instant turn skips the thinking phase`() = runTest {
        val f = fixture { _, _ -> ack }
        assertEquals(ReplyPhase.ANSWERING, collect(f, request(ThinkingDepth.INSTANT)).first().phase)
    }

    @Test
    fun `thinking and answer deltas build the reply and a completed turn ends the flow`() = runTest {
        val f = fixture { _, _ -> ack }
        val seen = collect(f)
        f.link.emit(LinkEvent.ThinkingDelta(1, DeltaDto("c1", "p1", "Let me ", 0)))
        f.link.emit(LinkEvent.ThinkingDelta(2, DeltaDto("c1", "p1", "think.", 7)))
        f.link.emit(LinkEvent.AnswerDelta(3, DeltaDto("c1", "p1", "Hi", 0)))
        f.link.emit(LinkEvent.AnswerDelta(4, DeltaDto("c1", "p1", " there", 2)))
        f.link.emit(LinkEvent.TurnCompleted(5, TurnCompletedDto("c1", "p1", thinkingMs = 900)))
        runCurrent()
        val last = seen.last()
        assertEquals("Hi there", last.message.content)
        assertEquals("Let me think.", last.message.thinking)
        assertEquals(900L, last.message.thinkingDurationMs)
        assertEquals(MessageStatus.COMPLETE, last.message.status)
        assertEquals(ReplyPhase.DONE, last.phase)
        assertTrue(seen.any { it.phase == ReplyPhase.THINKING && it.message.thinking == "Let me think." })
        assertTrue(seen.any { it.phase == ReplyPhase.ANSWERING && it.message.content == "Hi" })
    }

    @Test
    fun `a replayed delta is ignored and events of other turns are skipped`() = runTest {
        val f = fixture { _, _ -> ack }
        val seen = collect(f)
        f.link.emit(LinkEvent.AnswerDelta(1, DeltaDto("c1", "p1", "abc", 0)))
        f.link.emit(LinkEvent.AnswerDelta(2, DeltaDto("c1", "p1", "abc", 0))) // resume replay
        f.link.emit(LinkEvent.AnswerDelta(3, DeltaDto("c1", "OTHER", "zzz", 0)))
        f.link.emit(LinkEvent.AnswerDelta(4, DeltaDto("c9", "p1", "zzz", 0)))
        f.link.emit(LinkEvent.AnswerDelta(5, DeltaDto("c1", "p1", "def", 3)))
        runCurrent()
        assertEquals("abcdef", seen.last().message.content)
    }

    @Test
    fun `an overlapping delta only adds its new tail`() = runTest {
        val f = fixture { _, _ -> ack }
        val seen = collect(f)
        f.link.emit(LinkEvent.AnswerDelta(1, DeltaDto("c1", "p1", "Hello", 0)))
        f.link.emit(LinkEvent.AnswerDelta(2, DeltaDto("c1", "p1", "lo world", 3)))
        runCurrent()
        assertEquals("Hello world", seen.last().message.content)
    }

    @Test
    fun `a gap reloads the turn with turn get and carries on from there`() = runTest {
        val f = fixture { op, _ ->
            when (op) {
                "prompt" -> ack
                "turn.get" -> buildJsonObject {
                    put("turn", buildJsonObject {
                        put("promptId", "p1")
                        put("status", "in-progress")
                        put("assistant", buildJsonObject { put("text", "Hello wor") })
                        put("thinking", buildJsonObject { put("ms", 10); put("text", "hmm") })
                    })
                }
                else -> error(op)
            }
        }
        val seen = collect(f)
        f.link.emit(LinkEvent.AnswerDelta(1, DeltaDto("c1", "p1", "Hello", 0)))
        f.link.emit(LinkEvent.AnswerDelta(2, DeltaDto("c1", "p1", "ld", 11))) // offset 11 but only 5 known: gap
        runCurrent()
        assertEquals(1, f.link.opsCalled("turn.get").size)
        assertEquals("Hello wor", seen.last().message.content)
        assertEquals("hmm", seen.last().message.thinking)
        assertEquals("ui1:a", seen.last().message.uiKey)
        f.link.emit(LinkEvent.AnswerDelta(3, DeltaDto("c1", "p1", "ld", 9)))
        runCurrent()
        assertEquals("Hello world", seen.last().message.content)
    }

    @Test
    fun `after a reconnect the turn is looked at again and ends if it finished meanwhile`() = runTest {
        val f = fixture { op, _ ->
            when (op) {
                "prompt" -> ack
                "turn.get" -> buildJsonObject {
                    put("turn", buildJsonObject {
                        put("promptId", "p1")
                        put("status", "completed")
                        put("assistant", buildJsonObject { put("text", "All done") })
                    })
                }
                else -> error(op)
            }
        }
        val seen = collect(f)
        f.link.emit(LinkEvent.AnswerDelta(1, DeltaDto("c1", "p1", "All", 0)))
        f.link.emit(LinkEvent.Refresh)
        runCurrent()
        assertEquals("All done", seen.last().message.content)
        assertEquals(MessageStatus.COMPLETE, seen.last().message.status)
        assertEquals(ReplyPhase.DONE, seen.last().phase)
    }

    @Test
    fun `a failed reload keeps what we have`() = runTest {
        val f = fixture { op, _ -> if (op == "prompt") ack else throw RpcException.notConnected() }
        val seen = collect(f)
        f.link.emit(LinkEvent.AnswerDelta(1, DeltaDto("c1", "p1", "Hi", 0)))
        f.link.emit(LinkEvent.AnswerDelta(2, DeltaDto("c1", "p1", "!", 50)))
        runCurrent()
        assertEquals("Hi", seen.last().message.content)
    }

    @Test
    fun `tools appear while running and settle with their result`() = runTest {
        val f = fixture { _, _ -> ack }
        val seen = collect(f)
        f.link.emit(LinkEvent.ToolCall(1, ToolCallEventDto("c1", "p1", "t1", "read_file", "Reading notes.md", "notes.md")))
        runCurrent()
        assertEquals("Reading notes.md", seen.last().activity)
        assertTrue(seen.last().message.tools.single().isRunning)
        f.link.emit(LinkEvent.ToolResult(2, ToolResultEventDto("c1", "p1", "t1", ok = true, title = "Read notes.md")))
        runCurrent()
        val tool = seen.last().message.tools.single()
        assertEquals(true, tool.ok)
        assertEquals("Read notes.md", tool.title)
        assertEquals("read_file", tool.name)
        assertNull(seen.last().activity)
    }

    @Test
    fun `status updates show as activity until done`() = runTest {
        val f = fixture { _, _ -> ack }
        val seen = collect(f)
        f.link.emit(LinkEvent.Status(1, StatusDto("c1", "p1", "loading", "update", "Loading Ornith…")))
        runCurrent()
        assertEquals("Loading Ornith…", seen.last().activity)
        f.link.emit(LinkEvent.Status(2, StatusDto("c1", "p1", "loading", "done", "")))
        runCurrent()
        assertNull(seen.last().activity)
    }

    @Test
    fun `sources are attached to the reply`() = runTest {
        val f = fixture { _, _ -> ack }
        val seen = collect(f)
        f.link.emit(LinkEvent.Sources(1, SourcesEventDto("c1", "p1", listOf(SourceDto("T", "example.com", "https://example.com", "s")))))
        runCurrent()
        assertEquals("example.com", seen.last().message.sources.single().domain)
    }

    @Test
    fun `an ask pauses the turn and its resolution resumes it`() = runTest {
        val f = fixture { _, _ -> ack }
        val seen = collect(f)
        f.link.emit(LinkEvent.AskRequest(1, AskRequestDto("c1", "p1", "ask1", "approval", "run_command", "Run npm install?")))
        runCurrent()
        assertEquals(MessageStatus.WAITING, seen.last().message.status)
        f.link.emit(LinkEvent.AskResolved(2, AskResolvedDto("ask1", "allow", "phone")))
        runCurrent()
        assertEquals(MessageStatus.STREAMING, seen.last().message.status)
    }

    @Test
    fun `a cancelled turn is stopped and a failed turn carries its message`() = runTest {
        val cancelled = fixture { _, _ -> ack }
        val a = collect(cancelled)
        cancelled.link.emit(LinkEvent.AnswerDelta(1, DeltaDto("c1", "p1", "partial", 0)))
        cancelled.link.emit(LinkEvent.TurnCancelled(2, TurnEndedDto("c1", "p1")))
        runCurrent()
        assertEquals(MessageStatus.STOPPED, a.last().message.status)
        assertEquals("partial", a.last().message.content)

        val failed = fixture { _, _ -> ack }
        val b = collect(failed)
        failed.link.emit(LinkEvent.TurnFailed(1, TurnFailedDto("c1", "p1", "Model crashed")))
        runCurrent()
        assertEquals(MessageStatus.ERROR, b.last().message.status)
        assertEquals("Model crashed", b.last().message.error)
        assertEquals(ReplyPhase.DONE, b.last().phase)
    }

    @Test
    fun `nothing is emitted for a turn after it ended`() = runTest {
        val f = fixture { _, _ -> ack }
        val seen = collect(f)
        f.link.emit(LinkEvent.TurnCompleted(1, TurnCompletedDto("c1", "p1")))
        runCurrent()
        val count = seen.size
        f.link.emit(LinkEvent.AnswerDelta(2, DeltaDto("c1", "p1", "late", 0)))
        runCurrent()
        assertEquals(count, seen.size)
    }

    @Test
    fun `a rejected prompt fails the flow with the protocol error`() = runTest {
        val f = fixture { _, _ -> throw RpcException("model-unavailable", "No such model") }
        var error: Throwable? = null
        backgroundScope.launch { try { f.useCase(request()).collect { } } catch (e: Throwable) { error = e } }
        runCurrent()
        assertEquals("model-unavailable", (error as RpcException).code)
    }

    @Test
    fun `events that arrive right after the acknowledgement are not lost`() = runTest {
        val link = FakeLink()
        link.handler = { op, _ ->
            // The PC sends the first delta immediately after the ack, before the app has looked at the ack.
            if (op == "prompt") { link.emit(LinkEvent.AnswerDelta(1, DeltaDto("c1", "p1", "fast", 0))); ack } else error(op)
        }
        val api = HarnessApi(link)
        val useCase = GenerateReplyUseCase(api, link, TurnFollower(RemoteChatRepository(api)), time)
        val seen = mutableListOf<StreamingReply>()
        backgroundScope.launch { useCase(request()).collect { seen += it } }
        runCurrent()
        assertEquals("fast", seen.last().message.content)
    }
}
