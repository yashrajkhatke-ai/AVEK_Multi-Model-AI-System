package com.avek.chat.data

import com.avek.chat.core.data.fonts.FontCatalogParser
import com.avek.chat.core.model.FontCategory
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class FontCatalogParserTest {

    @Test
    fun `parses rows and skips comments and junk`() {
        val fonts = FontCatalogParser.parse(
            sequenceOf(
                "# header",
                "Inter\tsans\t100,400,900\t1",
                "Broken line",
                "Lora\tserif\t400,700\t0",
                "Odd\tunknown\t400\t0",
            ),
        )
        assertEquals(listOf("Inter", "Lora"), fonts.map { it.name })
        assertEquals(FontCategory.SANS, fonts[0].category)
        assertEquals(listOf(100, 400, 900), fonts[0].weights)
        assertTrue(fonts[0].hasItalic)
    }
}
