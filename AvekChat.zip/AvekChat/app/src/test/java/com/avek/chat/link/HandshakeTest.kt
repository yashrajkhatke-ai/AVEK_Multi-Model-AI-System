package com.avek.chat.link

import com.avek.chat.core.link.crypto.AvekProtocol
import com.avek.chat.core.link.crypto.HandshakeException
import com.avek.chat.core.link.crypto.PairingGrant
import com.avek.chat.core.link.crypto.PairingResult
import com.avek.chat.core.link.crypto.SecureCrypto
import com.avek.chat.core.link.crypto.SessionGrant
import com.avek.chat.core.link.crypto.SessionHandshake
import com.avek.chat.core.link.rpc.LinkClosedException
import com.avek.chat.core.link.rpc.SecureLinkSession
import com.avek.chat.core.link.store.DeviceKey
import com.avek.chat.core.link.store.SoftwareIdentityVault
import com.avek.chat.core.link.wire.WireJson
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.launch
import kotlinx.coroutines.test.TestScope
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

/** Both handshakes of UI-WIRE v4 (sections 3 and 4) against the in-test fake PC. */
@OptIn(ExperimentalCoroutinesApi::class)
class HandshakeTest {

    private fun TestScope.newServer() = FakeHarnessServer(backgroundScope)

    /** Connects a client channel to [server], serving it in the background. */
    private fun TestScope.connect(server: FakeHarnessServer): InMemoryChannel {
        val (client, serverSide) = InMemoryChannel.pair()
        backgroundScope.launch { server.serve(serverSide) }
        return client
    }

    private fun newKey(alias: String = TEST_ALIAS): DeviceKey {
        val vault = SoftwareIdentityVault().also { it.create(alias) }
        return DeviceKey(vault, alias)
    }

    private suspend fun TestScope.pair(server: FakeHarnessServer, key: DeviceKey = newKey(), code: String = FakeHarnessServer.CODE): Pair<PairingResult, InMemoryChannel> {
        val client = connect(server)
        val result = testPairing().pair(client, key, code.toByteArray(), "Tablet Test")
        return result to client
    }

    private suspend fun TestScope.paired(server: FakeHarnessServer, key: DeviceKey = newKey()): PairingGrant =
        (pair(server, key).first as PairingResult.Paired).grant

    private inline fun <reified T : Throwable> expectFailure(block: () -> Unit): T {
        try {
            block()
        } catch (e: Throwable) {
            if (e is T) return e
            throw AssertionError("Expected ${T::class.simpleName} but got $e", e)
        }
        fail("Expected ${T::class.simpleName}")
        throw IllegalStateException()
    }

    // ------------------------------------------------------------------ pairing (section 3)

    @Test
    fun `pairing with the right code delivers dk and rk and pins the PC`() = runTest {
        val server = newServer()
        val key = newKey()
        val (result, channel) = pair(server, key)
        val grant = (result as PairingResult.Paired).grant
        assertEquals(server.serverId, grant.serverId)
        assertEquals("Test PC", grant.serverName)
        assertArrayEquals(server.serverPub, grant.serverPub)
        assertEquals(AvekProtocol.deviceIdOf(key.publicKey()), grant.deviceId)
        val stored = server.devices.getValue(grant.deviceId)
        assertArrayEquals(stored.dk, grant.secrets.dk)
        assertArrayEquals(stored.rk, grant.secrets.rk)
        assertTrue("the socket is closed and never reused", channel.closedLocally)
    }

    @Test
    fun `the hello carries v4, the keys and a nonce but never the code`() = runTest {
        val server = newServer()
        val (_, channel) = pair(server)
        val hello = WireJson.parseToJsonElement(channel.sentTexts.first()).jsonObject
        assertEquals("pair.hello", hello.getValue("t").jsonPrimitive.content)
        assertEquals("4", hello.getValue("v").jsonPrimitive.content)
        assertEquals(setOf("t", "v", "devPub", "epk", "nonce", "name", "platform"), hello.keys)
        assertEquals("android", hello.getValue("platform").jsonPrimitive.content)
        channel.sentTexts.forEach { assertFalse("the code never travels", FakeHarnessServer.CODE in it) }
        val proof = WireJson.parseToJsonElement(channel.sentTexts[1]).jsonObject
        assertEquals(setOf("t", "sig", "mac"), proof.keys)
    }

    @Test
    fun `the typed digits are wiped after pairing`() = runTest {
        val server = newServer()
        val digits = FakeHarnessServer.CODE.toByteArray()
        testPairing().pair(connect(server), newKey(), digits, "Tablet")
        assertTrue(digits.all { it == 0.toByte() })
    }

    @Test
    fun `a wrong code is NotPaired and nothing is stored on the PC`() = runTest {
        val server = newServer()
        val (result, _) = pair(server, code = "123456789013")
        assertEquals(PairingResult.NotPaired, result)
        assertTrue(server.devices.isEmpty())
    }

    @Test
    fun `a bad server signature in the box is NotPaired`() = runTest {
        val server = newServer().apply { corruptBoxSig = true }
        assertEquals(PairingResult.NotPaired, pair(server).first)
    }

    @Test
    fun `a bad server MAC in the box is NotPaired`() = runTest {
        val server = newServer().apply { corruptBoxMac = true }
        assertEquals(PairingResult.NotPaired, pair(server).first)
    }

    @Test
    fun `a box with another serverId is NotPaired`() = runTest {
        val server = newServer().apply { wrongBoxServerId = true }
        assertEquals(PairingResult.NotPaired, pair(server).first)
    }

    @Test
    fun `a box with another deviceId is NotPaired`() = runTest {
        val server = newServer().apply { wrongBoxDeviceId = true }
        assertEquals(PairingResult.NotPaired, pair(server).first)
    }

    @Test
    fun `a busy window is WindowBusy and a closed window is NotPaired`() = runTest {
        assertEquals(PairingResult.WindowBusy, pair(newServer().apply { busy = true }).first)
        assertEquals(PairingResult.NotPaired, pair(newServer().apply { pairingWindowOpen = false }).first)
    }

    @Test
    fun `weaker scrypt parameters from the PC are refused`() = runTest {
        val server = newServer().apply { weakKdf = true }
        val (result, channel) = pair(server)
        assertEquals(PairingResult.NotPaired, result)
        assertEquals("no proof is sent to such a PC", 1, channel.sentTexts.size)
    }

    @Test
    fun `a silent PC is NotPaired after the hello timeout`() = runTest {
        val server = newServer().apply { staySilentInHandshake = true }
        assertEquals(PairingResult.NotPaired, pair(server).first)
    }

    // ------------------------------------------------------------------ session (section 4)

    private fun grantFor(key: DeviceKey, grant: PairingGrant, dk: ByteArray = grant.secrets.dk, pinned: ByteArray = grant.serverPub, slotNext: Boolean = false) =
        SessionGrant(grant.deviceId, key, pinned, dk, slotNext)

    @Test
    fun `session handshake with dk yields working directional keys`() = runTest {
        val server = newServer()
        val key = newKey()
        val grant = paired(server, key)
        val client = connect(server)
        val keys = SessionHandshake().open(client, grantFor(key, grant))
        val session = SecureLinkSession(client, keys, backgroundScope, onEvent = {}, nowMs = { testScheduler.currentTime })
        session.start()
        val ready = session.awaitReady(5_000)
        assertEquals(4, ready.protocol)
        assertEquals("wifi", ready.route)
        assertTrue(server.sawSessionProof)
        val hello = WireJson.parseToJsonElement(client.sentTexts.first()).jsonObject
        assertEquals("4", hello.getValue("v").jsonPrimitive.content)
        assertNull("no slot outside a key replacement", hello["slot"])
    }

    @Test
    fun `a wrong dk fails the PC's MAC before anything is sent`() = runTest {
        val server = newServer()
        val key = newKey()
        val grant = paired(server, key)
        val client = connect(server)
        expectFailure<HandshakeException.NotOurPc> { SessionHandshake().open(client, grantFor(key, grant, dk = ByteArray(32) { 7 })) }
        assertEquals("only the hello was sent", 1, client.sentTexts.size)
        assertFalse(server.sawSessionProof)
    }

    @Test
    fun `a different PC key is NotOurPc and gets no proof`() = runTest {
        val server = newServer()
        val key = newKey()
        val grant = paired(server, key)
        server.impostor = SoftwareIdentityVault().also { it.create(FakeHarnessServer.ALIAS) }
        val client = connect(server)
        expectFailure<HandshakeException.NotOurPc> { SessionHandshake().open(client, grantFor(key, grant)) }
        assertFalse(server.sawSessionProof)
    }

    @Test
    fun `a bad session signature or MAC is NotOurPc`() = runTest {
        for (flag in listOf("sig", "mac")) {
            val server = newServer()
            val key = newKey()
            val grant = paired(server, key)
            if (flag == "sig") server.corruptSessionSig = true else server.corruptSessionMac = true
            expectFailure<HandshakeException.NotOurPc> { SessionHandshake().open(connect(server), grantFor(key, grant)) }
        }
    }

    @Test
    fun `an unknown device is closed with 4401 and maps to Forgotten`() = runTest {
        val server = newServer()
        val key = newKey()
        val grant = paired(server, key)
        server.devices.clear()
        expectFailure<HandshakeException.Forgotten> { SessionHandshake().open(connect(server), grantFor(key, grant)) }
    }

    @Test
    fun `a device rejected after its proof is closed with 4401 and ready fails`() = runTest {
        val server = newServer()
        val key = newKey()
        val grant = paired(server, key)
        server.rejectProof = true
        val client = connect(server)
        val keys = SessionHandshake().open(client, grantFor(key, grant))
        val session = SecureLinkSession(client, keys, backgroundScope, onEvent = {}, nowMs = { testScheduler.currentTime })
        session.start()
        val error = expectFailure<LinkClosedException> { session.awaitReady(5_000) }
        assertEquals(4401, error.info.code)
        assertTrue(error.info.isAuthFailure)
    }

    @Test
    fun `waking before ready is reported and ready still arrives`() = runTest {
        val server = newServer().apply { wakingBeforeReady = true }
        val key = newKey()
        val grant = paired(server, key)
        val client = connect(server)
        val keys = SessionHandshake().open(client, grantFor(key, grant))
        val waking = mutableListOf<Boolean>()
        val session = SecureLinkSession(client, keys, backgroundScope, onEvent = {}, onWaking = { waking += it }, nowMs = { testScheduler.currentTime })
        session.start()
        session.awaitReady(5_000)
        assertEquals(listOf(true, false), waking)
    }

    @Test
    fun `a replayed or reordered frame closes the session`() = runTest {
        val server = newServer()
        val key = newKey()
        val grant = paired(server, key)
        val client = connect(server)
        val keys = SessionHandshake().open(client, grantFor(key, grant))
        val session = SecureLinkSession(client, keys, backgroundScope, onEvent = {}, nowMs = { testScheduler.currentTime })
        session.start()
        session.awaitReady(5_000)
        val connection = server.connections.single()
        connection.sendEvent("x", obj { })
        connection.sendEvent("y", obj { })
        runCurrent()
        connection.replayFrame(back = 1)
        assertEquals(4400, session.awaitClosed().code)
    }

    @Test
    fun `binary frames during the clear phase are a protocol error`() = runTest {
        val (client, serverSide) = InMemoryChannel.pair()
        backgroundScope.launch {
            serverSide.incoming.receive() // the hello
            serverSide.sendBinary(byteArrayOf(1, 2, 3))
        }
        val key = newKey()
        expectFailure<HandshakeException.Protocol> {
            SessionHandshake().open(client, SessionGrant("d_0000000000", key, key.publicKey(), ByteArray(32)))
        }
    }

    @Test
    fun `a text frame in the secure phase closes the session with 4400`() = runTest {
        val server = newServer()
        val key = newKey()
        val grant = paired(server, key)
        val client = connect(server)
        val keys = SessionHandshake().open(client, grantFor(key, grant))
        val session = SecureLinkSession(client, keys, backgroundScope, onEvent = {}, nowMs = { testScheduler.currentTime })
        session.start()
        session.awaitReady(5_000)
        server.connections.single().sendRawText("{\"ev\":\"nope\"}")
        assertEquals(4400, session.awaitClosed().code)
    }

    @Test
    fun `slot next uses the announced key and promotes it on the PC`() = runTest {
        val server = newServer()
        val vault = SoftwareIdentityVault().also { it.create("avek.identity.1"); it.create("avek.identity.2") }
        val old = DeviceKey(vault, "avek.identity.1")
        val new = DeviceKey(vault, "avek.identity.2")
        val grant = paired(server, old)
        val device = server.devices.getValue(grant.deviceId)
        val newDk = ByteArray(32) { 9 }
        device.nextPub = new.publicKey(); device.nextDk = newDk; device.nextRk = ByteArray(32) { 8 }
        val client = connect(server)
        SessionHandshake().open(client, SessionGrant(grant.deviceId, new, grant.serverPub, newDk, slotNext = true))
        runCurrent()
        assertEquals(listOf<String?>("next"), server.helloSlots)
        assertArrayEquals(new.publicKey(), device.pub)
        assertArrayEquals(newDk, device.dk)
    }

    @Test
    fun `random key source never repeats a public key`() {
        val keys = (0 until 20).map { SecureCrypto.b64(SecureCrypto.generateKeyPair().publicRaw) }
        assertEquals(20, keys.toSet().size)
    }
}
