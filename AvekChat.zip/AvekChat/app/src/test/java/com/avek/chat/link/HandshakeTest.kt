package com.avek.chat.link

import com.avek.chat.core.link.crypto.AvekProtocol
import com.avek.chat.core.link.crypto.Handshake
import com.avek.chat.core.link.crypto.HandshakeException
import com.avek.chat.core.link.crypto.PairedServer
import com.avek.chat.core.link.crypto.PairingDigits
import com.avek.chat.core.link.crypto.SecureCrypto
import com.avek.chat.core.link.rpc.LinkClosedException
import com.avek.chat.core.link.rpc.SecureLinkSession
import com.avek.chat.core.link.store.SoftwareIdentityVault
import com.avek.chat.core.link.transport.RawMessage
import com.avek.chat.core.link.wire.WireJson
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.async
import kotlinx.coroutines.launch
import kotlinx.coroutines.test.TestScope
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class HandshakeTest {

    private fun TestScope.newServer() = FakeHarnessServer(backgroundScope)

    /** Connects a client channel to [server], serving it in the background. */
    private fun TestScope.connect(server: FakeHarnessServer): InMemoryChannel {
        val (client, serverSide) = InMemoryChannel.pair()
        backgroundScope.launch { server.serve(serverSide) }
        return client
    }

    private suspend inline fun <reified E : Throwable> expectFailure(block: () -> Unit): E {
        try {
            block()
        } catch (e: Throwable) {
            if (e is E) return e
            throw e
        }
        fail("expected ${E::class.simpleName}")
        throw AssertionError()
    }

    // ------------------------------------------------------------------ pairing

    @Test
    fun `pairing shows the same six digits as the PC and pins its key`() = runTest {
        val server = newServer()
        val identity = SoftwareIdentityVault()
        var shown: PairingDigits? = null
        var awaiting = false
        val paired = Handshake().pair(connect(server), identity, "Yash Tablet", confirm = { shown = it; true }, onAwaitingApproval = { awaiting = true })

        assertEquals(server.lastSas, shown!!.sas)
        assertEquals(7, shown!!.formatted.length)
        assertEquals("Test PC", shown!!.serverName)
        assertTrue(awaiting)
        assertEquals(server.serverId, paired.serverId)
        assertArrayEquals(server.serverPub, paired.serverPub)
        assertEquals(AvekProtocol.deviceIdOf(identity.publicKey()), paired.deviceId)
        assertArrayEquals(identity.publicKey(), server.devices.getValue(paired.deviceId))
    }

    @Test
    fun `answering No to the digits cancels, closes and stores nothing`() = runTest {
        val server = newServer()
        val client = connect(server)
        expectFailure<HandshakeException.Cancelled> { Handshake().pair(client, SoftwareIdentityVault(), "Tablet", confirm = { false }) }
        assertTrue(client.closedLocally)
        assertTrue(server.devices.isEmpty())
        // No confirmation was ever sent.
        assertFalse(client.sentTexts.any { it.contains("pair.confirm") })
    }

    @Test
    fun `the PC refusing on its side is Denied`() = runTest {
        val server = newServer().apply { approve = false }
        val error = expectFailure<HandshakeException.Denied> { Handshake().pair(connect(server), SoftwareIdentityVault(), "Tablet", confirm = { true }) }
        assertEquals("denied", error.reason)
        assertTrue(server.devices.isEmpty())
    }

    @Test
    fun `the client waits for the approval on the PC`() = runTest {
        val gate = CompletableDeferred<Boolean>()
        val server = newServer().apply { approvalGate = gate }
        var awaiting = false
        val result = async { Handshake().pair(connect(server), SoftwareIdentityVault(), "Tablet", confirm = { true }, onAwaitingApproval = { awaiting = true }) }
        runCurrent()
        assertTrue(awaiting)
        assertFalse(result.isCompleted)
        gate.complete(true)
        assertTrue(result.await().serverId.startsWith("s_"))
    }

    @Test
    fun `a closed pairing window is WindowClosed and busy is Busy`() = runTest {
        val closed = newServer().apply { pairingWindowOpen = false }
        expectFailure<HandshakeException.WindowClosed> { Handshake().pair(connect(closed), SoftwareIdentityVault(), "Tablet", confirm = { true }) }
        val busy = newServer().apply { this.busy = true }
        expectFailure<HandshakeException.Busy> { Handshake().pair(connect(busy), SoftwareIdentityVault(), "Tablet", confirm = { true }) }
    }

    @Test
    fun `a revealed key that does not match the commit is refused by the PC`() = runTest {
        // A client that commits to one key and reveals another (what a man in the middle would need).
        val server = newServer()
        val (client, serverSide) = InMemoryChannel.pair()
        backgroundScope.launch { server.serve(serverSide) }
        val real = SoftwareIdentityVault().also { it.create() }
        val other = SoftwareIdentityVault().also { it.create() }
        val nonce = ByteArray(16) { 3 }
        val commit = AvekProtocol.pairCommit("Tablet", "android", real.publicKey(), nonce)
        client.sendText("""{"t":"pair.hello","v":3,"commit":"${SecureCrypto.b64(commit)}","name":"Tablet","platform":"android"}""")
        client.incoming.receive()
        client.sendText("""{"t":"pair.reveal","devPub":"${SecureCrypto.b64(other.publicKey())}","nonce":"${SecureCrypto.b64(nonce)}"}""")
        val closed = client.incoming.receive() as RawMessage.Closed
        assertEquals(4400, closed.code)
        assertNull(server.lastSas)
    }

    @Test
    fun `a wrong pair-done signature is NotOurPc`() = runTest {
        val server = newServer().apply { corruptDoneSig = true }
        expectFailure<HandshakeException.NotOurPc> { Handshake().pair(connect(server), SoftwareIdentityVault(), "Tablet", confirm = { true }) }
    }

    @Test
    fun `a pair-done with another device id is NotOurPc`() = runTest {
        val server = newServer().apply { corruptDoneDeviceId = true }
        expectFailure<HandshakeException.NotOurPc> { Handshake().pair(connect(server), SoftwareIdentityVault(), "Tablet", confirm = { true }) }
    }

    @Test
    fun `a hello-ok whose serverId does not match its key is NotOurPc`() = runTest {
        val (client, serverSide) = InMemoryChannel.pair()
        val key = SoftwareIdentityVault().also { it.create() }
        backgroundScope.launch {
            serverSide.incoming.receive()
            serverSide.sendText(
                """{"t":"pair.hello.ok","srvPub":"${SecureCrypto.b64(key.publicKey())}","nonce":"${SecureCrypto.b64(ByteArray(16))}","serverId":"s_00000000","serverName":"X"}""",
            )
        }
        expectFailure<HandshakeException.NotOurPc> { Handshake().pair(client, SoftwareIdentityVault(), "Tablet", confirm = { true }) }
    }

    @Test
    fun `a silent server times out after the handshake limit`() = runTest {
        val server = newServer().apply { staySilentInHandshake = true }
        val client = connect(server)
        expectFailure<HandshakeException.Timeout> { Handshake(timeoutMs = 10_000).pair(client, SoftwareIdentityVault(), "Tablet", confirm = { true }) }
        assertEquals(10_000L, testScheduler.currentTime)
    }

    @Test
    fun `the pair hello carries only a commitment, not the key`() = runTest {
        val server = newServer()
        val client = connect(server)
        val identity = SoftwareIdentityVault()
        Handshake().pair(client, identity, "Tablet", confirm = { true })
        val hello = WireJson.parseToJsonElement(client.sentTexts.first()).jsonObject
        assertEquals("pair.hello", hello.getValue("t").jsonPrimitive.content)
        assertFalse(client.sentTexts.first().contains(SecureCrypto.b64(identity.publicKey())))
        assertEquals(3, hello.getValue("v").jsonPrimitive.content.toInt())
    }

    // ------------------------------------------------------------------ session

    private suspend fun TestScope.paired(server: FakeHarnessServer): Pair<SoftwareIdentityVault, PairedServer> {
        val identity = SoftwareIdentityVault()
        return identity to Handshake().pair(connect(server), identity, "Tablet", confirm = { true })
    }

    @Test
    fun `session handshake yields working directional keys`() = runTest {
        val server = newServer()
        val (identity, pc) = paired(server)

        val client = connect(server)
        val keys = Handshake().session(client, identity, pc.serverPub)
        val session = SecureLinkSession(client, keys, backgroundScope, onEvent = {}, nowMs = { testScheduler.currentTime })
        session.start()
        val ready = session.awaitReady(5_000)

        assertEquals("e_1", ready.epoch)
        assertEquals("Test PC", session.serverName)
        val answer = session.rpc.call("ping", kotlinx.serialization.json.JsonObject(emptyMap()))
        assertTrue(answer.toString().contains("now"))
    }

    @Test
    fun `an unknown device is closed with 4401 and maps to Forgotten`() = runTest {
        val server = newServer()
        val (_, pc) = paired(server)
        expectFailure<HandshakeException.Forgotten> { Handshake().session(connect(server), SoftwareIdentityVault().also { it.create() }, pc.serverPub) }
    }

    @Test
    fun `a different PC key is NotOurPc and gets no proof`() = runTest {
        val server = newServer()
        val (identity, pc) = paired(server)
        server.impostor = SoftwareIdentityVault().also { it.create() }
        expectFailure<HandshakeException.NotOurPc> { Handshake().session(connect(server), identity, pc.serverPub) }
        assertFalse("client must not send hello.proof to a server it does not trust", server.sawSessionProof)
    }

    @Test
    fun `a bad session signature or MAC is NotOurPc`() = runTest {
        val server = newServer()
        val (identity, pc) = paired(server)
        server.corruptSessionSig = true
        expectFailure<HandshakeException.NotOurPc> { Handshake().session(connect(server), identity, pc.serverPub) }
        server.corruptSessionSig = false
        server.corruptSessionMac = true
        expectFailure<HandshakeException.NotOurPc> { Handshake().session(connect(server), identity, pc.serverPub) }
        assertFalse(server.sawSessionProof)
    }

    @Test
    fun `a device rejected after its proof is closed with 4401 and ready fails`() = runTest {
        val server = newServer()
        val (identity, pc) = paired(server)
        server.rejectProof = true

        val client = connect(server)
        val keys = Handshake().session(client, identity, pc.serverPub)
        val session = SecureLinkSession(client, keys, backgroundScope, onEvent = {}, nowMs = { testScheduler.currentTime })
        session.start()

        val error = expectFailure<LinkClosedException> { session.awaitReady(5_000) }
        assertEquals(4401, error.info.code)
        assertTrue(error.info.isAuthFailure)
        assertEquals(4401, session.awaitClosed().code)
    }

    @Test
    fun `a replayed or reordered frame closes the session`() = runTest {
        val server = newServer()
        val (identity, pc) = paired(server)
        val client = connect(server)
        val keys = Handshake().session(client, identity, pc.serverPub)
        val session = SecureLinkSession(client, keys, backgroundScope, onEvent = {}, nowMs = { testScheduler.currentTime })
        session.start()
        session.awaitReady(5_000)
        val connection = server.connections.single()
        connection.sendEvent("x", obj { })
        connection.sendEvent("y", obj { })
        runCurrent()
        // An older frame again: its counter is not strictly greater than the last one opened.
        connection.replayFrame(back = 1)
        assertEquals(4400, session.awaitClosed().code)
    }

    @Test
    fun `binary frames during the clear phase are a protocol error`() = runTest {
        val (client, serverSide) = InMemoryChannel.pair()
        backgroundScope.launch {
            serverSide.incoming.receive() // the hello
            serverSide.sendBinary(byteArrayOf(1, 2, 3))
        }
        val identity = SoftwareIdentityVault().also { it.create() }
        expectFailure<HandshakeException.Protocol> { Handshake().session(client, identity, identity.publicKey()) }
    }

    @Test
    fun `a text frame in the secure phase closes the session with 4400`() = runTest {
        val server = newServer()
        val (identity, pc) = paired(server)
        val client = connect(server)
        val keys = Handshake().session(client, identity, pc.serverPub)
        val session = SecureLinkSession(client, keys, backgroundScope, onEvent = {}, nowMs = { testScheduler.currentTime })
        session.start()
        session.awaitReady(5_000)

        server.connections.single().sendRawText("{\"ev\":\"nope\"}")
        assertEquals(4400, session.awaitClosed().code)
    }

    @Test
    fun `random key source never repeats a public key`() {
        val keys = (0 until 20).map { SecureCrypto.b64(SecureCrypto.generateKeyPair().publicRaw) }
        assertEquals(20, keys.toSet().size)
    }
}
