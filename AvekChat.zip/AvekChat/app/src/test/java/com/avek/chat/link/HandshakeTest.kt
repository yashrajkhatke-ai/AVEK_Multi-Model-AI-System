package com.avek.chat.link

import com.avek.chat.core.link.crypto.Handshake
import com.avek.chat.core.link.crypto.HandshakeException
import com.avek.chat.core.link.crypto.SecureCrypto
import com.avek.chat.core.link.rpc.LinkClosedException
import com.avek.chat.core.link.rpc.SecureLinkSession
import com.avek.chat.core.link.transport.RawChannel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.test.TestScope
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class HandshakeTest {

    private fun TestScope.newServer() = FakeHarnessServer(backgroundScope)

    /** Connects a client channel to [server], serving it in the background. */
    private fun TestScope.connect(server: FakeHarnessServer): InMemoryChannel {
        val (client, serverSide) = InMemoryChannel.pair()
        backgroundScope.launch { server.serve(serverSide) }
        return client
    }

    private suspend inline fun <reified E : Throwable> expectFailure(block: () -> Unit): E {
        try {
            block()
        } catch (e: Throwable) {
            if (e is E) return e
            throw e
        }
        fail("expected ${E::class.simpleName}")
        throw AssertionError()
    }

    // ------------------------------------------------------------------ pairing

    @Test
    fun `pairing with the right code returns the grant`() = runTest {
        val server = newServer()
        val grant = Handshake().pair(connect(server), "abcd-efgh-jklm", "Yash Tablet")

        assertTrue(grant.deviceId.startsWith("d_"))
        assertEquals(32, grant.deviceSecret.size)
        assertEquals("s_test0001", grant.serverId)
        assertEquals("Test PC", grant.serverName)
        assertArrayEquals(server.devices.getValue(grant.deviceId), grant.deviceSecret)
    }

    @Test
    fun `pairing with a wrong code is denied as bad-code`() = runTest {
        val server = newServer()
        val error = expectFailure<HandshakeException.Denied> { Handshake().pair(connect(server), "ZZZZ-ZZZZ-ZZZZ", "Tablet") }
        assertEquals("bad-code", error.reason)
        assertTrue(server.devices.isEmpty())
    }

    @Test
    fun `pairing when the PC has no code is denied as no-code`() = runTest {
        val server = newServer().apply { pairingCode = null }
        val error = expectFailure<HandshakeException.Denied> { Handshake().pair(connect(server), "ABCD-EFGH-JKLM", "Tablet") }
        assertEquals("no-code", error.reason)
    }

    @Test
    fun `a wrong server MAC during pairing is rejected before the grant is decrypted`() = runTest {
        val server = newServer().apply {
            corruptServerMac = true
            corruptGrant = true // would fail decryption: proves the MAC is verified first
        }
        expectFailure<HandshakeException.UntrustedServer> { Handshake().pair(connect(server), "ABCD-EFGH-JKLM", "Tablet") }
    }

    @Test
    fun `a grant that fails authentication is a protocol error`() = runTest {
        val server = newServer().apply { corruptGrant = true }
        expectFailure<HandshakeException.Protocol> { Handshake().pair(connect(server), "ABCD-EFGH-JKLM", "Tablet") }
    }

    @Test
    fun `a silent server times out after the handshake limit`() = runTest {
        val server = newServer().apply { staySilentInHandshake = true }
        val client = connect(server)
        expectFailure<HandshakeException.Timeout> { Handshake(timeoutMs = 10_000).pair(client, "ABCD-EFGH-JKLM", "Tablet") }
        assertEquals(10_000L, testScheduler.currentTime)
    }

    // ------------------------------------------------------------------ session

    private suspend fun TestScope.paired(server: FakeHarnessServer): Pair<String, ByteArray> {
        val grant = Handshake().pair(connect(server), "ABCDEFGHJKLM", "Tablet")
        return grant.deviceId to grant.deviceSecret
    }

    @Test
    fun `session handshake yields working directional keys`() = runTest {
        val server = newServer()
        val (deviceId, secret) = paired(server)

        val client = connect(server)
        val keys = Handshake().session(client, deviceId, secret)
        val session = SecureLinkSession(client, keys, backgroundScope, onEvent = {}, nowMs = { testScheduler.currentTime })
        session.start()
        val ready = session.awaitReady(5_000)

        assertEquals("e_1", ready.epoch)
        assertEquals("Test PC", session.serverName)
        val answer = session.rpc.call("ping", kotlinx.serialization.json.JsonObject(emptyMap()))
        assertTrue(answer.toString().contains("now"))
    }

    @Test
    fun `an unknown device is denied`() = runTest {
        val server = newServer()
        val error = expectFailure<HandshakeException.Denied> {
            Handshake().session(connect(server), "d_nobody", ByteArray(32) { 1 })
        }
        assertEquals("unknown-device", error.reason)
    }

    @Test
    fun `a server that cannot prove the secret is rejected and gets no proof`() = runTest {
        val server = newServer()
        val (deviceId, secret) = paired(server)
        server.corruptServerMac = true

        expectFailure<HandshakeException.UntrustedServer> { Handshake().session(connect(server), deviceId, secret) }
        assertFalse("client must not send hello.proof to a server it does not trust", server.sawSessionProof)
    }

    @Test
    fun `a wrong secret is detected by the server MAC check on the client`() = runTest {
        val server = newServer()
        val (deviceId, _) = paired(server)
        expectFailure<HandshakeException.UntrustedServer> { Handshake().session(connect(server), deviceId, ByteArray(32) { 7 }) }
    }

    @Test
    fun `a device rejected after its proof is closed with 4401 and ready fails`() = runTest {
        val server = newServer()
        val (deviceId, secret) = paired(server)
        server.rejectProof = true

        val client = connect(server)
        val keys = Handshake().session(client, deviceId, secret)
        val session = SecureLinkSession(client, keys, backgroundScope, onEvent = {}, nowMs = { testScheduler.currentTime })
        session.start()

        val error = expectFailure<LinkClosedException> { session.awaitReady(5_000) }
        assertEquals(4401, error.info.code)
        assertTrue(error.info.isAuthFailure)
        assertEquals(4401, session.awaitClosed().code)
    }

    @Test
    fun `binary frames during the clear phase are a protocol error`() = runTest {
        val (client, serverSide) = InMemoryChannel.pair()
        backgroundScope.launch {
            serverSide.incoming.receive() // the hello
            serverSide.sendBinary(byteArrayOf(1, 2, 3))
        }
        expectFailure<HandshakeException.Protocol> { Handshake().session(client, "d_x", ByteArray(32)) }
    }

    @Test
    fun `a text frame in the secure phase closes the session with 4400`() = runTest {
        val server = newServer()
        val (deviceId, secret) = paired(server)
        val client = connect(server)
        val keys = Handshake().session(client, deviceId, secret)
        val session = SecureLinkSession(client, keys, backgroundScope, onEvent = {}, nowMs = { testScheduler.currentTime })
        session.start()
        session.awaitReady(5_000)

        server.connections.single().sendRawText("{\"ev\":\"nope\"}")
        assertEquals(4400, session.awaitClosed().code)
    }

    @Test
    fun `random key source never repeats a public key`() {
        val keys = (0 until 20).map { SecureCrypto.b64(SecureCrypto.generateKeyPair().publicRaw) }
        assertEquals(20, keys.toSet().size)
    }
}
