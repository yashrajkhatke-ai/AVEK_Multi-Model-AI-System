package com.avek.chat.domain

import com.avek.chat.core.domain.trace.CallKey
import com.avek.chat.core.domain.trace.TokenKind
import com.avek.chat.core.domain.trace.TraceReducer
import com.avek.chat.core.domain.trace.TraceRepository
import com.avek.chat.core.domain.trace.TurnKey
import com.avek.chat.core.domain.trace.TurnTelemetry
import com.avek.chat.core.link.HarnessApi
import com.avek.chat.core.link.wire.EventDecoder
import com.avek.chat.core.link.wire.LinkEvent
import com.avek.chat.core.link.wire.TraceGenDto
import com.avek.chat.core.link.wire.TraceLogDto
import com.avek.chat.core.link.wire.TracePhaseDto
import com.avek.chat.core.link.wire.TraceSnapshotDto
import com.avek.chat.core.link.wire.WireEvent
import com.avek.chat.core.link.wire.WireJson
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.longOrNull
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Replays the recorded harness output of `trace-fixture.json` (real numbers, phases and logs). */
@OptIn(ExperimentalCoroutinesApi::class)
class TraceReducerTest {

    private val fixture: JsonObject by lazy {
        val stream = checkNotNull(javaClass.classLoader.getResourceAsStream("trace-fixture-v1.json"))
        Json.parseToJsonElement(stream.bufferedReader().readText()).jsonObject
    }
    private val key by lazy { TurnKey(fixture.getValue("chatId").jsonPrimitive.content, fixture.getValue("promptId").jsonPrimitive.content) }

    private val events: List<LinkEvent> by lazy {
        fixture.getValue("events").jsonArray.map { it.jsonObject }
            .filter { it.getValue("ev").jsonPrimitive.content != "_mark" }
            .mapNotNull { e ->
                EventDecoder.decode(WireEvent(e.getValue("ev").jsonPrimitive.content, e["seq"]?.jsonPrimitive?.longOrNull, e.getValue("data").jsonObject))
            }
    }

    private val snapshot: TraceSnapshotDto by lazy {
        Json { ignoreUnknownKeys = true }.decodeFromJsonElement(TraceSnapshotDto.serializer(), fixture.getValue("snapshot"))
    }

    private fun replay(list: List<LinkEvent>, start: TurnTelemetry = TraceReducer.empty(key)): TurnTelemetry =
        list.fold(start) { acc, e -> TraceReducer.reduce(acc, e, 1_000L) }

    @Test
    fun `every recorded event decodes`() {
        val raw = fixture.getValue("events").jsonArray.count { it.jsonObject.getValue("ev").jsonPrimitive.content != "_mark" }
        assertEquals(raw, events.size)
    }

    @Test
    fun `replaying the events gives the same phases, steps, tools and context as the snapshot`() {
        val live = replay(events)
        val fromSnapshot = TraceReducer.reduce(TraceReducer.empty(key), snapshot, 1_000L)

        assertEquals(fromSnapshot.phases, live.phases)
        assertEquals(fromSnapshot.steps, live.steps)
        assertEquals(fromSnapshot.context, live.context)
        assertEquals(fromSnapshot.tools.keys, live.tools.keys)
        fromSnapshot.tools.forEach { (k, tool) ->
            val replayed = live.tools.getValue(k)
            assertEquals(tool.state, replayed.state)
            assertEquals(tool.callId, replayed.callId)
            assertEquals(tool.name, replayed.name)
            assertEquals(tool.ms, replayed.ms)
            assertEquals(tool.resultChars, replayed.resultChars)
            assertEquals(tool.resultTokens, replayed.resultTokens)
        }
        assertEquals(fromSnapshot.logs, live.logs)
        assertEquals(snapshot.modelName, live.modelName)
        assertFalse("turn.completed ends the live turn", live.live)
        assertFalse(fromSnapshot.live)
    }

    @Test
    fun `the numbers are the recorded ones`() {
        val t = replay(events)
        assertEquals(2, t.stepCount)
        assertEquals(1, t.toolCount)
        assertEquals(15, t.reasoningTokens)
        assertEquals(20, t.answerTokens)
        assertEquals(5, t.toolCallTokens)
        assertTrue(t.tokensExact)
        assertEquals(3188, t.promptTokens)
        assertEquals(40, t.completionTokens)
        assertEquals(10L, t.ttftMs)
        assertEquals(18, t.tools.getValue(CallKey(1, 0)).argTokens) // from `writing`, kept after `done`
        assertEquals(2215, t.context!!.promptTokens)
        assertFalse(t.context!!.exact)
        assertEquals(2, t.contexts.size)
        assertEquals("Checking plug-ins", t.phases.first().label)
        assertEquals("Saving the chat", t.phases.first { it.phase == "saving" }.label)
        assertNull(t.currentPhase)
        assertTrue(t.phases.none { it.open })
        assertEquals(719L, t.phases.first { it.phase == "thinking" }.ms)
        assertEquals("Beta 3B", t.modelName)
        assertNotNull(t.runtime)
        assertTrue(t.tokens.any { it.kind == TokenKind.REASONING })
        assertTrue(t.tokens.any { it.kind == TokenKind.ANSWER })
        assertTrue(t.toolArgs.getValue(CallKey(1, 0)).text.startsWith("{"))
        assertEquals("write_file", t.toolArgs.getValue(CallKey(1, 0)).name)
    }

    @Test
    fun `duplicates and reversed order give the same result`() {
        val once = replay(events)
        val twice = replay(events + events)
        val reversed = replay(events.filterNot { it is LinkEvent.TurnCompleted }.reversed() + events.filterIsInstance<LinkEvent.TurnCompleted>())
        listOf(twice, reversed).forEach { other ->
            assertEquals(once.phases, other.phases)
            assertEquals(once.steps, other.steps)
            assertEquals(once.tools, other.tools)
            assertEquals(once.context, other.context)
            assertEquals(once.logs, other.logs)
            assertEquals(once.phaseHistory, other.phaseHistory)
            assertEquals(once.tpsSamples, other.tpsSamples)
            assertEquals(once.runtime, other.runtime)
        }
        // Deltas replayed by a resume add no text and no token cells.
        assertEquals(once.tokenCount, twice.tokenCount)
        assertEquals(once.thinkingLength, twice.thinkingLength)
        assertEquals(once.toolArgs, twice.toolArgs)
    }

    @Test
    fun `a snapshot replaces what it covers and live events continue on top`() {
        val half = replay(events.take(events.size / 2))
        val withSnapshot = TraceReducer.reduce(half, snapshot, 2_000L)
        val after = replay(events.drop(events.size / 2), withSnapshot)
        assertEquals(replay(events).phases, after.phases)
        assertEquals(replay(events).steps, after.steps)
        assertTrue(after.fromSnapshot)
        assertEquals(snapshot.startedAt, after.startedAt)
    }

    @Test
    fun `ring buffers keep their limits`() {
        var t = TraceReducer.empty(key)
        repeat(450) { i ->
            t = TraceReducer.reduce(t, LinkEvent.TraceLog(null, TraceLogDto(key.chatId, key.promptId, i.toLong(), "info", "s", "line $i")), 0)
            t = TraceReducer.reduce(t, LinkEvent.TracePhase(null, TracePhaseDto(key.chatId, key.promptId, i.toLong(), "p:$i", "thinking", "start", "Thinking")), 0)
        }
        repeat(700) { i ->
            t = TraceReducer.reduce(t, LinkEvent.TraceGen(null, TraceGenDto(key.chatId, key.promptId, 1_000L + i * 50, 1, state = "reasoning", tps = i.toDouble())), 0)
        }
        assertEquals(TurnTelemetry.MAX_LOGS, t.logs.size)
        assertEquals("line 449", t.logs.last().text)
        assertEquals(TurnTelemetry.MAX_PHASE_HISTORY, t.phaseHistory.size)
        assertEquals(TurnTelemetry.MAX_TPS_SAMPLES, t.tpsSamples.size)
        assertTrue(t.tpsSamples.last().t - t.tpsSamples.first().t <= TurnTelemetry.TPS_WINDOW_MS)
        var d = TraceReducer.empty(key)
        repeat(800) { i -> d = TraceReducer.reduce(d, LinkEvent.ThinkingDelta(null, com.avek.chat.core.link.wire.DeltaDto(key.chatId, key.promptId, "x", i)), i.toLong()) }
        assertEquals(TurnTelemetry.MAX_TOKEN_CELLS, d.tokens.size)
        assertEquals(800, d.tokenCount)
        assertEquals(800, d.thinkingLength)
    }

    @Test
    fun `a live turn with no trace event for 3 s is stale`() {
        val started = TraceReducer.reduce(
            TraceReducer.empty(key),
            LinkEvent.TurnStarted(null, com.avek.chat.core.link.wire.TurnStartedDto(key.chatId, key.promptId, "beta")),
            10_000L,
        )
        val t = TraceReducer.reduce(started, LinkEvent.TracePhase(null, TracePhaseDto(key.chatId, key.promptId, 5L, "p:1", "prefill", "start", "Reading")), 10_000L)
        assertFalse(t.isStale(12_999L))
        assertTrue(t.isStale(13_001L))
        assertEquals(3_001L, t.silenceMs(13_001L))
        val done = TraceReducer.reduce(t, LinkEvent.TurnCompleted(null, com.avek.chat.core.link.wire.TurnCompletedDto(key.chatId, key.promptId)), 20_000L)
        assertFalse(done.isStale(60_000L))
    }

    @Test
    fun `nothing is derived without data`() {
        val t = TraceReducer.empty(key)
        assertNull(t.tps)
        assertNull(t.ttftMs)
        assertNull(t.contextFill)
        assertNull(t.promptTokens)
        assertNull(t.currentPhase)
        assertFalse(t.tokensExact)
        assertFalse(t.hasTrace)
    }

    @Test
    fun `the repository follows a turn, wants the trace topic only while viewed and keeps 6 turns`() = runTest {
        val link = FakeLink { op, _ ->
            if (op == "trace.get") WireJson.encodeToJsonElement(TraceSnapshotDto.serializer(), snapshot) else kotlinx.serialization.json.buildJsonObject { }
        }
        val repo = TraceRepository(link, HarnessApi(link), backgroundScope, nowMs = { testScheduler.currentTime })
        repo.start(); runCurrent()

        val release = repo.viewing()
        assertTrue(link.traceIsWanted)
        val second = repo.viewing()
        release()
        assertTrue(link.traceIsWanted)
        second()
        assertFalse(link.traceIsWanted)

        events.forEach { link.emit(it) }
        runCurrent()
        assertEquals(key, repo.latest.value)
        val flow = repo.telemetry(key.chatId, key.promptId)
        assertEquals(2, flow.value.stepCount)
        assertTrue("known turns are not fetched again", link.opsCalled("trace.get").isEmpty())

        repeat(7) { i -> repo.telemetry("c$i", "p000001") }
        runCurrent()
        assertEquals(7, link.opsCalled("trace.get").size)
        // The fixture turn was evicted (6 most recent kept): asking again fetches it.
        repo.telemetry(key.chatId, key.promptId)
        runCurrent()
        assertEquals(8, link.opsCalled("trace.get").size)
    }
}
