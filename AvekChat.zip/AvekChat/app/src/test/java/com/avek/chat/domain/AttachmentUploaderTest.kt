package com.avek.chat.domain

import com.avek.chat.core.domain.chat.AttachmentSource
import com.avek.chat.core.domain.chat.AttachmentUploader
import com.avek.chat.core.domain.chat.UploadProgress
import com.avek.chat.core.link.HarnessApi
import com.avek.chat.core.link.crypto.SecureCrypto
import com.avek.chat.core.link.rpc.RpcException
import com.avek.chat.core.link.wire.LimitsDto
import kotlinx.coroutines.flow.toList
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.take
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.runBlocking
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.io.ByteArrayInputStream
import java.security.MessageDigest
import java.util.Base64

class AttachmentUploaderTest {

    private class Bytes(override val name: String, val data: ByteArray, override val mime: String = "image/png") : AttachmentSource {
        override val size get() = data.size.toLong()
        override fun open() = ByteArrayInputStream(data)
    }

    private fun link(chunkBytes: Int, onEnd: () -> Unit = {}): FakeLink = FakeLink { op, args ->
        when (op) {
            "attach.begin" -> buildJsonObject { put("uploadId", "u1"); put("chunkBytes", chunkBytes) }
            "attach.chunk" -> buildJsonObject { }
            "attach.end" -> { onEnd(); buildJsonObject { put("attachmentId", "att1"); put("name", "x.png"); put("size", 0) } }
            "attach.abort" -> buildJsonObject { }
            else -> error(op)
        }
    }

    @Test
    fun `chunks are indexed from zero, reassemble to the file and the end carries its sha256`() = runBlocking {
        val data = ByteArray(1000) { (it * 7).toByte() }
        val link = link(chunkBytes = 300)
        val uploader = AttachmentUploader(HarnessApi(link)) { LimitsDto() }
        val progress = uploader.upload(Bytes("x.png", data)).toList()

        val chunks = link.opsCalled("attach.chunk")
        assertEquals(listOf("0", "1", "2", "3"), chunks.map { it["index"]!!.jsonPrimitive.content })
        val joined = chunks.map { Base64.getDecoder().decode(it["data"]!!.jsonPrimitive.content) }.reduce { a, b -> a + b }
        assertArrayEquals(data, joined)
        assertEquals(listOf(300, 300, 300, 100), chunks.map { Base64.getDecoder().decode(it["data"]!!.jsonPrimitive.content).size })

        val end = link.opsCalled("attach.end").single()
        assertEquals(SecureCrypto.hex(MessageDigest.getInstance("SHA-256").digest(data)), end["sha256"]!!.jsonPrimitive.content)
        assertEquals("u1", end["uploadId"]!!.jsonPrimitive.content)

        val sending = progress.filterIsInstance<UploadProgress.Sending>()
        assertEquals(0L, sending.first().sent)
        assertEquals(1000L, sending.last().sent)
        assertEquals(1f, sending.last().fraction, 0f)
        assertTrue(progress.last() is UploadProgress.Done)
        assertEquals("att1", (progress.last() as UploadProgress.Done).attachmentId)
        assertTrue(link.opsCalled("attach.abort").isEmpty())
    }

    @Test
    fun `a chunk size larger than the advertised limit is capped`() = runBlocking {
        val link = link(chunkBytes = 5_000_000)
        AttachmentUploader(HarnessApi(link)) { LimitsDto(attachChunkBytes = 400) }.upload(Bytes("a", ByteArray(1000))).toList()
        assertEquals(3, link.opsCalled("attach.chunk").size)
    }

    @Test
    fun `an empty file is a begin plus an end`() = runBlocking {
        val link = link(chunkBytes = 300)
        AttachmentUploader(HarnessApi(link)) { LimitsDto() }.upload(Bytes("empty", ByteArray(0))).toList()
        assertTrue(link.opsCalled("attach.chunk").isEmpty())
        assertEquals(1, link.opsCalled("attach.end").size)
    }

    @Test
    fun `a file over the limit is refused before anything is sent`() = runBlocking {
        val link = link(chunkBytes = 300)
        try {
            AttachmentUploader(HarnessApi(link)) { LimitsDto(maxAttachmentBytes = 10) }.upload(Bytes("big", ByteArray(11))).toList()
            fail()
        } catch (e: RpcException) {
            assertEquals("too-large", e.code)
        }
        assertTrue(link.calls.isEmpty())
    }

    @Test
    fun `cancelling in the middle aborts the upload`() = runBlocking {
        // Each chunk takes a moment, so the upload is still running when the collector stops.
        val link = FakeLink { op, _ ->
            when (op) {
                "attach.begin" -> buildJsonObject { put("uploadId", "u1"); put("chunkBytes", 100) }
                "attach.chunk" -> { kotlinx.coroutines.delay(40); buildJsonObject { } }
                "attach.end" -> buildJsonObject { put("attachmentId", "att1"); put("name", "x"); put("size", 0) }
                "attach.abort" -> buildJsonObject { }
                else -> error(op)
            }
        }
        val uploader = AttachmentUploader(HarnessApi(link)) { LimitsDto() }
        uploader.upload(Bytes("x", ByteArray(1000))).take(3).toList() // stop after the first chunks
        // The upstream runs on another dispatcher; its clean-up (attach.abort) finishes a moment later.
        kotlinx.coroutines.withTimeout(5_000) { while (link.opsCalled("attach.abort").isEmpty()) kotlinx.coroutines.delay(10) }
        assertEquals(listOf("u1"), link.opsCalled("attach.abort").map { it["uploadId"]!!.jsonPrimitive.content })
        assertTrue(link.opsCalled("attach.end").isEmpty())
    }

    @Test
    fun `a failing chunk aborts the upload and rethrows`() = runBlocking {
        var n = 0
        val link = FakeLink { op, _ ->
            when (op) {
                "attach.begin" -> buildJsonObject { put("uploadId", "u1"); put("chunkBytes", 100) }
                "attach.chunk" -> if (++n == 2) throw RpcException.notConnected() else buildJsonObject { }
                "attach.abort" -> buildJsonObject { }
                else -> error(op)
            }
        }
        try {
            AttachmentUploader(HarnessApi(link)) { LimitsDto() }.upload(Bytes("x", ByteArray(1000))).toList()
            fail()
        } catch (e: RpcException) {
            assertEquals(RpcException.NOT_CONNECTED, e.code)
        }
        assertEquals(1, link.opsCalled("attach.abort").size)
    }
}
