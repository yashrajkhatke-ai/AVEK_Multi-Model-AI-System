# kotlinx.serialization — keep generated serializers for persisted settings.
-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.AnnotationsKt
-keepclassmembers class kotlinx.serialization.json.** { *** Companion; }
-keepclasseswithmembers class kotlinx.serialization.json.** { kotlinx.serialization.KSerializer serializer(...); }
-keep,includedescriptorclasses class com.avek.chat.**$$serializer { *; }
-keepclassmembers class com.avek.chat.** { *** Companion; }
-keepclasseswithmembers class com.avek.chat.** { kotlinx.serialization.KSerializer serializer(...); }

# OkHttp / Okio (WebSocket link to the PC)
-dontwarn okhttp3.internal.platform.**
-dontwarn org.conscrypt.**
-dontwarn org.bouncycastle.**
-dontwarn org.openjsse.**
